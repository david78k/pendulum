Instruction:

run ..\q_demo\q_demo.exe