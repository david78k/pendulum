/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "images_private_iptprefs.h"
#include "libmatlbm.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'a', 'g', 'e',
                                's', '/', 'p', 'r', 'i', 'v', 'a', 't', 'e',
                                '/', 'i', 'p', 't', 'p', 'r', 'e', 'f', 's',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'm', 'a',
                                'g', 'e', 's', '/', 'p', 'r', 'i', 'v', 'a',
                                't', 'e', '/', 'i', 'p', 't', 'p', 'r', 'e',
                                'f', 's', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'a', 'g', 'e',
                                's', '/', 'p', 'r', 'i', 'v', 'a', 't', 'e',
                                '/', 'i', 'p', 't', 'p', 'r', 'e', 'f', 's',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'm', 'a',
                                'g', 'e', 's', '/', 'p', 'r', 'i', 'v', 'a',
                                't', 'e', '/', 'i', 'p', 't', 'p', 'r', 'e',
                                'f', 's', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '0', ')',
                                '.' };
static mxArray * _mxarray2_;

static mxChar _array7_[12] = { 'I', 'm', 's', 'h', 'o', 'w',
                               'B', 'o', 'r', 'd', 'e', 'r' };
static mxArray * _mxarray6_;

static mxChar _array9_[17] = { 'I', 'm', 's', 'h', 'o', 'w', 'A', 'x', 'e',
                               's', 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray8_;

static mxChar _array11_[14] = { 'I', 'm', 's', 'h', 'o', 'w', 'T',
                                'r', 'u', 'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray10_;

static mxChar _array13_[15] = { 'T', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                'W', 'a', 'r', 'n', 'i', 'n', 'g' };
static mxArray * _mxarray12_;

static mxChar _array17_[5] = { 't', 'i', 'g', 'h', 't' };
static mxArray * _mxarray16_;

static mxChar _array19_[5] = { 'l', 'o', 'o', 's', 'e' };
static mxArray * _mxarray18_;

static mxArray * _array15_[2] = { NULL /*_mxarray16_*/, NULL /*_mxarray18_*/ };
static mxArray * _mxarray14_;

static mxChar _array23_[2] = { 'o', 'n' };
static mxArray * _mxarray22_;

static mxChar _array25_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray24_;

static mxArray * _array21_[2] = { NULL /*_mxarray22_*/, NULL /*_mxarray24_*/ };
static mxArray * _mxarray20_;

static mxChar _array29_[4] = { 'a', 'u', 't', 'o' };
static mxArray * _mxarray28_;

static mxChar _array31_[6] = { 'm', 'a', 'n', 'u', 'a', 'l' };
static mxArray * _mxarray30_;

static mxArray * _array27_[2] = { NULL /*_mxarray28_*/, NULL /*_mxarray30_*/ };
static mxArray * _mxarray26_;
static mxArray * _mxarray32_;
static mxArray * _mxarray33_;
static mxArray * _mxarray34_;
static mxArray * _mxarray35_;

static mxArray * _array5_[12] = { NULL /*_mxarray6_*/, NULL /*_mxarray8_*/,
                                  NULL /*_mxarray10_*/, NULL /*_mxarray12_*/,
                                  NULL /*_mxarray14_*/, NULL /*_mxarray20_*/,
                                  NULL /*_mxarray26_*/, NULL /*_mxarray20_*/,
                                  NULL /*_mxarray32_*/, NULL /*_mxarray33_*/,
                                  NULL /*_mxarray34_*/, NULL /*_mxarray35_*/ };
static mxArray * _mxarray4_;

void InitializeModule_images_private_iptprefs(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray6_ = mclInitializeString(12, _array7_);
    _array5_[0] = _mxarray6_;
    _mxarray8_ = mclInitializeString(17, _array9_);
    _array5_[1] = _mxarray8_;
    _mxarray10_ = mclInitializeString(14, _array11_);
    _array5_[2] = _mxarray10_;
    _mxarray12_ = mclInitializeString(15, _array13_);
    _array5_[3] = _mxarray12_;
    _mxarray16_ = mclInitializeString(5, _array17_);
    _array15_[0] = _mxarray16_;
    _mxarray18_ = mclInitializeString(5, _array19_);
    _array15_[1] = _mxarray18_;
    _mxarray14_ = mclInitializeCellVector(2, 1, _array15_);
    _array5_[4] = _mxarray14_;
    _mxarray22_ = mclInitializeString(2, _array23_);
    _array21_[0] = _mxarray22_;
    _mxarray24_ = mclInitializeString(3, _array25_);
    _array21_[1] = _mxarray24_;
    _mxarray20_ = mclInitializeCellVector(2, 1, _array21_);
    _array5_[5] = _mxarray20_;
    _mxarray28_ = mclInitializeString(4, _array29_);
    _array27_[0] = _mxarray28_;
    _mxarray30_ = mclInitializeString(6, _array31_);
    _array27_[1] = _mxarray30_;
    _mxarray26_ = mclInitializeCellVector(2, 1, _array27_);
    _array5_[6] = _mxarray26_;
    _array5_[7] = _mxarray20_;
    _mxarray32_ = mclInitializeCell(_mxarray18_);
    _array5_[8] = _mxarray32_;
    _mxarray33_ = mclInitializeCell(_mxarray24_);
    _array5_[9] = _mxarray33_;
    _mxarray34_ = mclInitializeCell(_mxarray28_);
    _array5_[10] = _mxarray34_;
    _mxarray35_ = mclInitializeCell(_mxarray22_);
    _array5_[11] = _mxarray35_;
    _mxarray4_ = mclInitializeCellVector(4, 3, _array5_);
}

void TerminateModule_images_private_iptprefs(void) {
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimages_private_iptprefs(int nargout_);

_mexLocalFunctionTable _local_function_table_images_private_iptprefs
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_iptprefs" contains the normal interface for
 * the "images/private/iptprefs" M-function from file
 * "C:\matlabR12\toolbox\images\images\private\iptprefs.m" (lines 1-30). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfImages_private_iptprefs(void) {
    int nargout = 1;
    mxArray * preferences = mclGetUninitializedArray();
    mlfEnterNewContext(0, 0);
    preferences = Mimages_private_iptprefs(nargout);
    mlfRestorePreviousContext(0, 0);
    return mlfReturnValue(preferences);
}

/*
 * The function "mlxImages_private_iptprefs" contains the feval interface for
 * the "images/private/iptprefs" M-function from file
 * "C:\matlabR12\toolbox\images\images\private\iptprefs.m" (lines 1-30). The
 * feval function calls the implementation version of images/private/iptprefs
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImages_private_iptprefs(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 0) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mplhs[0] = Mimages_private_iptprefs(nlhs);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_iptprefs" is the implementation version of the
 * "images/private/iptprefs" M-function from file
 * "C:\matlabR12\toolbox\images\images\private\iptprefs.m" (lines 1-30). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function preferences = iptprefs
 */
static mxArray * Mimages_private_iptprefs(int nargout_) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_images_private_iptprefs);
    mxArray * preferences = mclGetUninitializedArray();
    /*
     * %IPTPREFS Image Processing Toolbox preference settings.
     * %   IPTPREFS returns a 3-column cell array containing the Image
     * %   Processing Toolbox preference settings.  Each row contains
     * %   information about a single preference.  
     * %   
     * %   The first column of each row contains a string indicating the
     * %   name of the preference.  The second column of each row is a
     * %   cell array containing the set of acceptable values for that
     * %   preference setting.  An empty cell array indicates that the
     * %   preference does not have a fixed set of values.  
     * %
     * %   The third column of each row contains a single-element cell
     * %   array containing the default value for the preference.  An
     * %   empy cell array indicates that the preference does not have a
     * %   default value.
     * %
     * %   See also IPTSETPREF, IPTGETPREF.
     * 
     * %   Copyright 1993-2000 The MathWorks, Inc.
     * %   $Revision: 1.11 $  $Date: 2000/01/21 20:18:41 $
     * 
     * preferences = { ...
     */
    mlfAssign(&preferences, _mxarray4_);
    mclValidateOutput(
      preferences, 1, nargout_, "preferences", "images/private/iptprefs");
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return preferences;
    /*
     * 'ImshowBorder',        {'tight'; 'loose'},        {'loose'}
     * 'ImshowAxesVisible',   {'on'; 'off'},             {'off'}
     * 'ImshowTruesize',      {'auto'; 'manual'},        {'auto'}
     * 'TruesizeWarning',     {'on'; 'off'},             {'on'}
     * };
     * 
     */
}
