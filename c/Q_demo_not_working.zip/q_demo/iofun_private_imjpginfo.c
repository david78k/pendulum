/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imjpginfo.h"
#include "iofun_private_imjpg_mex_interface.h"
#include "libmatlbm.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'j', 'p', 'g', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'j', 'p', 'g', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'j', 'p', 'g', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'j', 'p', 'g', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray6_;

static mxChar _array9_[1] = { 'r' };
static mxArray * _mxarray8_;

static mxChar _array11_[7] = { 'i', 'e', 'e', 'e', '-', 'b', 'e' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;
static mxArray * _mxarray13_;

static mxChar _array15_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray14_;

static double _array17_[2] = { 255.0, 216.0 };
static mxArray * _mxarray16_;

static mxChar _array19_[15] = { 'N', 'o', 't', ' ', 'a', ' ', 'J', 'P',
                                'E', 'G', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray18_;
static mxArray * _mxarray20_;

static mxChar _array22_[9] = { 'g', 'r', 'a', 'y', 's', 'c', 'a', 'l', 'e' };
static mxArray * _mxarray21_;

static mxChar _array24_[9] = { 't', 'r', 'u', 'e', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray23_;

void InitializeModule_iofun_private_imjpginfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(7, _array11_);
    _mxarray12_ = mclInitializeDouble(-1.0);
    _mxarray13_ = mclInitializeDouble(2.0);
    _mxarray14_ = mclInitializeString(5, _array15_);
    _mxarray16_ = mclInitializeDoubleVector(2, 1, _array17_);
    _mxarray18_ = mclInitializeString(15, _array19_);
    _mxarray20_ = mclInitializeDouble(8.0);
    _mxarray21_ = mclInitializeString(9, _array22_);
    _mxarray23_ = mclInitializeString(9, _array24_);
}

void TerminateModule_iofun_private_imjpginfo(void) {
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_imjpginfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_imjpginfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_imjpginfo" contains the normal interface for
 * the "iofun/private/imjpginfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imjpginfo.m" (lines 1-59). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imjpginfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_imjpginfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_imjpginfo" contains the feval interface for
 * the "iofun/private/imjpginfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imjpginfo.m" (lines 1-59). The
 * feval function calls the implementation version of iofun/private/imjpginfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imjpginfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imjpginfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_imjpginfo" is the implementation version of the
 * "iofun/private/imjpginfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imjpginfo.m" (lines 1-59). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imjpginfo(filename)
 */
static mxArray * Miofun_private_imjpginfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imjpginfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * d = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMJPGINFO Information about a JPEG file.
     * %   [INFO,MSG] = IMJPGINFO(FILENAME) returns a structure containing
     * %   information about the JPEG file specified by the string
     * %   FILENAME.  
     * %
     * %   If any error condition is encountered, such as an error opening
     * %   the file, MSG will contain a string describing the error and
     * %   INFO will be empty.  Otherwise, MSG will be empty.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, August 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.9 $  $Date: 2000/06/01 04:17:06 $
     * 
     * % This function should not call error()!  -SLE
     * 
     * info = [];
     */
    mlfAssign(&info, _mxarray4_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray5_);
    /*
     * 
     * if (~isstr(filename))
     */
    if (mclNotBool(mclVe(mlfIsstr(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray6_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * % JPEG files are big-endian.  Open the file and look at the first
     * % 2 bytes.  If they are not [255 216], then we don't have a JFIF
     * % or raw JPEG file and we can bail out without calling the
     * % MEX-file.
     * 
     * [fid,m] = fopen(filename, 'r', 'ieee-be');
     */
    mlfAssign(
      &fid,
      mlfFopen(&m, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray10_));
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray12_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = m;
         */
        mlfAssign(msg, mclVsv(m, "m"));
    /*
     * return;
     * else
     */
    } else {
        /*
         * filename = fopen(fid);
         */
        mlfAssign(
          &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
        /*
         * d = dir(filename);
         */
        mlfAssign(&d, mlfNDir(1, mclVa(filename, "filename")));
        /*
         * sig = fread(fid, 2, 'uint8');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray13_, _mxarray14_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * if (~isequal(sig, [255; 216]))
         */
        if (mclNotBool(
              mclVe(mlfIsequal(mclVv(sig, "sig"), _mxarray16_, NULL)))) {
            /*
             * info = [];
             */
            mlfAssign(&info, _mxarray4_);
            /*
             * msg = 'Not a JPEG file';
             */
            mlfAssign(msg, _mxarray18_);
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
        /*
         * [info,msg] = imjpg(filename);
         */
        mlfNIofun_private_imjpg(
          0, mlfVarargout(&info, msg, NULL), mclVa(filename, "filename"), NULL);
        /*
         * if (~isempty(info))
         */
        if (mclNotBool(mclVe(mlfIsempty(mclVv(info, "info"))))) {
            /*
             * info.FileModDate = d.date;
             */
            mlfIndexAssign(
              &info, ".FileModDate", mlfIndexRef(mclVsv(d, "d"), ".date"));
            /*
             * info.FileSize = d.bytes;
             */
            mlfIndexAssign(
              &info, ".FileSize", mlfIndexRef(mclVsv(d, "d"), ".bytes"));
            /*
             * if (info.BitDepth == 8)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxEq,
                    mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitDepth")),
                    _mxarray20_,
                    NULL))) {
                /*
                 * info.ColorType = 'grayscale';
                 */
                mlfIndexAssign(&info, ".ColorType", _mxarray21_);
            /*
             * else
             */
            } else {
                /*
                 * info.ColorType = 'truecolor';
                 */
                mlfIndexAssign(&info, ".ColorType", _mxarray23_);
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     */
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/imjpginfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/imjpginfo");
    mxDestroyArray(fid);
    mxDestroyArray(m);
    mxDestroyArray(d);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
