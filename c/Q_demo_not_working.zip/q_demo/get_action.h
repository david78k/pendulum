/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:43 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __get_action_h
#define __get_action_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_get_action(void);
extern void TerminateModule_get_action(void);
extern _mexLocalFunctionTable _local_function_table_get_action;

extern mxArray * mlfGet_action(mxArray * * pre_state,
                               mxArray * * pre_action,
                               mxArray * * cur_state,
                               mxArray * * cur_action,
                               mxArray * x,
                               mxArray * v_x,
                               mxArray * theta,
                               mxArray * v_theta,
                               mxArray * reinf,
                               mxArray * q_val_in,
                               mxArray * pre_state_in,
                               mxArray * cur_state_in,
                               mxArray * pre_action_in,
                               mxArray * cur_action_in,
                               mxArray * ALPHA,
                               mxArray * BETA,
                               mxArray * GAMMA);
extern void mlxGet_action(int nlhs,
                          mxArray * plhs[],
                          int nrhs,
                          mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
