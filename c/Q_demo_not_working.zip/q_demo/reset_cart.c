/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "reset_cart.h"
#include "libmatlbm.h"

static mxChar _array1_[138] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'r', 'e', 's', 'e', 't',
                                '_', 'c', 'a', 'r', 't', ' ', 'L', 'i', 'n',
                                'e', ':', ' ', '1', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'r', 'e', 's', 'e', 't', '_', 'c',
                                'a', 'r', 't', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'o', 'u', 't', 'p', 'u', 't', 's', ' ', '(',
                                '8', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[137] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'r', 'e', 's', 'e', 't',
                                '_', 'c', 'a', 'r', 't', ' ', 'L', 'i', 'n',
                                'e', ':', ' ', '1', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'r', 'e', 's', 'e', 't', '_', 'c',
                                'a', 'r', 't', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'i', 'n', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

void InitializeModule_reset_cart(void) {
    _mxarray0_ = mclInitializeString(138, _array1_);
    _mxarray2_ = mclInitializeString(137, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeDouble(-1.0);
}

void TerminateModule_reset_cart(void) {
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mreset_cart(mxArray * * cur_state,
                             mxArray * * pre_action,
                             mxArray * * cur_action,
                             mxArray * * x,
                             mxArray * * v_x,
                             mxArray * * theta,
                             mxArray * * v_theta,
                             int nargout_,
                             mxArray * BETA);

_mexLocalFunctionTable _local_function_table_reset_cart
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfReset_cart" contains the normal interface for the
 * "reset_cart" M-function from file "C:\temp\q\reset_cart.m" (lines 1-10).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfReset_cart(mxArray * * cur_state,
                        mxArray * * pre_action,
                        mxArray * * cur_action,
                        mxArray * * x,
                        mxArray * * v_x,
                        mxArray * * theta,
                        mxArray * * v_theta,
                        mxArray * BETA) {
    int nargout = 1;
    mxArray * pre_state = mclGetUninitializedArray();
    mxArray * cur_state__ = mclGetUninitializedArray();
    mxArray * pre_action__ = mclGetUninitializedArray();
    mxArray * cur_action__ = mclGetUninitializedArray();
    mxArray * x__ = mclGetUninitializedArray();
    mxArray * v_x__ = mclGetUninitializedArray();
    mxArray * theta__ = mclGetUninitializedArray();
    mxArray * v_theta__ = mclGetUninitializedArray();
    mlfEnterNewContext(
      7, 1, cur_state, pre_action, cur_action, x, v_x, theta, v_theta, BETA);
    if (cur_state != NULL) {
        ++nargout;
    }
    if (pre_action != NULL) {
        ++nargout;
    }
    if (cur_action != NULL) {
        ++nargout;
    }
    if (x != NULL) {
        ++nargout;
    }
    if (v_x != NULL) {
        ++nargout;
    }
    if (theta != NULL) {
        ++nargout;
    }
    if (v_theta != NULL) {
        ++nargout;
    }
    pre_state
      = Mreset_cart(
          &cur_state__,
          &pre_action__,
          &cur_action__,
          &x__,
          &v_x__,
          &theta__,
          &v_theta__,
          nargout,
          BETA);
    mlfRestorePreviousContext(
      7, 1, cur_state, pre_action, cur_action, x, v_x, theta, v_theta, BETA);
    if (cur_state != NULL) {
        mclCopyOutputArg(cur_state, cur_state__);
    } else {
        mxDestroyArray(cur_state__);
    }
    if (pre_action != NULL) {
        mclCopyOutputArg(pre_action, pre_action__);
    } else {
        mxDestroyArray(pre_action__);
    }
    if (cur_action != NULL) {
        mclCopyOutputArg(cur_action, cur_action__);
    } else {
        mxDestroyArray(cur_action__);
    }
    if (x != NULL) {
        mclCopyOutputArg(x, x__);
    } else {
        mxDestroyArray(x__);
    }
    if (v_x != NULL) {
        mclCopyOutputArg(v_x, v_x__);
    } else {
        mxDestroyArray(v_x__);
    }
    if (theta != NULL) {
        mclCopyOutputArg(theta, theta__);
    } else {
        mxDestroyArray(theta__);
    }
    if (v_theta != NULL) {
        mclCopyOutputArg(v_theta, v_theta__);
    } else {
        mxDestroyArray(v_theta__);
    }
    return mlfReturnValue(pre_state);
}

/*
 * The function "mlxReset_cart" contains the feval interface for the
 * "reset_cart" M-function from file "C:\temp\q\reset_cart.m" (lines 1-10). The
 * feval function calls the implementation version of reset_cart through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxReset_cart(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[8];
    int i;
    if (nlhs > 8) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 8; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0]
      = Mreset_cart(
          &mplhs[1],
          &mplhs[2],
          &mplhs[3],
          &mplhs[4],
          &mplhs[5],
          &mplhs[6],
          &mplhs[7],
          nlhs,
          mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 8 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 8; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Mreset_cart" is the implementation version of the "reset_cart"
 * M-function from file "C:\temp\q\reset_cart.m" (lines 1-10). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function [pre_state,cur_state,pre_action,cur_action,x,v_x,theta,v_theta] = reset_cart(BETA)  % reset the cart pole to initial state
 */
static mxArray * Mreset_cart(mxArray * * cur_state,
                             mxArray * * pre_action,
                             mxArray * * cur_action,
                             mxArray * * x,
                             mxArray * * v_x,
                             mxArray * * theta,
                             mxArray * * v_theta,
                             int nargout_,
                             mxArray * BETA) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_reset_cart);
    mxArray * pre_state = mclGetUninitializedArray();
    mclCopyArray(&BETA);
    /*
     * pre_state=1;
     */
    mlfAssign(&pre_state, _mxarray4_);
    /*
     * cur_state=1;
     */
    mlfAssign(cur_state, _mxarray4_);
    /*
     * pre_action=-1;  % -1 means no action been taken
     */
    mlfAssign(pre_action, _mxarray5_);
    /*
     * cur_action=-1;
     */
    mlfAssign(cur_action, _mxarray5_);
    /*
     * x=rand*BETA;     % the location of cart
     */
    mlfAssign(x, mclMtimes(mclVe(mlfNRand(1, NULL)), mclVa(BETA, "BETA")));
    /*
     * v_x=rand*BETA;   % the velocity of cart
     */
    mlfAssign(v_x, mclMtimes(mclVe(mlfNRand(1, NULL)), mclVa(BETA, "BETA")));
    /*
     * theta=rand*BETA;   %the angle of pole
     */
    mlfAssign(theta, mclMtimes(mclVe(mlfNRand(1, NULL)), mclVa(BETA, "BETA")));
    /*
     * v_theta=rand*BETA;    %the velocity of pole angle
     */
    mlfAssign(
      v_theta, mclMtimes(mclVe(mlfNRand(1, NULL)), mclVa(BETA, "BETA")));
    mclValidateOutput(pre_state, 1, nargout_, "pre_state", "reset_cart");
    mclValidateOutput(*cur_state, 2, nargout_, "cur_state", "reset_cart");
    mclValidateOutput(*pre_action, 3, nargout_, "pre_action", "reset_cart");
    mclValidateOutput(*cur_action, 4, nargout_, "cur_action", "reset_cart");
    mclValidateOutput(*x, 5, nargout_, "x", "reset_cart");
    mclValidateOutput(*v_x, 6, nargout_, "v_x", "reset_cart");
    mclValidateOutput(*theta, 7, nargout_, "theta", "reset_cart");
    mclValidateOutput(*v_theta, 8, nargout_, "v_theta", "reset_cart");
    mxDestroyArray(BETA);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return pre_state;
}
