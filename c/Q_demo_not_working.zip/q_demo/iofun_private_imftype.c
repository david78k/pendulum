/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imftype.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'f', 't', 'y', 'p', 'e', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'f', 't', 'y', 'p', 'e', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'f', 't', 'y', 'p', 'e', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'f', 't', 'y', 'p', 'e', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't',
                                's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray2_;

static mxChar _array5_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                'p', 'e', '/', 'i', 's', 'b', 'm', 'p', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', '6', '9',
                                ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'b',
                                'm', 'p', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray4_;

static mxChar _array7_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                'p', 'e', '/', 'i', 's', 'b', 'm', 'p', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', '6', '9',
                                ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'b',
                                'm', 'p', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray6_;

static mxChar _array9_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                'p', 'e', '/', 'i', 's', 'x', 'w', 'd', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', '8', '2',
                                ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'x',
                                'w', 'd', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray8_;

static mxChar _array11_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'x', 'w', 'd', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '1', '8', '2',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'x',
                                 'w', 'd', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray10_;

static mxChar _array13_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'p', 'n', 'g', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '1', '2',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'p',
                                 'n', 'g', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray12_;

static mxChar _array15_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'p', 'n', 'g', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '1', '2',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'p',
                                 'n', 'g', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray14_;

static mxChar _array17_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'p', 'c', 'x', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '2', '5',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'p',
                                 'c', 'x', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray16_;

static mxChar _array19_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'p', 'c', 'x', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '2', '5',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'p',
                                 'c', 'x', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray18_;

static mxChar _array21_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'j', 'p', 'g', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '4', '2',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'j',
                                 'p', 'g', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray20_;

static mxChar _array23_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'j', 'p', 'g', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '4', '2',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'j',
                                 'p', 'g', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray22_;

static mxChar _array25_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 't', 'i', 'f', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '5', '5',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 't',
                                 'i', 'f', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray24_;

static mxChar _array27_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 't', 'i', 'f', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '5', '5',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 't',
                                 'i', 'f', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray26_;

static mxChar _array29_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'h', 'd', 'f', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '6', '8',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'h',
                                 'd', 'f', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray28_;

static mxChar _array31_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'h', 'd', 'f', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '6', '8',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'h',
                                 'd', 'f', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray30_;

static mxChar _array33_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'g', 'i', 'f', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '8', '1',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'g',
                                 'i', 'f', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray32_;

static mxChar _array35_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'g', 'i', 'f', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '8', '1',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'g',
                                 'i', 'f', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray34_;

static mxChar _array37_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'c', 'u', 'r', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '9', '4',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'c',
                                 'u', 'r', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray36_;

static mxChar _array39_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'c', 'u', 'r', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '9', '4',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'c',
                                 'u', 'r', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray38_;

static mxChar _array41_[146] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'i', 'c', 'o', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '3', '0', '7',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'i',
                                 'c', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray40_;

static mxChar _array43_[145] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'i', 's', 'i', 'c', 'o', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '3', '0', '7',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'f', 't', 'y', 'p', 'e', '/', 'i', 's', 'i',
                                 'c', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray42_;

static mxChar _array45_[152] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'b', 'y', 't', 'e', 's', 'w',
                                 'a', 'p', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '3', '2', '0', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 'i', 'm', 'f', 't', 'y', 'p', 'e', '/',
                                 'b', 'y', 't', 'e', 's', 'w', 'a', 'p', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                 'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray44_;

static mxChar _array47_[151] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'f', 't', 'y',
                                 'p', 'e', '/', 'b', 'y', 't', 'e', 's', 'w',
                                 'a', 'p', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '3', '2', '0', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 'i', 'm', 'f', 't', 'y', 'p', 'e', '/',
                                 'b', 'y', 't', 'e', 's', 'w', 'a', 'p', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u',
                                 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray46_;
static mxArray * _mxarray48_;

static mxChar _array50_[1] = { '.' };
static mxArray * _mxarray49_;
static mxArray * _mxarray51_;
static mxArray * _mxarray52_;

static mxChar _array54_[3] = { 'b', 'm', 'p' };
static mxArray * _mxarray53_;

static mxChar _array56_[3] = { 'x', 'w', 'd' };
static mxArray * _mxarray55_;

static mxChar _array58_[3] = { 'p', 'c', 'x' };
static mxArray * _mxarray57_;

static mxChar _array62_[4] = { 'j', 'p', 'e', 'g' };
static mxArray * _mxarray61_;

static mxChar _array64_[3] = { 'j', 'p', 'g' };
static mxArray * _mxarray63_;

static mxArray * _array60_[2] = { NULL /*_mxarray61_*/, NULL /*_mxarray63_*/ };
static mxArray * _mxarray59_;

static mxChar _array68_[4] = { 't', 'i', 'f', 'f' };
static mxArray * _mxarray67_;

static mxChar _array70_[3] = { 't', 'i', 'f' };
static mxArray * _mxarray69_;

static mxArray * _array66_[2] = { NULL /*_mxarray67_*/, NULL /*_mxarray69_*/ };
static mxArray * _mxarray65_;

static mxChar _array72_[3] = { 'h', 'd', 'f' };
static mxArray * _mxarray71_;

static mxChar _array74_[3] = { 'p', 'n', 'g' };
static mxArray * _mxarray73_;

static mxChar _array76_[3] = { 'g', 'i', 'f' };
static mxArray * _mxarray75_;

static mxChar _array78_[3] = { 'c', 'u', 'r' };
static mxArray * _mxarray77_;

static mxChar _array80_[3] = { 'i', 'c', 'o' };
static mxArray * _mxarray79_;

static mxChar _array82_[1] = { 'r' };
static mxArray * _mxarray81_;

static mxChar _array84_[7] = { 'i', 'e', 'e', 'e', '-', 'l', 'e' };
static mxArray * _mxarray83_;
static mxArray * _mxarray85_;

static mxChar _array87_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray86_;

static mxChar _array89_[2] = { 'B', 'M' };
static mxArray * _mxarray88_;

static mxChar _array91_[7] = { 'i', 'e', 'e', 'e', '-', 'b', 'e' };
static mxArray * _mxarray90_;
static mxArray * _mxarray92_;

static mxChar _array94_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray93_;
static mxArray * _mxarray95_;
static mxArray * _mxarray96_;

static double _array98_[3] = { 0.0, 1.0, 2.0 };
static mxArray * _mxarray97_;
static mxArray * _mxarray99_;

static double _array101_[8] = { 137.0, 80.0, 78.0, 71.0,
                                13.0, 10.0, 26.0, 10.0 };
static mxArray * _mxarray100_;
static mxArray * _mxarray102_;
static mxArray * _mxarray103_;

static double _array105_[5] = { 0.0, 2.0, 3.0, 4.0, 5.0 };
static mxArray * _mxarray104_;

static double _array107_[2] = { 255.0, 216.0 };
static mxArray * _mxarray106_;
static mxArray * _mxarray108_;

static double _array110_[4] = { 73.0, 73.0, 42.0, 0.0 };
static mxArray * _mxarray109_;

static double _array112_[4] = { 77.0, 77.0, 0.0, 42.0 };
static mxArray * _mxarray111_;

static double _array114_[4] = { 14.0, 3.0, 19.0, 1.0 };
static mxArray * _mxarray113_;

static double _array116_[3] = { 71.0, 73.0, 70.0 };
static mxArray * _mxarray115_;

static mxChar _array118_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray117_;

static double _array120_[2] = { 0.0, 2.0 };
static mxArray * _mxarray119_;

static double _array122_[2] = { 0.0, 1.0 };
static mxArray * _mxarray121_;
static mxArray * _mxarray123_;
static mxArray * _mxarray124_;
static mxArray * _mxarray125_;

void InitializeModule_iofun_private_imftype(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
    _mxarray4_ = mclInitializeString(146, _array5_);
    _mxarray6_ = mclInitializeString(145, _array7_);
    _mxarray8_ = mclInitializeString(146, _array9_);
    _mxarray10_ = mclInitializeString(145, _array11_);
    _mxarray12_ = mclInitializeString(146, _array13_);
    _mxarray14_ = mclInitializeString(145, _array15_);
    _mxarray16_ = mclInitializeString(146, _array17_);
    _mxarray18_ = mclInitializeString(145, _array19_);
    _mxarray20_ = mclInitializeString(146, _array21_);
    _mxarray22_ = mclInitializeString(145, _array23_);
    _mxarray24_ = mclInitializeString(146, _array25_);
    _mxarray26_ = mclInitializeString(145, _array27_);
    _mxarray28_ = mclInitializeString(146, _array29_);
    _mxarray30_ = mclInitializeString(145, _array31_);
    _mxarray32_ = mclInitializeString(146, _array33_);
    _mxarray34_ = mclInitializeString(145, _array35_);
    _mxarray36_ = mclInitializeString(146, _array37_);
    _mxarray38_ = mclInitializeString(145, _array39_);
    _mxarray40_ = mclInitializeString(146, _array41_);
    _mxarray42_ = mclInitializeString(145, _array43_);
    _mxarray44_ = mclInitializeString(152, _array45_);
    _mxarray46_ = mclInitializeString(151, _array47_);
    _mxarray48_ = mclInitializeDouble(1.0);
    _mxarray49_ = mclInitializeString(1, _array50_);
    _mxarray51_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray52_ = mclInitializeDouble(0.0);
    _mxarray53_ = mclInitializeString(3, _array54_);
    _mxarray55_ = mclInitializeString(3, _array56_);
    _mxarray57_ = mclInitializeString(3, _array58_);
    _mxarray61_ = mclInitializeString(4, _array62_);
    _array60_[0] = _mxarray61_;
    _mxarray63_ = mclInitializeString(3, _array64_);
    _array60_[1] = _mxarray63_;
    _mxarray59_ = mclInitializeCellVector(1, 2, _array60_);
    _mxarray67_ = mclInitializeString(4, _array68_);
    _array66_[0] = _mxarray67_;
    _mxarray69_ = mclInitializeString(3, _array70_);
    _array66_[1] = _mxarray69_;
    _mxarray65_ = mclInitializeCellVector(1, 2, _array66_);
    _mxarray71_ = mclInitializeString(3, _array72_);
    _mxarray73_ = mclInitializeString(3, _array74_);
    _mxarray75_ = mclInitializeString(3, _array76_);
    _mxarray77_ = mclInitializeString(3, _array78_);
    _mxarray79_ = mclInitializeString(3, _array80_);
    _mxarray81_ = mclInitializeString(1, _array82_);
    _mxarray83_ = mclInitializeString(7, _array84_);
    _mxarray85_ = mclInitializeDouble(2.0);
    _mxarray86_ = mclInitializeString(5, _array87_);
    _mxarray88_ = mclInitializeString(2, _array89_);
    _mxarray90_ = mclInitializeString(7, _array91_);
    _mxarray92_ = mclInitializeDouble(3.0);
    _mxarray93_ = mclInitializeString(6, _array94_);
    _mxarray95_ = mclInitializeDouble(7.0);
    _mxarray96_ = mclInitializeDouble(100.0);
    _mxarray97_ = mclInitializeDoubleVector(1, 3, _array98_);
    _mxarray99_ = mclInitializeDouble(8.0);
    _mxarray100_ = mclInitializeDoubleVector(1, 8, _array101_);
    _mxarray102_ = mclInitializeDouble(128.0);
    _mxarray103_ = mclInitializeDouble(10.0);
    _mxarray104_ = mclInitializeDoubleVector(1, 5, _array105_);
    _mxarray106_ = mclInitializeDoubleVector(2, 1, _array107_);
    _mxarray108_ = mclInitializeDouble(4.0);
    _mxarray109_ = mclInitializeDoubleVector(4, 1, _array110_);
    _mxarray111_ = mclInitializeDoubleVector(4, 1, _array112_);
    _mxarray113_ = mclInitializeDoubleVector(4, 1, _array114_);
    _mxarray115_ = mclInitializeDoubleVector(3, 1, _array116_);
    _mxarray117_ = mclInitializeString(6, _array118_);
    _mxarray119_ = mclInitializeDoubleVector(2, 1, _array120_);
    _mxarray121_ = mclInitializeDoubleVector(2, 1, _array122_);
    _mxarray123_ = mclInitializeDouble(255.0);
    _mxarray124_ = mclInitializeDouble(65280.0);
    _mxarray125_ = mclInitializeDouble(-8.0);
}

void TerminateModule_iofun_private_imftype(void) {
    mxDestroyArray(_mxarray125_);
    mxDestroyArray(_mxarray124_);
    mxDestroyArray(_mxarray123_);
    mxDestroyArray(_mxarray121_);
    mxDestroyArray(_mxarray119_);
    mxDestroyArray(_mxarray117_);
    mxDestroyArray(_mxarray115_);
    mxDestroyArray(_mxarray113_);
    mxDestroyArray(_mxarray111_);
    mxDestroyArray(_mxarray109_);
    mxDestroyArray(_mxarray108_);
    mxDestroyArray(_mxarray106_);
    mxDestroyArray(_mxarray104_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray102_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray96_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray90_);
    mxDestroyArray(_mxarray88_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray85_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImftype_isbmp(mxArray * filename);
static void mlxImftype_isbmp(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_isxwd(mxArray * filename);
static void mlxImftype_isxwd(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_ispng(mxArray * filename);
static void mlxImftype_ispng(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_ispcx(mxArray * filename);
static void mlxImftype_ispcx(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_isjpg(mxArray * filename);
static void mlxImftype_isjpg(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_istif(mxArray * filename);
static void mlxImftype_istif(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_ishdf(mxArray * filename);
static void mlxImftype_ishdf(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_isgif(mxArray * filename);
static void mlxImftype_isgif(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_iscur(mxArray * filename);
static void mlxImftype_iscur(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_isico(mxArray * filename);
static void mlxImftype_isico(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfImftype_byteswap(mxArray * in);
static void mlxImftype_byteswap(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static mxArray * Miofun_private_imftype(int nargout_, mxArray * filename);
static mxArray * Mimftype_isbmp(int nargout_, mxArray * filename);
static mxArray * Mimftype_isxwd(int nargout_, mxArray * filename);
static mxArray * Mimftype_ispng(int nargout_, mxArray * filename);
static mxArray * Mimftype_ispcx(int nargout_, mxArray * filename);
static mxArray * Mimftype_isjpg(int nargout_, mxArray * filename);
static mxArray * Mimftype_istif(int nargout_, mxArray * filename);
static mxArray * Mimftype_ishdf(int nargout_, mxArray * filename);
static mxArray * Mimftype_isgif(int nargout_, mxArray * filename);
static mxArray * Mimftype_iscur(int nargout_, mxArray * filename);
static mxArray * Mimftype_isico(int nargout_, mxArray * filename);
static mxArray * Mimftype_byteswap(int nargout_, mxArray * in);

static mexFunctionTableEntry local_function_table_[11]
  = { { "isbmp", mlxImftype_isbmp, 1, 1, NULL },
      { "isxwd", mlxImftype_isxwd, 1, 1, NULL },
      { "ispng", mlxImftype_ispng, 1, 1, NULL },
      { "ispcx", mlxImftype_ispcx, 1, 1, NULL },
      { "isjpg", mlxImftype_isjpg, 1, 1, NULL },
      { "istif", mlxImftype_istif, 1, 1, NULL },
      { "ishdf", mlxImftype_ishdf, 1, 1, NULL },
      { "isgif", mlxImftype_isgif, 1, 1, NULL },
      { "iscur", mlxImftype_iscur, 1, 1, NULL },
      { "isico", mlxImftype_isico, 1, 1, NULL },
      { "byteswap", mlxImftype_byteswap, 1, 1, NULL } };

_mexLocalFunctionTable _local_function_table_iofun_private_imftype
  = { 11, local_function_table_ };

/*
 * The function "mlfIofun_private_imftype" contains the normal interface for
 * the "iofun/private/imftype" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 1-169). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imftype(mxArray * filename) {
    int nargout = 1;
    mxArray * format = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    format = Miofun_private_imftype(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(format);
}

/*
 * The function "mlxIofun_private_imftype" contains the feval interface for the
 * "iofun/private/imftype" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 1-169). The
 * feval function calls the implementation version of iofun/private/imftype
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imftype(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imftype(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_isbmp" contains the normal interface for the
 * "imftype/isbmp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 169-182). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_isbmp(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_isbmp(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_isbmp" contains the feval interface for the
 * "imftype/isbmp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 169-182). The
 * feval function calls the implementation version of imftype/isbmp through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_isbmp(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray4_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray6_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_isbmp(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_isxwd" contains the normal interface for the
 * "imftype/isxwd" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 182-212). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_isxwd(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_isxwd(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_isxwd" contains the feval interface for the
 * "imftype/isxwd" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 182-212). The
 * feval function calls the implementation version of imftype/isxwd through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_isxwd(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray8_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray10_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_isxwd(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_ispng" contains the normal interface for the
 * "imftype/ispng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 212-225). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_ispng(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_ispng(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_ispng" contains the feval interface for the
 * "imftype/ispng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 212-225). The
 * feval function calls the implementation version of imftype/ispng through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_ispng(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray12_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray14_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_ispng(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_ispcx" contains the normal interface for the
 * "imftype/ispcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 225-242). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_ispcx(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_ispcx(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_ispcx" contains the feval interface for the
 * "imftype/ispcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 225-242). The
 * feval function calls the implementation version of imftype/ispcx through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_ispcx(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray16_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray18_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_ispcx(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_isjpg" contains the normal interface for the
 * "imftype/isjpg" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 242-255). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_isjpg(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_isjpg(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_isjpg" contains the feval interface for the
 * "imftype/isjpg" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 242-255). The
 * feval function calls the implementation version of imftype/isjpg through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_isjpg(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray20_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray22_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_isjpg(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_istif" contains the normal interface for the
 * "imftype/istif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 255-268). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_istif(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_istif(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_istif" contains the feval interface for the
 * "imftype/istif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 255-268). The
 * feval function calls the implementation version of imftype/istif through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_istif(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray24_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray26_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_istif(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_ishdf" contains the normal interface for the
 * "imftype/ishdf" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 268-281). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_ishdf(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_ishdf(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_ishdf" contains the feval interface for the
 * "imftype/ishdf" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 268-281). The
 * feval function calls the implementation version of imftype/ishdf through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_ishdf(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray28_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray30_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_ishdf(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_isgif" contains the normal interface for the
 * "imftype/isgif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 281-294). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_isgif(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_isgif(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_isgif" contains the feval interface for the
 * "imftype/isgif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 281-294). The
 * feval function calls the implementation version of imftype/isgif through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_isgif(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray32_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray34_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_isgif(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_iscur" contains the normal interface for the
 * "imftype/iscur" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 294-307). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_iscur(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_iscur(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_iscur" contains the feval interface for the
 * "imftype/iscur" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 294-307). The
 * feval function calls the implementation version of imftype/iscur through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_iscur(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray36_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray38_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_iscur(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_isico" contains the normal interface for the
 * "imftype/isico" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 307-320). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_isico(mxArray * filename) {
    int nargout = 1;
    mxArray * tf = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, filename);
    tf = Mimftype_isico(nargout, filename);
    mlfRestorePreviousContext(0, 1, filename);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImftype_isico" contains the feval interface for the
 * "imftype/isico" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 307-320). The
 * feval function calls the implementation version of imftype/isico through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_isico(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray40_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray42_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_isico(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImftype_byteswap" contains the normal interface for the
 * "imftype/byteswap" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 320-329). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImftype_byteswap(mxArray * in) {
    int nargout = 1;
    mxArray * out = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, in);
    out = Mimftype_byteswap(nargout, in);
    mlfRestorePreviousContext(0, 1, in);
    return mlfReturnValue(out);
}

/*
 * The function "mlxImftype_byteswap" contains the feval interface for the
 * "imftype/byteswap" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 320-329). The
 * feval function calls the implementation version of imftype/byteswap through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImftype_byteswap(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray44_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray46_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimftype_byteswap(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Miofun_private_imftype" is the implementation version of the
 * "iofun/private/imftype" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 1-169). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function format = imftype(filename)
 */
static mxArray * Miofun_private_imftype(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    int nargin_ = mclNargin(1, filename, NULL);
    mxArray * format = mclGetUninitializedArray();
    mxArray * formatFound = mclGetUninitializedArray();
    mxArray * extension = mclGetUninitializedArray();
    mxArray * idx = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMFTYPE Determine image file format.
     * %   FORMAT = IMFTYPE(FILENAME) attempts to determine the image
     * %   file format for the file FILENAME.  If IMFTYPE is successful,
     * %   FORMAT will be returned as one of these strings: 
     * %
     * %     'bmp'  'gif'  'hdf'  'jpg'  'pcx'  'tif'  'xwd'  'png'
     * %     'cur'  'ico'
     * %
     * %   FORMAT will be an empty string if IMFTYPE cannot determine
     * %   the file format.
     * %   
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc.
     * %   $Revision: 1.10 $  $Date: 2000/06/01 04:17:14 $
     * 
     * error(nargchk(1, 1, nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray48_, _mxarray48_, mlfScalar(nargin_))));
    /*
     * 
     * % Optimization:  look for a filename extension as a clue for the
     * % first format to try.
     * 
     * idx = find(filename == '.');
     */
    mlfAssign(
      &idx,
      mlfFind(NULL, NULL, mclEq(mclVa(filename, "filename"), _mxarray49_)));
    /*
     * if (~isempty(idx))
     */
    if (mclNotBool(mclVe(mlfIsempty(mclVv(idx, "idx"))))) {
        /*
         * extension = lower(filename(idx(end)+1:end));
         */
        mlfAssign(
          &extension,
          mlfLower(
            mclVe(
              mclArrayRef1(
                mclVsa(filename, "filename"),
                mlfColon(
                  mclPlus(
                    mclVe(
                      mclArrayRef1(
                        mclVsv(idx, "idx"),
                        mlfEnd(mclVv(idx, "idx"), _mxarray48_, _mxarray48_))),
                    _mxarray48_),
                  mlfEnd(mclVa(filename, "filename"), _mxarray48_, _mxarray48_),
                  NULL)))));
    /*
     * else
     */
    } else {
        /*
         * extension = '';
         */
        mlfAssign(&extension, _mxarray51_);
    /*
     * end
     */
    }
    /*
     * 
     * formatFound = 0;
     */
    mlfAssign(&formatFound, _mxarray52_);
    /*
     * 
     * if (~isempty(extension))
     */
    if (mclNotBool(mclVe(mlfIsempty(mclVv(extension, "extension"))))) {
        /*
         * switch extension
         */
        mxArray * v_ = mclInitialize(mclVv(extension, "extension"));
        if (mclSwitchCompare(v_, _mxarray53_)) {
            /*
             * case 'bmp'
             * formatFound = isbmp(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_isbmp(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'bmp';
                 */
                mlfAssign(&format, _mxarray53_);
            /*
             * end
             */
            }
        /*
         * 
         * case 'xwd'
         */
        } else if (mclSwitchCompare(v_, _mxarray55_)) {
            /*
             * formatFound = isxwd(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_isxwd(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'xwd';
                 */
                mlfAssign(&format, _mxarray55_);
            /*
             * end
             */
            }
        /*
         * 
         * case 'pcx'
         */
        } else if (mclSwitchCompare(v_, _mxarray57_)) {
            /*
             * formatFound = ispcx(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_ispcx(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'pcx';
                 */
                mlfAssign(&format, _mxarray57_);
            /*
             * end
             */
            }
        /*
         * 
         * case {'jpeg', 'jpg'}
         */
        } else if (mclSwitchCompare(v_, _mxarray59_)) {
            /*
             * formatFound = isjpg(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_isjpg(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'jpg';
                 */
                mlfAssign(&format, _mxarray63_);
            /*
             * end
             */
            }
        /*
         * 
         * case {'tiff', 'tif'}
         */
        } else if (mclSwitchCompare(v_, _mxarray65_)) {
            /*
             * formatFound = istif(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_istif(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'tif';
                 */
                mlfAssign(&format, _mxarray69_);
            /*
             * end
             */
            }
        /*
         * 
         * case 'hdf'
         */
        } else if (mclSwitchCompare(v_, _mxarray71_)) {
            /*
             * formatFound = ishdf(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_ishdf(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'hdf';
                 */
                mlfAssign(&format, _mxarray71_);
            /*
             * end
             */
            }
        /*
         * 
         * case 'png'
         */
        } else if (mclSwitchCompare(v_, _mxarray73_)) {
            /*
             * formatFound = ispng(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_ispng(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'png';
                 */
                mlfAssign(&format, _mxarray73_);
            /*
             * end
             */
            }
        /*
         * 
         * case 'gif'
         */
        } else if (mclSwitchCompare(v_, _mxarray75_)) {
            /*
             * formatFound = isgif(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_isgif(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'gif';
                 */
                mlfAssign(&format, _mxarray75_);
            /*
             * end
             */
            }
        /*
         * 
         * case 'cur'
         */
        } else if (mclSwitchCompare(v_, _mxarray77_)) {
            /*
             * formatFound = iscur(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_iscur(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'cur';
                 */
                mlfAssign(&format, _mxarray77_);
            /*
             * end
             */
            }
        /*
         * 
         * case 'ico'
         */
        } else if (mclSwitchCompare(v_, _mxarray79_)) {
            /*
             * formatFound = isico(filename);
             */
            mlfAssign(
              &formatFound, mlfImftype_isico(mclVa(filename, "filename")));
            /*
             * if (formatFound)
             */
            if (mlfTobool(mclVv(formatFound, "formatFound"))) {
                /*
                 * format = 'ico';
                 */
                mlfAssign(&format, _mxarray79_);
            /*
             * end
             */
            }
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    /*
     * end
     */
    }
    /*
     * 
     * % If the format hasn't been identified yet, try them all one at a
     * % time.
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = isbmp(filename);
         */
        mlfAssign(&formatFound, mlfImftype_isbmp(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'bmp';
             */
            mlfAssign(&format, _mxarray53_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = ispng(filename);
         */
        mlfAssign(&formatFound, mlfImftype_ispng(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'png';
             */
            mlfAssign(&format, _mxarray73_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = isxwd(filename);
         */
        mlfAssign(&formatFound, mlfImftype_isxwd(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'xwd';
             */
            mlfAssign(&format, _mxarray55_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = ispcx(filename);
         */
        mlfAssign(&formatFound, mlfImftype_ispcx(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'pcx';
             */
            mlfAssign(&format, _mxarray57_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = isjpg(filename);
         */
        mlfAssign(&formatFound, mlfImftype_isjpg(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'jpg';
             */
            mlfAssign(&format, _mxarray63_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = istif(filename);
         */
        mlfAssign(&formatFound, mlfImftype_istif(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'tif';
             */
            mlfAssign(&format, _mxarray69_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = ishdf(filename);
         */
        mlfAssign(&formatFound, mlfImftype_ishdf(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'hdf';
             */
            mlfAssign(&format, _mxarray71_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = iscur(filename);
         */
        mlfAssign(&formatFound, mlfImftype_iscur(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'cur';
             */
            mlfAssign(&format, _mxarray77_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * formatFound = isico(filename);
         */
        mlfAssign(&formatFound, mlfImftype_isico(mclVa(filename, "filename")));
        /*
         * if (formatFound)
         */
        if (mlfTobool(mclVv(formatFound, "formatFound"))) {
            /*
             * format = 'ico';
             */
            mlfAssign(&format, _mxarray79_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~formatFound)
     */
    if (mclNotBool(mclVv(formatFound, "formatFound"))) {
        /*
         * format = '';
         */
        mlfAssign(&format, _mxarray51_);
    /*
     * end
     */
    }
    mclValidateOutput(format, 1, nargout_, "format", "iofun/private/imftype");
    mxDestroyArray(ans);
    mxDestroyArray(idx);
    mxDestroyArray(extension);
    mxDestroyArray(formatFound);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return format;
    /*
     * 
     * 
     */
}

/*
 * The function "Mimftype_isbmp" is the implementation version of the
 * "imftype/isbmp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 169-182). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = isbmp(filename)
 */
static mxArray * Mimftype_isbmp(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISBMP Returns true for a BMP file.
     * %   TF = ISBMP(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 2, 'uint8');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray85_, _mxarray86_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, double('BM')');
         */
        mlfAssign(
          &tf,
          mlfIsequal(
            mclVv(sig, "sig"),
            mlfCtranspose(mclVe(mlfDouble(_mxarray88_))), NULL));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/isbmp");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_isxwd" is the implementation version of the
 * "imftype/isxwd" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 182-212). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = isxwd(filename)
 */
static mxArray * Mimftype_isxwd(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISXWD Returns true for an XWD file.
     * %   TF = ISXWD(FILENAME)
     * 
     * % XWD files can be big or little-endian.  Try it big-endian
     * % first.
     * fid = fopen(filename, 'r', 'ieee-be');  % BMP files are little-endian
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray90_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 3, 'uint32');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray92_, _mxarray93_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * if (length(sig) < 3)
         */
        if (mclLengthInt(mclVv(sig, "sig")) < 3) {
            /*
             * tf = logical(0);
             */
            mlfAssign(&tf, mlfLogical(_mxarray52_));
        /*
         * else
         */
        } else {
            /*
             * if (sig(2) == 7)
             */
            if (mclEqBool(
                  mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 2)), _mxarray95_)) {
                /*
                 * tf = ((sig(1) >= 100) & (ismember(sig(3), [0 1 2])));
                 */
                mlfAssign(
                  &tf,
                  mclAnd(
                    mclGe(
                      mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 1)),
                      _mxarray96_),
                    mclVe(
                      mlfIsmember(
                        mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 3)),
                        _mxarray97_,
                        NULL))));
            /*
             * 
             * elseif (sig(2) == byteswap(7))
             */
            } else if (mclEqBool(
                         mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 2)),
                         mclVe(mlfImftype_byteswap(_mxarray95_)))) {
                /*
                 * % 112 is 7 byte-reversed; maybe it's a little-endian XWD file.
                 * sig(1) = byteswap(sig(1));
                 */
                mclIntArrayAssign1(
                  &sig,
                  mlfImftype_byteswap(
                    mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 1))),
                  1);
                /*
                 * sig(3) = byteswap(sig(3));
                 */
                mclIntArrayAssign1(
                  &sig,
                  mlfImftype_byteswap(
                    mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 3))),
                  3);
                /*
                 * tf = ((sig(1) >= 100) & (ismember(sig(3), [0 1 2])));
                 */
                mlfAssign(
                  &tf,
                  mclAnd(
                    mclGe(
                      mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 1)),
                      _mxarray96_),
                    mclVe(
                      mlfIsmember(
                        mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 3)),
                        _mxarray97_,
                        NULL))));
            /*
             * 
             * else
             */
            } else {
                /*
                 * tf = logical(0);
                 */
                mlfAssign(&tf, mlfLogical(_mxarray52_));
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/isxwd");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_ispng" is the implementation version of the
 * "imftype/ispng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 212-225). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = ispng(filename)
 */
static mxArray * Mimftype_ispng(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISPNG Returns true for a PNG file.
     * %   TF = ISPNG(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-be');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray90_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 8, 'uint8')';
         */
        mlfAssign(
          &sig,
          mlfCtranspose(
            mclVe(
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray99_, _mxarray86_, NULL))));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, [137 80 78 71 13 10 26 10]);
         */
        mlfAssign(&tf, mlfIsequal(mclVv(sig, "sig"), _mxarray100_, NULL));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/ispng");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_ispcx" is the implementation version of the
 * "imftype/ispcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 225-242). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = ispcx(filename)
 */
static mxArray * Mimftype_ispcx(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * header = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISPCX Returns true for a PCX file.
     * %   TF = ISPCX(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * header = fread(fid, 128, 'uint8');
         */
        mlfAssign(
          &header,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray102_, _mxarray86_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * if (length(header) < 128)
         */
        if (mclLengthInt(mclVv(header, "header")) < 128) {
            /*
             * tf = logical(0);
             */
            mlfAssign(&tf, mlfLogical(_mxarray52_));
        /*
         * else
         */
        } else {
            /*
             * tf = (header(1) == 10) & ismember(header(2), [0 2 3 4 5]);
             */
            mlfAssign(
              &tf,
              mclAnd(
                mclEq(
                  mclVe(mclIntArrayRef1(mclVsv(header, "header"), 1)),
                  _mxarray103_),
                mclVe(
                  mlfIsmember(
                    mclVe(mclIntArrayRef1(mclVsv(header, "header"), 2)),
                    _mxarray104_,
                    NULL))));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/ispcx");
    mxDestroyArray(fid);
    mxDestroyArray(header);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_isjpg" is the implementation version of the
 * "imftype/isjpg" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 242-255). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = isjpg(filename)
 */
static mxArray * Mimftype_isjpg(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISJPG Returns true for a JPG file.
     * %   TF = ISJPG(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 2, 'uint8');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray85_, _mxarray86_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, [255; 216]);
         */
        mlfAssign(&tf, mlfIsequal(mclVv(sig, "sig"), _mxarray106_, NULL));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/isjpg");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_istif" is the implementation version of the
 * "imftype/istif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 255-268). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = istif(filename)
 */
static mxArray * Mimftype_istif(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISTIF Returns true for a TIF file.
     * %   TF = ISTIF(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 4, 'uint8');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray108_, _mxarray86_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, [73; 73; 42; 0]) | isequal(sig, [77; 77; 0; 42]);
         */
        mlfAssign(
          &tf,
          mclOr(
            mclVe(mlfIsequal(mclVv(sig, "sig"), _mxarray109_, NULL)),
            mclVe(mlfIsequal(mclVv(sig, "sig"), _mxarray111_, NULL))));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/istif");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_ishdf" is the implementation version of the
 * "imftype/ishdf" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 268-281). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = ishdf(filename)
 */
static mxArray * Mimftype_ishdf(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISHDF Returns true for an HDF file.
     * %   TF = ISHDF(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 4, 'uint8');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray108_, _mxarray86_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, [14; 3; 19; 1]);
         */
        mlfAssign(&tf, mlfIsequal(mclVv(sig, "sig"), _mxarray113_, NULL));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/ishdf");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_isgif" is the implementation version of the
 * "imftype/isgif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 281-294). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = isgif(filename)
 */
static mxArray * Mimftype_isgif(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISGIF Returns true for a GIF file.
     * %   TF = ISGIF(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 3, 'uint8');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray92_, _mxarray86_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, [71; 73; 70]);
         */
        mlfAssign(&tf, mlfIsequal(mclVv(sig, "sig"), _mxarray115_, NULL));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/isgif");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_iscur" is the implementation version of the
 * "imftype/iscur" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 294-307). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = iscur(filename)
 */
static mxArray * Mimftype_iscur(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISCUR Returns true for a CUR file.
     * %   TF = ISCUR(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 2, 'uint16');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray85_, _mxarray117_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, [0; 2]);
         */
        mlfAssign(&tf, mlfIsequal(mclVv(sig, "sig"), _mxarray119_, NULL));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/iscur");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_isico" is the implementation version of the
 * "imftype/isico" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 307-320). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = isico(filename)
 */
static mxArray * Mimftype_isico(int nargout_, mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * tf = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %ISICO Returns true for an ICO file.
     * %   TF = ISICO(FILENAME)
     * 
     * fid = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        NULL, NULL, mclVa(filename, "filename"), _mxarray81_, _mxarray83_));
    /*
     * if (fid < 0)
     */
    if (mclLtBool(mclVv(fid, "fid"), _mxarray52_)) {
        /*
         * tf = logical(0);
         */
        mlfAssign(&tf, mlfLogical(_mxarray52_));
    /*
     * else
     */
    } else {
        /*
         * sig = fread(fid, 2, 'uint16');
         */
        mlfAssign(
          &sig,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray85_, _mxarray117_, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * tf = isequal(sig, [0; 1]);
         */
        mlfAssign(&tf, mlfIsequal(mclVv(sig, "sig"), _mxarray121_, NULL));
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imftype/isico");
    mxDestroyArray(fid);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     */
}

/*
 * The function "Mimftype_byteswap" is the implementation version of the
 * "imftype/byteswap" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imftype.m" (lines 320-329). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function out = byteswap(in)
 */
static mxArray * Mimftype_byteswap(int nargout_, mxArray * in) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imftype);
    mxArray * out = mclGetUninitializedArray();
    mxArray * highByte = mclGetUninitializedArray();
    mxArray * lowByte = mclGetUninitializedArray();
    mclCopyArray(&in);
    /*
     * %BYTESWAP Swap byte order for a number between 0 and 65535.
     * %   OUT = BYTESWAP(IN)
     * 
     * lowByte = bitand(in, 255);
     */
    mlfAssign(&lowByte, mlfBitand(mclVa(in, "in"), _mxarray123_));
    /*
     * highByte = bitshift(bitand(in, 65280), -8);
     */
    mlfAssign(
      &highByte,
      mlfBitshift(
        mclVe(mlfBitand(mclVa(in, "in"), _mxarray124_)), _mxarray125_, NULL));
    /*
     * out = bitor(bitshift(lowByte, 8), highByte);
     */
    mlfAssign(
      &out,
      mlfBitor(
        mclVe(mlfBitshift(mclVv(lowByte, "lowByte"), _mxarray99_, NULL)),
        mclVv(highByte, "highByte")));
    mclValidateOutput(out, 1, nargout_, "out", "imftype/byteswap");
    mxDestroyArray(lowByte);
    mxDestroyArray(highByte);
    mxDestroyArray(in);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return out;
    /*
     * 
     * 
     */
}
