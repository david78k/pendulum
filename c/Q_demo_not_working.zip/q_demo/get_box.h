/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __get_box_h
#define __get_box_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_get_box(void);
extern void TerminateModule_get_box(void);
extern _mexLocalFunctionTable _local_function_table_get_box;

extern mxArray * mlfGet_box(mxArray * x,
                            mxArray * v_x,
                            mxArray * theta,
                            mxArray * v_theta);
extern void mlxGet_box(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
