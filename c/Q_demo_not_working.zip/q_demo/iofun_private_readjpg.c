/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readjpg.h"
#include "iofun_private_rjpgc_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'j', 'p', 'g', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'j', 'p', 'g', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray0_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;

void InitializeModule_iofun_private_readjpg(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeDouble(1.0);
    _mxarray3_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
}

void TerminateModule_iofun_private_readjpg(void) {
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_readjpg(mxArray * * junk,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * varargin);

_mexLocalFunctionTable _local_function_table_iofun_private_readjpg
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_readjpg" contains the normal interface for
 * the "iofun/private/readjpg" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readjpg.m" (lines 1-17). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readjpg(mxArray * * junk, mxArray * filename, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * A = mclGetUninitializedArray();
    mxArray * junk__ = mclGetUninitializedArray();
    mlfVarargin(&varargin, filename, 0);
    mlfEnterNewContext(1, -2, junk, filename, varargin);
    if (junk != NULL) {
        ++nargout;
    }
    A = Miofun_private_readjpg(&junk__, nargout, filename, varargin);
    mlfRestorePreviousContext(1, 1, junk, filename);
    mxDestroyArray(varargin);
    if (junk != NULL) {
        mclCopyOutputArg(junk, junk__);
    } else {
        mxDestroyArray(junk__);
    }
    return mlfReturnValue(A);
}

/*
 * The function "mlxIofun_private_readjpg" contains the feval interface for the
 * "iofun/private/readjpg" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readjpg.m" (lines 1-17). The
 * feval function calls the implementation version of iofun/private/readjpg
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readjpg(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mprhs[1] = NULL;
    mlfAssign(&mprhs[1], mclCreateVararginCell(nrhs - 1, prhs + 1));
    mplhs[0] = Miofun_private_readjpg(&mplhs[1], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[1]);
}

/*
 * The function "Miofun_private_readjpg" is the implementation version of the
 * "iofun/private/readjpg" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readjpg.m" (lines 1-17). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [A,junk] = readjpg(filename, varargin)
 */
static mxArray * Miofun_private_readjpg(mxArray * * junk,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readjpg);
    int nargin_ = mclNargin(-2, filename, varargin, NULL);
    mxArray * A = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&varargin);
    /*
     * %READJPG Read image data from a JPEG file.
     * %   A = READJPG(FILENAME) reads image data from a JPEG file.
     * %   A is a uint8 array that is 2-D for grayscale and 2-D for RGB
     * %   images. 
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.6 $  $Date: 2000/06/01 04:17:04 $
     * 
     * error(nargchk(1, 1, nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray2_, _mxarray2_, mlfScalar(nargin_))));
    /*
     * 
     * A = rjpgc(filename);
     */
    mlfAssign(
      &A,
      mlfNIofun_private_rjpgc(
        0, mclValueVarargout(), mclVa(filename, "filename"), NULL));
    /*
     * junk = [];
     */
    mlfAssign(junk, _mxarray3_);
    mclValidateOutput(A, 1, nargout_, "A", "iofun/private/readjpg");
    mclValidateOutput(*junk, 2, nargout_, "junk", "iofun/private/readjpg");
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return A;
}
