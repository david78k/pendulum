/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "imfinfo.h"
#include "iofun_private_imbmpinfo.h"
#include "iofun_private_imcurinfo.h"
#include "iofun_private_imftype.h"
#include "iofun_private_imgifinfo.h"
#include "iofun_private_imhdfinfo.h"
#include "iofun_private_imicoinfo.h"
#include "iofun_private_imjpginfo.h"
#include "iofun_private_impcxinfo.h"
#include "iofun_private_impnginfo.h"
#include "iofun_private_imtifinfo.h"
#include "iofun_private_imxwdinfo.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[132] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'f', 'i', 'n',
                                'f', 'o', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'i',
                                'm', 'f', 'i', 'n', 'f', 'o', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[131] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'f', 'i', 'n',
                                'f', 'o', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'i',
                                'm', 'f', 'i', 'n', 'f', 'o', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'i', 'n', 'p', 'u', 't', 's',
                                ' ', '(', '2', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;
static mxArray * _mxarray7_;

static mxChar _array9_[1] = { 'r' };
static mxArray * _mxarray8_;
static mxArray * _mxarray10_;

static mxChar _array12_[36] = { 'U', 'n', 'a', 'b', 'l', 'e', ' ', 't', 'o',
                                ' ', 'o', 'p', 'e', 'n', ' ', 'f', 'i', 'l',
                                'e', ' ', '"', '%', 's', '"', ' ', 'f', 'o',
                                'r', ' ', 'r', 'e', 'a', 'd', 'i', 'n', 'g' };
static mxArray * _mxarray11_;

static mxChar _array14_[31] = { 'U', 'n', 'a', 'b', 'l', 'e', ' ', 't',
                                'o', ' ', 'd', 'e', 't', 'e', 'r', 'm',
                                'i', 'n', 'e', ' ', 'f', 'i', 'l', 'e',
                                ' ', 'f', 'o', 'r', 'm', 'a', 't' };
static mxArray * _mxarray13_;

static mxChar _array16_[4] = { 't', 'i', 'f', 'f' };
static mxArray * _mxarray15_;

static mxChar _array18_[3] = { 't', 'i', 'f' };
static mxArray * _mxarray17_;

static mxChar _array20_[4] = { 'j', 'p', 'e', 'g' };
static mxArray * _mxarray19_;

static mxChar _array22_[3] = { 'j', 'p', 'g' };
static mxArray * _mxarray21_;

static mxChar _array24_[3] = { 'h', 'd', 'f' };
static mxArray * _mxarray23_;

static mxChar _array26_[4] = { '.', 'h', 'd', 'f' };
static mxArray * _mxarray25_;

static mxChar _array28_[3] = { 'b', 'm', 'p' };
static mxArray * _mxarray27_;

static mxChar _array30_[4] = { '.', 'b', 'm', 'p' };
static mxArray * _mxarray29_;

static mxChar _array32_[3] = { 'p', 'c', 'x' };
static mxArray * _mxarray31_;

static mxChar _array34_[4] = { '.', 'p', 'c', 'x' };
static mxArray * _mxarray33_;

static mxChar _array36_[3] = { 'x', 'w', 'd' };
static mxArray * _mxarray35_;

static mxChar _array38_[4] = { '.', 'x', 'w', 'd' };
static mxArray * _mxarray37_;

static mxChar _array40_[3] = { 'p', 'n', 'g' };
static mxArray * _mxarray39_;

static mxChar _array42_[4] = { '.', 'p', 'n', 'g' };
static mxArray * _mxarray41_;

static mxChar _array44_[3] = { 'g', 'i', 'f' };
static mxArray * _mxarray43_;

static mxChar _array46_[4] = { '.', 'g', 'i', 'f' };
static mxArray * _mxarray45_;

static mxChar _array48_[4] = { '.', 'j', 'p', 'g' };
static mxArray * _mxarray47_;

static mxChar _array50_[5] = { '.', 'j', 'p', 'e', 'g' };
static mxArray * _mxarray49_;

static mxChar _array52_[4] = { '.', 't', 'i', 'f' };
static mxArray * _mxarray51_;

static mxChar _array54_[5] = { '.', 't', 'i', 'f', 'f' };
static mxArray * _mxarray53_;

static mxChar _array56_[3] = { 'i', 'c', 'o' };
static mxArray * _mxarray55_;

static mxChar _array58_[4] = { '.', 'i', 'c', 'o' };
static mxArray * _mxarray57_;

static mxChar _array60_[3] = { 'c', 'u', 'r' };
static mxArray * _mxarray59_;

static mxChar _array62_[4] = { '.', 'c', 'u', 'r' };
static mxArray * _mxarray61_;

static mxChar _array64_[39] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                'i', 'z', 'e', 'd', ' ', 'o', 'r', ' ',
                                'u', 'n', 's', 'u', 'p', 'p', 'o', 'r',
                                't', 'e', 'd', ' ', 'f', 'o', 'r', 'm',
                                'a', 't', ' ', '"', '%', 's', '"' };
static mxArray * _mxarray63_;

static mxChar _array66_[28] = { 'C', 'a', 'n', 'n', 'o', 't', ' ',
                                'o', 'p', 'e', 'n', ' ', '"', '%',
                                's', '"', ' ', 'f', 'o', 'r', ' ',
                                'r', 'e', 'a', 'd', 'i', 'n', 'g' };
static mxArray * _mxarray65_;

void InitializeModule_imfinfo(void) {
    _mxarray0_ = mclInitializeString(132, _array1_);
    _mxarray2_ = mclInitializeString(131, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeDouble(2.0);
    _mxarray6_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray7_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeDouble(-1.0);
    _mxarray11_ = mclInitializeString(36, _array12_);
    _mxarray13_ = mclInitializeString(31, _array14_);
    _mxarray15_ = mclInitializeString(4, _array16_);
    _mxarray17_ = mclInitializeString(3, _array18_);
    _mxarray19_ = mclInitializeString(4, _array20_);
    _mxarray21_ = mclInitializeString(3, _array22_);
    _mxarray23_ = mclInitializeString(3, _array24_);
    _mxarray25_ = mclInitializeString(4, _array26_);
    _mxarray27_ = mclInitializeString(3, _array28_);
    _mxarray29_ = mclInitializeString(4, _array30_);
    _mxarray31_ = mclInitializeString(3, _array32_);
    _mxarray33_ = mclInitializeString(4, _array34_);
    _mxarray35_ = mclInitializeString(3, _array36_);
    _mxarray37_ = mclInitializeString(4, _array38_);
    _mxarray39_ = mclInitializeString(3, _array40_);
    _mxarray41_ = mclInitializeString(4, _array42_);
    _mxarray43_ = mclInitializeString(3, _array44_);
    _mxarray45_ = mclInitializeString(4, _array46_);
    _mxarray47_ = mclInitializeString(4, _array48_);
    _mxarray49_ = mclInitializeString(5, _array50_);
    _mxarray51_ = mclInitializeString(4, _array52_);
    _mxarray53_ = mclInitializeString(5, _array54_);
    _mxarray55_ = mclInitializeString(3, _array56_);
    _mxarray57_ = mclInitializeString(4, _array58_);
    _mxarray59_ = mclInitializeString(3, _array60_);
    _mxarray61_ = mclInitializeString(4, _array62_);
    _mxarray63_ = mclInitializeString(39, _array64_);
    _mxarray65_ = mclInitializeString(28, _array66_);
}

void TerminateModule_imfinfo(void) {
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimfinfo(mxArray * * msg,
                          int nargout_,
                          mxArray * filename,
                          mxArray * format);

_mexLocalFunctionTable _local_function_table_imfinfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNImfinfo" contains the nargout interface for the "imfinfo"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imfinfo.m" (lines
 * 1-223). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNImfinfo(int nargout,
                      mxArray * * msg,
                      mxArray * filename,
                      mxArray * format) {
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 2, msg, filename, format);
    info = Mimfinfo(&msg__, nargout, filename, format);
    mlfRestorePreviousContext(1, 2, msg, filename, format);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlfImfinfo" contains the normal interface for the "imfinfo"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imfinfo.m" (lines
 * 1-223). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImfinfo(mxArray * * msg, mxArray * filename, mxArray * format) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 2, msg, filename, format);
    if (msg != NULL) {
        ++nargout;
    }
    info = Mimfinfo(&msg__, nargout, filename, format);
    mlfRestorePreviousContext(1, 2, msg, filename, format);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlfVImfinfo" contains the void interface for the "imfinfo"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imfinfo.m" (lines
 * 1-223). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVImfinfo(mxArray * filename, mxArray * format) {
    mxArray * info = NULL;
    mxArray * msg = NULL;
    mlfEnterNewContext(0, 2, filename, format);
    info = Mimfinfo(&msg, 0, filename, format);
    mlfRestorePreviousContext(0, 2, filename, format);
    mxDestroyArray(info);
    mxDestroyArray(msg);
}

/*
 * The function "mlxImfinfo" contains the feval interface for the "imfinfo"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imfinfo.m" (lines
 * 1-223). The feval function calls the implementation version of imfinfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImfinfo(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mimfinfo(&mplhs[1], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Mimfinfo" is the implementation version of the "imfinfo"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imfinfo.m" (lines
 * 1-223). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imfinfo(filename, format)
 */
static mxArray * Mimfinfo(mxArray * * msg,
                          int nargout_,
                          mxArray * filename,
                          mxArray * format) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_imfinfo);
    int nargin_ = mclNargin(2, filename, format, NULL);
    mxArray * info = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&format);
    /*
     * %IMFINFO Information about graphics file.
     * %   INFO = IMFINFO(FILENAME,FMT) returns a structure whose
     * %   fields contain information about an image in a graphics
     * %   file.  FILENAME is a string that specifies the name of the
     * %   graphics file, and FMT is a string that specifies the format
     * %   of the file.  The file must be in the current directory or in
     * %   a directory on the MATLAB path.  If IMFINFO cannot find a
     * %   file named FILENAME, it looks for a file named FILENAME.FMT.
     * %   
     * %   The possible values for FMT include:
     * %   
     * %      'bmp'           Windows Bitmap (BMP)
     * %      'cur'           Windows Cursor resources (CUR)
     * %      'gif'           Graphics Interchange Format (GIF)
     * %      'hdf'           Hierarchical Data Format (HDF)
     * %      'ico'           Windows Icon resources (ICO)
     * %      'jpg' or 'jpeg' Joint Photographric Experts Group
     * %      'pcx'           Windows Paintbrush (PCX)
     * %      'png'           Portable Network Graphics (PNG)
     * %      'tif' or 'tiff' Tagged Image File Format (TIFF)
     * %      'xwd'           X Window Dump (XWD)
     * %
     * %   If FILENAME is a TIFF, HDF, ICO, or CUR file containing more
     * %   than one image, INFO is a structure array with one element for
     * %   each image in the file.  For example, INFO(3) would contain
     * %   information about the third image in the file.
     * %
     * %   INFO = IMFINFO(FILENAME) attempts to infer the format of the
     * %   file from its content.
     * %
     * %   The set of fields in INFO depends on the individual file and
     * %   its format.  However, the first nine fields are always the
     * %   same.  These common fields are:
     * %
     * %   Filename       A string containing the name of the file
     * %
     * %   FileModDate    A string containing the modification date of
     * %                  the file
     * %
     * %   FileSize       An integer indicating the size of the file in
     * %                  bytes
     * %
     * %   Format         A string containing the file format, as
     * %                  specified by FMT; for JPEG and TIFF files, the
     * %                  three-letter variant is returned
     * %
     * %   FormatVersion  A string or number specifying the file format
     * %                  version 
     * %
     * %   Width          An integer indicating the width of the image
     * %                  in pixels
     * %
     * %   Height         An integer indicating the height of the image
     * %                  in pixels
     * %
     * %   BitDepth       An integer indicating the number of bits per
     * %                  pixel 
     * %
     * %   ColorType      A string indicating the type of image; either
     * %                  'truecolor' for a truecolor (RGB) image,
     * %                  'grayscale' for a grayscale intensity image,
     * %                  or 'indexed', for an indexed image 
     * %
     * %   
     * %   See also IMREAD, IMWRITE.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.16 $  $Date: 2000/06/01 04:17:47 $
     * 
     * error(nargchk(1, 2, nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray4_, _mxarray5_, mlfScalar(nargin_))));
    /*
     * 
     * info = [];
     */
    mlfAssign(&info, _mxarray6_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray7_);
    /*
     * 
     * if (nargin < 2)
     */
    if (nargin_ < 2) {
        /*
         * % With 1 input argument, we must be able to open the file
         * % exactly as given.  Try it.
         * fid = fopen(filename, 'r');
         */
        mlfAssign(
          &fid,
          mlfFopen(NULL, NULL, mclVa(filename, "filename"), _mxarray8_, NULL));
        /*
         * if (fid == -1)
         */
        if (mclEqBool(mclVv(fid, "fid"), _mxarray10_)) {
            /*
             * msg = sprintf('Unable to open file "%s" for reading', filename);
             */
            mlfAssign(
              msg,
              mlfSprintf(NULL, _mxarray11_, mclVa(filename, "filename"), NULL));
            /*
             * if (nargout < 2)
             */
            if (nargout_ < 2) {
                /*
                 * error(msg);
                 */
                mlfError(mclVv(*msg, "msg"));
            /*
             * else
             */
            } else {
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            }
        /*
         * else
         */
        } else {
            /*
             * filename = fopen(fid);  % Get the full pathname if not in pwd
             */
            mlfAssign(
              &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * end
         */
        }
        /*
         * 
         * format = imftype(filename);
         */
        mlfAssign(
          &format, mlfIofun_private_imftype(mclVa(filename, "filename")));
        /*
         * if (isempty(format))
         */
        if (mlfTobool(mclVe(mlfIsempty(mclVa(format, "format"))))) {
            /*
             * msg = 'Unable to determine file format';
             */
            mlfAssign(msg, _mxarray13_);
            /*
             * if (nargout < 2)
             */
            if (nargout_ < 2) {
                /*
                 * error(msg);
                 */
                mlfError(mclVv(*msg, "msg"));
            /*
             * else
             */
            } else {
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * else
     */
    } else {
        /*
         * % Allow for some variance in specifying file format
         * format = lower(format);
         */
        mlfAssign(&format, mlfLower(mclVa(format, "format")));
        /*
         * if (strcmp(format,'tiff'))
         */
        if (mlfTobool(mclVe(mlfStrcmp(mclVa(format, "format"), _mxarray15_)))) {
            /*
             * format = 'tif';
             */
            mlfAssign(&format, _mxarray17_);
        /*
         * elseif (strcmp(format,'jpeg'))
         */
        } else if (mlfTobool(
                     mclVe(mlfStrcmp(mclVa(format, "format"), _mxarray19_)))) {
            /*
             * format = 'jpg';
             */
            mlfAssign(&format, _mxarray21_);
        /*
         * end
         */
        }
        /*
         * 
         * % See if we can open the file.  If we can't, and since
         * % the user explicitly specified the format, see if we
         * % can find the file using an extension.
         * fid = fopen(filename,'r');
         */
        mlfAssign(
          &fid,
          mlfFopen(NULL, NULL, mclVa(filename, "filename"), _mxarray8_, NULL));
        /*
         * if (fid == -1)
         */
        if (mclEqBool(mclVv(fid, "fid"), _mxarray10_)) {
            /*
             * switch format
             */
            mxArray * v_ = mclInitialize(mclVa(format, "format"));
            if (mclSwitchCompare(v_, _mxarray23_)) {
                /*
                 * case 'hdf'
                 * fid = fopen([filename '.hdf'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray25_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * case 'bmp'
             */
            } else if (mclSwitchCompare(v_, _mxarray27_)) {
                /*
                 * fid = fopen([filename '.bmp'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray29_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * case 'pcx'
             */
            } else if (mclSwitchCompare(v_, _mxarray31_)) {
                /*
                 * fid = fopen([filename '.pcx'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray33_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * case 'xwd'
             */
            } else if (mclSwitchCompare(v_, _mxarray35_)) {
                /*
                 * fid = fopen([filename '.xwd'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray37_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * case 'png'
             */
            } else if (mclSwitchCompare(v_, _mxarray39_)) {
                /*
                 * fid = fopen([filename '.png'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray41_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * case 'gif'
             */
            } else if (mclSwitchCompare(v_, _mxarray43_)) {
                /*
                 * fid = fopen([filename '.gif'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray45_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * case 'jpg'
             */
            } else if (mclSwitchCompare(v_, _mxarray21_)) {
                /*
                 * fid = fopen([filename '.jpg'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray47_, NULL),
                    _mxarray8_,
                    NULL));
                /*
                 * if (fid == -1)
                 */
                if (mclEqBool(mclVv(fid, "fid"), _mxarray10_)) {
                    /*
                     * fid = fopen([filename '.jpeg'], 'r');
                     */
                    mlfAssign(
                      &fid,
                      mlfFopen(
                        NULL,
                        NULL,
                        mlfHorzcat(
                          mclVa(filename, "filename"), _mxarray49_, NULL),
                        _mxarray8_,
                        NULL));
                /*
                 * end
                 */
                }
            /*
             * 
             * case 'tif'
             */
            } else if (mclSwitchCompare(v_, _mxarray17_)) {
                /*
                 * fid = fopen([filename '.tif'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray51_, NULL),
                    _mxarray8_,
                    NULL));
                /*
                 * if (fid == -1)
                 */
                if (mclEqBool(mclVv(fid, "fid"), _mxarray10_)) {
                    /*
                     * fid = fopen([filename '.tiff'], 'r');
                     */
                    mlfAssign(
                      &fid,
                      mlfFopen(
                        NULL,
                        NULL,
                        mlfHorzcat(
                          mclVa(filename, "filename"), _mxarray53_, NULL),
                        _mxarray8_,
                        NULL));
                /*
                 * end
                 */
                }
            /*
             * 
             * case 'ico'
             */
            } else if (mclSwitchCompare(v_, _mxarray55_)) {
                /*
                 * fid = fopen([filename '.ico'], 'r');           
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray57_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * case 'cur'  
             */
            } else if (mclSwitchCompare(v_, _mxarray59_)) {
                /*
                 * fid = fopen([filename '.cur'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVa(filename, "filename"), _mxarray61_, NULL),
                    _mxarray8_,
                    NULL));
            /*
             * 
             * otherwise
             */
            } else {
                /*
                 * if (nargout > 1)
                 */
                if (nargout_ > 1) {
                    /*
                     * msg = sprintf('Unrecognized or unsupported format "%s"', format);
                     */
                    mlfAssign(
                      msg,
                      mlfSprintf(
                        NULL, _mxarray63_, mclVa(format, "format"), NULL));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                /*
                 * else	    
                 */
                } else {
                    /*
                     * error(sprintf('Unrecognized or unsupported format "%s"', format));
                     */
                    mlfError(
                      mclVe(
                        mlfSprintf(
                          NULL, _mxarray63_, mclVa(format, "format"), NULL)));
                /*
                 * end
                 */
                }
            /*
             * end
             */
            }
            mxDestroyArray(v_);
            /*
             * 
             * if (fid == -1)
             */
            if (mclEqBool(mclVv(fid, "fid"), _mxarray10_)) {
                /*
                 * if (nargout > 1)
                 */
                if (nargout_ > 1) {
                    /*
                     * msg = sprintf('Cannot open "%s" for reading', filename);
                     */
                    mlfAssign(
                      msg,
                      mlfSprintf(
                        NULL, _mxarray65_, mclVa(filename, "filename"), NULL));
                    /*
                     * return;
                     */
                    goto return_;
                /*
                 * else
                 */
                } else {
                    /*
                     * error(sprintf('Cannot open "%s" for reading', filename));
                     */
                    mlfError(
                      mclVe(
                        mlfSprintf(
                          NULL,
                          _mxarray65_,
                          mclVa(filename, "filename"),
                          NULL)));
                /*
                 * end
                 */
                }
            /*
             * end
             */
            }
        /*
         * end
         */
        }
        /*
         * 
         * filename = fopen(fid);  % gets the full pathname if not in pwd
         */
        mlfAssign(
          &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    /*
     * 
     * end
     */
    }
    /*
     * 
     * msg = '';
     */
    mlfAssign(msg, _mxarray7_);
    /*
     * 
     * switch format
     */
    {
        mxArray * v_ = mclInitialize(mclVa(format, "format"));
        if (mclSwitchCompare(v_, _mxarray23_)) {
            /*
             * case 'hdf'
             * [info,msg] = imhdfinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imhdfinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'bmp'
         */
        } else if (mclSwitchCompare(v_, _mxarray27_)) {
            /*
             * [info,msg] = imbmpinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imbmpinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'pcx'
         */
        } else if (mclSwitchCompare(v_, _mxarray31_)) {
            /*
             * [info,msg] = impcxinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_impcxinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'xwd'
         */
        } else if (mclSwitchCompare(v_, _mxarray35_)) {
            /*
             * [info,msg] = imxwdinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imxwdinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'jpg'
         */
        } else if (mclSwitchCompare(v_, _mxarray21_)) {
            /*
             * [info,msg] = imjpginfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imjpginfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'tif'
         */
        } else if (mclSwitchCompare(v_, _mxarray17_)) {
            /*
             * [info,msg] = imtifinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imtifinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'png'
         */
        } else if (mclSwitchCompare(v_, _mxarray39_)) {
            /*
             * [info,msg] = impnginfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_impnginfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'gif'
         */
        } else if (mclSwitchCompare(v_, _mxarray43_)) {
            /*
             * [info,msg] = imgifinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imgifinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'ico'
         */
        } else if (mclSwitchCompare(v_, _mxarray55_)) {
            /*
             * [info,msg] = imicoinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imicoinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * case 'cur'
         */
        } else if (mclSwitchCompare(v_, _mxarray59_)) {
            /*
             * [info,msg] = imcurinfo(filename);
             */
            mlfAssign(
              &info,
              mlfIofun_private_imcurinfo(msg, mclVa(filename, "filename")));
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * if (nargout > 1)
             */
            if (nargout_ > 1) {
                /*
                 * msg = sprintf('Unrecognized or unsupported format "%s"', format);
                 */
                mlfAssign(
                  msg,
                  mlfSprintf(NULL, _mxarray63_, mclVa(format, "format"), NULL));
                /*
                 * return;
                 */
                mxDestroyArray(v_);
                goto return_;
            /*
             * else
             */
            } else {
                /*
                 * error(sprintf('Unrecognized or unsupported format "%s"', format));
                 */
                mlfError(
                  mclVe(
                    mlfSprintf(
                      NULL, _mxarray63_, mclVa(format, "format"), NULL)));
            /*
             * end
             */
            }
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * if ((nargout < 2) & (isempty(info)))
     */
    {
        mxArray * a_ = mclInitialize(mclBoolToArray(nargout_ < 2));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclVe(mlfIsempty(mclVv(info, "info")))))) {
            mxDestroyArray(a_);
            /*
             * error(msg);
             */
            mlfError(mclVv(*msg, "msg"));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "imfinfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "imfinfo");
    mxDestroyArray(ans);
    mxDestroyArray(fid);
    mxDestroyArray(format);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
