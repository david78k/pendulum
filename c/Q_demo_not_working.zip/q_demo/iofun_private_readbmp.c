/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readbmp.h"
#include "iofun_private_imbmpinfo.h"
#include "iofun_private_readbmpdata.h"
#include "libmatlbm.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'b', 'm', 'p', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'b', 'm', 'p', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'b', 'm', 'p', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'b', 'm', 'p', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't',
                                's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray2_;

void InitializeModule_iofun_private_readbmp(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
}

void TerminateModule_iofun_private_readbmp(void) {
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_readbmp(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_readbmp
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_readbmp" contains the normal interface for
 * the "iofun/private/readbmp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmp.m" (lines 1-25). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readbmp(mxArray * * map, mxArray * filename) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, map, filename);
    if (map != NULL) {
        ++nargout;
    }
    X = Miofun_private_readbmp(&map__, nargout, filename);
    mlfRestorePreviousContext(1, 1, map, filename);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlxIofun_private_readbmp" contains the feval interface for the
 * "iofun/private/readbmp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmp.m" (lines 1-25). The
 * feval function calls the implementation version of iofun/private/readbmp
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readbmp(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_readbmp(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_readbmp" is the implementation version of the
 * "iofun/private/readbmp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmp.m" (lines 1-25). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [X,map] = readbmp(filename)
 */
static mxArray * Miofun_private_readbmp(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmp);
    mxArray * X = mclGetUninitializedArray();
    mxArray * info = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %READBMP Read image data from a BMP file.
     * %   [X,MAP] = READBMP(FILENAME) reads image data from a BMP file.
     * %   X is a uint8 array that is 2-D for 1-bit, 4-bit, and 8-bit
     * %   image data.  X is M-by-N-by-3 for 24-bit and 32-bit image data.  
     * %   MAP is normally an M-by-3 MATLAB colormap, but it may be empty if the
     * %   BMP file does not contain a colormap.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.9 $  $Date: 2000/06/01 04:17:11 $
     * 
     * info = imbmpinfo(filename);
     */
    mlfAssign(
      &info, mlfIofun_private_imbmpinfo(NULL, mclVa(filename, "filename")));
    /*
     * 
     * map = info.Colormap;
     */
    mlfAssign(map, mlfIndexRef(mclVsv(info, "info"), ".Colormap"));
    /*
     * X = readbmpdata(info);
     */
    mlfAssign(&X, mlfIofun_private_readbmpdata(mclVv(info, "info")));
    mclValidateOutput(X, 1, nargout_, "X", "iofun/private/readbmp");
    mclValidateOutput(*map, 2, nargout_, "map", "iofun/private/readbmp");
    mxDestroyArray(info);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * return;
     * 
     * 
     * 
     * 
     * 
     */
}
