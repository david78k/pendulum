/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:43 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "get_action.h"
#include "get_box.h"
#include "libmatlbm.h"

static mxChar _array1_[138] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'g', 'e', 't', '_', 'a',
                                'c', 't', 'i', 'o', 'n', ' ', 'L', 'i', 'n',
                                'e', ':', ' ', '1', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'g', 'e', 't', '_', 'a', 'c', 't',
                                'i', 'o', 'n', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'o', 'u', 't', 'p', 'u', 't', 's', ' ', '(',
                                '5', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[138] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'g', 'e', 't', '_', 'a',
                                'c', 't', 'i', 'o', 'n', ' ', 'L', 'i', 'n',
                                'e', ':', ' ', '1', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'g', 'e', 't', '_', 'a', 'c', 't',
                                'i', 'o', 'n', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'i', 'n', 'p', 'u', 't', 's', ' ', '(', '1',
                                '3', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;
static mxArray * _mxarray7_;

void InitializeModule_get_action(void) {
    _mxarray0_ = mclInitializeString(138, _array1_);
    _mxarray2_ = mclInitializeString(138, _array3_);
    _mxarray4_ = mclInitializeDouble(-1.0);
    _mxarray5_ = mclInitializeDouble(0.0);
    _mxarray6_ = mclInitializeDouble(1.0);
    _mxarray7_ = mclInitializeDouble(2.0);
}

void TerminateModule_get_action(void) {
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mget_action(mxArray * * pre_state,
                             mxArray * * pre_action,
                             mxArray * * cur_state,
                             mxArray * * cur_action,
                             int nargout_,
                             mxArray * x,
                             mxArray * v_x,
                             mxArray * theta,
                             mxArray * v_theta,
                             mxArray * reinf,
                             mxArray * q_val_in,
                             mxArray * pre_state_in,
                             mxArray * cur_state_in,
                             mxArray * pre_action_in,
                             mxArray * cur_action_in,
                             mxArray * ALPHA,
                             mxArray * BETA,
                             mxArray * GAMMA);

_mexLocalFunctionTable _local_function_table_get_action
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfGet_action" contains the normal interface for the
 * "get_action" M-function from file "C:\temp\q\get_action.m" (lines 1-23).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfGet_action(mxArray * * pre_state,
                        mxArray * * pre_action,
                        mxArray * * cur_state,
                        mxArray * * cur_action,
                        mxArray * x,
                        mxArray * v_x,
                        mxArray * theta,
                        mxArray * v_theta,
                        mxArray * reinf,
                        mxArray * q_val_in,
                        mxArray * pre_state_in,
                        mxArray * cur_state_in,
                        mxArray * pre_action_in,
                        mxArray * cur_action_in,
                        mxArray * ALPHA,
                        mxArray * BETA,
                        mxArray * GAMMA) {
    int nargout = 1;
    mxArray * q_val = mclGetUninitializedArray();
    mxArray * pre_state__ = mclGetUninitializedArray();
    mxArray * pre_action__ = mclGetUninitializedArray();
    mxArray * cur_state__ = mclGetUninitializedArray();
    mxArray * cur_action__ = mclGetUninitializedArray();
    mlfEnterNewContext(
      4,
      13,
      pre_state,
      pre_action,
      cur_state,
      cur_action,
      x,
      v_x,
      theta,
      v_theta,
      reinf,
      q_val_in,
      pre_state_in,
      cur_state_in,
      pre_action_in,
      cur_action_in,
      ALPHA,
      BETA,
      GAMMA);
    if (pre_state != NULL) {
        ++nargout;
    }
    if (pre_action != NULL) {
        ++nargout;
    }
    if (cur_state != NULL) {
        ++nargout;
    }
    if (cur_action != NULL) {
        ++nargout;
    }
    q_val
      = Mget_action(
          &pre_state__,
          &pre_action__,
          &cur_state__,
          &cur_action__,
          nargout,
          x,
          v_x,
          theta,
          v_theta,
          reinf,
          q_val_in,
          pre_state_in,
          cur_state_in,
          pre_action_in,
          cur_action_in,
          ALPHA,
          BETA,
          GAMMA);
    mlfRestorePreviousContext(
      4,
      13,
      pre_state,
      pre_action,
      cur_state,
      cur_action,
      x,
      v_x,
      theta,
      v_theta,
      reinf,
      q_val_in,
      pre_state_in,
      cur_state_in,
      pre_action_in,
      cur_action_in,
      ALPHA,
      BETA,
      GAMMA);
    if (pre_state != NULL) {
        mclCopyOutputArg(pre_state, pre_state__);
    } else {
        mxDestroyArray(pre_state__);
    }
    if (pre_action != NULL) {
        mclCopyOutputArg(pre_action, pre_action__);
    } else {
        mxDestroyArray(pre_action__);
    }
    if (cur_state != NULL) {
        mclCopyOutputArg(cur_state, cur_state__);
    } else {
        mxDestroyArray(cur_state__);
    }
    if (cur_action != NULL) {
        mclCopyOutputArg(cur_action, cur_action__);
    } else {
        mxDestroyArray(cur_action__);
    }
    return mlfReturnValue(q_val);
}

/*
 * The function "mlxGet_action" contains the feval interface for the
 * "get_action" M-function from file "C:\temp\q\get_action.m" (lines 1-23). The
 * feval function calls the implementation version of get_action through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxGet_action(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[13];
    mxArray * mplhs[5];
    int i;
    if (nlhs > 5) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 13) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 5; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 13 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 13; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(
      0,
      13,
      mprhs[0],
      mprhs[1],
      mprhs[2],
      mprhs[3],
      mprhs[4],
      mprhs[5],
      mprhs[6],
      mprhs[7],
      mprhs[8],
      mprhs[9],
      mprhs[10],
      mprhs[11],
      mprhs[12]);
    mplhs[0]
      = Mget_action(
          &mplhs[1],
          &mplhs[2],
          &mplhs[3],
          &mplhs[4],
          nlhs,
          mprhs[0],
          mprhs[1],
          mprhs[2],
          mprhs[3],
          mprhs[4],
          mprhs[5],
          mprhs[6],
          mprhs[7],
          mprhs[8],
          mprhs[9],
          mprhs[10],
          mprhs[11],
          mprhs[12]);
    mlfRestorePreviousContext(
      0,
      13,
      mprhs[0],
      mprhs[1],
      mprhs[2],
      mprhs[3],
      mprhs[4],
      mprhs[5],
      mprhs[6],
      mprhs[7],
      mprhs[8],
      mprhs[9],
      mprhs[10],
      mprhs[11],
      mprhs[12]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 5 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 5; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Mget_action" is the implementation version of the "get_action"
 * M-function from file "C:\temp\q\get_action.m" (lines 1-23). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function [q_val,pre_state,pre_action,cur_state,cur_action] = get_action(x,v_x,theta,v_theta,reinf,q_val,pre_state,cur_state,pre_action,cur_action,ALPHA,BETA,GAMMA)
 */
static mxArray * Mget_action(mxArray * * pre_state,
                             mxArray * * pre_action,
                             mxArray * * cur_state,
                             mxArray * * cur_action,
                             int nargout_,
                             mxArray * x,
                             mxArray * v_x,
                             mxArray * theta,
                             mxArray * v_theta,
                             mxArray * reinf,
                             mxArray * q_val_in,
                             mxArray * pre_state_in,
                             mxArray * cur_state_in,
                             mxArray * pre_action_in,
                             mxArray * cur_action_in,
                             mxArray * ALPHA,
                             mxArray * BETA,
                             mxArray * GAMMA) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_get_action);
    mxArray * q_val = mclGetUninitializedArray();
    mxArray * predicted_value = mclGetUninitializedArray();
    mclCopyArray(&x);
    mclCopyArray(&v_x);
    mclCopyArray(&theta);
    mclCopyArray(&v_theta);
    mclCopyArray(&reinf);
    mclCopyInputArg(&q_val, q_val_in);
    mclCopyInputArg(pre_state, pre_state_in);
    mclCopyInputArg(cur_state, cur_state_in);
    mclCopyInputArg(pre_action, pre_action_in);
    mclCopyInputArg(cur_action, cur_action_in);
    mclCopyArray(&ALPHA);
    mclCopyArray(&BETA);
    mclCopyArray(&GAMMA);
    /*
     * 
     * pre_state=cur_state;
     */
    mlfAssign(pre_state, mclVsa(*cur_state, "cur_state"));
    /*
     * pre_action=cur_action;    % Action: 1 is push left.  2 is push right
     */
    mlfAssign(pre_action, mclVsa(*cur_action, "cur_action"));
    /*
     * cur_state=get_box(x,v_x,theta,v_theta);
     */
    mlfAssign(
      cur_state,
      mlfGet_box(
        mclVa(x, "x"),
        mclVa(v_x, "v_x"),
        mclVa(theta, "theta"),
        mclVa(v_theta, "v_theta")));
    /*
     * 
     * if (pre_action ~= -1)   % Update Q value. If previous action been taken
     */
    if (mclNeBool(mclVa(*pre_action, "pre_action"), _mxarray4_)) {
        /*
         * if (cur_state == -1)  % Current state is failed
         */
        if (mclEqBool(mclVa(*cur_state, "cur_state"), _mxarray4_)) {
            /*
             * predicted_value=0;  % fail state's value is zero
             */
            mlfAssign(&predicted_value, _mxarray5_);
        /*
         * elseif (q_val(cur_state,1)<=q_val(cur_state,2)) % Left Q<= Right Q
         */
        } else if (mclLeBool(
                     mclVe(
                       mclArrayRef2(
                         mclVsa(q_val, "q_val"),
                         mclVsa(*cur_state, "cur_state"),
                         _mxarray6_)),
                     mclVe(
                       mclArrayRef2(
                         mclVsa(q_val, "q_val"),
                         mclVsa(*cur_state, "cur_state"),
                         _mxarray7_)))) {
            /*
             * predicted_value=q_val(cur_state,2);         %  set Q to bigger one
             */
            mlfAssign(
              &predicted_value,
              mclArrayRef2(
                mclVsa(q_val, "q_val"),
                mclVsa(*cur_state, "cur_state"),
                _mxarray7_));
        /*
         * else 
         */
        } else {
            /*
             * predicted_value=q_val(cur_state,1);
             */
            mlfAssign(
              &predicted_value,
              mclArrayRef2(
                mclVsa(q_val, "q_val"),
                mclVsa(*cur_state, "cur_state"),
                _mxarray6_));
        /*
         * end %if
         */
        }
        /*
         * q_val(pre_state,pre_action)= q_val(pre_state,pre_action)+ ALPHA*(reinf+ GAMMA*predicted_value - q_val(pre_state,pre_action));
         */
        mclArrayAssign2(
          &q_val,
          mclPlus(
            mclVe(
              mclArrayRef2(
                mclVsa(q_val, "q_val"),
                mclVsa(*pre_state, "pre_state"),
                mclVsa(*pre_action, "pre_action"))),
            mclMtimes(
              mclVa(ALPHA, "ALPHA"),
              mclMinus(
                mclPlus(
                  mclVa(reinf, "reinf"),
                  mclMtimes(
                    mclVa(GAMMA, "GAMMA"),
                    mclVv(predicted_value, "predicted_value"))),
                mclVe(
                  mclArrayRef2(
                    mclVsa(q_val, "q_val"),
                    mclVsa(*pre_state, "pre_state"),
                    mclVsa(*pre_action, "pre_action")))))),
          mclVsa(*pre_state, "pre_state"),
          mclVsa(*pre_action, "pre_action"));
    /*
     * 
     * end %if
     */
    }
    /*
     * % Determine best action
     * if ( q_val(cur_state,1) + (rand*BETA) <= q_val(cur_state,2) )
     */
    if (mclLeBool(
          mclPlus(
            mclVe(
              mclArrayRef2(
                mclVsa(q_val, "q_val"),
                mclVsa(*cur_state, "cur_state"),
                _mxarray6_)),
            mclMtimes(mclVe(mlfNRand(1, NULL)), mclVa(BETA, "BETA"))),
          mclVe(
            mclArrayRef2(
              mclVsa(q_val, "q_val"),
              mclVsa(*cur_state, "cur_state"),
              _mxarray7_)))) {
        /*
         * cur_action=2;  % push right
         */
        mlfAssign(cur_action, _mxarray7_);
    /*
     * else cur_action=1;  % push left
     */
    } else {
        mlfAssign(cur_action, _mxarray6_);
    /*
     * end  %if
     */
    }
    mclVo(&q_val);
    mclVo(pre_state);
    mclVo(pre_action);
    mclVo(cur_state);
    mclVo(cur_action);
    mclValidateOutput(q_val, 1, nargout_, "q_val", "get_action");
    mclValidateOutput(*pre_state, 2, nargout_, "pre_state", "get_action");
    mclValidateOutput(*pre_action, 3, nargout_, "pre_action", "get_action");
    mclValidateOutput(*cur_state, 4, nargout_, "cur_state", "get_action");
    mclValidateOutput(*cur_action, 5, nargout_, "cur_action", "get_action");
    mxDestroyArray(predicted_value);
    mxDestroyArray(GAMMA);
    mxDestroyArray(BETA);
    mxDestroyArray(ALPHA);
    mxDestroyArray(reinf);
    mxDestroyArray(v_theta);
    mxDestroyArray(theta);
    mxDestroyArray(v_x);
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q_val;
}
