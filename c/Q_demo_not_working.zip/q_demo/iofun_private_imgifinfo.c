/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imgifinfo.h"
#include "libmatlbm.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'g', 'i', 'f', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'g', 'i', 'f', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'g', 'i', 'f', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'g', 'i', 'f', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray6_;

static mxChar _array9_[1] = { 'r' };
static mxArray * _mxarray8_;

static mxChar _array11_[7] = { 'i', 'e', 'e', 'e', '-', 'l', 'e' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;
static mxArray * _mxarray13_;

static double _array15_[3] = { 71.0, 73.0, 70.0 };
static mxArray * _mxarray14_;

static mxChar _array17_[14] = { 'N', 'o', 't', ' ', 'a', ' ', 'G',
                                'I', 'F', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray16_;
static mxArray * _mxarray18_;

static mxChar _array20_[3] = { 'b', 'o', 'f' };
static mxArray * _mxarray19_;
static mxArray * _mxarray21_;
static mxArray * _mxarray22_;

static mxChar _array24_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray23_;

static mxChar _array26_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray25_;
static mxArray * _mxarray27_;
static mxArray * _mxarray28_;

static double _array30_[3] = { 1.0, 2.0, 3.0 };
static mxArray * _mxarray29_;

static double _array32_[3] = { 1.0, 2.0, 4.0 };
static mxArray * _mxarray31_;
static mxArray * _mxarray33_;
static mxArray * _mxarray34_;
static mxArray * _mxarray35_;
static mxArray * _mxarray36_;

static mxChar _array38_[3] = { 'c', 'o', 'f' };
static mxArray * _mxarray37_;
static mxArray * _mxarray39_;
static mxArray * _mxarray40_;
static mxArray * _mxarray41_;

static mxChar _array43_[16] = { 'C', 'o', 'r', 'r', 'u', 'p', 't', ' ',
                                'G', 'I', 'F', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray42_;
static mxArray * _mxarray44_;
static mxArray * _mxarray45_;

static mxChar _array47_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray46_;
static mxArray * _mxarray48_;

static mxChar _array50_[3] = { 'y', 'e', 's' };
static mxArray * _mxarray49_;

static mxChar _array52_[2] = { 'n', 'o' };
static mxArray * _mxarray51_;

static double _array54_[6] = { 0.0, 1.0, 0.0, 1.0, 0.0, 1.0 };
static mxArray * _mxarray53_;

static mxChar _array56_[27] = { 'N', 'o', ' ', 'i', 'm', 'a', 'g', 'e', 's',
                                ' ', 'f', 'o', 'u', 'n', 'd', ' ', 'i', 'n',
                                ' ', 'G', 'I', 'F', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray55_;

void InitializeModule_iofun_private_imgifinfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(7, _array11_);
    _mxarray12_ = mclInitializeDouble(-1.0);
    _mxarray13_ = mclInitializeDouble(3.0);
    _mxarray14_ = mclInitializeDoubleVector(1, 3, _array15_);
    _mxarray16_ = mclInitializeString(14, _array17_);
    _mxarray18_ = mclInitializeDouble(0.0);
    _mxarray19_ = mclInitializeString(3, _array20_);
    _mxarray21_ = mclInitializeDouble(6.0);
    _mxarray22_ = mclInitializeDouble(2.0);
    _mxarray23_ = mclInitializeString(6, _array24_);
    _mxarray25_ = mclInitializeString(5, _array26_);
    _mxarray27_ = mclInitializeDouble(8.0);
    _mxarray28_ = mclInitializeDouble(1.0);
    _mxarray29_ = mclInitializeDoubleVector(1, 3, _array30_);
    _mxarray31_ = mclInitializeDoubleVector(1, 3, _array32_);
    _mxarray33_ = mclInitializeDouble(255.0);
    _mxarray34_ = mclInitializeDouble(59.0);
    _mxarray35_ = mclInitializeDouble(33.0);
    _mxarray36_ = mclInitializeDouble(249.0);
    _mxarray37_ = mclInitializeString(3, _array38_);
    _mxarray39_ = mclInitializeDouble(13.0);
    _mxarray40_ = mclInitializeDouble(12.0);
    _mxarray41_ = mclInitializeDouble(254.0);
    _mxarray42_ = mclInitializeString(16, _array43_);
    _mxarray44_ = mclInitializeDouble(44.0);
    _mxarray45_ = mclInitializeDouble(4.0);
    _mxarray46_ = mclInitializeString(7, _array47_);
    _mxarray48_ = mclInitializeDouble(7.0);
    _mxarray49_ = mclInitializeString(3, _array50_);
    _mxarray51_ = mclInitializeString(2, _array52_);
    _mxarray53_ = mclInitializeDoubleVector(2, 3, _array54_);
    _mxarray55_ = mclInitializeString(27, _array56_);
}

void TerminateModule_iofun_private_imgifinfo(void) {
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_imgifinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_imgifinfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_imgifinfo" contains the normal interface for
 * the "iofun/private/imgifinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imgifinfo.m" (lines 1-203). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imgifinfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_imgifinfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_imgifinfo" contains the feval interface for
 * the "iofun/private/imgifinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imgifinfo.m" (lines 1-203). The
 * feval function calls the implementation version of iofun/private/imgifinfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imgifinfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imgifinfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_imgifinfo" is the implementation version of the
 * "iofun/private/imgifinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imgifinfo.m" (lines 1-203). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imgifinfo(filename)
 */
static mxArray * Miofun_private_imgifinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imgifinfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * i = mclGetUninitializedArray();
    mxArray * numImages = mclGetUninitializedArray();
    mxArray * ltable = mclGetUninitializedArray();
    mxArray * Localbitdepth = mclGetUninitializedArray();
    mxArray * LCTbool = mclGetUninitializedArray();
    mxArray * LocalPacked = mclGetUninitializedArray();
    mxArray * LocalID = mclGetUninitializedArray();
    mxArray * letter = mclGetUninitializedArray();
    mxArray * countByte = mclGetUninitializedArray();
    mxArray * blockLabel = mclGetUninitializedArray();
    mxArray * separator = mclGetUninitializedArray();
    mxArray * CommentExtension = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * GlobalColorTable = mclGetUninitializedArray();
    mxArray * table = mclGetUninitializedArray();
    mxArray * bitdepth = mclGetUninitializedArray();
    mxArray * sizeGCT = mclGetUninitializedArray();
    mxArray * GCTbool = mclGetUninitializedArray();
    mxArray * PackedByte = mclGetUninitializedArray();
    mxArray * LogicalScreenDescriptor = mclGetUninitializedArray();
    mxArray * ScreenSize = mclGetUninitializedArray();
    mxArray * GIFheader = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * s = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMGIFINFO Information about a GIF file.
     * %   [INFO,MSG] = IMGIFINFO(FILENAME) returns a structure containing
     * %   information about the GIF file specified by the string
     * %   FILENAME. 
     * %
     * %   If any error condition is encountered, such as an error opening
     * %   the file, MSG will contain a string describing the error and
     * %   INFO will be empty.  Otherwise, MSG will be empty.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.2 $  $Date: 2000/06/01 04:17:17 $
     * 
     * info = [];
     */
    mlfAssign(&info, _mxarray4_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray5_);
    /*
     * 
     * if (~isstr(filename))
     */
    if (mclNotBool(mclVe(mlfIsstr(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray6_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * [fid,m] = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(&m, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray10_));
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray12_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = m;
         */
        mlfAssign(msg, mclVsv(m, "m"));
        /*
         * return;
         */
        goto return_;
    /*
     * else
     */
    } else {
        /*
         * filename = fopen(fid);
         */
        mlfAssign(
          &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Read directory information about the file
     * s = dir(filename);
     */
    mlfAssign(&s, mlfNDir(1, mclVa(filename, "filename")));
    /*
     * 
     * %
     * % Initialize universal structure fields to fix the order
     * %
     * info.Filename = '';
     */
    mlfIndexAssign(&info, ".Filename", _mxarray5_);
    /*
     * info.FileModDate = '';
     */
    mlfIndexAssign(&info, ".FileModDate", _mxarray5_);
    /*
     * info.FileSize = [];
     */
    mlfIndexAssign(&info, ".FileSize", _mxarray4_);
    /*
     * info.Format = '';
     */
    mlfIndexAssign(&info, ".Format", _mxarray5_);
    /*
     * info.FormatVersion = [];
     */
    mlfIndexAssign(&info, ".FormatVersion", _mxarray4_);
    /*
     * info.Width = [];
     */
    mlfIndexAssign(&info, ".Width", _mxarray4_);
    /*
     * info.Height = [];
     */
    mlfIndexAssign(&info, ".Height", _mxarray4_);
    /*
     * info.BitDepth = [];
     */
    mlfIndexAssign(&info, ".BitDepth", _mxarray4_);
    /*
     * info.ColorType = [];
     */
    mlfIndexAssign(&info, ".ColorType", _mxarray4_);
    /*
     * info.FormatSignature = '';
     */
    mlfIndexAssign(&info, ".FormatSignature", _mxarray5_);
    /*
     * 
     * % Initialize other tags
     * info.BackgroundColor = [];
     */
    mlfIndexAssign(&info, ".BackgroundColor", _mxarray4_);
    /*
     * info.AspectRatio = [];
     */
    mlfIndexAssign(&info, ".AspectRatio", _mxarray4_);
    /*
     * info.ColorTable = [];
     */
    mlfIndexAssign(&info, ".ColorTable", _mxarray4_);
    /*
     * info.Interlaced = [];
     */
    mlfIndexAssign(&info, ".Interlaced", _mxarray4_);
    /*
     * 
     * sig = fread(fid, 3)';
     */
    mlfAssign(
      &sig,
      mlfCtranspose(
        mclVe(mlfFread(NULL, mclVv(fid, "fid"), _mxarray13_, NULL, NULL))));
    /*
     * if ~isequal(sig, [71 73 70])
     */
    if (mclNotBool(mclVe(mlfIsequal(mclVv(sig, "sig"), _mxarray14_, NULL)))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'Not a GIF file';
         */
        mlfAssign(msg, _mxarray16_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * fseek(fid,0,'bof');
     */
    mclAssignAns(&ans, mlfFseek(mclVv(fid, "fid"), _mxarray18_, _mxarray19_));
    /*
     * 
     * % read in the Header, Logical Screen Descriptor and if there, the Global Color Table.
     * GIFheader = fread(fid,6)';
     */
    mlfAssign(
      &GIFheader,
      mlfCtranspose(
        mclVe(mlfFread(NULL, mclVv(fid, "fid"), _mxarray21_, NULL, NULL))));
    /*
     * ScreenSize = fread(fid,2,'uint16');
     */
    mlfAssign(
      &ScreenSize,
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
    /*
     * LogicalScreenDescriptor = fread(fid,3,'uint8')';
     */
    mlfAssign(
      &LogicalScreenDescriptor,
      mlfCtranspose(
        mclVe(
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray13_, _mxarray25_, NULL))));
    /*
     * PackedByte = LogicalScreenDescriptor(1);
     */
    mlfAssign(
      &PackedByte,
      mclIntArrayRef1(
        mclVsv(LogicalScreenDescriptor, "LogicalScreenDescriptor"), 1));
    /*
     * 
     * GCTbool = bitget(PackedByte,8)==1;  % do we have a Global Color Table?
     */
    mlfAssign(
      &GCTbool,
      mclEq(
        mclVe(mlfBitget(mclVv(PackedByte, "PackedByte"), _mxarray27_)),
        _mxarray28_));
    /*
     * 
     * if GCTbool
     */
    if (mlfTobool(mclVv(GCTbool, "GCTbool"))) {
        /*
         * sizeGCT = bitget(PackedByte,1:3);
         */
        mlfAssign(
          &sizeGCT, mlfBitget(mclVv(PackedByte, "PackedByte"), _mxarray29_));
        /*
         * bitdepth = sum(sizeGCT.*[1 2 4]) + 1;
         */
        mlfAssign(
          &bitdepth,
          mclPlus(
            mclVe(
              mlfSum(mclTimes(mclVv(sizeGCT, "sizeGCT"), _mxarray31_), NULL)),
            _mxarray28_));
        /*
         * table = fread(fid,3*bitshift(1,bitdepth),'uint8');
         */
        mlfAssign(
          &table,
          mlfFread(
            NULL,
            mclVv(fid, "fid"),
            mclMtimes(
              _mxarray13_,
              mclVe(
                mlfBitshift(_mxarray28_, mclVv(bitdepth, "bitdepth"), NULL))),
            _mxarray25_,
            NULL));
        /*
         * GlobalColorTable = reshape(table,3,length(table)/3)'./255;
         */
        mlfAssign(
          &GlobalColorTable,
          mclRdivide(
            mlfCtranspose(
              mclVe(
                mlfReshape(
                  mclVv(table, "table"),
                  _mxarray13_,
                  mclMrdivide(
                    mlfScalar(mclLengthInt(mclVv(table, "table"))),
                    _mxarray13_),
                  NULL))),
            _mxarray33_));
    /*
     * end
     */
    }
    /*
     * 
     * % Since those extension blocks can be anywhere (including before the Local
     * % Image Descriptor), we have to fread and sort until we hit a Separator
     * k = 0; CommentExtension = '';
     */
    mlfAssign(&k, _mxarray18_);
    mlfAssign(&CommentExtension, _mxarray5_);
    /*
     * 
     * separator = fread(fid,1,'uint8');
     */
    mlfAssign(
      &separator,
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray28_, _mxarray25_, NULL));
    /*
     * 
     * 
     * while (separator ~= 59)
     */
    while (mclNeBool(mclVv(separator, "separator"), _mxarray34_)) {
        /*
         * % keep going past the blocks until we hit an Image Descriptor or Extension Block
         * if (separator == 33)
         */
        if (mclEqBool(mclVv(separator, "separator"), _mxarray35_)) {
            /*
             * blockLabel = fread(fid,1,'uint8');
             */
            mlfAssign(
              &blockLabel,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray28_, _mxarray25_, NULL));
            /*
             * 
             * switch blockLabel
             */
            {
                mxArray * v_ = mclInitialize(mclVv(blockLabel, "blockLabel"));
                if (mclSwitchCompare(v_, _mxarray36_)) {
                    /*
                     * case 249 % Graphics Control Extension
                     * fseek(fid,6,'cof'); %6
                     */
                    mclAssignAns(
                      &ans,
                      mlfFseek(mclVv(fid, "fid"), _mxarray21_, _mxarray37_));
                /*
                 * case 1 % Plain Text Extension
                 */
                } else if (mclSwitchCompare(v_, _mxarray28_)) {
                    /*
                     * fseek(fid,13,'cof');
                     */
                    mclAssignAns(
                      &ans,
                      mlfFseek(mclVv(fid, "fid"), _mxarray39_, _mxarray37_));
                    /*
                     * countByte = fread(fid,1,'uint8');
                     */
                    mlfAssign(
                      &countByte,
                      mlfFread(
                        NULL,
                        mclVv(fid, "fid"),
                        _mxarray28_,
                        _mxarray25_,
                        NULL));
                    /*
                     * while (countByte ~=0)
                     */
                    while (mclNeBool(
                             mclVv(countByte, "countByte"), _mxarray18_)) {
                        /*
                         * fseek(fid,countByte+1,'cof');
                         */
                        mclAssignAns(
                          &ans,
                          mlfFseek(
                            mclVv(fid, "fid"),
                            mclPlus(mclVv(countByte, "countByte"), _mxarray28_),
                            _mxarray37_));
                        /*
                         * countByte = fread(fid,1,'uint8');
                         */
                        mlfAssign(
                          &countByte,
                          mlfFread(
                            NULL,
                            mclVv(fid, "fid"),
                            _mxarray28_,
                            _mxarray25_,
                            NULL));
                    /*
                     * end
                     */
                    }
                /*
                 * case 255 % Application Extension
                 */
                } else if (mclSwitchCompare(v_, _mxarray33_)) {
                    /*
                     * fseek(fid,12,'cof');
                     */
                    mclAssignAns(
                      &ans,
                      mlfFseek(mclVv(fid, "fid"), _mxarray40_, _mxarray37_));
                    /*
                     * countByte = fread(fid,1,'uint8');
                     */
                    mlfAssign(
                      &countByte,
                      mlfFread(
                        NULL,
                        mclVv(fid, "fid"),
                        _mxarray28_,
                        _mxarray25_,
                        NULL));
                    /*
                     * while (countByte ~= 0)
                     */
                    while (mclNeBool(
                             mclVv(countByte, "countByte"), _mxarray18_)) {
                        /*
                         * fseek(fid,countByte,'cof');
                         */
                        mclAssignAns(
                          &ans,
                          mlfFseek(
                            mclVv(fid, "fid"),
                            mclVv(countByte, "countByte"),
                            _mxarray37_));
                        /*
                         * countByte = fread(fid,1,'uint8');
                         */
                        mlfAssign(
                          &countByte,
                          mlfFread(
                            NULL,
                            mclVv(fid, "fid"),
                            _mxarray28_,
                            _mxarray25_,
                            NULL));
                    /*
                     * end
                     */
                    }
                /*
                 * case 254 % Comment Extension
                 */
                } else if (mclSwitchCompare(v_, _mxarray41_)) {
                    /*
                     * fread(fid,1); % pointer
                     */
                    mclAssignAns(
                      &ans,
                      mlfFread(
                        NULL, mclVv(fid, "fid"), _mxarray28_, NULL, NULL));
                    /*
                     * letter = fread(fid,1);
                     */
                    mlfAssign(
                      &letter,
                      mlfFread(
                        NULL, mclVv(fid, "fid"), _mxarray28_, NULL, NULL));
                    /*
                     * CommentExtension = char(letter);
                     */
                    mlfAssign(
                      &CommentExtension,
                      mlfChar(mclVv(letter, "letter"), NULL));
                    /*
                     * while (letter ~= 0)
                     */
                    while (mclNeBool(mclVv(letter, "letter"), _mxarray18_)) {
                        /*
                         * letter = fread(fid,1);
                         */
                        mlfAssign(
                          &letter,
                          mlfFread(
                            NULL, mclVv(fid, "fid"), _mxarray28_, NULL, NULL));
                        /*
                         * CommentExtension = [CommentExtension char(letter)];
                         */
                        mlfAssign(
                          &CommentExtension,
                          mlfHorzcat(
                            mclVv(CommentExtension, "CommentExtension"),
                            mclVe(mlfChar(mclVv(letter, "letter"), NULL)),
                            NULL));
                    /*
                     * end
                     */
                    }
                /*
                 * otherwise
                 */
                } else {
                    /*
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg = 'Corrupt GIF file';
                     */
                    mlfAssign(msg, _mxarray42_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                /*
                 * end
                 */
                }
                mxDestroyArray(v_);
            }
        /*
         * elseif (separator == 44)   
         */
        } else if (mclEqBool(mclVv(separator, "separator"), _mxarray44_)) {
            /*
             * k = k+1;
             */
            mlfAssign(&k, mclPlus(mclVv(k, "k"), _mxarray28_));
            /*
             * % First, fill in all the fields that aren't dependent on a Local Color Table
             * info(k).Filename = filename;
             */
            mlfIndexAssign(
              &info,
              "(?).Filename",
              mclVsv(k, "k"),
              mclVsa(filename, "filename"));
            /*
             * info(k).FileModDate = s.date;
             */
            mlfIndexAssign(
              &info,
              "(?).FileModDate",
              mclVsv(k, "k"),
              mlfIndexRef(mclVsv(s, "s"), ".date"));
            /*
             * info(k).FileSize = s.bytes;
             */
            mlfIndexAssign(
              &info,
              "(?).FileSize",
              mclVsv(k, "k"),
              mlfIndexRef(mclVsv(s, "s"), ".bytes"));
            /*
             * info(k).Format = char(GIFheader(1:3));
             */
            mlfIndexAssign(
              &info,
              "(?).Format",
              mclVsv(k, "k"),
              mlfChar(
                mclVe(
                  mclArrayRef1(
                    mclVsv(GIFheader, "GIFheader"),
                    mlfColon(_mxarray28_, _mxarray13_, NULL))),
                NULL));
            /*
             * info(k).FormatVersion = char(GIFheader(4:6));
             */
            mlfIndexAssign(
              &info,
              "(?).FormatVersion",
              mclVsv(k, "k"),
              mlfChar(
                mclVe(
                  mclArrayRef1(
                    mclVsv(GIFheader, "GIFheader"),
                    mlfColon(_mxarray45_, _mxarray21_, NULL))),
                NULL));
            /*
             * info(k).ColorType = 'indexed';
             */
            mlfIndexAssign(&info, "(?).ColorType", mclVsv(k, "k"), _mxarray46_);
            /*
             * info(k).FormatSignature = [info(k).Format info(k).FormatVersion];
             */
            mlfIndexAssign(
              &info,
              "(?).FormatSignature",
              mclVsv(k, "k"),
              mlfHorzcat(
                mclVe(
                  mlfIndexRef(
                    mclVsv(info, "info"), "(?).Format", mclVsv(k, "k"))),
                mclVe(
                  mlfIndexRef(
                    mclVsv(info, "info"), "(?).FormatVersion", mclVsv(k, "k"))),
                NULL));
            /*
             * 
             * % If GlobalColorTable Flag is set to 0, then Background Color is null.
             * if bitget(PackedByte,8) == 0
             */
            if (mclEqBool(
                  mclVe(
                    mlfBitget(mclVv(PackedByte, "PackedByte"), _mxarray27_)),
                  _mxarray18_)) {
                /*
                 * info(k).BackgroundColor = [];
                 */
                mlfIndexAssign(
                  &info, "(?).BackgroundColor", mclVsv(k, "k"), _mxarray4_);
            /*
             * else
             */
            } else {
                /*
                 * info(k).BackgroundColor = LogicalScreenDescriptor(2);
                 */
                mlfIndexAssign(
                  &info,
                  "(?).BackgroundColor",
                  mclVsv(k, "k"),
                  mclIntArrayRef1(
                    mclVsv(LogicalScreenDescriptor, "LogicalScreenDescriptor"),
                    2));
            /*
             * end
             */
            }
            /*
             * info(k).AspectRatio = LogicalScreenDescriptor(3);
             */
            mlfIndexAssign(
              &info,
              "(?).AspectRatio",
              mclVsv(k, "k"),
              mclIntArrayRef1(
                mclVsv(LogicalScreenDescriptor, "LogicalScreenDescriptor"), 3));
            /*
             * 
             * % Now fill in the fields which we must first check for a Local Image Descriptor
             * LocalID = fread(fid,4,'uint16');
             */
            mlfAssign(
              &LocalID,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray45_, _mxarray23_, NULL));
            /*
             * LocalPacked = fread(fid,1,'uint8');
             */
            mlfAssign(
              &LocalPacked,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray28_, _mxarray25_, NULL));
            /*
             * 
             * % Account for reading in an extra byte.
             * fread(fid,1,'uint8');
             */
            mclAssignAns(
              &ans,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray28_, _mxarray25_, NULL));
            /*
             * 
             * info(k).Width = LocalID(3);
             */
            mlfIndexAssign(
              &info,
              "(?).Width",
              mclVsv(k, "k"),
              mclIntArrayRef1(mclVsv(LocalID, "LocalID"), 3));
            /*
             * info(k).Height = LocalID(4);
             */
            mlfIndexAssign(
              &info,
              "(?).Height",
              mclVsv(k, "k"),
              mclIntArrayRef1(mclVsv(LocalID, "LocalID"), 4));
            /*
             * 
             * % Is it interlaced?
             * if (bitget(LocalPacked,7) == 1)
             */
            if (mclEqBool(
                  mclVe(
                    mlfBitget(mclVv(LocalPacked, "LocalPacked"), _mxarray48_)),
                  _mxarray28_)) {
                /*
                 * info(k).Interlaced = 'yes';
                 */
                mlfIndexAssign(
                  &info, "(?).Interlaced", mclVsv(k, "k"), _mxarray49_);
            /*
             * else
             */
            } else {
                /*
                 * info(k).Interlaced = 'no';
                 */
                mlfIndexAssign(
                  &info, "(?).Interlaced", mclVsv(k, "k"), _mxarray51_);
            /*
             * end
             */
            }
            /*
             * 
             * % Check and see if we have a Local Color Table
             * LCTbool = bitget(LocalPacked,8)==1;
             */
            mlfAssign(
              &LCTbool,
              mclEq(
                mclVe(
                  mlfBitget(mclVv(LocalPacked, "LocalPacked"), _mxarray27_)),
                _mxarray28_));
            /*
             * if LCTbool
             */
            if (mlfTobool(mclVv(LCTbool, "LCTbool"))) {
                /*
                 * Localbitdepth = bitget(LocalPacked,1:3);
                 */
                mlfAssign(
                  &Localbitdepth,
                  mlfBitget(mclVv(LocalPacked, "LocalPacked"), _mxarray29_));
                /*
                 * Localbitdepth = sum(Localbitdepth.*[1 2 4]) + 1; 
                 */
                mlfAssign(
                  &Localbitdepth,
                  mclPlus(
                    mclVe(
                      mlfSum(
                        mclTimes(
                          mclVv(Localbitdepth, "Localbitdepth"), _mxarray31_),
                        NULL)),
                    _mxarray28_));
                /*
                 * info(k).BitDepth = Localbitdepth;
                 */
                mlfIndexAssign(
                  &info,
                  "(?).BitDepth",
                  mclVsv(k, "k"),
                  mclVsv(Localbitdepth, "Localbitdepth"));
                /*
                 * ltable = fread(fid,3*bitshift(1,Localbitdepth),'uint8');
                 */
                mlfAssign(
                  &ltable,
                  mlfFread(
                    NULL,
                    mclVv(fid, "fid"),
                    mclMtimes(
                      _mxarray13_,
                      mclVe(
                        mlfBitshift(
                          _mxarray28_,
                          mclVv(Localbitdepth, "Localbitdepth"),
                          NULL))),
                    _mxarray25_,
                    NULL));
                /*
                 * info(k).ColorTable = reshape(ltable,3,length(ltable)/3)'./255;
                 */
                mlfIndexAssign(
                  &info,
                  "(?).ColorTable",
                  mclVsv(k, "k"),
                  mclRdivide(
                    mlfCtranspose(
                      mclVe(
                        mlfReshape(
                          mclVv(ltable, "ltable"),
                          _mxarray13_,
                          mclMrdivide(
                            mlfScalar(mclLengthInt(mclVv(ltable, "ltable"))),
                            _mxarray13_),
                          NULL))),
                    _mxarray33_));
            /*
             * elseif GCTbool
             */
            } else if (mlfTobool(mclVv(GCTbool, "GCTbool"))) {
                /*
                 * % use the Global Color Table
                 * info(k).BitDepth = bitdepth;
                 */
                mlfIndexAssign(
                  &info,
                  "(?).BitDepth",
                  mclVsv(k, "k"),
                  mclVsv(bitdepth, "bitdepth"));
                /*
                 * info(k).ColorTable = GlobalColorTable;   
                 */
                mlfIndexAssign(
                  &info,
                  "(?).ColorTable",
                  mclVsv(k, "k"),
                  mclVsv(GlobalColorTable, "GlobalColorTable"));
            /*
             * else
             */
            } else {
                /*
                 * % use a default color table
                 * info(k).ColorTable = [0 0 0;1 1 1];
                 */
                mlfIndexAssign(
                  &info, "(?).ColorTable", mclVsv(k, "k"), _mxarray53_);
                /*
                 * info(k).BitDepth = 1;
                 */
                mlfIndexAssign(
                  &info, "(?).BitDepth", mclVsv(k, "k"), _mxarray28_);
            /*
             * end
             */
            }
            /*
             * 
             * % fseek past the Image data 
             * countByte = fread(fid,1,'uint8');
             */
            mlfAssign(
              &countByte,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray28_, _mxarray25_, NULL));
            /*
             * fseek(fid,countByte,'cof');
             */
            mclAssignAns(
              &ans,
              mlfFseek(
                mclVv(fid, "fid"), mclVv(countByte, "countByte"), _mxarray37_));
        /*
         * 
         * else
         */
        } else {
            /*
             * % separator is another countByte for image data block and we have to go past it
             * fseek(fid,separator,'cof');
             */
            mclAssignAns(
              &ans,
              mlfFseek(
                mclVv(fid, "fid"), mclVv(separator, "separator"), _mxarray37_));
        /*
         * end  %%% IF
         */
        }
        /*
         * separator = fread(fid,1,'uint8');   
         */
        mlfAssign(
          &separator,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray28_, _mxarray25_, NULL));
    /*
     * end  %%% WHILE
     */
    }
    /*
     * 
     * numImages = k;
     */
    mlfAssign(&numImages, mclVsv(k, "k"));
    /*
     * if ~isempty(CommentExtension)
     */
    if (mclNotBool(
          mclVe(mlfIsempty(mclVv(CommentExtension, "CommentExtension"))))) {
        /*
         * for i = 1:numImages
         */
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(numImages, "numImages"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray4_);
        } else {
            /*
             * info(i).CommentExtension = CommentExtension;
             * end
             */
            for (; ; ) {
                mlfIndexAssign(
                  &info,
                  "(?).CommentExtension",
                  mlfScalar(v_),
                  mclVsv(CommentExtension, "CommentExtension"));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (numImages == 0)
     */
    if (mclEqBool(mclVv(numImages, "numImages"), _mxarray18_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'No images found in GIF file';
         */
        mlfAssign(msg, _mxarray55_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * fclose(fid);
     */
    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/imgifinfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/imgifinfo");
    mxDestroyArray(fid);
    mxDestroyArray(m);
    mxDestroyArray(s);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(GIFheader);
    mxDestroyArray(ScreenSize);
    mxDestroyArray(LogicalScreenDescriptor);
    mxDestroyArray(PackedByte);
    mxDestroyArray(GCTbool);
    mxDestroyArray(sizeGCT);
    mxDestroyArray(bitdepth);
    mxDestroyArray(table);
    mxDestroyArray(GlobalColorTable);
    mxDestroyArray(k);
    mxDestroyArray(CommentExtension);
    mxDestroyArray(separator);
    mxDestroyArray(blockLabel);
    mxDestroyArray(countByte);
    mxDestroyArray(letter);
    mxDestroyArray(LocalID);
    mxDestroyArray(LocalPacked);
    mxDestroyArray(LCTbool);
    mxDestroyArray(Localbitdepth);
    mxDestroyArray(ltable);
    mxDestroyArray(numImages);
    mxDestroyArray(i);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
