/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readcur.h"
#include "imfinfo.h"
#include "iofun_private_readbmpdata.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'c', 'u', 'r', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'c', 'u', 'r', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '3', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'c', 'u', 'r', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'c', 'u', 'r', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't',
                                's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[42] = { 'R', 'e', 'q', 'u', 'i', 'r', 'e', 's', ' ',
                               'a', ' ', 's', 't', 'r', 'i', 'n', 'g', ' ',
                               'f', 'i', 'l', 'e', 'n', 'a', 'm', 'e', ' ',
                               'a', 's', ' ', 'a', 'n', ' ', 'a', 'r', 'g',
                               'u', 'm', 'e', 'n', 't', '.' };
static mxArray * _mxarray6_;

static mxChar _array9_[1] = { '.' };
static mxArray * _mxarray8_;

static mxChar _array11_[4] = { '.', 'c', 'u', 'r' };
static mxArray * _mxarray10_;

static mxChar _array13_[3] = { 'c', 'u', 'r' };
static mxArray * _mxarray12_;

static mxChar _array15_[18] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ', 'o',
                                'p', 't', 'i', 'o', 'n', ':', ' ', '%', 's' };
static mxArray * _mxarray14_;

static mxChar _array17_[36] = { 'C', 'u', 'r', 's', 'o', 'r', ' ', 'i', 'n',
                                'd', 'e', 'x', ' ', 'i', 's', ' ', '1', '-',
                                'b', 'a', 's', 'e', 'd', ' ', 'n', 'o', 't',
                                ' ', '0', '-', 'b', 'a', 's', 'e', 'd', '.' };
static mxArray * _mxarray16_;

static mxChar _array19_[69] = { 'C', 'a', 'n', 'n', 'o', 't', ' ', 'r', 'e',
                                'a', 'd', ' ', 'c', 'u', 'r', 's', 'o', 'r',
                                ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', '%',
                                'd', ' ', 's', 'i', 'n', 'c', 'e', ' ', '%',
                                '.', '9', '0', '0', 's', ' ', 'o', 'n', 'l',
                                'y', ' ', 'c', 'o', 'n', 't', 'a', 'i', 'n',
                                's', ' ', '%', 'd', ' ', 'c', 'u', 'r', 's',
                                'o', 'r', 's', '.', 0x005c, 'n' };
static mxArray * _mxarray18_;
static mxArray * _mxarray20_;
static mxArray * _mxarray21_;

void InitializeModule_iofun_private_readcur(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeDouble(2.0);
    _mxarray6_ = mclInitializeString(42, _array7_);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(4, _array11_);
    _mxarray12_ = mclInitializeString(3, _array13_);
    _mxarray14_ = mclInitializeString(18, _array15_);
    _mxarray16_ = mclInitializeString(36, _array17_);
    _mxarray18_ = mclInitializeString(69, _array19_);
    _mxarray20_ = mclInitializeDouble(32.0);
    _mxarray21_ = mclInitializeDouble(8.0);
}

void TerminateModule_iofun_private_readcur(void) {
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_readcur(mxArray * * map,
                                        mxArray * * mask,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * index);

_mexLocalFunctionTable _local_function_table_iofun_private_readcur
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_readcur" contains the normal interface for
 * the "iofun/private/readcur" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readcur.m" (lines 1-75). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readcur(mxArray * * map,
                                   mxArray * * mask,
                                   mxArray * filename,
                                   mxArray * index) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mxArray * mask__ = mclGetUninitializedArray();
    mlfEnterNewContext(2, 2, map, mask, filename, index);
    if (map != NULL) {
        ++nargout;
    }
    if (mask != NULL) {
        ++nargout;
    }
    X = Miofun_private_readcur(&map__, &mask__, nargout, filename, index);
    mlfRestorePreviousContext(2, 2, map, mask, filename, index);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    if (mask != NULL) {
        mclCopyOutputArg(mask, mask__);
    } else {
        mxDestroyArray(mask__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlxIofun_private_readcur" contains the feval interface for the
 * "iofun/private/readcur" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readcur.m" (lines 1-75). The
 * feval function calls the implementation version of iofun/private/readcur
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readcur(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[3];
    int i;
    if (nlhs > 3) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 3; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0]
      = Miofun_private_readcur(&mplhs[1], &mplhs[2], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 3 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 3; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_readcur" is the implementation version of the
 * "iofun/private/readcur" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readcur.m" (lines 1-75). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [X, map, mask] = readcur(filename, index)
 */
static mxArray * Miofun_private_readcur(mxArray * * map,
                                        mxArray * * mask,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * index) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readcur);
    int nargin_ = mclNargin(2, filename, index, NULL);
    mxArray * X = mclGetUninitializedArray();
    mxArray * imsize = mclGetUninitializedArray();
    mxArray * maskinfo = mclGetUninitializedArray();
    mxArray * msg = mclGetUninitializedArray();
    mxArray * info = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&index);
    /*
     * %READCUR Read cursor from a Windows CUR file
     * %   [X,MAP] = READCUR(FILENAME) reads image data from a CUR file
     * %   containing one or more Microsoft Windows cursor resources.  X
     * %   is a 2-D uint8 array.  MAP is an M-by-3 MATLAB colormap.  If
     * %   FILENAME contains more than one cursor resource, the first will
     * %   be read.
     * %
     * %   [X,MAP] = READCUR(FILENAME,INDEX) reads the cursor in position
     * %   INDEX from FILENAME, which contains multiple cursors.
     * %
     * %   [X,MAP,MASK] = READCUR(FILENAME,...) returns the transperency mask
     * %   for the given image from FILENAME.
     * %
     * %   Note: By default Microsoft Windows cursor resources are 32-by-32
     * %   pixels.  MATLAB requires that pointers be 16-by-16.  Images read
     * %   with READCUR will likely need to be scaled.  The IMRESIZE function
     * %   in the Image Processing Toolbox may be helpful.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc.
     * %   $Revision: 1.3 $  $Date: 2000/06/01 04:17:19 $
     * %   $ Revision $  $ Date $
     * 
     * error(nargchk(1, 2, nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray4_, _mxarray5_, mlfScalar(nargin_))));
    /*
     * 
     * if (nargin < 2)
     */
    if (nargin_ < 2) {
        /*
         * index = 1;
         */
        mlfAssign(&index, _mxarray4_);
    /*
     * end
     */
    }
    /*
     * 
     * if (~ischar(filename))
     */
    if (mclNotBool(mclVe(mlfIschar(mclVa(filename, "filename"))))) {
        /*
         * error('Requires a string filename as an argument.');
         */
        mlfError(_mxarray6_);
    /*
     * end;
     */
    }
    /*
     * 
     * if (isempty(findstr(filename,'.')))
     */
    if (mlfTobool(
          mclVe(
            mlfIsempty(
              mclVe(mlfFindstr(mclVa(filename, "filename"), _mxarray8_)))))) {
        /*
         * filename=[filename,'.cur'];
         */
        mlfAssign(
          &filename,
          mlfHorzcat(mclVa(filename, "filename"), _mxarray10_, NULL));
    /*
     * end;
     */
    }
    /*
     * 
     * [info, msg] = imfinfo(filename, 'cur');
     */
    mlfAssign(
      &info, mlfNImfinfo(2, &msg, mclVa(filename, "filename"), _mxarray12_));
    /*
     * 
     * if (isempty(info))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(info, "info"))))) {
        /*
         * error(msg)
         */
        mlfError(mclVv(msg, "msg"));
    /*
     * end
     */
    }
    /*
     * 
     * if (ischar(index))
     */
    if (mlfTobool(mclVe(mlfIschar(mclVa(index, "index"))))) {
        /*
         * msg = sprintf('Unknown option: %s', index);
         */
        mlfAssign(
          &msg, mlfSprintf(NULL, _mxarray14_, mclVa(index, "index"), NULL));
        /*
         * error(msg);
         */
        mlfError(mclVv(msg, "msg"));
    /*
     * end
     */
    }
    /*
     * 
     * if (index < 1)
     */
    if (mclLtBool(mclVa(index, "index"), _mxarray4_)) {
        /*
         * error('Cursor index is 1-based not 0-based.')
         */
        mlfError(_mxarray16_);
    /*
     * end	
     */
    }
    /*
     * 
     * if (index > length(info))
     */
    if (mclGtBool(
          mclVa(index, "index"),
          mlfScalar(mclLengthInt(mclVv(info, "info"))))) {
        /*
         * msg = sprintf('Cannot read cursor number %d since %.900s only contains %d cursors.\n', index, filename, length(info));
         */
        mlfAssign(
          &msg,
          mlfSprintf(
            NULL,
            _mxarray18_,
            mclVa(index, "index"),
            mclVa(filename, "filename"),
            mlfScalar(mclLengthInt(mclVv(info, "info"))),
            NULL));
        /*
         * error(msg)
         */
        mlfError(mclVv(msg, "msg"));
    /*
     * end
     */
    }
    /*
     * 
     * % Read the XOR data and its colormap
     * X = readbmpdata(info(index));
     */
    mlfAssign(
      &X,
      mlfIofun_private_readbmpdata(
        mclVe(mclArrayRef1(mclVsv(info, "info"), mclVsa(index, "index")))));
    /*
     * 
     * map = info(index).Colormap;
     */
    mlfAssign(
      map,
      mlfIndexRef(
        mclVsv(info, "info"), "(?).Colormap", mclVsa(index, "index")));
    /*
     * 
     * maskinfo = info(index);
     */
    mlfAssign(
      &maskinfo, mclArrayRef1(mclVsv(info, "info"), mclVsa(index, "index")));
    /*
     * maskinfo.BitDepth = 1;
     */
    mlfIndexAssign(&maskinfo, ".BitDepth", _mxarray4_);
    /*
     * 
     * % Caluculate the offset of the AND mask.
     * % Bitmap scanlines are aligned on 4 byte boundaries
     * imsize = maskinfo.Height * (32 * ceil(maskinfo.Width / 32))/8;
     */
    mlfAssign(
      &imsize,
      mclMrdivide(
        mclFeval(
          mclValueVarargout(),
          mlxMtimes,
          mclVe(mlfIndexRef(mclVsv(maskinfo, "maskinfo"), ".Height")),
          mclMtimes(
            _mxarray20_,
            mclVe(
              mlfCeil(
                mclFeval(
                  mclValueVarargout(),
                  mlxMrdivide,
                  mclVe(mlfIndexRef(mclVsv(maskinfo, "maskinfo"), ".Width")),
                  _mxarray20_,
                  NULL)))),
          NULL),
        _mxarray21_));
    /*
     * maskinfo.ImageDataOffset = maskinfo.ResourceDataOffset + ...
     */
    mlfIndexAssign(
      &maskinfo,
      ".ImageDataOffset",
      mclMinus(
        mclFeval(
          mclValueVarargout(),
          mlxPlus,
          mclVe(
            mlfIndexRef(mclVsv(maskinfo, "maskinfo"), ".ResourceDataOffset")),
          mclVe(mlfIndexRef(mclVsv(maskinfo, "maskinfo"), ".ResourceSize")),
          NULL),
        mclVv(imsize, "imsize")));
    /*
     * maskinfo.ResourceSize - imsize;
     * 
     * mask = readbmpdata(maskinfo);
     */
    mlfAssign(mask, mlfIofun_private_readbmpdata(mclVv(maskinfo, "maskinfo")));
    mclValidateOutput(X, 1, nargout_, "X", "iofun/private/readcur");
    mclValidateOutput(*map, 2, nargout_, "map", "iofun/private/readcur");
    mclValidateOutput(*mask, 3, nargout_, "mask", "iofun/private/readcur");
    mxDestroyArray(ans);
    mxDestroyArray(info);
    mxDestroyArray(msg);
    mxDestroyArray(maskinfo);
    mxDestroyArray(imsize);
    mxDestroyArray(index);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
}
