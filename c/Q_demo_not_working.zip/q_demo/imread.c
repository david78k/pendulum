/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "imread.h"
#include "iofun_private_imftype.h"
#include "iofun_private_readbmp.h"
#include "iofun_private_readcur.h"
#include "iofun_private_readgif.h"
#include "iofun_private_readhdf.h"
#include "iofun_private_readico.h"
#include "iofun_private_readjpg.h"
#include "iofun_private_readpcx.h"
#include "iofun_private_readpng.h"
#include "iofun_private_readtif.h"
#include "iofun_private_readxwd.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[130] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'r', 'e', 'a',
                                'd', ' ', 'L', 'i', 'n', 'e', ':', ' ', '1',
                                ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                'r', 'e', 'a', 'd', '"', ' ', 'w', 'a', 's',
                                ' ', 'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w',
                                'i', 't', 'h', ' ', 'm', 'o', 'r', 'e', ' ',
                                't', 'h', 'a', 'n', ' ', 't', 'h', 'e', ' ',
                                'd', 'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ',
                                'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f',
                                ' ', 'o', 'u', 't', 'p', 'u', 't', 's', ' ',
                                '(', '3', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[158] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'r', 'e', 'a',
                                'd', '/', 'p', 'a', 'r', 's', 'e', '_', 'i',
                                'n', 'p', 'u', 't', 's', ' ', 'L', 'i', 'n',
                                'e', ':', ' ', '2', '7', '2', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'm', 'r', 'e', 'a',
                                'd', '/', 'p', 'a', 'r', 's', 'e', '_', 'i',
                                'n', 'p', 'u', 't', 's', '"', ' ', 'w', 'a',
                                's', ' ', 'c', 'a', 'l', 'l', 'e', 'd', ' ',
                                'w', 'i', 't', 'h', ' ', 'm', 'o', 'r', 'e',
                                ' ', 't', 'h', 'a', 'n', ' ', 't', 'h', 'e',
                                ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e', 'd',
                                ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o',
                                'f', ' ', 'o', 'u', 't', 'p', 'u', 't', 's',
                                ' ', '(', '4', ')', '.' };
static mxArray * _mxarray2_;

static mxChar _array5_[1] = { 'r' };
static mxArray * _mxarray4_;
static mxArray * _mxarray6_;

static mxChar _array8_[90] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'o', 'p', 'e',
                               'n', ' ', 'f', 'i', 'l', 'e', ' ', '"', '%',
                               's', '"', ' ', 'f', 'o', 'r', ' ', 'r', 'e',
                               'a', 'd', 'i', 'n', 'g', ';', 0x005c, 'n', ' ',
                               'i', 't', ' ', 'm', 'a', 'y', ' ', 'n', 'o',
                               't', ' ', 'e', 'x', 'i', 's', 't', ',', ' ',
                               'o', 'r', ' ', 'y', 'o', 'u', ' ', 'm', 'a',
                               'y', ' ', 'n', 'o', 't', ' ', 'h', 'a', 'v',
                               'e', ' ', 'r', 'e', 'a', 'd', ' ', 'p', 'e',
                               'r', 'm', 'i', 's', 's', 'i', 'o', 'n', '.' };
static mxArray * _mxarray7_;

static mxChar _array10_[35] = { 'U', 'n', 'a', 'b', 'l', 'e', ' ', 't', 'o',
                                ' ', 'd', 'e', 't', 'e', 'r', 'm', 'i', 'n',
                                'e', ' ', 't', 'h', 'e', ' ', 'f', 'i', 'l',
                                'e', ' ', 'f', 'o', 'r', 'm', 'a', 't' };
static mxArray * _mxarray9_;

static mxChar _array12_[3] = { 't', 'i', 'f' };
static mxArray * _mxarray11_;

static mxChar _array14_[4] = { '.', 't', 'i', 'f' };
static mxArray * _mxarray13_;

static mxChar _array16_[5] = { '.', 't', 'i', 'f', 'f' };
static mxArray * _mxarray15_;

static mxChar _array18_[3] = { 'b', 'm', 'p' };
static mxArray * _mxarray17_;

static mxChar _array20_[4] = { '.', 'b', 'm', 'p' };
static mxArray * _mxarray19_;

static mxChar _array22_[3] = { 'h', 'd', 'f' };
static mxArray * _mxarray21_;

static mxChar _array24_[4] = { '.', 'h', 'd', 'f' };
static mxArray * _mxarray23_;

static mxChar _array26_[3] = { 'p', 'c', 'x' };
static mxArray * _mxarray25_;

static mxChar _array28_[4] = { '.', 'p', 'c', 'x' };
static mxArray * _mxarray27_;

static mxChar _array30_[3] = { 'x', 'w', 'd' };
static mxArray * _mxarray29_;

static mxChar _array32_[4] = { '.', 'x', 'w', 'd' };
static mxArray * _mxarray31_;

static mxChar _array34_[3] = { 'j', 'p', 'g' };
static mxArray * _mxarray33_;

static mxChar _array36_[4] = { '.', 'j', 'p', 'g' };
static mxArray * _mxarray35_;

static mxChar _array38_[5] = { '.', 'j', 'p', 'e', 'g' };
static mxArray * _mxarray37_;

static mxChar _array40_[3] = { 'p', 'n', 'g' };
static mxArray * _mxarray39_;

static mxChar _array42_[4] = { '.', 'p', 'n', 'g' };
static mxArray * _mxarray41_;

static mxChar _array44_[3] = { 'g', 'i', 'f' };
static mxArray * _mxarray43_;

static mxChar _array46_[4] = { '.', 'g', 'i', 'f' };
static mxArray * _mxarray45_;

static mxChar _array48_[3] = { 'c', 'u', 'r' };
static mxArray * _mxarray47_;

static mxChar _array50_[4] = { '.', 'c', 'u', 'r' };
static mxArray * _mxarray49_;

static mxChar _array52_[3] = { 'i', 'c', 'o' };
static mxArray * _mxarray51_;

static mxChar _array54_[4] = { '.', 'i', 'c', 'o' };
static mxArray * _mxarray53_;

static mxChar _array56_[32] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'o', 'p',
                                'e', 'n', ' ', 'f', 'i', 'l', 'e', ' ',
                                '"', '%', 's', '"', ' ', 'f', 'o', 'r',
                                ' ', 'r', 'e', 'a', 'd', 'i', 'n', 'g' };
static mxArray * _mxarray55_;
static mxArray * _mxarray57_;

static mxChar _array59_[39] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                'i', 'z', 'e', 'd', ' ', 'o', 'r', ' ',
                                'u', 'n', 's', 'u', 'p', 'p', 'o', 'r',
                                't', 'e', 'd', ' ', 'f', 'o', 'r', 'm',
                                'a', 't', ' ', '"', '%', 's', '"' };
static mxArray * _mxarray58_;
static mxArray * _mxarray60_;
static mxArray * _mxarray61_;

static mxChar _array63_[30] = { 'b', 'x', 'p', 'h', 't', 'j', 'p', 'g',
                                'c', 'i', 'm', 'w', 'c', 'd', 'i', 'p',
                                'n', 'i', 'u', 'c', 'p', 'd', 'x', 'f',
                                'f', 'g', 'g', 'f', 'r', 'o' };
static mxArray * _mxarray62_;
static mxArray * _mxarray64_;

static mxChar _array66_[23] = { 'T', 'o', 'o', ' ', 'f', 'e', 'w', ' ',
                                'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray65_;
static mxArray * _mxarray67_;
static mxArray * _mxarray68_;

static mxChar _array70_[4] = { 't', 'i', 'f', 'f' };
static mxArray * _mxarray69_;

static mxChar _array72_[4] = { 'j', 'p', 'e', 'g' };
static mxArray * _mxarray71_;

static mxChar _array74_[5] = { 'e', 'x', 'a', 'c', 't' };
static mxArray * _mxarray73_;
static mxArray * _mxarray75_;

void InitializeModule_imread(void) {
    _mxarray0_ = mclInitializeString(130, _array1_);
    _mxarray2_ = mclInitializeString(158, _array3_);
    _mxarray4_ = mclInitializeString(1, _array5_);
    _mxarray6_ = mclInitializeDouble(-1.0);
    _mxarray7_ = mclInitializeString(90, _array8_);
    _mxarray9_ = mclInitializeString(35, _array10_);
    _mxarray11_ = mclInitializeString(3, _array12_);
    _mxarray13_ = mclInitializeString(4, _array14_);
    _mxarray15_ = mclInitializeString(5, _array16_);
    _mxarray17_ = mclInitializeString(3, _array18_);
    _mxarray19_ = mclInitializeString(4, _array20_);
    _mxarray21_ = mclInitializeString(3, _array22_);
    _mxarray23_ = mclInitializeString(4, _array24_);
    _mxarray25_ = mclInitializeString(3, _array26_);
    _mxarray27_ = mclInitializeString(4, _array28_);
    _mxarray29_ = mclInitializeString(3, _array30_);
    _mxarray31_ = mclInitializeString(4, _array32_);
    _mxarray33_ = mclInitializeString(3, _array34_);
    _mxarray35_ = mclInitializeString(4, _array36_);
    _mxarray37_ = mclInitializeString(5, _array38_);
    _mxarray39_ = mclInitializeString(3, _array40_);
    _mxarray41_ = mclInitializeString(4, _array42_);
    _mxarray43_ = mclInitializeString(3, _array44_);
    _mxarray45_ = mclInitializeString(4, _array46_);
    _mxarray47_ = mclInitializeString(3, _array48_);
    _mxarray49_ = mclInitializeString(4, _array50_);
    _mxarray51_ = mclInitializeString(3, _array52_);
    _mxarray53_ = mclInitializeString(4, _array54_);
    _mxarray55_ = mclInitializeString(32, _array56_);
    _mxarray57_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray58_ = mclInitializeString(39, _array59_);
    _mxarray60_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray61_ = mclInitializeCellVector(0, 0, (mxArray * *)NULL);
    _mxarray62_ = mclInitializeCharVector(10, 3, _array63_);
    _mxarray64_ = mclInitializeDouble(0.0);
    _mxarray65_ = mclInitializeString(23, _array66_);
    _mxarray67_ = mclInitializeDouble(1.0);
    _mxarray68_ = mclInitializeDouble(2.0);
    _mxarray69_ = mclInitializeString(4, _array70_);
    _mxarray71_ = mclInitializeString(4, _array72_);
    _mxarray73_ = mclInitializeString(5, _array74_);
    _mxarray75_ = mclInitializeDouble(3.0);
}

void TerminateModule_imread(void) {
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImread_parse_inputs(mxArray * * format,
                                        mxArray * * extraArgs,
                                        mxArray * * msg,
                                        ...);
static void mlxImread_parse_inputs(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]);
static mxArray * Mimread(mxArray * * map,
                         mxArray * * alpha,
                         int nargout_,
                         mxArray * varargin);
static mxArray * Mimread_parse_inputs(mxArray * * format,
                                      mxArray * * extraArgs,
                                      mxArray * * msg,
                                      int nargout_,
                                      mxArray * varargin);

static mexFunctionTableEntry local_function_table_[1]
  = { { "parse_inputs", mlxImread_parse_inputs, -1, 4, NULL } };

_mexLocalFunctionTable _local_function_table_imread
  = { 1, local_function_table_ };

/*
 * The function "mlfNImread" contains the nargout interface for the "imread"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines
 * 1-272). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNImread(int nargout, mxArray * * map, mxArray * * alpha, ...) {
    mxArray * varargin = NULL;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mxArray * alpha__ = mclGetUninitializedArray();
    mlfVarargin(&varargin, alpha, 0);
    mlfEnterNewContext(2, -1, map, alpha, varargin);
    X = Mimread(&map__, &alpha__, nargout, varargin);
    mlfRestorePreviousContext(2, 0, map, alpha);
    mxDestroyArray(varargin);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    if (alpha != NULL) {
        mclCopyOutputArg(alpha, alpha__);
    } else {
        mxDestroyArray(alpha__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlfImread" contains the normal interface for the "imread"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines
 * 1-272). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImread(mxArray * * map, mxArray * * alpha, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mxArray * alpha__ = mclGetUninitializedArray();
    mlfVarargin(&varargin, alpha, 0);
    mlfEnterNewContext(2, -1, map, alpha, varargin);
    if (map != NULL) {
        ++nargout;
    }
    if (alpha != NULL) {
        ++nargout;
    }
    X = Mimread(&map__, &alpha__, nargout, varargin);
    mlfRestorePreviousContext(2, 0, map, alpha);
    mxDestroyArray(varargin);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    if (alpha != NULL) {
        mclCopyOutputArg(alpha, alpha__);
    } else {
        mxDestroyArray(alpha__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlfVImread" contains the void interface for the "imread"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines
 * 1-272). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVImread(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * X = NULL;
    mxArray * map = NULL;
    mxArray * alpha = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    X = Mimread(&map, &alpha, 0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    mxDestroyArray(X);
    mxDestroyArray(map);
}

/*
 * The function "mlxImread" contains the feval interface for the "imread"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines
 * 1-272). The feval function calls the implementation version of imread
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImread(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[3];
    int i;
    if (nlhs > 3) {
        mlfError(_mxarray0_);
    }
    for (i = 0; i < 3; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimread(&mplhs[1], &mplhs[2], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 3 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 3; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImread_parse_inputs" contains the normal interface for the
 * "imread/parse_inputs" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines 272-323). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static mxArray * mlfImread_parse_inputs(mxArray * * format,
                                        mxArray * * extraArgs,
                                        mxArray * * msg,
                                        ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * filename = mclGetUninitializedArray();
    mxArray * format__ = mclGetUninitializedArray();
    mxArray * extraArgs__ = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfVarargin(&varargin, msg, 0);
    mlfEnterNewContext(3, -1, format, extraArgs, msg, varargin);
    if (format != NULL) {
        ++nargout;
    }
    if (extraArgs != NULL) {
        ++nargout;
    }
    if (msg != NULL) {
        ++nargout;
    }
    filename
      = Mimread_parse_inputs(
          &format__, &extraArgs__, &msg__, nargout, varargin);
    mlfRestorePreviousContext(3, 0, format, extraArgs, msg);
    mxDestroyArray(varargin);
    if (format != NULL) {
        mclCopyOutputArg(format, format__);
    } else {
        mxDestroyArray(format__);
    }
    if (extraArgs != NULL) {
        mclCopyOutputArg(extraArgs, extraArgs__);
    } else {
        mxDestroyArray(extraArgs__);
    }
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(filename);
}

/*
 * The function "mlxImread_parse_inputs" contains the feval interface for the
 * "imread/parse_inputs" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines 272-323). The feval
 * function calls the implementation version of imread/parse_inputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImread_parse_inputs(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[4];
    int i;
    if (nlhs > 4) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 4; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mimread_parse_inputs(&mplhs[1], &mplhs[2], &mplhs[3], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 4 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 4; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mimread" is the implementation version of the "imread"
 * M-function from file "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines
 * 1-272). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [X, map, alpha] = imread(varargin)
 */
static mxArray * Mimread(mxArray * * map,
                         mxArray * * alpha,
                         int nargout_,
                         mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_imread);
    mxArray * X = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * msg = mclGetUninitializedArray();
    mxArray * extraArgs = mclGetUninitializedArray();
    mxArray * format = mclGetUninitializedArray();
    mxArray * filename = mclGetUninitializedArray();
    mclCopyArray(&varargin);
    /*
     * %IMREAD Read image from graphics file.
     * %   A = IMREAD(FILENAME,FMT) reads the image in FILENAME into
     * %   A. If the file contains a grayscale intensity image, A is
     * %   a two-dimensional array.  If the file contains a truecolor
     * %   (RGB) image, A is a three-dimensional (M-by-N-by-3) array.
     * %   FILENAME is a string that specifies the name of the
     * %   graphics file, and FMT is a string that specifies the
     * %   format of the file.  The file must be in the current
     * %   directory or in a directory on the MATLAB path.  If IMREAD
     * %   cannot find a file named FILENAME, it looks for a file
     * %   named FILENAME.FMT.
     * %
     * %   The possible values for FMT include:
     * %
     * %      'jpg' or 'jpeg' Joint Photographic Experts Group (JPEG)
     * %      'tif' or 'tiff' Tagged Image File Format (TIFF)
     * %      'gif'           Graphics Interchange Format (GIF)
     * %      'bmp'           Windows Bitmap (BMP)
     * %      'png'           Portable Network Graphics
     * %      'hdf'           Hierarchical Data Format (HDF)
     * %      'pcx'           Windows Paintbrush (PCX)
     * %      'xwd'           X Window Dump (XWD)
     * %      'cur'           Windows Cursor resources (CUR)
     * %      'ico'           Windows Icon resources (ICO)
     * %
     * %   [X,MAP] = IMREAD(FILENAME,FMT) reads the indexed image in
     * %   FILENAME into X and its associated colormap into MAP.
     * %   Colormap values in the image file are automatically
     * %   rescaled into the range [0,1]. 
     * %
     * %   [...] = IMREAD(FILENAME) attempts to infer the format of the
     * %   file from its content.
     * %
     * %   Data types
     * %   ----------
     * %   In most of the image file formats supported by IMREAD,
     * %   pixels are stored using 8 or fewer bits per color plane.
     * %   When reading such a file, the class of the output (A or X)
     * %   is uint8.  IMREAD also supports reading 16-bit-per-pixel
     * %   data from TIFF and PNG files; for such image files, the
     * %   class of the output (A or X) is uint16.
     * %
     * %   TIFF-specific syntaxes
     * %   ----------------------
     * %   [...] = IMREAD(...,IDX) reads in one image from a
     * %   multi-image TIFF file.  IDX is an integer value that
     * %   specifies the order that the image appears in the file.
     * %   For example, if IDX is 3, IMREAD reads the third image in
     * %   the file.  If you omit this argument, IMREAD reads the
     * %   first image in the file. 
     * %
     * %   PNG-specific syntaxes
     * %   ---------------------
     * %   [...] = IMREAD(...,'BackgroundColor',BG) composites any
     * %   transparent pixels in the input image against the color
     * %   specified in BG.  If BG is 'none', then no compositing is
     * %   performed. Otherwise, if the input image is indexed, BG
     * %   should be an integer in the range [1,P] where P is the
     * %   colormap length. If the input image is grayscale, BG
     * %   should be an integer in the range [0,1].  If the input
     * %   image is RGB, BG should be a three-element vector whose
     * %   values are in the range [0,1]. The string
     * %   'BackgroundColor' may be abbreviated.  
     * %
     * %   If the ALPHA output argument is used (see below), then BG
     * %   defaults to 'none' if not specified by the
     * %   user. Otherwise, if the PNG file contains a background
     * %   color chunk, that color is used as the default value for
     * %   BG. If ALPHA is not used and the file does not contain a
     * %   background color chunk, then the default value for BG is 1
     * %   for indexed images; 0 for grayscale images; and [0 0 0]
     * %   for RGB images.  
     * %
     * %   [A,MAP,ALPHA] = IMREAD(...) returns the alpha channel if
     * %   one is present; otherwise ALPHA is [].  Note that MAP may
     * %   be empty if the file contains a grayscale or truecolor 
     * %   image.
     * %
     * %   HDF-specific syntaxes
     * %   ---------------------
     * %   [...] = IMREAD(...,REF) reads in one image from a
     * %   multi-image HDF file.  REF is an integer value that
     * %   specifies the reference number used to identify the image.
     * %   For example, if REF is 12, IMREAD reads the image whose
     * %   reference number is 12.  (Note that in an HDF file the
     * %   reference numbers do not necessarily correspond with the
     * %   order of the images in the file.  You can use IMFINFO to
     * %   match up image order with reference number.)  If you omit
     * %   this argument, IMREAD reads the first image in the file.
     * %
     * %   ICO- and CUR-specific syntaxes
     * %   ------------------------------
     * %   [...] = IMREAD(...,IDX) reads in one image from a
     * %   multi-image icon or cursor file.  IDX is an integer value
     * %   that specifies the order that the image appears in the file.
     * %   For example, if IDX is 3, IMREAD reads the third image in
     * %   the file.  If you omit this argument, IMREAD reads the
     * %   first image in the file. 
     * %
     * %   [A,MAP,ALPHA] = IMREAD(...) returns the AND mask for the
     * %   resource, which can be used to determine the transparency
     * %   information.  For cursor files, this mask may contain the
     * %   only useful data.
     * %
     * %   Supported file types
     * %   --------------------
     * %   JPEG  Any baseline JPEG image; JPEG images with some
     * %         commonly used extensions
     * %
     * %   TIFF  Any baseline TIFF image, including 1-bit, 8-bit, and
     * %         24-bit uncompressed images; 1-bit, 8-bit, and 24-bit
     * %         images with packbits compression; 1-bit images with
     * %         CCITT compression; also, 16-bit grayscale, 16-bit
     * %         indexed, and 48-bit RGB images
     * %
     * %   GIF   Any 1-bit to 8-bit GIF image
     * %
     * %   BMP   1-bit, 4-bit, 8-bit, 24-bit, and 32-bit uncompressed images;
     * %         4-bit and 8-bit run-length encoded (RLE) images
     * %
     * %   PNG   Any PNG image, including 1-bit, 2-bit, 4-bit, 8-bit,
     * %         and 16-bit grayscale images; 8-bit and 16-bit
     * %         indexed images; 24-bit and 48-bit RGB images
     * %
     * %   HDF   8-bit raster image datasets, with or without an
     * %         associated colormap; 24-bit raster image datasets
     * %
     * %   PCX   1-bit, 8-bit, and 24-bit images
     * %
     * %   XWD   1-bit and 8-bit ZPixmaps; XYBitmaps; 1-bit XYPixmaps
     * %
     * %   ICO   1-bit, 4-bit, and 8-bit uncompressed images
     * %
     * %   CUR   1-bit, 4-bit, and 8-bit uncompressed images
     * %
     * %   See also IMFINFO, IMWRITE, FREAD, IMAGE, DOUBLE, UINT8.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc.
     * %   $Revision: 1.21 $  $Date: 2000/06/01 04:17:45 $
     * 
     * [filename, format, extraArgs, msg] = parse_inputs(varargin{:});
     */
    mlfAssign(
      &filename,
      mlfImread_parse_inputs(
        &format,
        &extraArgs,
        &msg,
        mclVe(
          mlfIndexRef(
            mclVsa(varargin, "varargin"), "{?}", mlfCreateColonIndex())),
        NULL));
    /*
     * if (~isempty(msg))
     */
    if (mclNotBool(mclVe(mlfIsempty(mclVv(msg, "msg"))))) {
        /*
         * error(msg);
         */
        mlfError(mclVv(msg, "msg"));
    /*
     * end
     */
    }
    /*
     * 
     * %
     * % Open the file and determine/verify its format
     * %
     * if (isempty(format))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(format, "format"))))) {
        /*
         * % The format wasn't specified explicitly
         * 
         * fid = fopen(filename, 'r');
         */
        mlfAssign(
          &fid,
          mlfFopen(NULL, NULL, mclVv(filename, "filename"), _mxarray4_, NULL));
        /*
         * if (fid == -1)
         */
        if (mclEqBool(mclVv(fid, "fid"), _mxarray6_)) {
            /*
             * error(sprintf('Can''t open file "%s" for reading;\n it may not exist, or you may not have read permission.', ...
             */
            mlfError(
              mclVe(
                mlfSprintf(
                  NULL, _mxarray7_, mclVv(filename, "filename"), NULL)));
        /*
         * filename));
         * else
         */
        } else {
            /*
             * filename = fopen(fid);
             */
            mlfAssign(
              &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * end
         */
        }
        /*
         * 
         * format = imftype(filename);
         */
        mlfAssign(
          &format, mlfIofun_private_imftype(mclVv(filename, "filename")));
        /*
         * if (isempty(format))
         */
        if (mlfTobool(mclVe(mlfIsempty(mclVv(format, "format"))))) {
            /*
             * error('Unable to determine the file format');
             */
            mlfError(_mxarray9_);
        /*
         * end
         */
        }
    /*
     * 
     * else
     */
    } else {
        /*
         * % The format was specified explicitly
         * 
         * fid = fopen(filename, 'r');
         */
        mlfAssign(
          &fid,
          mlfFopen(NULL, NULL, mclVv(filename, "filename"), _mxarray4_, NULL));
        /*
         * if (fid == -1)
         */
        if (mclEqBool(mclVv(fid, "fid"), _mxarray6_)) {
            /*
             * % Couldn't open using the given filename; search for a
             * % file with an appropriate extension.
             * switch format
             */
            mxArray * v_ = mclInitialize(mclVv(format, "format"));
            if (mclSwitchCompare(v_, _mxarray11_)) {
                /*
                 * case 'tif'
                 * fid = fopen([filename '.tif'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray13_, NULL),
                    _mxarray4_,
                    NULL));
                /*
                 * if (fid == -1)
                 */
                if (mclEqBool(mclVv(fid, "fid"), _mxarray6_)) {
                    /*
                     * fid = fopen([filename '.tiff'], 'r');
                     */
                    mlfAssign(
                      &fid,
                      mlfFopen(
                        NULL,
                        NULL,
                        mlfHorzcat(
                          mclVv(filename, "filename"), _mxarray15_, NULL),
                        _mxarray4_,
                        NULL));
                /*
                 * end
                 */
                }
            /*
             * 
             * case 'bmp'
             */
            } else if (mclSwitchCompare(v_, _mxarray17_)) {
                /*
                 * fid = fopen([filename '.bmp'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray19_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * case 'hdf'
             */
            } else if (mclSwitchCompare(v_, _mxarray21_)) {
                /*
                 * fid = fopen([filename '.hdf'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray23_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * case 'pcx' 
             */
            } else if (mclSwitchCompare(v_, _mxarray25_)) {
                /*
                 * fid = fopen([filename '.pcx'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray27_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * case 'xwd'
             */
            } else if (mclSwitchCompare(v_, _mxarray29_)) {
                /*
                 * fid = fopen([filename '.xwd'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray31_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * case 'jpg'
             */
            } else if (mclSwitchCompare(v_, _mxarray33_)) {
                /*
                 * fid = fopen([filename '.jpg'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray35_, NULL),
                    _mxarray4_,
                    NULL));
                /*
                 * if (fid == -1)
                 */
                if (mclEqBool(mclVv(fid, "fid"), _mxarray6_)) {
                    /*
                     * fid = fopen([filename '.jpeg'], 'r');
                     */
                    mlfAssign(
                      &fid,
                      mlfFopen(
                        NULL,
                        NULL,
                        mlfHorzcat(
                          mclVv(filename, "filename"), _mxarray37_, NULL),
                        _mxarray4_,
                        NULL));
                /*
                 * end
                 */
                }
            /*
             * 
             * case 'png'
             */
            } else if (mclSwitchCompare(v_, _mxarray39_)) {
                /*
                 * fid = fopen([filename '.png'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray41_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * case 'gif'
             */
            } else if (mclSwitchCompare(v_, _mxarray43_)) {
                /*
                 * fid = fopen([filename '.gif'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray45_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * case 'cur'
             */
            } else if (mclSwitchCompare(v_, _mxarray47_)) {
                /*
                 * fid = fopen([filename '.cur'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray49_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * case 'ico'
             */
            } else if (mclSwitchCompare(v_, _mxarray51_)) {
                /*
                 * fid = fopen([filename '.ico'], 'r');
                 */
                mlfAssign(
                  &fid,
                  mlfFopen(
                    NULL,
                    NULL,
                    mlfHorzcat(mclVv(filename, "filename"), _mxarray53_, NULL),
                    _mxarray4_,
                    NULL));
            /*
             * 
             * end
             */
            }
            mxDestroyArray(v_);
        /*
         * end
         */
        }
        /*
         * 
         * if (fid == -1)
         */
        if (mclEqBool(mclVv(fid, "fid"), _mxarray6_)) {
            /*
             * error(sprintf('Can''t open file "%s" for reading', filename));
             */
            mlfError(
              mclVe(
                mlfSprintf(
                  NULL, _mxarray55_, mclVv(filename, "filename"), NULL)));
        /*
         * 
         * else
         */
        } else {
            /*
             * filename = fopen(fid);
             */
            mlfAssign(
              &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * end
         */
        }
    /*
     * 
     * end
     */
    }
    /*
     * 
     * alpha = [];
     */
    mlfAssign(alpha, _mxarray57_);
    /*
     * 
     * switch format
     */
    {
        mxArray * v_ = mclInitialize(mclVv(format, "format"));
        if (mclSwitchCompare(v_, _mxarray17_)) {
            /*
             * case 'bmp'
             * [X,map] = readbmp(filename, extraArgs{:});
             */
            mclFeval(
              mlfVarargout(&X, map, NULL),
              mlxIofun_private_readbmp,
              mclVv(filename, "filename"),
              mclVe(
                mlfIndexRef(
                  mclVsv(extraArgs, "extraArgs"),
                  "{?}",
                  mlfCreateColonIndex())),
              NULL);
        /*
         * 
         * case 'xwd'
         */
        } else if (mclSwitchCompare(v_, _mxarray29_)) {
            /*
             * [X,map] = readxwd(filename, extraArgs{:});
             */
            mclFeval(
              mlfVarargout(&X, map, NULL),
              mlxIofun_private_readxwd,
              mclVv(filename, "filename"),
              mclVe(
                mlfIndexRef(
                  mclVsv(extraArgs, "extraArgs"),
                  "{?}",
                  mlfCreateColonIndex())),
              NULL);
        /*
         * 
         * case 'pcx'
         */
        } else if (mclSwitchCompare(v_, _mxarray25_)) {
            /*
             * [X,map] = readpcx(filename, extraArgs{:});
             */
            mclFeval(
              mlfVarargout(&X, map, NULL),
              mlxIofun_private_readpcx,
              mclVv(filename, "filename"),
              mclVe(
                mlfIndexRef(
                  mclVsv(extraArgs, "extraArgs"),
                  "{?}",
                  mlfCreateColonIndex())),
              NULL);
        /*
         * 
         * case 'hdf'
         */
        } else if (mclSwitchCompare(v_, _mxarray21_)) {
            /*
             * [X,map] = readhdf(filename, extraArgs{:});
             */
            mclFeval(
              mlfVarargout(&X, map, NULL),
              mlxIofun_private_readhdf,
              mclVv(filename, "filename"),
              mclVe(
                mlfIndexRef(
                  mclVsv(extraArgs, "extraArgs"),
                  "{?}",
                  mlfCreateColonIndex())),
              NULL);
        /*
         * 
         * case 'tif'
         */
        } else if (mclSwitchCompare(v_, _mxarray11_)) {
            /*
             * [X,map] = readtif(filename, extraArgs{:});
             */
            mclFeval(
              mlfVarargout(&X, map, NULL),
              mlxIofun_private_readtif,
              mclVv(filename, "filename"),
              mclVe(
                mlfIndexRef(
                  mclVsv(extraArgs, "extraArgs"),
                  "{?}",
                  mlfCreateColonIndex())),
              NULL);
        /*
         * 
         * case 'jpg'
         */
        } else if (mclSwitchCompare(v_, _mxarray33_)) {
            /*
             * [X,map] = readjpg(filename, extraArgs{:});
             */
            mlfAssign(
              &X,
              mlfIofun_private_readjpg(
                map,
                mclVv(filename, "filename"),
                mclVe(
                  mlfIndexRef(
                    mclVsv(extraArgs, "extraArgs"),
                    "{?}",
                    mlfCreateColonIndex())),
                NULL));
        /*
         * 
         * case 'png'
         */
        } else if (mclSwitchCompare(v_, _mxarray39_)) {
            /*
             * % PNG has slightly different behavior if alpha is
             * % requested, so we need the following if statement.
             * if (nargout >= 3)
             */
            if (nargout_ >= 3) {
                /*
                 * [X,map,alpha] = readpng(filename, extraArgs{:});
                 */
                mlfAssign(
                  &X,
                  mlfNIofun_private_readpng(
                    3,
                    map,
                    alpha,
                    mclVv(filename, "filename"),
                    mclVe(
                      mlfIndexRef(
                        mclVsv(extraArgs, "extraArgs"),
                        "{?}",
                        mlfCreateColonIndex())),
                    NULL));
            /*
             * else
             */
            } else {
                /*
                 * [X,map] = readpng(filename, extraArgs{:});
                 */
                mlfAssign(
                  &X,
                  mlfNIofun_private_readpng(
                    2,
                    map,
                    NULL,
                    mclVv(filename, "filename"),
                    mclVe(
                      mlfIndexRef(
                        mclVsv(extraArgs, "extraArgs"),
                        "{?}",
                        mlfCreateColonIndex())),
                    NULL));
            /*
             * end
             */
            }
        /*
         * case 'gif'
         */
        } else if (mclSwitchCompare(v_, _mxarray43_)) {
            /*
             * [X,map] = readgif(filename,extraArgs{:});
             */
            mlfAssign(
              &X,
              mlfIofun_private_readgif(
                map,
                mclVv(filename, "filename"),
                mclVe(
                  mlfIndexRef(
                    mclVsv(extraArgs, "extraArgs"),
                    "{?}",
                    mlfCreateColonIndex())),
                NULL));
        /*
         * 
         * case 'cur'
         */
        } else if (mclSwitchCompare(v_, _mxarray47_)) {
            /*
             * [X,map,alpha] = readcur(filename, extraArgs{:});
             */
            mclFeval(
              mlfVarargout(&X, map, alpha, NULL),
              mlxIofun_private_readcur,
              mclVv(filename, "filename"),
              mclVe(
                mlfIndexRef(
                  mclVsv(extraArgs, "extraArgs"),
                  "{?}",
                  mlfCreateColonIndex())),
              NULL);
        /*
         * 
         * case 'ico'
         */
        } else if (mclSwitchCompare(v_, _mxarray51_)) {
            /*
             * [X,map,alpha] = readico(filename, extraArgs{:});
             */
            mclFeval(
              mlfVarargout(&X, map, alpha, NULL),
              mlxIofun_private_readico,
              mclVv(filename, "filename"),
              mclVe(
                mlfIndexRef(
                  mclVsv(extraArgs, "extraArgs"),
                  "{?}",
                  mlfCreateColonIndex())),
              NULL);
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * error(sprintf('Unrecognized or unsupported format "%s"', format));
             */
            mlfError(
              mclVe(
                mlfSprintf(NULL, _mxarray58_, mclVv(format, "format"), NULL)));
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(X, 1, nargout_, "X", "imread");
    mclValidateOutput(*map, 2, nargout_, "map", "imread");
    mclValidateOutput(*alpha, 3, nargout_, "alpha", "imread");
    mxDestroyArray(filename);
    mxDestroyArray(format);
    mxDestroyArray(extraArgs);
    mxDestroyArray(msg);
    mxDestroyArray(ans);
    mxDestroyArray(fid);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * 
     * %%%
     * %%% Function parse_inputs
     * %%%
     * function [filename, format, extraArgs, msg] = ...
     * parse_inputs(varargin)
     * 
     * filename = '';
     * format = '';
     * extraArgs = {};
     * msg = '';
     * 
     * formatStrings = ['bmp'
     * 'xwd'
     * 'pcx'
     * 'hdf'
     * 'tif'
     * 'jpg'
     * 'png'
     * 'gif'
     * 'cur'
     * 'ico'];
     * 
     * switch (nargin)
     * case 0
     * msg = 'Too few input arguments';
     * return;
     * 
     * case 1
     * filename = varargin{1};
     * 
     * otherwise
     * filename = varargin{1};
     * 
     * % Is the second argument a format specifier?
     * % Allow some variability in specifying some of the formats.
     * arg2 = lower(varargin{2});
     * if (strcmp(arg2, 'tiff'))
     * arg2 = 'tif';
     * elseif (strcmp(arg2, 'jpeg'))
     * arg2 = 'jpg';
     * end
     * idx = strmatch(arg2, formatStrings, 'exact');
     * if (~isempty(idx))
     * % The second input argument is a format specifier
     * format = deblank(formatStrings(idx,:));
     * extraArgs = varargin(3:end);
     * 
     * else
     * % The second input argument is not a format specifier
     * extraArgs = varargin(2:end);
     * end
     * 
     * end
     * 
     */
}

/*
 * The function "Mimread_parse_inputs" is the implementation version of the
 * "imread/parse_inputs" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\imread.m" (lines 272-323). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [filename, format, extraArgs, msg] = ...
 */
static mxArray * Mimread_parse_inputs(mxArray * * format,
                                      mxArray * * extraArgs,
                                      mxArray * * msg,
                                      int nargout_,
                                      mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_imread);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * filename = mclGetUninitializedArray();
    mxArray * idx = mclGetUninitializedArray();
    mxArray * arg2 = mclGetUninitializedArray();
    mxArray * formatStrings = mclGetUninitializedArray();
    mclCopyArray(&varargin);
    /*
     * parse_inputs(varargin)
     * 
     * filename = '';
     */
    mlfAssign(&filename, _mxarray60_);
    /*
     * format = '';
     */
    mlfAssign(format, _mxarray60_);
    /*
     * extraArgs = {};
     */
    mlfAssign(extraArgs, _mxarray61_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray60_);
    /*
     * 
     * formatStrings = ['bmp'
     */
    mlfAssign(&formatStrings, _mxarray62_);
    /*
     * 'xwd'
     * 'pcx'
     * 'hdf'
     * 'tif'
     * 'jpg'
     * 'png'
     * 'gif'
     * 'cur'
     * 'ico'];
     * 
     * switch (nargin)
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargin_));
        if (mclSwitchCompare(v_, _mxarray64_)) {
            /*
             * case 0
             * msg = 'Too few input arguments';
             */
            mlfAssign(msg, _mxarray65_);
        /*
         * return;
         * 
         * case 1
         */
        } else if (mclSwitchCompare(v_, _mxarray67_)) {
            /*
             * filename = varargin{1};
             */
            mlfAssign(
              &filename,
              mlfIndexRef(mclVsa(varargin, "varargin"), "{?}", _mxarray67_));
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * filename = varargin{1};
             */
            mlfAssign(
              &filename,
              mlfIndexRef(mclVsa(varargin, "varargin"), "{?}", _mxarray67_));
            /*
             * 
             * % Is the second argument a format specifier?
             * % Allow some variability in specifying some of the formats.
             * arg2 = lower(varargin{2});
             */
            mlfAssign(
              &arg2,
              mclFeval(
                mclValueVarargout(),
                mlxLower,
                mclVe(
                  mlfIndexRef(
                    mclVsa(varargin, "varargin"), "{?}", _mxarray68_)),
                NULL));
            /*
             * if (strcmp(arg2, 'tiff'))
             */
            if (mlfTobool(mclVe(mlfStrcmp(mclVv(arg2, "arg2"), _mxarray69_)))) {
                /*
                 * arg2 = 'tif';
                 */
                mlfAssign(&arg2, _mxarray11_);
            /*
             * elseif (strcmp(arg2, 'jpeg'))
             */
            } else if (mlfTobool(
                         mclVe(mlfStrcmp(mclVv(arg2, "arg2"), _mxarray71_)))) {
                /*
                 * arg2 = 'jpg';
                 */
                mlfAssign(&arg2, _mxarray33_);
            /*
             * end
             */
            }
            /*
             * idx = strmatch(arg2, formatStrings, 'exact');
             */
            mlfAssign(
              &idx,
              mlfStrmatch(
                mclVv(arg2, "arg2"),
                mclVv(formatStrings, "formatStrings"),
                _mxarray73_));
            /*
             * if (~isempty(idx))
             */
            if (mclNotBool(mclVe(mlfIsempty(mclVv(idx, "idx"))))) {
                /*
                 * % The second input argument is a format specifier
                 * format = deblank(formatStrings(idx,:));
                 */
                mlfAssign(
                  format,
                  mlfDeblank(
                    mclVe(
                      mclArrayRef2(
                        mclVsv(formatStrings, "formatStrings"),
                        mclVsv(idx, "idx"),
                        mlfCreateColonIndex()))));
                /*
                 * extraArgs = varargin(3:end);
                 */
                mlfAssign(
                  extraArgs,
                  mclArrayRef1(
                    mclVsa(varargin, "varargin"),
                    mlfColon(
                      _mxarray75_,
                      mlfEnd(
                        mclVa(varargin, "varargin"), _mxarray67_, _mxarray67_),
                      NULL)));
            /*
             * 
             * else
             */
            } else {
                /*
                 * % The second input argument is not a format specifier
                 * extraArgs = varargin(2:end);
                 */
                mlfAssign(
                  extraArgs,
                  mclArrayRef1(
                    mclVsa(varargin, "varargin"),
                    mlfColon(
                      _mxarray68_,
                      mlfEnd(
                        mclVa(varargin, "varargin"), _mxarray67_, _mxarray67_),
                      NULL)));
            /*
             * end
             */
            }
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(filename, 1, nargout_, "filename", "imread/parse_inputs");
    mclValidateOutput(*format, 2, nargout_, "format", "imread/parse_inputs");
    mclValidateOutput(
      *extraArgs, 3, nargout_, "extraArgs", "imread/parse_inputs");
    mclValidateOutput(*msg, 4, nargout_, "msg", "imread/parse_inputs");
    mxDestroyArray(formatStrings);
    mxDestroyArray(arg2);
    mxDestroyArray(idx);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return filename;
    /*
     * 
     */
}
