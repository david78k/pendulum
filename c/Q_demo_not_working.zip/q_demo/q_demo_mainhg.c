/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#include "libmatlb.h"
#include "libsgl.h"
#include "q_demo.h"
#include "get_action.h"
#include "get_box.h"
#include "guidata.h"
#include "guihandles.h"
#include "imread.h"
#include "imshow.h"
#include "openfig.h"
#include "opengl.h"
#include "reset_cart.h"
#include "surf.h"
#include "title.h"
#include "isvarname.h"
#include "iofun_private_imftype.h"
#include "iofun_private_readbmp.h"
#include "iofun_private_readcur.h"
#include "iofun_private_readgif.h"
#include "iofun_private_readhdf.h"
#include "iofun_private_readico.h"
#include "iofun_private_readjpg.h"
#include "iofun_private_readpcx.h"
#include "iofun_private_readpng.h"
#include "iofun_private_readtif.h"
#include "iofun_private_readxwd.h"
#include "iptgetpref.h"
#include "truesize.h"
#include "movegui.h"
#include "grid.h"
#include "iskeyword.h"
#include "iofun_private_imbmpinfo.h"
#include "iofun_private_readbmpdata.h"
#include "imfinfo.h"
#include "iofun_private_imhdfinfo.h"
#include "iofun_private_rjpgc_mex_interface.h"
#include "iofun_private_bitslice_mex_interface.h"
#include "iofun_private_freadu8_mex_interface.h"
#include "iofun_private_impcxinfo.h"
#include "iofun_private_pcxdrle_mex_interface.h"
#include "iofun_private_rtifc_mex_interface.h"
#include "iofun_private_imxwdinfo.h"
#include "images_private_iptprefs.h"
#include "images_private_iptregistry_mex_interface.h"
#include "iofun_private_bmpdrle_mex_interface.h"
#include "iofun_private_imcurinfo.h"
#include "iofun_private_imgifinfo.h"
#include "iofun_private_imicoinfo.h"
#include "iofun_private_imjpginfo.h"
#include "iofun_private_impnginfo.h"
#include "iofun_private_imtifinfo.h"
#include "iofun_private_imjpg_mex_interface.h"
#include "libmmfile.h"
#include "libmwsglm.h"

mxArray * ALPHA = NULL;

mxArray * BETA = NULL;

mxArray * GAMMA = NULL;

static mexGlobalTableEntry global_table[3]
  = { { "ALPHA", &ALPHA }, { "BETA", &BETA }, { "GAMMA", &GAMMA } };

static mexFunctionTableEntry function_table[50]
  = { { "q_demo", mlxQ_demo, -1, -1, &_local_function_table_q_demo },
      { "get_action", mlxGet_action, 13, 5,
        &_local_function_table_get_action },
      { "get_box", mlxGet_box, 4, 1, &_local_function_table_get_box },
      { "guidata", mlxGuidata, 2, 1, &_local_function_table_guidata },
      { "guihandles", mlxGuihandles, 1, 1, &_local_function_table_guihandles },
      { "imread", mlxImread, -1, 3, &_local_function_table_imread },
      { "imshow", mlxImshow, -1, 1, &_local_function_table_imshow },
      { "openfig", mlxOpenfig, 2, 1, &_local_function_table_openfig },
      { "opengl", mlxOpengl, 1, 1, &_local_function_table_opengl },
      { "reset_cart", mlxReset_cart, 1, 8, &_local_function_table_reset_cart },
      { "surf", mlxSurf, -1, 1, &_local_function_table_surf },
      { "title", mlxTitle, -2, 1, &_local_function_table_title },
      { "isvarname", mlxIsvarname, 1, 1, &_local_function_table_isvarname },
      { "iofun/private/imftype", mlxIofun_private_imftype, 1,
        1, &_local_function_table_iofun_private_imftype },
      { "iofun/private/readbmp", mlxIofun_private_readbmp, 1,
        2, &_local_function_table_iofun_private_readbmp },
      { "iofun/private/readcur", mlxIofun_private_readcur, 2,
        3, &_local_function_table_iofun_private_readcur },
      { "iofun/private/readgif", mlxIofun_private_readgif, -2,
        2, &_local_function_table_iofun_private_readgif },
      { "iofun/private/readhdf", mlxIofun_private_readhdf, 2,
        2, &_local_function_table_iofun_private_readhdf },
      { "iofun/private/readico", mlxIofun_private_readico, 2,
        3, &_local_function_table_iofun_private_readico },
      { "iofun/private/readjpg", mlxIofun_private_readjpg, -2,
        2, &_local_function_table_iofun_private_readjpg },
      { "iofun/private/readpcx", mlxIofun_private_readpcx, 1,
        2, &_local_function_table_iofun_private_readpcx },
      { "iofun/private/readpng", mlxIofun_private_readpng, -2,
        3, &_local_function_table_iofun_private_readpng },
      { "iofun/private/readtif", mlxIofun_private_readtif, 2,
        2, &_local_function_table_iofun_private_readtif },
      { "iofun/private/readxwd", mlxIofun_private_readxwd, 1,
        2, &_local_function_table_iofun_private_readxwd },
      { "iptgetpref", mlxIptgetpref, 1, 1, &_local_function_table_iptgetpref },
      { "truesize", mlxTruesize, -1, 0, &_local_function_table_truesize },
      { "movegui", mlxMovegui, -1, 0, &_local_function_table_movegui },
      { "grid", mlxGrid, 2, 0, &_local_function_table_grid },
      { "iskeyword", mlxIskeyword, 1, 1, &_local_function_table_iskeyword },
      { "iofun/private/imbmpinfo", mlxIofun_private_imbmpinfo,
        1, 2, &_local_function_table_iofun_private_imbmpinfo },
      { "iofun/private/readbmpdata", mlxIofun_private_readbmpdata,
        1, 1, &_local_function_table_iofun_private_readbmpdata },
      { "imfinfo", mlxImfinfo, 2, 2, &_local_function_table_imfinfo },
      { "iofun/private/imhdfinfo", mlxIofun_private_imhdfinfo,
        1, 2, &_local_function_table_iofun_private_imhdfinfo },
      { "iofun/private/rjpgc", mlxIofun_private_rjpgc, -1,
        -1, &_local_function_table_iofun_private_rjpgc },
      { "iofun/private/bitslice", mlxIofun_private_bitslice, -1,
        -1, &_local_function_table_iofun_private_bitslice },
      { "iofun/private/freadu8", mlxIofun_private_freadu8, -1,
        -1, &_local_function_table_iofun_private_freadu8 },
      { "iofun/private/impcxinfo", mlxIofun_private_impcxinfo,
        1, 2, &_local_function_table_iofun_private_impcxinfo },
      { "iofun/private/pcxdrle", mlxIofun_private_pcxdrle, -1,
        -1, &_local_function_table_iofun_private_pcxdrle },
      { "iofun/private/rtifc", mlxIofun_private_rtifc, -1,
        -1, &_local_function_table_iofun_private_rtifc },
      { "iofun/private/imxwdinfo", mlxIofun_private_imxwdinfo,
        1, 2, &_local_function_table_iofun_private_imxwdinfo },
      { "images/private/iptprefs", mlxImages_private_iptprefs,
        0, 1, &_local_function_table_images_private_iptprefs },
      { "images/private/iptregistry", mlxImages_private_iptregistry,
        -1, -1, &_local_function_table_images_private_iptregistry },
      { "iofun/private/bmpdrle", mlxIofun_private_bmpdrle, -1,
        -1, &_local_function_table_iofun_private_bmpdrle },
      { "iofun/private/imcurinfo", mlxIofun_private_imcurinfo,
        1, 2, &_local_function_table_iofun_private_imcurinfo },
      { "iofun/private/imgifinfo", mlxIofun_private_imgifinfo,
        1, 2, &_local_function_table_iofun_private_imgifinfo },
      { "iofun/private/imicoinfo", mlxIofun_private_imicoinfo,
        1, 2, &_local_function_table_iofun_private_imicoinfo },
      { "iofun/private/imjpginfo", mlxIofun_private_imjpginfo,
        1, 2, &_local_function_table_iofun_private_imjpginfo },
      { "iofun/private/impnginfo", mlxIofun_private_impnginfo,
        1, 2, &_local_function_table_iofun_private_impnginfo },
      { "iofun/private/imtifinfo", mlxIofun_private_imtifinfo,
        1, 2, &_local_function_table_iofun_private_imtifinfo },
      { "iofun/private/imjpg", mlxIofun_private_imjpg, -1,
        -1, &_local_function_table_iofun_private_imjpg } };

static const char * path_list_[2]
  = { "C:\\matlabR12\\toolbox\\matlab\\iofun",
      "C:\\matlabR12\\toolbox\\images\\images" };

static _mexInitTermTableEntry init_term_table[52]
  = { { libmmfileInitialize, libmmfileTerminate },
      { libmwsglmInitialize, libmwsglmTerminate },
      { InitializeModule_q_demo, TerminateModule_q_demo },
      { InitializeModule_get_action, TerminateModule_get_action },
      { InitializeModule_get_box, TerminateModule_get_box },
      { InitializeModule_guidata, TerminateModule_guidata },
      { InitializeModule_guihandles, TerminateModule_guihandles },
      { InitializeModule_imread, TerminateModule_imread },
      { InitializeModule_imshow, TerminateModule_imshow },
      { InitializeModule_openfig, TerminateModule_openfig },
      { InitializeModule_opengl, TerminateModule_opengl },
      { InitializeModule_reset_cart, TerminateModule_reset_cart },
      { InitializeModule_surf, TerminateModule_surf },
      { InitializeModule_title, TerminateModule_title },
      { InitializeModule_isvarname, TerminateModule_isvarname },
      { InitializeModule_iofun_private_imftype,
        TerminateModule_iofun_private_imftype },
      { InitializeModule_iofun_private_readbmp,
        TerminateModule_iofun_private_readbmp },
      { InitializeModule_iofun_private_readcur,
        TerminateModule_iofun_private_readcur },
      { InitializeModule_iofun_private_readgif,
        TerminateModule_iofun_private_readgif },
      { InitializeModule_iofun_private_readhdf,
        TerminateModule_iofun_private_readhdf },
      { InitializeModule_iofun_private_readico,
        TerminateModule_iofun_private_readico },
      { InitializeModule_iofun_private_readjpg,
        TerminateModule_iofun_private_readjpg },
      { InitializeModule_iofun_private_readpcx,
        TerminateModule_iofun_private_readpcx },
      { InitializeModule_iofun_private_readpng,
        TerminateModule_iofun_private_readpng },
      { InitializeModule_iofun_private_readtif,
        TerminateModule_iofun_private_readtif },
      { InitializeModule_iofun_private_readxwd,
        TerminateModule_iofun_private_readxwd },
      { InitializeModule_iptgetpref, TerminateModule_iptgetpref },
      { InitializeModule_truesize, TerminateModule_truesize },
      { InitializeModule_movegui, TerminateModule_movegui },
      { InitializeModule_grid, TerminateModule_grid },
      { InitializeModule_iskeyword, TerminateModule_iskeyword },
      { InitializeModule_iofun_private_imbmpinfo,
        TerminateModule_iofun_private_imbmpinfo },
      { InitializeModule_iofun_private_readbmpdata,
        TerminateModule_iofun_private_readbmpdata },
      { InitializeModule_imfinfo, TerminateModule_imfinfo },
      { InitializeModule_iofun_private_imhdfinfo,
        TerminateModule_iofun_private_imhdfinfo },
      { InitializeModule_iofun_private_rjpgc_mex_interface,
        TerminateModule_iofun_private_rjpgc_mex_interface },
      { InitializeModule_iofun_private_bitslice_mex_interface,
        TerminateModule_iofun_private_bitslice_mex_interface },
      { InitializeModule_iofun_private_freadu8_mex_interface,
        TerminateModule_iofun_private_freadu8_mex_interface },
      { InitializeModule_iofun_private_impcxinfo,
        TerminateModule_iofun_private_impcxinfo },
      { InitializeModule_iofun_private_pcxdrle_mex_interface,
        TerminateModule_iofun_private_pcxdrle_mex_interface },
      { InitializeModule_iofun_private_rtifc_mex_interface,
        TerminateModule_iofun_private_rtifc_mex_interface },
      { InitializeModule_iofun_private_imxwdinfo,
        TerminateModule_iofun_private_imxwdinfo },
      { InitializeModule_images_private_iptprefs,
        TerminateModule_images_private_iptprefs },
      { InitializeModule_images_private_iptregistry_mex_interface,
        TerminateModule_images_private_iptregistry_mex_interface },
      { InitializeModule_iofun_private_bmpdrle_mex_interface,
        TerminateModule_iofun_private_bmpdrle_mex_interface },
      { InitializeModule_iofun_private_imcurinfo,
        TerminateModule_iofun_private_imcurinfo },
      { InitializeModule_iofun_private_imgifinfo,
        TerminateModule_iofun_private_imgifinfo },
      { InitializeModule_iofun_private_imicoinfo,
        TerminateModule_iofun_private_imicoinfo },
      { InitializeModule_iofun_private_imjpginfo,
        TerminateModule_iofun_private_imjpginfo },
      { InitializeModule_iofun_private_impnginfo,
        TerminateModule_iofun_private_impnginfo },
      { InitializeModule_iofun_private_imtifinfo,
        TerminateModule_iofun_private_imtifinfo },
      { InitializeModule_iofun_private_imjpg_mex_interface,
        TerminateModule_iofun_private_imjpg_mex_interface } };

static _mex_information _main_info
  = { 1, 50, function_table, 3, global_table, 2,
      path_list_, 52, init_term_table };

/*
 * The function "main" is a Compiler-generated main wrapper, suitable for
 * building a stand-alone application.  It calls a library function to perform
 * initialization, call the main function, and perform library termination.
 */
int main(int argc, const char * * argv) {
    return mclMainhg(argc, argv, mlxQ_demo, 1, &_main_info);
}
