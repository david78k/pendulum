/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "openfig.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"
#include "movegui.h"

static mxChar _array1_[132] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'o', 'p', 'e', 'n', 'f',
                                'i', 'g', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'o',
                                'p', 'e', 'n', 'f', 'i', 'g', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[131] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'o', 'p', 'e', 'n', 'f',
                                'i', 'g', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'o',
                                'p', 'e', 'n', 'f', 'i', 'g', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'i', 'n', 'p', 'u', 't', 's',
                                ' ', '(', '2', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[3] = { 'n', 'e', 'w' };
static mxArray * _mxarray6_;

static mxChar _array9_[4] = { '.', 'f', 'i', 'g' };
static mxArray * _mxarray8_;

static mxChar _array11_[28] = { 'A', 'r', 'g', 'u', 'm', 'e', 'n',
                                't', ' ', 'm', 'u', 's', 't', ' ',
                                'b', 'e', ' ', 'a', ' ', '.', 'f',
                                'i', 'g', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray10_;

static mxChar _array13_[17] = { '_', 'S', 'I', 'N', 'G', 'L', 'E', 'T', 'O',
                                'N', '_', 'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray12_;
static mxArray * _mxarray14_;
static mxArray * _mxarray15_;

static mxChar _array17_[5] = { 'r', 'e', 'u', 's', 'e' };
static mxArray * _mxarray16_;

static mxChar _array19_[47] = { 'S', 'e', 'c', 'o', 'n', 'd', ' ', 'i', 'n',
                                'p', 'u', 't', ' ', 'a', 'r', 'g', 'u', 'm',
                                'e', 'n', 't', ' ', 'm', 'u', 's', 't', ' ',
                                'b', 'e', ' ', 0x0027, 'n', 'e', 'w',
                                0x0027, ' ', 'o', 'r', ' ', 0x0027, 'r',
                                'e', 'u', 's', 'e', 0x0027, '.' };
static mxArray * _mxarray18_;

static mxChar _array21_[8] = { 'o', 'n', 's', 'c', 'r', 'e', 'e', 'n' };
static mxArray * _mxarray20_;

static mxChar _array23_[7] = { 'v', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray22_;

static mxChar _array25_[2] = { 'o', 'n' };
static mxArray * _mxarray24_;

void InitializeModule_openfig(void) {
    _mxarray0_ = mclInitializeString(132, _array1_);
    _mxarray2_ = mclInitializeString(131, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeDouble(2.0);
    _mxarray6_ = mclInitializeString(3, _array7_);
    _mxarray8_ = mclInitializeString(4, _array9_);
    _mxarray10_ = mclInitializeString(28, _array11_);
    _mxarray12_ = mclInitializeString(17, _array13_);
    _mxarray14_ = mclInitializeDouble(31.0);
    _mxarray15_ = mclInitializeDouble(0.0);
    _mxarray16_ = mclInitializeString(5, _array17_);
    _mxarray18_ = mclInitializeString(47, _array19_);
    _mxarray20_ = mclInitializeString(8, _array21_);
    _mxarray22_ = mclInitializeString(7, _array23_);
    _mxarray24_ = mclInitializeString(2, _array25_);
}

void TerminateModule_openfig(void) {
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mopenfig(int nargout_, mxArray * filename, mxArray * policy);

_mexLocalFunctionTable _local_function_table_openfig
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfOpenfig" contains the normal interface for the "openfig"
 * M-function from file "C:\matlabR12\toolbox\matlab\graphics\openfig.m" (lines
 * 1-81). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfOpenfig(mxArray * filename, mxArray * policy) {
    int nargout = 1;
    mxArray * fig = mclGetUninitializedArray();
    mlfEnterNewContext(0, 2, filename, policy);
    fig = Mopenfig(nargout, filename, policy);
    mlfRestorePreviousContext(0, 2, filename, policy);
    return mlfReturnValue(fig);
}

/*
 * The function "mlxOpenfig" contains the feval interface for the "openfig"
 * M-function from file "C:\matlabR12\toolbox\matlab\graphics\openfig.m" (lines
 * 1-81). The feval function calls the implementation version of openfig
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxOpenfig(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mopenfig(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mopenfig" is the implementation version of the "openfig"
 * M-function from file "C:\matlabR12\toolbox\matlab\graphics\openfig.m" (lines
 * 1-81). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function fig = openfig(filename, policy)
 */
static mxArray * Mopenfig(int nargout_, mxArray * filename, mxArray * policy) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_openfig);
    int nargin_ = mclNargin(2, filename, policy, NULL);
    mxArray * fig = mclGetUninitializedArray();
    mxArray * figs = mclGetUninitializedArray();
    mxArray * TOKEN = mclGetUninitializedArray();
    mxArray * ext = mclGetUninitializedArray();
    mxArray * name = mclGetUninitializedArray();
    mxArray * path = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&policy);
    /*
     * % OPENFIG Open new copy or raise existing copy of saved figure.
     * %    OPENFIG('NAME.FIG', 'new') opens figure contained in .fig file,
     * %    NAME.FIG, and ensures it is completely on screen.  Specifying the
     * %    .fig extension is optional. Specifying the full path is optional
     * %    as long as the .fig file is on the MATLAB path.
     * %
     * %    If the .fig file contains an invisible figure, OPENFIG returns
     * %    its handle and leaves it invisible.  The caller should make the
     * %    figure visible when appropriate.
     * %
     * %    OPENFIG('NAME.FIG', 'reuse') opens figure contained in .fig file
     * %    only if a copy is not currently open, otherwise ensures existing
     * %    copy is still completely on screen.  If the existing copy is
     * %    visible, it is also raised above all other windows.
     * %
     * %    OPENFIG('NAME.FIG') is the same as OPENFIG('NAME.FIG', 'new').
     * %
     * %    F = OPENFIG(...) returns the handle to the figure.
     * %
     * %    See also: OPEN, MOVEGUI, GUIDE, GUIHANDLES, SAVE, SAVEAS.
     * 
     * %   Damian T. Packer 6-8-2000
     * %   Copyright (c) 1984-2000 The MathWorks, Inc. All Rights Reserved.
     * %   $Revision: 1.14 $  $Date: 2000/08/25 22:34:35 $
     * 
     * error(nargchk(1,2,nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray4_, _mxarray5_, mlfScalar(nargin_))));
    /*
     * 
     * if nargin == 1
     */
    if (nargin_ == 1) {
        /*
         * policy = 'new';
         */
        mlfAssign(&policy, _mxarray6_);
    /*
     * end
     */
    }
    /*
     * 
     * [path, name, ext] = fileparts(filename);
     */
    mlfAssign(
      &path, mlfFileparts(&name, &ext, NULL, mclVa(filename, "filename")));
    /*
     * 
     * if isempty(ext)
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(ext, "ext"))))) {
        /*
         * ext = '.fig';
         */
        mlfAssign(&ext, _mxarray8_);
    /*
     * elseif ~isequal(ext, '.fig')
     */
    } else if (mclNotBool(
                 mclVe(mlfIsequal(mclVv(ext, "ext"), _mxarray8_, NULL)))) {
        /*
         * error('Argument must be a .fig file');
         */
        mlfError(_mxarray10_);
    /*
     * end
     */
    }
    /*
     * 
     * filename = fullfile(path, [name ext]);
     */
    mlfAssign(
      &filename,
      mlfFullfile(
        mclVv(path, "path"),
        mlfHorzcat(mclVv(name, "name"), mclVv(ext, "ext"), NULL),
        NULL));
    /*
     * 
     * % We will use this token, based on the base name of the file
     * % (without path or extension) to track open instances of figure.
     * TOKEN = [name '_SINGLETON_handle'];
     */
    mlfAssign(&TOKEN, mlfHorzcat(mclVv(name, "name"), _mxarray12_, NULL));
    /*
     * TOKEN = TOKEN(1:min(end, 31));
     */
    mlfAssign(
      &TOKEN,
      mclArrayRef1(
        mclVsv(TOKEN, "TOKEN"),
        mlfColon(
          _mxarray4_,
          mclVe(
            mlfMin(
              NULL,
              mlfEnd(mclVv(TOKEN, "TOKEN"), _mxarray4_, _mxarray4_),
              _mxarray14_,
              NULL)),
          NULL)));
    /*
     * 
     * % get the existing list of figures, and prune out stale handles.
     * figs = getappdata(0, TOKEN);
     */
    mlfAssign(&figs, mlfGetappdata(_mxarray15_, mclVv(TOKEN, "TOKEN")));
    /*
     * figs = figs(ishandle(figs));
     */
    mlfAssign(
      &figs,
      mclArrayRef1(mclVsv(figs, "figs"), mlfIshandle(mclVv(figs, "figs"))));
    /*
     * 
     * switch policy
     */
    {
        mxArray * v_ = mclInitialize(mclVa(policy, "policy"));
        if (mclSwitchCompare(v_, _mxarray6_)) {
            /*
             * 
             * case 'new'
             * % create another one, unconditionally
             * fig = hgload(filename);
             */
            mlfAssign(
              &fig, mlfNHgload(1, NULL, mclVa(filename, "filename"), NULL));
            /*
             * figs(end + 1) = fig;
             */
            mclArrayAssign1(
              &figs,
              mclVsv(fig, "fig"),
              mclPlus(
                mlfEnd(mclVv(figs, "figs"), _mxarray4_, _mxarray4_),
                _mxarray4_));
        /*
         * 
         * case 'reuse'
         */
        } else if (mclSwitchCompare(v_, _mxarray16_)) {
            /*
             * % create one only if there are no others
             * if isempty(figs)
             */
            if (mlfTobool(mclVe(mlfIsempty(mclVv(figs, "figs"))))) {
                /*
                 * figs = hgload(filename);
                 */
                mlfAssign(
                  &figs,
                  mlfNHgload(1, NULL, mclVa(filename, "filename"), NULL));
            /*
             * end
             */
            }
            /*
             * % reuse the one at the end of the list:
             * fig = figs(end);
             */
            mlfAssign(
              &fig,
              mclArrayRef1(
                mclVsv(figs, "figs"),
                mlfEnd(mclVv(figs, "figs"), _mxarray4_, _mxarray4_)));
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * error('Second input argument must be ''new'' or ''reuse''.');
             */
            mlfError(_mxarray18_);
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * % remember all instances of this figure.
     * setappdata(0, TOKEN, figs);
     */
    mlfSetappdata(
      _mxarray15_, mclVv(TOKEN, "TOKEN"), mclVv(figs, "figs"), NULL);
    /*
     * 
     * % ensure the figure is completely on the screen:
     * movegui(fig, 'onscreen');
     */
    mlfMovegui(mclVv(fig, "fig"), _mxarray20_, NULL);
    /*
     * 
     * % raise it, if it is visible:
     * if isequal(get(fig,'visible'), 'on')
     */
    if (mlfTobool(
          mclVe(
            mlfIsequal(
              mclVe(mlfNGet(1, mclVv(fig, "fig"), _mxarray22_, NULL)),
              _mxarray24_, NULL)))) {
        /*
         * figure(fig);
         */
        mclAssignAns(&ans, mlfNFigure(0, mclVv(fig, "fig"), NULL));
    /*
     * end
     */
    }
    mclValidateOutput(fig, 1, nargout_, "fig", "openfig");
    mxDestroyArray(ans);
    mxDestroyArray(path);
    mxDestroyArray(name);
    mxDestroyArray(ext);
    mxDestroyArray(TOKEN);
    mxDestroyArray(figs);
    mxDestroyArray(policy);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return fig;
}
