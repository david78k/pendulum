/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readpng.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'p', 'n', 'g', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'p', 'n', 'g', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '3', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[15] = { 'T', 'o', 'o', ' ', 'f', 'e', 'w', ' ',
                               'i', 'n', 'p', 'u', 't', 's', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[15] = { 'b', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                               'n', 'd', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray5_;

static mxChar _array8_[31] = { 'P', 'a', 'r', 'a', 'm', 'e', 't', 'e',
                               'r', ' ', 'n', 'a', 'm', 'e', ' ', 'm',
                               'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray7_;

static mxChar _array10_[32] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                'i', 'z', 'e', 'd', ' ', 'p', 'a', 'r',
                                'a', 'm', 'e', 't', 'e', 'r', ' ', 'n',
                                'a', 'm', 'e', ' ', '"', '%', 's', '"' };
static mxArray * _mxarray9_;

static mxChar _array12_[29] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u',
                                's', ' ', 'p', 'a', 'r', 'a', 'm', 'e',
                                't', 'e', 'r', ' ', 'n', 'a', 'm', 'e',
                                ' ', '"', '%', 's', '"' };
static mxArray * _mxarray11_;

static mxChar _array14_[4] = { 'n', 'o', 'n', 'e' };
static mxArray * _mxarray13_;

static mxChar _array16_[4] = { 'r', 'e', 'a', 'd' };
static mxArray * _mxarray15_;
static mxArray * _mxarray17_;
static mxArray * _mxarray18_;
static mxArray * _mxarray19_;

static double _array21_[2] = { 2.0, 4.0 };
static mxArray * _mxarray20_;

void InitializeModule_iofun_private_readpng(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(15, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeString(15, _array6_);
    _mxarray7_ = mclInitializeString(31, _array8_);
    _mxarray9_ = mclInitializeString(32, _array10_);
    _mxarray11_ = mclInitializeString(29, _array12_);
    _mxarray13_ = mclInitializeString(4, _array14_);
    _mxarray15_ = mclInitializeString(4, _array16_);
    _mxarray17_ = mclInitializeDouble(-1.0);
    _mxarray18_ = mclInitializeDouble(1.0);
    _mxarray19_ = mclInitializeDouble(3.0);
    _mxarray20_ = mclInitializeDoubleVector(1, 2, _array21_);
}

void TerminateModule_iofun_private_readpng(void) {
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_readpng(mxArray * * map,
                                        mxArray * * alpha,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * varargin);

_mexLocalFunctionTable _local_function_table_iofun_private_readpng
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNIofun_private_readpng" contains the nargout interface for
 * the "iofun/private/readpng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpng.m" (lines 1-67). This
 * interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNIofun_private_readpng(int nargout,
                                    mxArray * * map,
                                    mxArray * * alpha,
                                    mxArray * filename,
                                    ...) {
    mxArray * varargin = NULL;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mxArray * alpha__ = mclGetUninitializedArray();
    mlfVarargin(&varargin, filename, 0);
    mlfEnterNewContext(2, -2, map, alpha, filename, varargin);
    X = Miofun_private_readpng(&map__, &alpha__, nargout, filename, varargin);
    mlfRestorePreviousContext(2, 1, map, alpha, filename);
    mxDestroyArray(varargin);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    if (alpha != NULL) {
        mclCopyOutputArg(alpha, alpha__);
    } else {
        mxDestroyArray(alpha__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlfIofun_private_readpng" contains the normal interface for
 * the "iofun/private/readpng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpng.m" (lines 1-67). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readpng(mxArray * * map,
                                   mxArray * * alpha,
                                   mxArray * filename,
                                   ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mxArray * alpha__ = mclGetUninitializedArray();
    mlfVarargin(&varargin, filename, 0);
    mlfEnterNewContext(2, -2, map, alpha, filename, varargin);
    if (map != NULL) {
        ++nargout;
    }
    if (alpha != NULL) {
        ++nargout;
    }
    X = Miofun_private_readpng(&map__, &alpha__, nargout, filename, varargin);
    mlfRestorePreviousContext(2, 1, map, alpha, filename);
    mxDestroyArray(varargin);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    if (alpha != NULL) {
        mclCopyOutputArg(alpha, alpha__);
    } else {
        mxDestroyArray(alpha__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlfVIofun_private_readpng" contains the void interface for the
 * "iofun/private/readpng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpng.m" (lines 1-67). The void
 * interface is only produced if the M-function uses the special variable
 * "nargout", and has at least one output. The void interface function
 * specifies zero output arguments to the implementation version of the
 * function, and in the event that the implementation version still returns an
 * output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVIofun_private_readpng(mxArray * filename, ...) {
    mxArray * varargin = NULL;
    mxArray * X = NULL;
    mxArray * map = NULL;
    mxArray * alpha = NULL;
    mlfVarargin(&varargin, filename, 0);
    mlfEnterNewContext(0, -2, filename, varargin);
    X = Miofun_private_readpng(&map, &alpha, 0, filename, varargin);
    mlfRestorePreviousContext(0, 1, filename);
    mxDestroyArray(varargin);
    mxDestroyArray(X);
    mxDestroyArray(map);
}

/*
 * The function "mlxIofun_private_readpng" contains the feval interface for the
 * "iofun/private/readpng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpng.m" (lines 1-67). The
 * feval function calls the implementation version of iofun/private/readpng
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readpng(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[3];
    int i;
    if (nlhs > 3) {
        mlfError(_mxarray0_);
    }
    for (i = 0; i < 3; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mprhs[1] = NULL;
    mlfAssign(&mprhs[1], mclCreateVararginCell(nrhs - 1, prhs + 1));
    mplhs[0]
      = Miofun_private_readpng(&mplhs[1], &mplhs[2], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 3 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 3; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[1]);
}

/*
 * The function "Miofun_private_readpng" is the implementation version of the
 * "iofun/private/readpng" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpng.m" (lines 1-67). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [X,map,alpha] = readpng(filename, varargin)
 */
static mxArray * Miofun_private_readpng(mxArray * * map,
                                        mxArray * * alpha,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readpng);
    int nargin_ = mclNargin(-2, filename, varargin, NULL);
    mxArray * X = mclGetUninitializedArray();
    mxArray * idx = mclGetUninitializedArray();
    mxArray * prop = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * propStrings = mclGetUninitializedArray();
    mxArray * bg = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&varargin);
    /*
     * %READPNG Read an image from a PNG file.
     * %   [X,MAP] = READPNG(FILENAME) reads the image from the
     * %   specified file.
     * %
     * %   [X,MAP] = READPNG(FILENAME,'BackgroundColor',BG) uses the
     * %   specified background color for compositing transparent
     * %   pixels.  By default, READPNG uses the background color
     * %   specified in the file, if present.  If not present, the
     * %   default is either the first colormap color or black.  If the
     * %   file contains an indexed image, BG must be an integer in the
     * %   range [1,P] where P is the colormap length.  If the file
     * %   contains a grayscale image, BG must be an integer in the
     * %   range [0,65535].  If the file contains an RGB image, BG must
     * %   be a 3-element vector whose values are in the range
     * %   [0,65535].
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.3 $  $Date: 2000/06/01 04:17:02 $
     * 
     * if (nargin < 1)
     */
    if (nargin_ < 1) {
        /*
         * error('Too few inputs.');
         */
        mlfError(_mxarray2_);
    /*
     * end
     */
    }
    /*
     * 
     * bg = [];
     */
    mlfAssign(&bg, _mxarray4_);
    /*
     * 
     * % Process param/value pairs
     * propStrings = ['backgroundcolor'];
     */
    mlfAssign(&propStrings, _mxarray5_);
    /*
     * 
     * for k = 1:2:length(varargin)
     */
    {
        int v_ = mclForIntStart(1);
        int i_ = 2;
        int e_ = mclForIntIntEnd(
                   v_,
                   i_,
                   mlfScalar(mclLengthInt(mclVa(varargin, "varargin"))));
        if (e_ == mclIntMin()) {
            mlfAssign(&k, _mxarray4_);
        } else {
            /*
             * prop = lower(varargin{k});
             * if (~isstr(prop))
             * error('Parameter name must be a string');
             * end
             * idx = strmatch(prop, propStrings);
             * if (isempty(idx))
             * error(sprintf('Unrecognized parameter name "%s"', prop));
             * elseif (length(idx) > 1)
             * error(sprintf('Ambiguous parameter name "%s"', prop));
             * end
             * 
             * prop = deblank(propStrings(idx,:));
             * 
             * switch prop
             * case 'backgroundcolor'
             * bg = varargin{k+1};
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &prop,
                  mclFeval(
                    mclValueVarargout(),
                    mlxLower,
                    mclVe(
                      mlfIndexRef(
                        mclVsa(varargin, "varargin"), "{?}", mlfScalar(v_))),
                    NULL));
                if (mclNotBool(mclVe(mlfIsstr(mclVv(prop, "prop"))))) {
                    mlfError(_mxarray7_);
                }
                mlfAssign(
                  &idx,
                  mlfStrmatch(
                    mclVv(prop, "prop"),
                    mclVv(propStrings, "propStrings"),
                    NULL));
                if (mlfTobool(mclVe(mlfIsempty(mclVv(idx, "idx"))))) {
                    mlfError(
                      mclVe(
                        mlfSprintf(
                          NULL, _mxarray9_, mclVv(prop, "prop"), NULL)));
                } else if (mclLengthInt(mclVv(idx, "idx")) > 1) {
                    mlfError(
                      mclVe(
                        mlfSprintf(
                          NULL, _mxarray11_, mclVv(prop, "prop"), NULL)));
                }
                mlfAssign(
                  &prop,
                  mlfDeblank(
                    mclVe(
                      mclArrayRef2(
                        mclVsv(propStrings, "propStrings"),
                        mclVsv(idx, "idx"),
                        mlfCreateColonIndex()))));
                {
                    mxArray * v_0 = mclInitialize(mclVv(prop, "prop"));
                    if (mclSwitchCompare(v_0, _mxarray5_)) {
                        mlfAssign(
                          &bg,
                          mlfIndexRef(
                            mclVsa(varargin, "varargin"),
                            "{?}",
                            mlfScalar(v_ + 1)));
                    }
                    mxDestroyArray(v_0);
                }
                if (v_ == e_) {
                    break;
                }
                v_ += i_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * 
     * if (isempty(bg) & (nargout >= 3))
     */
    {
        mxArray * a_ = mclInitialize(mclVe(mlfIsempty(mclVv(bg, "bg"))));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclBoolToArray(nargout_ >= 3)))) {
            mxDestroyArray(a_);
            /*
             * % User asked for alpha and didn't specify a background
             * % color; in this case we don't perform the compositing.
             * bg = 'none';
             */
            mlfAssign(&bg, _mxarray13_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * alpha = [];
     */
    mlfAssign(alpha, _mxarray4_);
    /*
     * [X,map] = png('read',filename, bg);
     */
    mlfNIofun_private_png(
      0,
      mlfVarargout(&X, map, NULL),
      _mxarray15_,
      mclVa(filename, "filename"),
      mclVv(bg, "bg"),
      NULL);
    /*
     * X = permute(X, ndims(X):-1:1);
     */
    mlfAssign(
      &X,
      mlfPermute(
        mclVv(X, "X"),
        mlfColon(mclVe(mlfNdims(mclVv(X, "X"))), _mxarray17_, _mxarray18_)));
    /*
     * if (ismember(size(X,3), [2 4]))
     */
    if (mlfTobool(
          mclVe(
            mlfIsmember(
              mclVe(mlfSize(mclValueVarargout(), mclVv(X, "X"), _mxarray19_)),
              _mxarray20_,
              NULL)))) {
        /*
         * alpha = X(:,:,end);
         */
        mlfAssign(
          alpha,
          mlfIndexRef(
            mclVsv(X, "X"),
            "(?,?,?)",
            mlfCreateColonIndex(),
            mlfCreateColonIndex(),
            mlfEnd(mclVv(X, "X"), _mxarray19_, _mxarray19_)));
        /*
         * % Strip the alpha channel off of X.
         * X = X(:,:,1:end-1);
         */
        mlfAssign(
          &X,
          mlfIndexRef(
            mclVsv(X, "X"),
            "(?,?,?)",
            mlfCreateColonIndex(),
            mlfCreateColonIndex(),
            mlfColon(
              _mxarray18_,
              mclMinus(
                mlfEnd(mclVv(X, "X"), _mxarray19_, _mxarray19_), _mxarray18_),
              NULL)));
    /*
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "iofun/private/readpng");
    mclValidateOutput(*map, 2, nargout_, "map", "iofun/private/readpng");
    mclValidateOutput(*alpha, 3, nargout_, "alpha", "iofun/private/readpng");
    mxDestroyArray(ans);
    mxDestroyArray(bg);
    mxDestroyArray(propStrings);
    mxDestroyArray(k);
    mxDestroyArray(prop);
    mxDestroyArray(idx);
    mxDestroyArray(varargin);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     */
}
