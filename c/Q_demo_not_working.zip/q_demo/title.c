/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "title.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[128] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 't', 'i', 't', 'l', 'e',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 't', 'i', 't',
                                'l', 'e', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[5] = { 't', 'i', 't', 'l', 'e' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[35] = { 'I', 'n', 'c', 'o', 'r', 'r', 'e', 'c', 't',
                               ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o',
                               'f', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'a',
                               'r', 'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray5_;

static mxChar _array8_[9] = { 'F', 'o', 'n', 't', 'A', 'n', 'g', 'l', 'e' };
static mxArray * _mxarray7_;

static mxChar _array10_[8] = { 'F', 'o', 'n', 't', 'N', 'a', 'm', 'e' };
static mxArray * _mxarray9_;

static mxChar _array12_[8] = { 'F', 'o', 'n', 't', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray11_;

static mxChar _array14_[10] = { 'F', 'o', 'n', 't', 'W',
                                'e', 'i', 'g', 'h', 't' };
static mxArray * _mxarray13_;

static mxChar _array16_[8] = { 'R', 'o', 't', 'a', 't', 'i', 'o', 'n' };
static mxArray * _mxarray15_;
static mxArray * _mxarray17_;

static mxChar _array19_[6] = { 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray18_;

void InitializeModule_title(void) {
    _mxarray0_ = mclInitializeString(128, _array1_);
    _mxarray2_ = mclInitializeString(5, _array3_);
    _mxarray4_ = mclInitializeDouble(2.0);
    _mxarray5_ = mclInitializeString(35, _array6_);
    _mxarray7_ = mclInitializeString(9, _array8_);
    _mxarray9_ = mclInitializeString(8, _array10_);
    _mxarray11_ = mclInitializeString(8, _array12_);
    _mxarray13_ = mclInitializeString(10, _array14_);
    _mxarray15_ = mclInitializeString(8, _array16_);
    _mxarray17_ = mclInitializeDouble(0.0);
    _mxarray18_ = mclInitializeString(6, _array19_);
}

void TerminateModule_title(void) {
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mtitle(int nargout_, mxArray * string, mxArray * varargin);

_mexLocalFunctionTable _local_function_table_title
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNTitle" contains the nargout interface for the "title"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph2d\title.m" (lines
 * 1-34). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNTitle(int nargout, mxArray * string, ...) {
    mxArray * varargin = NULL;
    mxArray * hh = mclGetUninitializedArray();
    mlfVarargin(&varargin, string, 0);
    mlfEnterNewContext(0, -2, string, varargin);
    hh = Mtitle(nargout, string, varargin);
    mlfRestorePreviousContext(0, 1, string);
    mxDestroyArray(varargin);
    return mlfReturnValue(hh);
}

/*
 * The function "mlfTitle" contains the normal interface for the "title"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph2d\title.m" (lines
 * 1-34). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfTitle(mxArray * string, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * hh = mclGetUninitializedArray();
    mlfVarargin(&varargin, string, 0);
    mlfEnterNewContext(0, -2, string, varargin);
    hh = Mtitle(nargout, string, varargin);
    mlfRestorePreviousContext(0, 1, string);
    mxDestroyArray(varargin);
    return mlfReturnValue(hh);
}

/*
 * The function "mlfVTitle" contains the void interface for the "title"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph2d\title.m" (lines
 * 1-34). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVTitle(mxArray * string, ...) {
    mxArray * varargin = NULL;
    mxArray * hh = NULL;
    mlfVarargin(&varargin, string, 0);
    mlfEnterNewContext(0, -2, string, varargin);
    hh = Mtitle(0, string, varargin);
    mlfRestorePreviousContext(0, 1, string);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxTitle" contains the feval interface for the "title"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph2d\title.m" (lines
 * 1-34). The feval function calls the implementation version of title through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxTitle(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mprhs[1] = NULL;
    mlfAssign(&mprhs[1], mclCreateVararginCell(nrhs - 1, prhs + 1));
    mplhs[0] = Mtitle(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[1]);
}

/*
 * The function "Mtitle" is the implementation version of the "title"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph2d\title.m" (lines
 * 1-34). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function hh = title(string,varargin)
 */
static mxArray * Mtitle(int nargout_, mxArray * string, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_title);
    int nargin_ = mclNargin(-2, string, varargin, NULL);
    mxArray * hh = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * h = mclGetUninitializedArray();
    mxArray * ax = mclGetUninitializedArray();
    mclCopyArray(&string);
    mclCopyArray(&varargin);
    /*
     * %TITLE  Graph title.
     * %   TITLE('text') adds text at the top of the current axis.
     * %
     * %   TITLE('text','Property1',PropertyValue1,'Property2',PropertyValue2,...)
     * %   sets the values of the specified properties of the title.
     * %
     * %   H = TITLE(...) returns the handle to the text object used as the title.
     * %
     * %   See also XLABEL, YLABEL, ZLABEL, TEXT.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 5.11 $  $Date: 2000/06/01 02:53:18 $
     * 
     * ax = gca;
     */
    mlfAssign(&ax, mlfGca(NULL));
    /*
     * h = get(ax,'title');
     */
    mlfAssign(&h, mlfNGet(1, mclVv(ax, "ax"), _mxarray2_, NULL));
    /*
     * 
     * if nargin > 1 & (nargin-1)/2-fix((nargin-1)/2),
     */
    {
        mxArray * a_ = mclInitialize(mclBoolToArray(nargin_ > 1));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclMinus(
                     mclMrdivide(mlfScalar(nargin_ - 1), _mxarray4_),
                     mclVe(
                       mlfFix(
                         mclMrdivide(
                           mlfScalar(nargin_ - 1), _mxarray4_))))))) {
            mxDestroyArray(a_);
            /*
             * error('Incorrect number of input arguments')
             */
            mlfError(_mxarray5_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * %Over-ride text objects default font attributes with
     * %the Axes' default font attributes.
     * set(h, 'FontAngle',  get(ax, 'FontAngle'), ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(h, "h"),
        _mxarray7_,
        mclVe(mlfNGet(1, mclVv(ax, "ax"), _mxarray7_, NULL)),
        _mxarray9_,
        mclVe(mlfNGet(1, mclVv(ax, "ax"), _mxarray9_, NULL)),
        _mxarray11_,
        mclVe(mlfNGet(1, mclVv(ax, "ax"), _mxarray11_, NULL)),
        _mxarray13_,
        mclVe(mlfNGet(1, mclVv(ax, "ax"), _mxarray13_, NULL)),
        _mxarray15_,
        _mxarray17_,
        _mxarray18_,
        mclVa(string, "string"),
        mclVe(
          mlfIndexRef(
            mclVsa(varargin, "varargin"), "{?}", mlfCreateColonIndex())),
        NULL));
    /*
     * 'FontName',   get(ax, 'FontName'), ...
     * 'FontSize',   get(ax, 'FontSize'), ...
     * 'FontWeight', get(ax, 'FontWeight'), ...
     * 'Rotation',   0, ...
     * 'string',     string, varargin{:});
     * 
     * if nargout > 0
     */
    if (nargout_ > 0) {
        /*
         * hh = h;
         */
        mlfAssign(&hh, mclVsv(h, "h"));
    /*
     * end
     */
    }
    mclValidateOutput(hh, 1, nargout_, "hh", "title");
    mxDestroyArray(ax);
    mxDestroyArray(h);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(string);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return hh;
}
