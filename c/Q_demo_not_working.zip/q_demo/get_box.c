/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "get_box.h"
#include "libmatlbm.h"

static mxChar _array1_[132] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'g', 'e', 't', '_', 'b',
                                'o', 'x', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '2', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'g',
                                'e', 't', '_', 'b', 'o', 'x', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[131] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'g', 'e', 't', '_', 'b',
                                'o', 'x', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '2', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'g',
                                'e', 't', '_', 'b', 'o', 'x', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'i', 'n', 'p', 'u', 't', 's',
                                ' ', '(', '4', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;
static mxArray * _mxarray7_;
static mxArray * _mxarray8_;
static mxArray * _mxarray9_;
static mxArray * _mxarray10_;
static mxArray * _mxarray11_;
static mxArray * _mxarray12_;
static mxArray * _mxarray13_;
static mxArray * _mxarray14_;
static mxArray * _mxarray15_;
static mxArray * _mxarray16_;
static mxArray * _mxarray17_;
static mxArray * _mxarray18_;
static mxArray * _mxarray19_;
static mxArray * _mxarray20_;
static mxArray * _mxarray21_;
static mxArray * _mxarray22_;
static mxArray * _mxarray23_;
static mxArray * _mxarray24_;
static mxArray * _mxarray25_;
static mxArray * _mxarray26_;
static mxArray * _mxarray27_;
static mxArray * _mxarray28_;

void InitializeModule_get_box(void) {
    _mxarray0_ = mclInitializeString(132, _array1_);
    _mxarray2_ = mclInitializeString(131, _array3_);
    _mxarray4_ = mclInitializeDouble(.017453292519943295);
    _mxarray5_ = mclInitializeDouble(-.8);
    _mxarray6_ = mclInitializeDouble(1.0);
    _mxarray7_ = mclInitializeDouble(.8);
    _mxarray8_ = mclInitializeDouble(2.0);
    _mxarray9_ = mclInitializeDouble(3.0);
    _mxarray10_ = mclInitializeDouble(-.5);
    _mxarray11_ = mclInitializeDouble(.5);
    _mxarray12_ = mclInitializeDouble(6.0);
    _mxarray13_ = mclInitializeDouble(-6.0);
    _mxarray14_ = mclInitializeDouble(9.0);
    _mxarray15_ = mclInitializeDouble(0.0);
    _mxarray16_ = mclInitializeDouble(18.0);
    _mxarray17_ = mclInitializeDouble(27.0);
    _mxarray18_ = mclInitializeDouble(36.0);
    _mxarray19_ = mclInitializeDouble(45.0);
    _mxarray20_ = mclInitializeDouble(-50.0);
    _mxarray21_ = mclInitializeDouble(50.0);
    _mxarray22_ = mclInitializeDouble(54.0);
    _mxarray23_ = mclInitializeDouble(108.0);
    _mxarray24_ = mclInitializeDouble(2.4);
    _mxarray25_ = mclInitializeDouble(-12.0);
    _mxarray26_ = mclInitializeDouble(12.0);
    _mxarray27_ = mclInitializeDouble(-1.0);
    _mxarray28_ = mclInitializeDouble(-2.4);
}

void TerminateModule_get_box(void) {
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mget_box(int nargout_,
                          mxArray * x,
                          mxArray * v_x,
                          mxArray * theta,
                          mxArray * v_theta);

_mexLocalFunctionTable _local_function_table_get_box
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfGet_box" contains the normal interface for the "get_box"
 * M-function from file "C:\temp\q\get_box.m" (lines 1-30). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfGet_box(mxArray * x,
                     mxArray * v_x,
                     mxArray * theta,
                     mxArray * v_theta) {
    int nargout = 1;
    mxArray * box = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, x, v_x, theta, v_theta);
    box = Mget_box(nargout, x, v_x, theta, v_theta);
    mlfRestorePreviousContext(0, 4, x, v_x, theta, v_theta);
    return mlfReturnValue(box);
}

/*
 * The function "mlxGet_box" contains the feval interface for the "get_box"
 * M-function from file "C:\temp\q\get_box.m" (lines 1-30). The feval function
 * calls the implementation version of get_box through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
void mlxGet_box(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0] = Mget_box(nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mget_box" is the implementation version of the "get_box"
 * M-function from file "C:\temp\q\get_box.m" (lines 1-30). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * % To tell the state now, if box=-1 means fail.
 * function [box]=get_box(x,v_x,theta,v_theta)
 */
static mxArray * Mget_box(int nargout_,
                          mxArray * x,
                          mxArray * v_x,
                          mxArray * theta,
                          mxArray * v_theta) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_get_box);
    mxArray * box = mclGetUninitializedArray();
    mxArray * degree = mclGetUninitializedArray();
    mclCopyArray(&x);
    mclCopyArray(&v_x);
    mclCopyArray(&theta);
    mclCopyArray(&v_theta);
    /*
     * degree=pi/180;  
     */
    mlfAssign(&degree, _mxarray4_);
    /*
     * 
     * if (x<-0.8)      box=1;
     */
    if (mclLtBool(mclVa(x, "x"), _mxarray5_)) {
        mlfAssign(&box, _mxarray6_);
    /*
     * elseif (x<0.8)  box=2;
     */
    } else if (mclLtBool(mclVa(x, "x"), _mxarray7_)) {
        mlfAssign(&box, _mxarray8_);
    /*
     * else            box=3;
     */
    } else {
        mlfAssign(&box, _mxarray9_);
    /*
     * end %if
     */
    }
    /*
     * 
     * if (v_x<-0.5)
     */
    if (mclLtBool(mclVa(v_x, "v_x"), _mxarray10_)) {
    /*
     * elseif (v_x<0.5) box=box+3;
     */
    } else if (mclLtBool(mclVa(v_x, "v_x"), _mxarray11_)) {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray9_));
    /*
     * else             box=box+6;
     */
    } else {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray12_));
    /*
     * end %if
     */
    }
    /*
     * 
     * if (theta<-6*degree)
     */
    if (mclLtBool(
          mclVa(theta, "theta"),
          mclMtimes(_mxarray13_, mclVv(degree, "degree")))) {
    /*
     * elseif (theta<-degree)  box=box+9;
     */
    } else if (mclLtBool(
                 mclVa(theta, "theta"), mclUminus(mclVv(degree, "degree")))) {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray14_));
    /*
     * elseif (theta<0)        box=box+18;
     */
    } else if (mclLtBool(mclVa(theta, "theta"), _mxarray15_)) {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray16_));
    /*
     * elseif (theta<degree)   box=box+27;
     */
    } else if (mclLtBool(mclVa(theta, "theta"), mclVv(degree, "degree"))) {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray17_));
    /*
     * elseif (theta<6*degree) box=box+36;
     */
    } else if (mclLtBool(
                 mclVa(theta, "theta"),
                 mclMtimes(_mxarray12_, mclVv(degree, "degree")))) {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray18_));
    /*
     * else                    box=box+45;
     */
    } else {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray19_));
    /*
     * end  %if
     */
    }
    /*
     * 
     * if (v_theta<-50*degree)
     */
    if (mclLtBool(
          mclVa(v_theta, "v_theta"),
          mclMtimes(_mxarray20_, mclVv(degree, "degree")))) {
    /*
     * elseif (v_theta<50*degree)  box=box+54;
     */
    } else if (mclLtBool(
                 mclVa(v_theta, "v_theta"),
                 mclMtimes(_mxarray21_, mclVv(degree, "degree")))) {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray22_));
    /*
     * else                        box=box+108;
     */
    } else {
        mlfAssign(&box, mclPlus(mclVv(box, "box"), _mxarray23_));
    /*
     * end  %if
     */
    }
    /*
     * 
     * if (x<-2.4 | x>2.4  | theta<-12*degree | theta>12*degree)
     */
    {
        mxArray * a_ = mclInitialize(mclLt(mclVa(x, "x"), _mxarray28_));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mclGt(mclVa(x, "x"), _mxarray24_)));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_,
              mclOr(
                a_,
                mclLt(
                  mclVa(theta, "theta"),
                  mclMtimes(_mxarray25_, mclVv(degree, "degree")))));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclGt(
                     mclVa(theta, "theta"),
                     mclMtimes(_mxarray26_, mclVv(degree, "degree")))))) {
            mxDestroyArray(a_);
            /*
             * box=-1;
             */
            mlfAssign(&box, _mxarray27_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end %if
     */
    }
    mclValidateOutput(box, 1, nargout_, "box", "get_box");
    mxDestroyArray(degree);
    mxDestroyArray(v_theta);
    mxDestroyArray(theta);
    mxDestroyArray(v_x);
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return box;
}
