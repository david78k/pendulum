/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:43 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "q_demo.h"
#include "get_action.h"
#include "get_box.h"
#include "guidata.h"
#include "guihandles.h"
#include "imread.h"
#include "imshow.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "openfig.h"
#include "opengl.h"
#include "reset_cart.h"
#include "surf.h"
#include "title.h"

extern mxArray * ALPHA;
extern mxArray * BETA;
extern mxArray * GAMMA;

static mxChar _array1_[10] = { 'r', 'i', 'g', 'h', 't',
                               's', '.', 'b', 'm', 'p' };
static mxArray * _mxarray0_;

static mxChar _array3_[6] = { 'q', '_', 'd', 'e', 'm', 'o' };
static mxArray * _mxarray2_;

static mxChar _array5_[5] = { 'r', 'e', 'u', 's', 'e' };
static mxArray * _mxarray4_;

static mxChar _array7_[5] = { 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray6_;
static mxArray * _mxarray8_;

static mxChar _array10_[31] = { 'd', 'e', 'f', 'a', 'u', 'l', 't', 'U',
                                'i', 'c', 'o', 'n', 't', 'r', 'o', 'l',
                                'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[6] = { 'S', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray12_;

static mxChar _array15_[5] = { 'V', 'a', 'l', 'u', 'e' };
static mxArray * _mxarray14_;

static mxChar _array17_[38] = { 'f', 'i', 'g', 'u', 'r', 'e', '1', ' ',
                                'R', 'e', 's', 'i', 'z', 'e', 'F', 'c',
                                'n', ' ', 'n', 'o', 't', ' ', 'i', 'm',
                                'p', 'l', 'e', 'm', 'e', 'n', 't', 'e',
                                'd', ' ', 'y', 'e', 't', '.' };
static mxArray * _mxarray16_;

static mxChar _array19_[10] = { 'a', 'u', 't', 'o', 's',
                                'e', 'l', 'e', 'c', 't' };
static mxArray * _mxarray18_;
static mxArray * _mxarray20_;
static mxArray * _mxarray21_;
static mxArray * _mxarray22_;
static mxArray * _mxarray23_;
static mxArray * _mxarray24_;
static mxArray * _mxarray25_;
static mxArray * _mxarray26_;
static mxArray * _mxarray27_;

static double _array29_[4] = { -3.0, 3.0, 0.0, 1.5 };
static mxArray * _mxarray28_;

static mxChar _array31_[15] = { 'D', 'a', 't', 'a', 'A', 's', 'p', 'e',
                                'c', 't', 'R', 'a', 't', 'i', 'o' };
static mxArray * _mxarray30_;

static double _array33_[3] = { 1.0, 1.0, 1.0 };
static mxArray * _mxarray32_;

static mxChar _array35_[8] = { 'P', 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray34_;

static double _array37_[4] = { 10.0, 100.0, 500.0, 200.0 };
static mxArray * _mxarray36_;

static mxChar _array39_[12] = { 'D', 'o', 'u', 'b', 'l', 'e',
                                'B', 'u', 'f', 'f', 'e', 'r' };
static mxArray * _mxarray38_;

static mxChar _array41_[2] = { 'o', 'n' };
static mxArray * _mxarray40_;

static mxChar _array43_[18] = { 'P', 'l', 'o', 't', 'B', 'o', 'x', 'A', 's',
                                'p', 'e', 'c', 't', 'R', 'a', 't', 'i', 'o' };
static mxArray * _mxarray42_;

static double _array45_[4] = { 510.0, 50.0, 400.0, 400.0 };
static mxArray * _mxarray44_;

static mxChar _array47_[8] = { 'R', 'e', 'n', 'd', 'e', 'r', 'e', 'r' };
static mxArray * _mxarray46_;

static mxChar _array49_[6] = { 'O', 'p', 'e', 'n', 'G', 'L' };
static mxArray * _mxarray48_;
static mxArray * _mxarray50_;
static mxArray * _mxarray51_;

static double _array53_[18] = { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0,
                                8.0, 9.0, 10.0, 11.0, 12.0, 13.0,
                                14.0, 15.0, 16.0, 17.0, 18.0 };
static mxArray * _mxarray52_;

static double _array55_[9] = { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0 };
static mxArray * _mxarray54_;
static mxArray * _mxarray56_;
static mxArray * _mxarray57_;
static mxArray * _mxarray58_;
static mxArray * _mxarray59_;
static mxArray * _mxarray60_;
static mxArray * _mxarray61_;
static mxArray * _mxarray62_;
static mxArray * _mxarray63_;
static mxArray * _mxarray64_;

static mxChar _array66_[9] = { 'f', 'a', 'c', 'e', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray65_;

static mxChar _array68_[1] = { 'b' };
static mxArray * _mxarray67_;
static mxArray * _mxarray69_;

static mxChar _array71_[2] = { 'r', '>' };
static mxArray * _mxarray70_;

static mxChar _array73_[2] = { 'r', '<' };
static mxArray * _mxarray72_;
static mxArray * _mxarray74_;

static mxChar _array76_[8] = { 'T', 'r', 'i', 'a', 'l', 's', ' ', ' ' };
static mxArray * _mxarray75_;

static mxChar _array78_[17] = { ',', ' ', 'B', 'e', 's', 't', ' ', 's', 'u',
                                'c', 'c', 'e', 's', 's', ' ', ':', ' ' };
static mxArray * _mxarray77_;

static mxChar _array80_[52] = { 'Q', '-', 'v', 'a', 'l', 'u', 'e', ' ', 'm',
                                'e', 's', 'h', ' ', ':', ' ', 'u', 'p', ' ',
                                'i', 's', ' ', 'p', 'u', 's', 'h', ' ', 'r',
                                'i', 'g', 'h', 't', ',', ' ', 'b', 'o', 't',
                                't', 'o', 'm', ' ', 'i', 's', ' ', 'p', 'u',
                                's', 'h', ' ', 'l', 'e', 'f', 't' };
static mxArray * _mxarray79_;
static mxArray * _mxarray81_;
static mxArray * _mxarray82_;
static mxArray * _mxarray83_;

static mxChar _array85_[11] = { 'S', 'u', 'c', 'c', 'e', 's',
                                's', ' ', 'a', 't', ' ' };
static mxArray * _mxarray84_;

static mxChar _array87_[7] = { ' ', 't', 'r', 'i', 'a', 'l', 's' };
static mxArray * _mxarray86_;

void InitializeModule_q_demo(void) {
    _mxarray0_ = mclInitializeString(10, _array1_);
    _mxarray2_ = mclInitializeString(6, _array3_);
    _mxarray4_ = mclInitializeString(5, _array5_);
    _mxarray6_ = mclInitializeString(5, _array7_);
    _mxarray8_ = mclInitializeDouble(0.0);
    _mxarray9_ = mclInitializeString(31, _array10_);
    _mxarray11_ = mclInitializeDouble(1.0);
    _mxarray12_ = mclInitializeString(6, _array13_);
    _mxarray14_ = mclInitializeString(5, _array15_);
    _mxarray16_ = mclInitializeString(38, _array17_);
    _mxarray18_ = mclInitializeString(10, _array19_);
    _mxarray20_ = mclInitializeDouble(1.1);
    _mxarray21_ = mclInitializeDouble(.1);
    _mxarray22_ = mclInitializeDouble(9.8);
    _mxarray23_ = mclInitializeDouble(.5);
    _mxarray24_ = mclInitializeDouble(10.0);
    _mxarray25_ = mclInitializeDouble(.02);
    _mxarray26_ = mclInitializeDouble(162.0);
    _mxarray27_ = mclInitializeDouble(2.0);
    _mxarray28_ = mclInitializeDoubleVector(1, 4, _array29_);
    _mxarray30_ = mclInitializeString(15, _array31_);
    _mxarray32_ = mclInitializeDoubleVector(1, 3, _array33_);
    _mxarray34_ = mclInitializeString(8, _array35_);
    _mxarray36_ = mclInitializeDoubleVector(1, 4, _array37_);
    _mxarray38_ = mclInitializeString(12, _array39_);
    _mxarray40_ = mclInitializeString(2, _array41_);
    _mxarray42_ = mclInitializeString(18, _array43_);
    _mxarray44_ = mclInitializeDoubleVector(1, 4, _array45_);
    _mxarray46_ = mclInitializeString(8, _array47_);
    _mxarray48_ = mclInitializeString(6, _array49_);
    _mxarray50_ = mclInitializeDouble(40.0);
    _mxarray51_ = mclInitializeDouble(-30.0);
    _mxarray52_ = mclInitializeDoubleVector(1, 18, _array53_);
    _mxarray54_ = mclInitializeDoubleVector(1, 9, _array55_);
    _mxarray56_ = mclInitializeDouble(9.0);
    _mxarray57_ = mclInitializeDouble(18.0);
    _mxarray58_ = mclInitializeDouble(100000.0);
    _mxarray59_ = mclInitializeDouble(-1.0);
    _mxarray60_ = mclInitializeDouble(1.3333333333333333);
    _mxarray61_ = mclInitializeDouble(1.5707963267948966);
    _mxarray62_ = mclInitializeDouble(.2);
    _mxarray63_ = mclInitializeDouble(.4);
    _mxarray64_ = mclInitializeDouble(.8);
    _mxarray65_ = mclInitializeString(9, _array66_);
    _mxarray67_ = mclInitializeString(1, _array68_);
    _mxarray69_ = mclInitializeDouble(.11);
    _mxarray70_ = mclInitializeString(2, _array71_);
    _mxarray72_ = mclInitializeString(2, _array73_);
    _mxarray74_ = mclInitializeDouble(1e-11);
    _mxarray75_ = mclInitializeString(8, _array76_);
    _mxarray77_ = mclInitializeString(17, _array78_);
    _mxarray79_ = mclInitializeString(52, _array80_);
    _mxarray81_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray82_ = mclInitializeDouble(30.0);
    _mxarray83_ = mclInitializeDouble(-15.0);
    _mxarray84_ = mclInitializeString(11, _array85_);
    _mxarray86_ = mclInitializeString(7, _array87_);
}

void TerminateModule_q_demo(void) {
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray82_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfQ_demo_alpha_sl_Callback(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...);
static void mlxQ_demo_alpha_sl_Callback(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfQ_demo_beta_sl_Callback(mlfVarargoutList * varargout,
                                            mxArray * h,
                                            mxArray * eventdata,
                                            mxArray * handles,
                                            ...);
static void mlxQ_demo_beta_sl_Callback(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfQ_demo_gamma_sl_Callback(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...);
static void mlxQ_demo_gamma_sl_Callback(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfQ_demo_reinf_sl_Callback(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...);
static void mlxQ_demo_reinf_sl_Callback(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfQ_demo_pushbutton2_Callback(mlfVarargoutList * varargout,
                                                mxArray * h,
                                                mxArray * eventdata,
                                                mxArray * handles,
                                                ...);
static void mlxQ_demo_pushbutton2_Callback(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static mxArray * mlfQ_demo_figure1_ResizeFcn(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...);
static void mlxQ_demo_figure1_ResizeFcn(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfQ_demo_pushbutton1_Callback(mlfVarargoutList * varargout,
                                                mxArray * h,
                                                mxArray * eventdata,
                                                mxArray * handles,
                                                ...);
static void mlxQ_demo_pushbutton1_Callback(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static mxArray * Mq_demo(int nargout_, mxArray * varargin);
static mxArray * Mq_demo_alpha_sl_Callback(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin);
static mxArray * Mq_demo_beta_sl_Callback(int nargout_,
                                          mxArray * h,
                                          mxArray * eventdata,
                                          mxArray * handles,
                                          mxArray * varargin);
static mxArray * Mq_demo_gamma_sl_Callback(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin);
static mxArray * Mq_demo_reinf_sl_Callback(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin);
static mxArray * Mq_demo_pushbutton2_Callback(int nargout_,
                                              mxArray * h,
                                              mxArray * eventdata,
                                              mxArray * handles,
                                              mxArray * varargin);
static mxArray * Mq_demo_figure1_ResizeFcn(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin);
static mxArray * Mq_demo_pushbutton1_Callback(int nargout_,
                                              mxArray * h,
                                              mxArray * eventdata,
                                              mxArray * handles,
                                              mxArray * varargin);

static mexFunctionTableEntry local_function_table_[7]
  = { { "alpha_sl_Callback", mlxQ_demo_alpha_sl_Callback, -4, -1, NULL },
      { "beta_sl_Callback", mlxQ_demo_beta_sl_Callback, -4, -1, NULL },
      { "gamma_sl_Callback", mlxQ_demo_gamma_sl_Callback, -4, -1, NULL },
      { "reinf_sl_Callback", mlxQ_demo_reinf_sl_Callback, -4, -1, NULL },
      { "pushbutton2_Callback", mlxQ_demo_pushbutton2_Callback, -4, -1, NULL },
      { "figure1_ResizeFcn", mlxQ_demo_figure1_ResizeFcn, -4, -1, NULL },
      { "pushbutton1_Callback",
        mlxQ_demo_pushbutton1_Callback, -4, -1, NULL } };

_mexLocalFunctionTable _local_function_table_q_demo
  = { 7, local_function_table_ };

/*
 * The function "mlfNQ_demo" contains the nargout interface for the "q_demo"
 * M-function from file "C:\temp\q\Q_Demo.m" (lines 1-72). This interface is
 * only produced if the M-function uses the special variable "nargout". The
 * nargout interface allows the number of requested outputs to be specified via
 * the nargout argument, as opposed to the normal interface which dynamically
 * calculates the number of outputs based on the number of non-NULL inputs it
 * receives. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfNQ_demo(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mq_demo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfQ_demo" contains the normal interface for the "q_demo"
 * M-function from file "C:\temp\q\Q_Demo.m" (lines 1-72). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfQ_demo(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mq_demo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVQ_demo" contains the void interface for the "q_demo"
 * M-function from file "C:\temp\q\Q_Demo.m" (lines 1-72). The void interface
 * is only produced if the M-function uses the special variable "nargout", and
 * has at least one output. The void interface function specifies zero output
 * arguments to the implementation version of the function, and in the event
 * that the implementation version still returns an output (which, in MATLAB,
 * would be assigned to the "ans" variable), it deallocates the output. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
void mlfVQ_demo(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mq_demo(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxQ_demo" contains the feval interface for the "q_demo"
 * M-function from file "C:\temp\q\Q_Demo.m" (lines 1-72). The feval function
 * calls the implementation version of q_demo through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
void mlxQ_demo(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mq_demo(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfQ_demo_alpha_sl_Callback" contains the normal interface for
 * the "q_demo/alpha_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 72-77). This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static mxArray * mlfQ_demo_alpha_sl_Callback(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, h, eventdata, handles, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mq_demo_alpha_sl_Callback(nargout, h, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, h, eventdata, handles);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxQ_demo_alpha_sl_Callback" contains the feval interface for
 * the "q_demo/alpha_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 72-77). The feval function calls the implementation version of
 * q_demo/alpha_sl_Callback through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxQ_demo_alpha_sl_Callback(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    mplhs[0]
      = Mq_demo_alpha_sl_Callback(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfQ_demo_beta_sl_Callback" contains the normal interface for
 * the "q_demo/beta_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 77-82). This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static mxArray * mlfQ_demo_beta_sl_Callback(mlfVarargoutList * varargout,
                                            mxArray * h,
                                            mxArray * eventdata,
                                            mxArray * handles,
                                            ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, h, eventdata, handles, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mq_demo_beta_sl_Callback(nargout, h, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, h, eventdata, handles);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxQ_demo_beta_sl_Callback" contains the feval interface for
 * the "q_demo/beta_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 77-82). The feval function calls the implementation version of
 * q_demo/beta_sl_Callback through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxQ_demo_beta_sl_Callback(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    mplhs[0]
      = Mq_demo_beta_sl_Callback(nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfQ_demo_gamma_sl_Callback" contains the normal interface for
 * the "q_demo/gamma_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 82-87). This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static mxArray * mlfQ_demo_gamma_sl_Callback(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, h, eventdata, handles, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mq_demo_gamma_sl_Callback(nargout, h, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, h, eventdata, handles);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxQ_demo_gamma_sl_Callback" contains the feval interface for
 * the "q_demo/gamma_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 82-87). The feval function calls the implementation version of
 * q_demo/gamma_sl_Callback through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxQ_demo_gamma_sl_Callback(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    mplhs[0]
      = Mq_demo_gamma_sl_Callback(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfQ_demo_reinf_sl_Callback" contains the normal interface for
 * the "q_demo/reinf_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 87-93). This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static mxArray * mlfQ_demo_reinf_sl_Callback(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, h, eventdata, handles, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mq_demo_reinf_sl_Callback(nargout, h, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, h, eventdata, handles);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxQ_demo_reinf_sl_Callback" contains the feval interface for
 * the "q_demo/reinf_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 87-93). The feval function calls the implementation version of
 * q_demo/reinf_sl_Callback through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxQ_demo_reinf_sl_Callback(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    mplhs[0]
      = Mq_demo_reinf_sl_Callback(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfQ_demo_pushbutton2_Callback" contains the normal interface
 * for the "q_demo/pushbutton2_Callback" M-function from file
 * "C:\temp\q\Q_Demo.m" (lines 93-97). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static mxArray * mlfQ_demo_pushbutton2_Callback(mlfVarargoutList * varargout,
                                                mxArray * h,
                                                mxArray * eventdata,
                                                mxArray * handles,
                                                ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, h, eventdata, handles, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mq_demo_pushbutton2_Callback(nargout, h, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, h, eventdata, handles);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxQ_demo_pushbutton2_Callback" contains the feval interface
 * for the "q_demo/pushbutton2_Callback" M-function from file
 * "C:\temp\q\Q_Demo.m" (lines 93-97). The feval function calls the
 * implementation version of q_demo/pushbutton2_Callback through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxQ_demo_pushbutton2_Callback(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    mplhs[0]
      = Mq_demo_pushbutton2_Callback(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfQ_demo_figure1_ResizeFcn" contains the normal interface for
 * the "q_demo/figure1_ResizeFcn" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 97-103). This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static mxArray * mlfQ_demo_figure1_ResizeFcn(mlfVarargoutList * varargout,
                                             mxArray * h,
                                             mxArray * eventdata,
                                             mxArray * handles,
                                             ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, h, eventdata, handles, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mq_demo_figure1_ResizeFcn(nargout, h, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, h, eventdata, handles);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxQ_demo_figure1_ResizeFcn" contains the feval interface for
 * the "q_demo/figure1_ResizeFcn" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 97-103). The feval function calls the implementation version of
 * q_demo/figure1_ResizeFcn through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxQ_demo_figure1_ResizeFcn(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    mplhs[0]
      = Mq_demo_figure1_ResizeFcn(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfQ_demo_pushbutton1_Callback" contains the normal interface
 * for the "q_demo/pushbutton1_Callback" M-function from file
 * "C:\temp\q\Q_Demo.m" (lines 103-207). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static mxArray * mlfQ_demo_pushbutton1_Callback(mlfVarargoutList * varargout,
                                                mxArray * h,
                                                mxArray * eventdata,
                                                mxArray * handles,
                                                ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, h, eventdata, handles, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mq_demo_pushbutton1_Callback(nargout, h, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, h, eventdata, handles);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxQ_demo_pushbutton1_Callback" contains the feval interface
 * for the "q_demo/pushbutton1_Callback" M-function from file
 * "C:\temp\q\Q_Demo.m" (lines 103-207). The feval function calls the
 * implementation version of q_demo/pushbutton1_Callback through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxQ_demo_pushbutton1_Callback(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    mplhs[0]
      = Mq_demo_pushbutton1_Callback(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "Mq_demo" is the implementation version of the "q_demo"
 * M-function from file "C:\temp\q\Q_Demo.m" (lines 1-72). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function varargout = Q_Demo(varargin)
 */
static mxArray * Mq_demo(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * _T0_ = mclGetUninitializedArray();
    mxArray * handles = mclGetUninitializedArray();
    mxArray * fig = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * A = mclGetUninitializedArray();
    mclCopyArray(&varargin);
    /*
     * 
     * % MENU Application M-file for menu.fig
     * %    FIG = MENU launch menu GUI.
     * %    MENU('callback_name', ...) invoke the named callback.
     * 
     * % Last Modified by GUIDE v2.0 21-Jan-2001 11:36:23
     * A=imread('rights.bmp');
     */
    mlfAssign(&A, mlfNImread(1, NULL, NULL, _mxarray0_, NULL));
    /*
     * imshow(A)
     */
    mclPrintAns(&ans, mlfNImshow(0, mclVv(A, "A"), NULL));
    /*
     * 
     * if nargin == 0  % LAUNCH GUI
     */
    if (nargin_ == 0) {
        /*
         * 
         * fig = openfig(mfilename,'reuse');
         */
        mlfAssign(&fig, mlfOpenfig(_mxarray2_, _mxarray4_));
        /*
         * 
         * % Use system color scheme for figure:
         * set(fig,'Color',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(fig, "fig"),
            _mxarray6_,
            mclVe(mlfNGet(1, _mxarray8_, _mxarray9_, NULL)),
            NULL));
        /*
         * 
         * % Generate a structure of handles to pass to callbacks, and store it. 
         * handles = guihandles(fig);
         */
        mlfAssign(&handles, mlfGuihandles(mclVv(fig, "fig")));
        /*
         * guidata(fig, handles);
         */
        mclAssignAns(
          &ans, mlfNGuidata(0, mclVv(fig, "fig"), mclVv(handles, "handles")));
        /*
         * 
         * if nargout > 0
         */
        if (nargout_ > 0) {
            /*
             * varargout{1} = fig;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray11_, mclVsv(fig, "fig"));
        /*
         * end
         */
        }
    /*
     * 
     * elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK
     */
    } else if (mlfTobool(
                 mclVe(
                   mclFeval(
                     mclValueVarargout(),
                     mlxIschar,
                     mclVe(
                       mlfIndexRef(
                         mclVsa(varargin, "varargin"), "{?}", _mxarray11_)),
                     NULL)))) {
        /*
         * 
         * try
         */
        mlfTry {
            /*
             * [varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
             */
            mlfAssign(&_T0_, mlfColon(_mxarray11_, mlfScalar(nargout_), NULL));
            mlfFeval(
              mlfIndexVarargout(&varargout, "{?}", _T0_, NULL),
              mclVe(
                mlfIndexRef(
                  mclVsa(varargin, "varargin"), "{?}", mlfCreateColonIndex())),
              NULL);
        /*
         * catch
         */
        } mlfCatch {
            /*
             * disp(lasterr);
             */
            mlfDisp(mclVe(mlfLasterr(NULL)));
        /*
         * end
         */
        } mlfEndCatch
    /*
     * 
     * end
     */
    }
    mxDestroyArray(A);
    mxDestroyArray(ans);
    mxDestroyArray(fig);
    mxDestroyArray(handles);
    mxDestroyArray(_T0_);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * 
     * %| ABOUT CALLBACKS:
     * %| GUIDE automatically appends subfunction prototypes to this file, and 
     * %| sets objects' callback properties to call them through the FEVAL 
     * %| switchyard above. This comment describes that mechanism.
     * %|
     * %| Each callback subfunction declaration has the following form:
     * %| <SUBFUNCTION_NAME>(H, EVENTDATA, HANDLES, VARARGIN)
     * %|
     * %| The subfunction name is composed using the object's Tag and the 
     * %| callback type separated by '_', e.g. 'slider2_Callback',
     * %| 'figure1_CloseRequestFcn', 'axis1_ButtondownFcn'.
     * %|
     * %| H is the callback object's handle (obtained using GCBO).
     * %|
     * %| EVENTDATA is empty, but reserved for future use.
     * %|
     * %| HANDLES is a structure containing handles of components in GUI using
     * %| tags as fieldnames, e.g. handles.figure1, handles.slider2. This
     * %| structure is created at GUI startup using GUIHANDLES and stored in
     * %| the figure's application data using GUIDATA. A copy of the structure
     * %| is passed to each callback.  You can store additional information in
     * %| this structure at GUI startup, and you can change the structure
     * %| during callbacks.  Call guidata(h, handles) after changing your
     * %| copy to replace the stored original so that subsequent callbacks see
     * %| the updates. Type "help guihandles" and "help guidata" for more
     * %| information.
     * %|
     * %| VARARGIN contains any extra arguments you have passed to the
     * %| callback. Specify the extra arguments by editing the callback
     * %| property in the inspector. By default, GUIDE sets the property to:
     * %| <MFILENAME>('<SUBFUNCTION_NAME>', gcbo, [], guidata(gcbo))
     * %| Add any extra arguments after the last argument, before the final
     * %| closing parenthesis.
     * 
     * % --------------------------------------------------------------------
     * function varargout = alpha_sl_Callback(h, eventdata, handles, varargin)
     * set(handles.alpha,'String',...
     * num2str(get(handles.alpha_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     */
}

/*
 * The function "Mq_demo_alpha_sl_Callback" is the implementation version of
 * the "q_demo/alpha_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 72-77). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function varargout = alpha_sl_Callback(h, eventdata, handles, varargin)
 */
static mxArray * Mq_demo_alpha_sl_Callback(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&h);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * set(handles.alpha,'String',...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".alpha")),
        _mxarray12_,
        mclVe(
          mlfNum2str(
            mclVe(
              mlfNGet(
                1,
                mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".alpha_sl")),
                _mxarray14_,
                NULL)),
            NULL)),
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(h);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * num2str(get(handles.alpha_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     * function varargout = beta_sl_Callback(h, eventdata, handles, varargin)
     * set(handles.beta,'String',...
     * num2str(get(handles.beta_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     */
}

/*
 * The function "Mq_demo_beta_sl_Callback" is the implementation version of the
 * "q_demo/beta_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m" (lines
 * 77-82). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function varargout = beta_sl_Callback(h, eventdata, handles, varargin)
 */
static mxArray * Mq_demo_beta_sl_Callback(int nargout_,
                                          mxArray * h,
                                          mxArray * eventdata,
                                          mxArray * handles,
                                          mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&h);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * set(handles.beta,'String',...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".beta")),
        _mxarray12_,
        mclVe(
          mlfNum2str(
            mclVe(
              mlfNGet(
                1,
                mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".beta_sl")),
                _mxarray14_,
                NULL)),
            NULL)),
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(h);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * num2str(get(handles.beta_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     * function varargout = gamma_sl_Callback(h, eventdata, handles, varargin)
     * set(handles.gamma,'String',...
     * num2str(get(handles.gamma_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     */
}

/*
 * The function "Mq_demo_gamma_sl_Callback" is the implementation version of
 * the "q_demo/gamma_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 82-87). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function varargout = gamma_sl_Callback(h, eventdata, handles, varargin)
 */
static mxArray * Mq_demo_gamma_sl_Callback(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&h);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * set(handles.gamma,'String',...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".gamma")),
        _mxarray12_,
        mclVe(
          mlfNum2str(
            mclVe(
              mlfNGet(
                1,
                mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".gamma_sl")),
                _mxarray14_,
                NULL)),
            NULL)),
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(h);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * num2str(get(handles.gamma_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     * function varargout = reinf_sl_Callback(h, eventdata, handles, varargin)
     * set(handles.reinf,'String',...
     * num2str(get(handles.reinf_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     * % Quit button
     */
}

/*
 * The function "Mq_demo_reinf_sl_Callback" is the implementation version of
 * the "q_demo/reinf_sl_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 87-93). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function varargout = reinf_sl_Callback(h, eventdata, handles, varargin)
 */
static mxArray * Mq_demo_reinf_sl_Callback(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&h);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * set(handles.reinf,'String',...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".reinf")),
        _mxarray12_,
        mclVe(
          mlfNum2str(
            mclVe(
              mlfNGet(
                1,
                mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".reinf_sl")),
                _mxarray14_,
                NULL)),
            NULL)),
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(h);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * num2str(get(handles.reinf_sl,'Value')));
     * 
     * % --------------------------------------------------------------------
     * % Quit button
     * function varargout = pushbutton2_Callback(h, eventdata, handles, varargin)
     * delete(handles.figure1);
     * 
     * % --------------------------------------------------------------------
     */
}

/*
 * The function "Mq_demo_pushbutton2_Callback" is the implementation version of
 * the "q_demo/pushbutton2_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 93-97). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function varargout = pushbutton2_Callback(h, eventdata, handles, varargin)
 */
static mxArray * Mq_demo_pushbutton2_Callback(int nargout_,
                                              mxArray * h,
                                              mxArray * eventdata,
                                              mxArray * handles,
                                              mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&h);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * delete(handles.figure1);
     */
    mlfDelete(mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".figure1")), NULL);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(h);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * % --------------------------------------------------------------------
     * function varargout = figure1_ResizeFcn(h, eventdata, handles, varargin)
     * % Stub for ResizeFcn of the figure handles.figure1.
     * disp('figure1 ResizeFcn not implemented yet.')
     * 
     * % --------------------------------------------------------------------
     * % It is the main start button for q-learning demo
     */
}

/*
 * The function "Mq_demo_figure1_ResizeFcn" is the implementation version of
 * the "q_demo/figure1_ResizeFcn" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 97-103). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function varargout = figure1_ResizeFcn(h, eventdata, handles, varargin)
 */
static mxArray * Mq_demo_figure1_ResizeFcn(int nargout_,
                                           mxArray * h,
                                           mxArray * eventdata,
                                           mxArray * handles,
                                           mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&h);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * % Stub for ResizeFcn of the figure handles.figure1.
     * disp('figure1 ResizeFcn not implemented yet.')
     */
    mlfDisp(_mxarray16_);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(h);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * % --------------------------------------------------------------------
     * % It is the main start button for q-learning demo
     * function varargout = pushbutton1_Callback(h, eventdata, handles, varargin)
     * opengl autoselect;
     * global ALPHA BETA GAMMA
     * ALPHA = get(handles.alpha_sl,'Value')  % learning rate parameter 
     * BETA = get(handles.beta_sl,'Value')    % magnitude of noise added to choice 
     * GAMMA = get(handles.alpha_sl,'Value')  % discount factor for future reinf 
     * if (get(handles.radiobutton1,'Value')==0)
     * BETA=0
     * end  %if
     * m=1.1;  %mass of cart + pole 
     * mp=0.1; %mass of the pole
     * g=9.8;  %���O�[�t��
     * length=0.5;  %half length of pole
     * Force=10;   %force =10N
     * T=0.02;  % Update time interval
     * % Define global variable
     * NUM_BOX=162;    % Number of states sets to 162
     * [pre_state,cur_state,pre_action,cur_action,x,v_x,theta,v_theta] = reset_cart(BETA);  % reset the cart pole to initial state
     * q_val=zeros(162,2);
     * h1=figure;    % this figure is cart-pole
     * axis([-3 3 0 1.5]);
     * set(gca, 'DataAspectRatio',[1 1 1]);
     * set(h1, 'Position',[10 100 500 200]);
     * set(h1,'DoubleBuffer','on')
     * set(gca, 'PlotBoxAspectRatio',[1 1 1]);
     * h2 = figure;   % this figure is Q-value
     * set(h2,'Position',[510 50 400 400]);
     * set(h2,'Renderer','OpenGL')
     * view(40,-30);
     * success=0;   % succesee 0 times
     * reinf=0;
     * trial=0;
     * % prepare grid for
     * [GX,GY]=meshgrid(1:18,1:9);
     * GZ=zeros(9,18);
     * best=0;
     * while success<100000
     * [q_val,pre_state,pre_action,cur_state,cur_action] = get_action(x,v_x,theta,v_theta,reinf,q_val,pre_state,cur_state,pre_action,cur_action,ALPHA,BETA,GAMMA);
     * if (cur_action==1)   % push left
     * F=-1*Force;
     * else  F=Force;    % push right
     * end %if
     * % Update the cart-pole state
     * a_theta=(m*g*sin(theta)-cos(theta)*(F+mp*length*v_theta^2*sin(theta)))/(4/3*m*length-mp*length*cos(theta)^2);
     * a_x=(F+mp*length*(v_theta^2*sin(theta)-a_theta*cos(theta)))/m;
     * v_theta=v_theta+a_theta*T;
     * theta=theta+v_theta*T;
     * v_x=v_x+a_x*T;
     * x=x+v_x*T;
     * % draw new state
     * figure(h1);
     * X=[x   x+cos(pi/2-theta)];
     * Y=[0.2  0.2+sin(pi/2-theta)];
     * obj=rectangle('Position',[x-0.4,0.1,0.8,0.1],...
     * 'facecolor','b');
     * obj2=line(X,Y);  
     * hold on
     * if (F>0)
     * obj3=plot(x-0.4,0.11,'r>');
     * else
     * obj3=plot(x+0.4,0.11,'r<');
     * end %if
     * pause(0.00000000001)
     * delete(obj)
     * delete(obj2)
     * delete(obj3)
     * % get new box
     * [box] = get_box(x,v_x,theta,v_theta);
     * if (box== -1)  % if fail
     * reinf=get(handles.reinf_sl,'Value');
     * predicted_value=0;
     * q_val(pre_state,pre_action)= q_val(pre_state,pre_action)+ ALPHA*(reinf+ GAMMA*predicted_value - q_val(pre_state,pre_action));
     * [pre_state,cur_state,pre_action,cur_action,x,v_x,theta,v_theta] = reset_cart(BETA);  % reset the cart pole to initial state
     * trial=trial+1;
     * if (success>best)
     * best=success;
     * end
     * success=0;
     * figure(h1);
     * title(strcat('Trials  ',num2str(trial),', Best success : ',num2str(best)));
     * % draw q-val figure
     * figure(h2);
     * title('Q-value mesh : up is push right, bottom is push left');
     * for i=1:2
     * m=1;
     * for j=1:9
     * for k=1:18
     * GZ(j,k)=q_val(m,i)+i;  
     * m=m+1;
     * end % k
     * end  % j
     * surf(GX,GY,GZ);
     * view(30,-15);
     * hold on;
     * end  %for i
     * else
     * success=success+1;
     * reinf=0;
     * end  %if (box
     * 
     * end %while
     * figure(h1);
     * title(strcat('Success at ',num2str(trial)),' trials');
     * 
     */
}

/*
 * The function "Mq_demo_pushbutton1_Callback" is the implementation version of
 * the "q_demo/pushbutton1_Callback" M-function from file "C:\temp\q\Q_Demo.m"
 * (lines 103-207). It contains the actual compiled code for that M-function.
 * It is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function varargout = pushbutton1_Callback(h, eventdata, handles, varargin)
 */
static mxArray * Mq_demo_pushbutton1_Callback(int nargout_,
                                              mxArray * h,
                                              mxArray * eventdata,
                                              mxArray * handles,
                                              mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_q_demo);
    mxArray * varargout = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * j = mclGetUninitializedArray();
    mxArray * i = mclGetUninitializedArray();
    mxArray * predicted_value = mclGetUninitializedArray();
    mxArray * box = mclGetUninitializedArray();
    mxArray * obj3 = mclGetUninitializedArray();
    mxArray * obj2 = mclGetUninitializedArray();
    mxArray * obj = mclGetUninitializedArray();
    mxArray * Y = mclGetUninitializedArray();
    mxArray * X = mclGetUninitializedArray();
    mxArray * a_x = mclGetUninitializedArray();
    mxArray * a_theta = mclGetUninitializedArray();
    mxArray * F = mclGetUninitializedArray();
    mxArray * best = mclGetUninitializedArray();
    mxArray * GZ = mclGetUninitializedArray();
    mxArray * GY = mclGetUninitializedArray();
    mxArray * GX = mclGetUninitializedArray();
    mxArray * trial = mclGetUninitializedArray();
    mxArray * reinf = mclGetUninitializedArray();
    mxArray * success = mclGetUninitializedArray();
    mxArray * h2 = mclGetUninitializedArray();
    mxArray * h1 = mclGetUninitializedArray();
    mxArray * q_val = mclGetUninitializedArray();
    mxArray * v_theta = mclGetUninitializedArray();
    mxArray * theta = mclGetUninitializedArray();
    mxArray * v_x = mclGetUninitializedArray();
    mxArray * x = mclGetUninitializedArray();
    mxArray * cur_action = mclGetUninitializedArray();
    mxArray * pre_action = mclGetUninitializedArray();
    mxArray * cur_state = mclGetUninitializedArray();
    mxArray * pre_state = mclGetUninitializedArray();
    mxArray * NUM_BOX = mclGetUninitializedArray();
    mxArray * T = mclGetUninitializedArray();
    mxArray * Force = mclGetUninitializedArray();
    mxArray * length = mclGetUninitializedArray();
    mxArray * g = mclGetUninitializedArray();
    mxArray * mp = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&h);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * opengl autoselect;
     */
    mclAssignAns(&ans, mlfNOpengl(0, _mxarray18_));
    /*
     * global ALPHA BETA GAMMA
     * ALPHA = get(handles.alpha_sl,'Value')  % learning rate parameter 
     */
    mlfAssign(
      mclPrepareGlobal(&ALPHA),
      mlfNGet(
        1,
        mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".alpha_sl")),
        _mxarray14_,
        NULL));
    mclPrintArray(mclVg(&ALPHA, "ALPHA"), "ALPHA");
    /*
     * BETA = get(handles.beta_sl,'Value')    % magnitude of noise added to choice 
     */
    mlfAssign(
      mclPrepareGlobal(&BETA),
      mlfNGet(
        1,
        mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".beta_sl")),
        _mxarray14_,
        NULL));
    mclPrintArray(mclVg(&BETA, "BETA"), "BETA");
    /*
     * GAMMA = get(handles.alpha_sl,'Value')  % discount factor for future reinf 
     */
    mlfAssign(
      mclPrepareGlobal(&GAMMA),
      mlfNGet(
        1,
        mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".alpha_sl")),
        _mxarray14_,
        NULL));
    mclPrintArray(mclVg(&GAMMA, "GAMMA"), "GAMMA");
    /*
     * if (get(handles.radiobutton1,'Value')==0)
     */
    if (mclEqBool(
          mclVe(
            mlfNGet(
              1,
              mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".radiobutton1")),
              _mxarray14_,
              NULL)),
          _mxarray8_)) {
        /*
         * BETA=0
         */
        mlfAssign(mclPrepareGlobal(&BETA), _mxarray8_);
        mclPrintArray(mclVg(&BETA, "BETA"), "BETA");
    /*
     * end  %if
     */
    }
    /*
     * m=1.1;  %mass of cart + pole 
     */
    mlfAssign(&m, _mxarray20_);
    /*
     * mp=0.1; %mass of the pole
     */
    mlfAssign(&mp, _mxarray21_);
    /*
     * g=9.8;  %���O�[�t��
     */
    mlfAssign(&g, _mxarray22_);
    /*
     * length=0.5;  %half length of pole
     */
    mlfAssign(&length, _mxarray23_);
    /*
     * Force=10;   %force =10N
     */
    mlfAssign(&Force, _mxarray24_);
    /*
     * T=0.02;  % Update time interval
     */
    mlfAssign(&T, _mxarray25_);
    /*
     * % Define global variable
     * NUM_BOX=162;    % Number of states sets to 162
     */
    mlfAssign(&NUM_BOX, _mxarray26_);
    /*
     * [pre_state,cur_state,pre_action,cur_action,x,v_x,theta,v_theta] = reset_cart(BETA);  % reset the cart pole to initial state
     */
    mlfAssign(
      &pre_state,
      mlfReset_cart(
        &cur_state,
        &pre_action,
        &cur_action,
        &x,
        &v_x,
        &theta,
        &v_theta,
        mclVg(&BETA, "BETA")));
    /*
     * q_val=zeros(162,2);
     */
    mlfAssign(&q_val, mlfZeros(_mxarray26_, _mxarray27_, NULL));
    /*
     * h1=figure;    % this figure is cart-pole
     */
    mlfAssign(&h1, mlfNFigure(1, NULL));
    /*
     * axis([-3 3 0 1.5]);
     */
    mclAssignAns(&ans, mlfAxis(NULL, NULL, _mxarray28_, NULL));
    /*
     * set(gca, 'DataAspectRatio',[1 1 1]);
     */
    mclAssignAns(
      &ans, mlfNSet(0, mclVe(mlfGca(NULL)), _mxarray30_, _mxarray32_, NULL));
    /*
     * set(h1, 'Position',[10 100 500 200]);
     */
    mclAssignAns(
      &ans, mlfNSet(0, mclVv(h1, "h1"), _mxarray34_, _mxarray36_, NULL));
    /*
     * set(h1,'DoubleBuffer','on')
     */
    mclPrintAns(
      &ans, mlfNSet(0, mclVv(h1, "h1"), _mxarray38_, _mxarray40_, NULL));
    /*
     * set(gca, 'PlotBoxAspectRatio',[1 1 1]);
     */
    mclAssignAns(
      &ans, mlfNSet(0, mclVe(mlfGca(NULL)), _mxarray42_, _mxarray32_, NULL));
    /*
     * h2 = figure;   % this figure is Q-value
     */
    mlfAssign(&h2, mlfNFigure(1, NULL));
    /*
     * set(h2,'Position',[510 50 400 400]);
     */
    mclAssignAns(
      &ans, mlfNSet(0, mclVv(h2, "h2"), _mxarray34_, _mxarray44_, NULL));
    /*
     * set(h2,'Renderer','OpenGL')
     */
    mclPrintAns(
      &ans, mlfNSet(0, mclVv(h2, "h2"), _mxarray46_, _mxarray48_, NULL));
    /*
     * view(40,-30);
     */
    mclAssignAns(&ans, mlfNView(0, NULL, _mxarray50_, _mxarray51_, NULL));
    /*
     * success=0;   % succesee 0 times
     */
    mlfAssign(&success, _mxarray8_);
    /*
     * reinf=0;
     */
    mlfAssign(&reinf, _mxarray8_);
    /*
     * trial=0;
     */
    mlfAssign(&trial, _mxarray8_);
    /*
     * % prepare grid for
     * [GX,GY]=meshgrid(1:18,1:9);
     */
    mlfAssign(&GX, mlfNMeshgrid(2, &GY, NULL, _mxarray52_, _mxarray54_, NULL));
    /*
     * GZ=zeros(9,18);
     */
    mlfAssign(&GZ, mlfZeros(_mxarray56_, _mxarray57_, NULL));
    /*
     * best=0;
     */
    mlfAssign(&best, _mxarray8_);
    /*
     * while success<100000
     */
    while (mclLtBool(mclVv(success, "success"), _mxarray58_)) {
        /*
         * [q_val,pre_state,pre_action,cur_state,cur_action] = get_action(x,v_x,theta,v_theta,reinf,q_val,pre_state,cur_state,pre_action,cur_action,ALPHA,BETA,GAMMA);
         */
        mlfAssign(
          &q_val,
          mlfGet_action(
            &pre_state,
            &pre_action,
            &cur_state,
            &cur_action,
            mclVv(x, "x"),
            mclVv(v_x, "v_x"),
            mclVv(theta, "theta"),
            mclVv(v_theta, "v_theta"),
            mclVv(reinf, "reinf"),
            mclVv(q_val, "q_val"),
            mclVv(pre_state, "pre_state"),
            mclVv(cur_state, "cur_state"),
            mclVv(pre_action, "pre_action"),
            mclVv(cur_action, "cur_action"),
            mclVg(&ALPHA, "ALPHA"),
            mclVg(&BETA, "BETA"),
            mclVg(&GAMMA, "GAMMA")));
        /*
         * if (cur_action==1)   % push left
         */
        if (mclEqBool(mclVv(cur_action, "cur_action"), _mxarray11_)) {
            /*
             * F=-1*Force;
             */
            mlfAssign(&F, mclMtimes(_mxarray59_, mclVv(Force, "Force")));
        /*
         * else  F=Force;    % push right
         */
        } else {
            mlfAssign(&F, mclVsv(Force, "Force"));
        /*
         * end %if
         */
        }
        /*
         * % Update the cart-pole state
         * a_theta=(m*g*sin(theta)-cos(theta)*(F+mp*length*v_theta^2*sin(theta)))/(4/3*m*length-mp*length*cos(theta)^2);
         */
        mlfAssign(
          &a_theta,
          mclMrdivide(
            mclMinus(
              mclMtimes(
                mclMtimes(mclVv(m, "m"), mclVv(g, "g")),
                mclVe(mlfSin(mclVv(theta, "theta")))),
              mclMtimes(
                mclVe(mlfCos(mclVv(theta, "theta"))),
                mclPlus(
                  mclVv(F, "F"),
                  mclMtimes(
                    mclMtimes(
                      mclMtimes(mclVv(mp, "mp"), mclVv(length, "length")),
                      mclMpower(mclVv(v_theta, "v_theta"), _mxarray27_)),
                    mclVe(mlfSin(mclVv(theta, "theta"))))))),
            mclMinus(
              mclMtimes(
                mclMtimes(_mxarray60_, mclVv(m, "m")), mclVv(length, "length")),
              mclMtimes(
                mclMtimes(mclVv(mp, "mp"), mclVv(length, "length")),
                mclMpower(
                  mclVe(mlfCos(mclVv(theta, "theta"))), _mxarray27_)))));
        /*
         * a_x=(F+mp*length*(v_theta^2*sin(theta)-a_theta*cos(theta)))/m;
         */
        mlfAssign(
          &a_x,
          mclMrdivide(
            mclPlus(
              mclVv(F, "F"),
              mclMtimes(
                mclMtimes(mclVv(mp, "mp"), mclVv(length, "length")),
                mclMinus(
                  mclMtimes(
                    mclMpower(mclVv(v_theta, "v_theta"), _mxarray27_),
                    mclVe(mlfSin(mclVv(theta, "theta")))),
                  mclMtimes(
                    mclVv(a_theta, "a_theta"),
                    mclVe(mlfCos(mclVv(theta, "theta"))))))),
            mclVv(m, "m")));
        /*
         * v_theta=v_theta+a_theta*T;
         */
        mlfAssign(
          &v_theta,
          mclPlus(
            mclVv(v_theta, "v_theta"),
            mclMtimes(mclVv(a_theta, "a_theta"), mclVv(T, "T"))));
        /*
         * theta=theta+v_theta*T;
         */
        mlfAssign(
          &theta,
          mclPlus(
            mclVv(theta, "theta"),
            mclMtimes(mclVv(v_theta, "v_theta"), mclVv(T, "T"))));
        /*
         * v_x=v_x+a_x*T;
         */
        mlfAssign(
          &v_x,
          mclPlus(
            mclVv(v_x, "v_x"), mclMtimes(mclVv(a_x, "a_x"), mclVv(T, "T"))));
        /*
         * x=x+v_x*T;
         */
        mlfAssign(
          &x,
          mclPlus(mclVv(x, "x"), mclMtimes(mclVv(v_x, "v_x"), mclVv(T, "T"))));
        /*
         * % draw new state
         * figure(h1);
         */
        mclAssignAns(&ans, mlfNFigure(0, mclVv(h1, "h1"), NULL));
        /*
         * X=[x   x+cos(pi/2-theta)];
         */
        mlfAssign(
          &X,
          mlfHorzcat(
            mclVv(x, "x"),
            mclPlus(
              mclVv(x, "x"),
              mclVe(mlfCos(mclMinus(_mxarray61_, mclVv(theta, "theta"))))),
            NULL));
        /*
         * Y=[0.2  0.2+sin(pi/2-theta)];
         */
        mlfAssign(
          &Y,
          mlfHorzcat(
            _mxarray62_,
            mclPlus(
              _mxarray62_,
              mclVe(mlfSin(mclMinus(_mxarray61_, mclVv(theta, "theta"))))),
            NULL));
        /*
         * obj=rectangle('Position',[x-0.4,0.1,0.8,0.1],...
         */
        mlfAssign(
          &obj,
          mlfNRectangle(
            1,
            _mxarray34_,
            mlfHorzcat(
              mclMinus(mclVv(x, "x"), _mxarray63_),
              _mxarray21_,
              _mxarray64_,
              _mxarray21_,
              NULL),
            _mxarray65_,
            _mxarray67_,
            NULL));
        /*
         * 'facecolor','b');
         * obj2=line(X,Y);  
         */
        mlfAssign(&obj2, mlfNLine(1, mclVv(X, "X"), mclVv(Y, "Y"), NULL));
        /*
         * hold on
         */
        mlfHold(_mxarray40_);
        /*
         * if (F>0)
         */
        if (mclGtBool(mclVv(F, "F"), _mxarray8_)) {
            /*
             * obj3=plot(x-0.4,0.11,'r>');
             */
            mlfAssign(
              &obj3,
              mlfNPlot(
                1,
                mclMinus(mclVv(x, "x"), _mxarray63_),
                _mxarray69_,
                _mxarray70_,
                NULL));
        /*
         * else
         */
        } else {
            /*
             * obj3=plot(x+0.4,0.11,'r<');
             */
            mlfAssign(
              &obj3,
              mlfNPlot(
                1,
                mclPlus(mclVv(x, "x"), _mxarray63_),
                _mxarray69_,
                _mxarray72_,
                NULL));
        /*
         * end %if
         */
        }
        /*
         * pause(0.00000000001)
         */
        mlfPause(_mxarray74_);
        /*
         * delete(obj)
         */
        mlfDelete(mclVv(obj, "obj"), NULL);
        /*
         * delete(obj2)
         */
        mlfDelete(mclVv(obj2, "obj2"), NULL);
        /*
         * delete(obj3)
         */
        mlfDelete(mclVv(obj3, "obj3"), NULL);
        /*
         * % get new box
         * [box] = get_box(x,v_x,theta,v_theta);
         */
        mlfAssign(
          &box,
          mlfGet_box(
            mclVv(x, "x"),
            mclVv(v_x, "v_x"),
            mclVv(theta, "theta"),
            mclVv(v_theta, "v_theta")));
        /*
         * if (box== -1)  % if fail
         */
        if (mclEqBool(mclVv(box, "box"), _mxarray59_)) {
            /*
             * reinf=get(handles.reinf_sl,'Value');
             */
            mlfAssign(
              &reinf,
              mlfNGet(
                1,
                mclVe(mlfIndexRef(mclVsa(handles, "handles"), ".reinf_sl")),
                _mxarray14_,
                NULL));
            /*
             * predicted_value=0;
             */
            mlfAssign(&predicted_value, _mxarray8_);
            /*
             * q_val(pre_state,pre_action)= q_val(pre_state,pre_action)+ ALPHA*(reinf+ GAMMA*predicted_value - q_val(pre_state,pre_action));
             */
            mclArrayAssign2(
              &q_val,
              mclPlus(
                mclVe(
                  mclArrayRef2(
                    mclVsv(q_val, "q_val"),
                    mclVsv(pre_state, "pre_state"),
                    mclVsv(pre_action, "pre_action"))),
                mclMtimes(
                  mclVg(&ALPHA, "ALPHA"),
                  mclMinus(
                    mclPlus(
                      mclVv(reinf, "reinf"),
                      mclMtimes(
                        mclVg(&GAMMA, "GAMMA"),
                        mclVv(predicted_value, "predicted_value"))),
                    mclVe(
                      mclArrayRef2(
                        mclVsv(q_val, "q_val"),
                        mclVsv(pre_state, "pre_state"),
                        mclVsv(pre_action, "pre_action")))))),
              mclVsv(pre_state, "pre_state"),
              mclVsv(pre_action, "pre_action"));
            /*
             * [pre_state,cur_state,pre_action,cur_action,x,v_x,theta,v_theta] = reset_cart(BETA);  % reset the cart pole to initial state
             */
            mlfAssign(
              &pre_state,
              mlfReset_cart(
                &cur_state,
                &pre_action,
                &cur_action,
                &x,
                &v_x,
                &theta,
                &v_theta,
                mclVg(&BETA, "BETA")));
            /*
             * trial=trial+1;
             */
            mlfAssign(&trial, mclPlus(mclVv(trial, "trial"), _mxarray11_));
            /*
             * if (success>best)
             */
            if (mclGtBool(mclVv(success, "success"), mclVv(best, "best"))) {
                /*
                 * best=success;
                 */
                mlfAssign(&best, mclVsv(success, "success"));
            /*
             * end
             */
            }
            /*
             * success=0;
             */
            mlfAssign(&success, _mxarray8_);
            /*
             * figure(h1);
             */
            mclAssignAns(&ans, mlfNFigure(0, mclVv(h1, "h1"), NULL));
            /*
             * title(strcat('Trials  ',num2str(trial),', Best success : ',num2str(best)));
             */
            mclAssignAns(
              &ans,
              mlfNTitle(
                0,
                mclVe(
                  mlfStrcat(
                    _mxarray75_,
                    mclVe(mlfNum2str(mclVv(trial, "trial"), NULL)),
                    _mxarray77_,
                    mclVe(mlfNum2str(mclVv(best, "best"), NULL)),
                    NULL)),
                NULL));
            /*
             * % draw q-val figure
             * figure(h2);
             */
            mclAssignAns(&ans, mlfNFigure(0, mclVv(h2, "h2"), NULL));
            /*
             * title('Q-value mesh : up is push right, bottom is push left');
             */
            mclAssignAns(&ans, mlfNTitle(0, _mxarray79_, NULL));
            /*
             * for i=1:2
             */
            {
                int v_ = mclForIntStart(1);
                int e_ = mclForIntEnd(_mxarray27_);
                if (v_ > e_) {
                    mlfAssign(&i, _mxarray81_);
                } else {
                    /*
                     * m=1;
                     * for j=1:9
                     * for k=1:18
                     * GZ(j,k)=q_val(m,i)+i;  
                     * m=m+1;
                     * end % k
                     * end  % j
                     * surf(GX,GY,GZ);
                     * view(30,-15);
                     * hold on;
                     * end  %for i
                     */
                    for (; ; ) {
                        mlfAssign(&m, _mxarray11_);
                        {
                            int v_0 = mclForIntStart(1);
                            int e_0 = mclForIntEnd(_mxarray56_);
                            if (v_0 > e_0) {
                                mlfAssign(&j, _mxarray81_);
                            } else {
                                for (; ; ) {
                                    int v_1 = mclForIntStart(1);
                                    int e_1 = mclForIntEnd(_mxarray57_);
                                    if (v_1 > e_1) {
                                        mlfAssign(&k, _mxarray81_);
                                    } else {
                                        for (; ; ) {
                                            mclIntArrayAssign2(
                                              &GZ,
                                              mclPlus(
                                                mclVe(
                                                  mclArrayRef2(
                                                    mclVsv(q_val, "q_val"),
                                                    mclVsv(m, "m"),
                                                    mlfScalar(v_))),
                                                mlfScalar(v_)),
                                              v_0,
                                              v_1);
                                            mlfAssign(
                                              &m,
                                              mclPlus(
                                                mclVv(m, "m"), _mxarray11_));
                                            if (v_1 == e_1) {
                                                break;
                                            }
                                            ++v_1;
                                        }
                                        mlfAssign(&k, mlfScalar(v_1));
                                    }
                                    if (v_0 == e_0) {
                                        break;
                                    }
                                    ++v_0;
                                }
                                mlfAssign(&j, mlfScalar(v_0));
                            }
                        }
                        mclAssignAns(
                          &ans,
                          mlfNSurf(
                            0,
                            mclVv(GX, "GX"),
                            mclVv(GY, "GY"),
                            mclVv(GZ, "GZ"),
                            NULL));
                        mclAssignAns(
                          &ans,
                          mlfNView(0, NULL, _mxarray82_, _mxarray83_, NULL));
                        mlfHold(_mxarray40_);
                        if (v_ == e_) {
                            break;
                        }
                        ++v_;
                    }
                    mlfAssign(&i, mlfScalar(v_));
                }
            }
        /*
         * else
         */
        } else {
            /*
             * success=success+1;
             */
            mlfAssign(
              &success, mclPlus(mclVv(success, "success"), _mxarray11_));
            /*
             * reinf=0;
             */
            mlfAssign(&reinf, _mxarray8_);
        /*
         * end  %if (box
         */
        }
    /*
     * 
     * end %while
     */
    }
    /*
     * figure(h1);
     */
    mclAssignAns(&ans, mlfNFigure(0, mclVv(h1, "h1"), NULL));
    /*
     * title(strcat('Success at ',num2str(trial)),' trials');
     */
    mclAssignAns(
      &ans,
      mlfNTitle(
        0,
        mclVe(
          mlfStrcat(
            _mxarray84_, mclVe(mlfNum2str(mclVv(trial, "trial"), NULL)), NULL)),
        _mxarray86_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(m);
    mxDestroyArray(mp);
    mxDestroyArray(g);
    mxDestroyArray(length);
    mxDestroyArray(Force);
    mxDestroyArray(T);
    mxDestroyArray(NUM_BOX);
    mxDestroyArray(pre_state);
    mxDestroyArray(cur_state);
    mxDestroyArray(pre_action);
    mxDestroyArray(cur_action);
    mxDestroyArray(x);
    mxDestroyArray(v_x);
    mxDestroyArray(theta);
    mxDestroyArray(v_theta);
    mxDestroyArray(q_val);
    mxDestroyArray(h1);
    mxDestroyArray(h2);
    mxDestroyArray(success);
    mxDestroyArray(reinf);
    mxDestroyArray(trial);
    mxDestroyArray(GX);
    mxDestroyArray(GY);
    mxDestroyArray(GZ);
    mxDestroyArray(best);
    mxDestroyArray(F);
    mxDestroyArray(a_theta);
    mxDestroyArray(a_x);
    mxDestroyArray(X);
    mxDestroyArray(Y);
    mxDestroyArray(obj);
    mxDestroyArray(obj2);
    mxDestroyArray(obj3);
    mxDestroyArray(box);
    mxDestroyArray(predicted_value);
    mxDestroyArray(i);
    mxDestroyArray(j);
    mxDestroyArray(k);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(h);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     */
}
