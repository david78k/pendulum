/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "movegui.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"

static mxChar _array1_[132] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'm', 'o', 'v', 'e', 'g',
                                'u', 'i', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'm',
                                'o', 'v', 'e', 'g', 'u', 'i', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                's', ' ', '(', '0', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'm', 'o', 'v', 'e', 'g',
                                'u', 'i', '/', 'g', 'e', 't', '_', 'p', 'a',
                                'r', 'e', 'n', 't', '_', 'f', 'i', 'g', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', '6', '6',
                                ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                'c', 't', 'i', 'o', 'n', ' ', '"', 'm', 'o',
                                'v', 'e', 'g', 'u', 'i', '/', 'g', 'e', 't',
                                '_', 'p', 'a', 'r', 'e', 'n', 't', '_', 'f',
                                'i', 'g', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray2_;

static mxChar _array5_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'm', 'o', 'v', 'e', 'g',
                                'u', 'i', '/', 'g', 'e', 't', '_', 'p', 'a',
                                'r', 'e', 'n', 't', '_', 'f', 'i', 'g', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', '6', '6',
                                ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                'c', 't', 'i', 'o', 'n', ' ', '"', 'm', 'o',
                                'v', 'e', 'g', 'u', 'i', '/', 'g', 'e', 't',
                                '_', 'p', 'a', 'r', 'e', 'n', 't', '_', 'f',
                                'i', 'g', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray4_;

static mxChar _array9_[5] = { 'n', 'o', 'r', 't', 'h' };
static mxArray * _mxarray8_;

static mxChar _array11_[5] = { 's', 'o', 'u', 't', 'h' };
static mxArray * _mxarray10_;

static mxChar _array13_[4] = { 'e', 'a', 's', 't' };
static mxArray * _mxarray12_;

static mxChar _array15_[4] = { 'w', 'e', 's', 't' };
static mxArray * _mxarray14_;

static mxChar _array17_[9] = { 'n', 'o', 'r', 't', 'h', 'e', 'a', 's', 't' };
static mxArray * _mxarray16_;

static mxChar _array19_[9] = { 's', 'o', 'u', 't', 'h', 'e', 'a', 's', 't' };
static mxArray * _mxarray18_;

static mxChar _array21_[9] = { 'n', 'o', 'r', 't', 'h', 'w', 'e', 's', 't' };
static mxArray * _mxarray20_;

static mxChar _array23_[9] = { 's', 'o', 'u', 't', 'h', 'w', 'e', 's', 't' };
static mxArray * _mxarray22_;

static mxChar _array25_[6] = { 'c', 'e', 'n', 't', 'e', 'r' };
static mxArray * _mxarray24_;

static mxChar _array27_[8] = { 'o', 'n', 's', 'c', 'r', 'e', 'e', 'n' };
static mxArray * _mxarray26_;

static mxArray * _array7_[10] = { NULL /*_mxarray8_*/, NULL /*_mxarray10_*/,
                                  NULL /*_mxarray12_*/, NULL /*_mxarray14_*/,
                                  NULL /*_mxarray16_*/, NULL /*_mxarray18_*/,
                                  NULL /*_mxarray20_*/, NULL /*_mxarray22_*/,
                                  NULL /*_mxarray24_*/, NULL /*_mxarray26_*/ };
static mxArray * _mxarray6_;
static mxArray * _mxarray28_;
static mxArray * _mxarray29_;
static mxArray * _mxarray30_;
static mxArray * _mxarray31_;
static mxArray * _mxarray32_;

static mxChar _array34_[39] = { 'h', 'a', 'n', 'd', 'l', 'e', ' ', 'o',
                                'f', ' ', 'f', 'i', 'g', 'u', 'r', 'e',
                                ' ', 'o', 'r', ' ', 'd', 'e', 's', 'c',
                                'e', 'n', 'd', 'a', 'n', 't', ' ', 'r',
                                'e', 'q', 'u', 'i', 'r', 'e', 'd' };
static mxArray * _mxarray33_;

static mxChar _array36_[5] = { 'e', 'x', 'a', 'c', 't' };
static mxArray * _mxarray35_;

static mxChar _array38_[21] = { 'u', 'n', 'r', 'e', 'c', 'o', 'g',
                                'n', 'i', 'z', 'e', 'd', ' ', 'p',
                                'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray37_;
static mxArray * _mxarray39_;

static mxChar _array41_[27] = { 'u', 'n', 'r', 'e', 'c', 'o', 'g', 'n', 'i',
                                'z', 'e', 'd', ' ', 'i', 'n', 'p', 'u', 't',
                                ' ', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't' };
static mxArray * _mxarray40_;

static mxChar _array43_[22] = { 'a', 'c', 't', 'i', 'v', 'e', 'p', 'o',
                                's', 'i', 't', 'i', 'o', 'n', 'p', 'r',
                                'o', 'p', 'e', 'r', 't', 'y' };
static mxArray * _mxarray42_;

static mxChar _array45_[5] = { 'u', 'n', 'i', 't', 's' };
static mxArray * _mxarray44_;

static mxChar _array47_[6] = { 'p', 'i', 'x', 'e', 'l', 's' };
static mxArray * _mxarray46_;

static mxChar _array49_[8] = { 'p', 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray48_;

static mxChar _array51_[13] = { 'o', 'u', 't', 'e', 'r', 'p', 'o',
                                's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray50_;

static mxChar _array53_[10] = { 's', 'c', 'r', 'e', 'e',
                                'n', 's', 'i', 'z', 'e' };
static mxArray * _mxarray52_;

static double _array55_[2] = { 0.0, 0.0 };
static mxArray * _mxarray54_;
static mxArray * _mxarray56_;
static mxArray * _mxarray57_;
static mxArray * _mxarray58_;

static mxChar _array60_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray59_;

static mxChar _array62_[6] = { 'f', 'i', 'g', 'u', 'r', 'e' };
static mxArray * _mxarray61_;

static mxChar _array64_[6] = { 'p', 'a', 'r', 'e', 'n', 't' };
static mxArray * _mxarray63_;

void InitializeModule_movegui(void) {
    _mxarray0_ = mclInitializeString(132, _array1_);
    _mxarray2_ = mclInitializeString(164, _array3_);
    _mxarray4_ = mclInitializeString(163, _array5_);
    _mxarray8_ = mclInitializeString(5, _array9_);
    _array7_[0] = _mxarray8_;
    _mxarray10_ = mclInitializeString(5, _array11_);
    _array7_[1] = _mxarray10_;
    _mxarray12_ = mclInitializeString(4, _array13_);
    _array7_[2] = _mxarray12_;
    _mxarray14_ = mclInitializeString(4, _array15_);
    _array7_[3] = _mxarray14_;
    _mxarray16_ = mclInitializeString(9, _array17_);
    _array7_[4] = _mxarray16_;
    _mxarray18_ = mclInitializeString(9, _array19_);
    _array7_[5] = _mxarray18_;
    _mxarray20_ = mclInitializeString(9, _array21_);
    _array7_[6] = _mxarray20_;
    _mxarray22_ = mclInitializeString(9, _array23_);
    _array7_[7] = _mxarray22_;
    _mxarray24_ = mclInitializeString(6, _array25_);
    _array7_[8] = _mxarray24_;
    _mxarray26_ = mclInitializeString(8, _array27_);
    _array7_[9] = _mxarray26_;
    _mxarray6_ = mclInitializeCellVector(1, 10, _array7_);
    _mxarray28_ = mclInitializeDouble(0.0);
    _mxarray29_ = mclInitializeDouble(3.0);
    _mxarray30_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray31_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray32_ = mclInitializeDouble(1.0);
    _mxarray33_ = mclInitializeString(39, _array34_);
    _mxarray35_ = mclInitializeString(5, _array36_);
    _mxarray37_ = mclInitializeString(21, _array38_);
    _mxarray39_ = mclInitializeDouble(2.0);
    _mxarray40_ = mclInitializeString(27, _array41_);
    _mxarray42_ = mclInitializeString(22, _array43_);
    _mxarray44_ = mclInitializeString(5, _array45_);
    _mxarray46_ = mclInitializeString(6, _array47_);
    _mxarray48_ = mclInitializeString(8, _array49_);
    _mxarray50_ = mclInitializeString(13, _array51_);
    _mxarray52_ = mclInitializeString(10, _array53_);
    _mxarray54_ = mclInitializeDoubleVector(1, 2, _array55_);
    _mxarray56_ = mclInitializeDouble(6.0);
    _mxarray57_ = mclInitializeDouble(24.0);
    _mxarray58_ = mclInitializeDouble(4.0);
    _mxarray59_ = mclInitializeString(4, _array60_);
    _mxarray61_ = mclInitializeString(6, _array62_);
    _mxarray63_ = mclInitializeString(6, _array64_);
}

void TerminateModule_movegui(void) {
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfMovegui_get_parent_fig(mxArray * h_in);
static void mlxMovegui_get_parent_fig(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]);
static void Mmovegui(mxArray * varargin);
static mxArray * Mmovegui_get_parent_fig(int nargout_, mxArray * h_in);

static mexFunctionTableEntry local_function_table_[1]
  = { { "get_parent_fig", mlxMovegui_get_parent_fig, 1, 1, NULL } };

_mexLocalFunctionTable _local_function_table_movegui
  = { 1, local_function_table_ };

/*
 * The function "mlfMovegui" contains the normal interface for the "movegui"
 * M-function from file "C:\matlabR12\toolbox\matlab\uitools\movegui.m" (lines
 * 1-166). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlfMovegui(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    Mmovegui(varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxMovegui" contains the feval interface for the "movegui"
 * M-function from file "C:\matlabR12\toolbox\matlab\uitools\movegui.m" (lines
 * 1-166). The feval function calls the implementation version of movegui
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxMovegui(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    if (nlhs > 0) {
        mlfError(_mxarray0_);
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    Mmovegui(mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMovegui_get_parent_fig" contains the normal interface for
 * the "movegui/get_parent_fig" M-function from file
 * "C:\matlabR12\toolbox\matlab\uitools\movegui.m" (lines 166-170). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMovegui_get_parent_fig(mxArray * h_in) {
    int nargout = 1;
    mxArray * h = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, h_in);
    h = Mmovegui_get_parent_fig(nargout, h_in);
    mlfRestorePreviousContext(0, 1, h_in);
    return mlfReturnValue(h);
}

/*
 * The function "mlxMovegui_get_parent_fig" contains the feval interface for
 * the "movegui/get_parent_fig" M-function from file
 * "C:\matlabR12\toolbox\matlab\uitools\movegui.m" (lines 166-170). The feval
 * function calls the implementation version of movegui/get_parent_fig through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMovegui_get_parent_fig(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray2_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray4_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmovegui_get_parent_fig(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mmovegui" is the implementation version of the "movegui"
 * M-function from file "C:\matlabR12\toolbox\matlab\uitools\movegui.m" (lines
 * 1-166). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function movegui(varargin)
 */
static void Mmovegui(mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_movegui);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * newpos = mclGetUninitializedArray();
    mxArray * fheight = mclGetUninitializedArray();
    mxArray * fwidth = mclGetUninitializedArray();
    mxArray * sheight = mclGetUninitializedArray();
    mxArray * swidth = mclGetUninitializedArray();
    mxArray * screensize = mclGetUninitializedArray();
    mxArray * old0units = mclGetUninitializedArray();
    mxArray * oldpos = mclGetUninitializedArray();
    mxArray * inpos = mclGetUninitializedArray();
    mxArray * oldfunits = mclGetUninitializedArray();
    mxArray * oldposmode = mclGetUninitializedArray();
    mxArray * numel = mclGetUninitializedArray();
    mxArray * i = mclGetUninitializedArray();
    mxArray * fig = mclGetUninitializedArray();
    mxArray * position = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * POSITIONS = mclGetUninitializedArray();
    mclCopyArray(&varargin);
    /*
     * %MOVEGUI  Move GUI figure to specified part of screen.
     * %    MOVEGUI(H, POSITION) moves the figure associated with handle H to
     * %    the specified part of the screen, preserving its size.
     * %
     * %    H can be the handle to a figure, or to any object within a figure
     * %    (for example, allowing a pushbutton uicontrol to move the figure
     * %    which contains it, from the pushbutton's function-handle
     * %    Callback.)
     * %
     * %    The POSITION argument can be any one of the strings:
     * %     'north'     - top center edge of screen
     * %     'south'     - bottom center edge of screen
     * %     'east'      - right center edge of screen
     * %     'west'      - left center edge of screen
     * %     'northeast' - top right corner of screen
     * %     'northwest' - top left corner of screen
     * %     'southeast' - bottom right corner of screen
     * %     'southwest' - bottom left corner of screen
     * %     'center'    - center of screen
     * %     'onscreen'  - nearest onscreen location to current position.
     * %
     * %    The POSITION argument can also be a two-element vector [H V],
     * %    where depending on sign, H specifies the figure's offset from the
     * %    left or right edge of the screen, and V specifies the figure's
     * %    offset from the top or bottom of the screen, in pixels:
     * %     H (for h >= 0) offset of left side from left edge of screen
     * %     H (for h < 0)  offset of right side from right edge of screen
     * %     V (for v >= 0) offset of bottom edge from bottom of screen
     * %     V (for v < 0)  offset of top edge from top of screen
     * %
     * %    MOVEGUI(POSITION) moves the GCBF or GCF to the specified
     * %    position.
     * %
     * %    MOVEGUI(H) moves the specified figure 'onscreen'.
     * %
     * %    MOVEGUI moves the GCBF or GCF 'onscreen' (useful as a
     * %    string-based CreateFcn callback for a saved figure, to ensure it
     * %    will appear onscreen when reloaded, regardless of its saved
     * %    position)
     * %
     * %    MOVEGUI(H, <event data>)
     * %    MOVEGUI(H, <event data>, POSITION) when used as a function-handle
     * %    callback, moves the specified figure to the default position, or
     * %    to the specified position, safely ignoring the automatically
     * %    passed-in event data struct.
     * %
     * %    Example:
     * %    This example demonstrates MOVEGUIs usefulness as a means of
     * %    ensuring that a saved GUI will appear onscreen when reloaded,
     * %    regardless of differences between screen sizes and resolutions
     * %    between the machines on which it was saved and relaoded.  It
     * %    creates a figure off the screen, assigns MOVEGUI as its CreateFcn
     * %    callback, then saves and reloads the figure:
     * %
     * %    	f=figure('position', [10000, 10000, 400, 300]);
     * %    	set(f, 'CreateFcn', 'movegui')
     * %    	hgsave(f, 'onscreenfig')
     * %    	close(f)
     * %    	f2 = hgload('onscreenfig')
     * %
     * %    The following are a few variations on ways MOVEGUI can be
     * %    assigned as the CreateFcn, using both string and function-handle
     * %    callbacks, with and without extra arguments, to achieve a variety
     * %    of behaviors:
     * %
     * %    	set(gcf, 'CreateFcn', 'movegui center')
     * %    	set(gcf, 'CreateFcn', @movegui)
     * %    	set(gcf, 'CreateFcn', {@movegui, 'northeast'})
     * %    	set(gcf, 'CreateFcn', {@movegui, [-100 -50]})
     * %
     * %    See also OPENFIG, GUIHANDLES, GUIDATA, GUIDE.
     * 
     * %   Damian T. Packer 2-5-2000
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.7 $  $Date: 2000/09/02 03:28:12 $
     * 
     * POSITIONS = {'north','south','east','west',...
     */
    mlfAssign(&POSITIONS, _mxarray6_);
    /*
     * 'northeast','southeast','northwest','southwest',...
     * 'center','onscreen'};
     * 
     * error(nargchk(0, 3, nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray28_, _mxarray29_, mlfScalar(nargin_))));
    /*
     * position = '';
     */
    mlfAssign(&position, _mxarray30_);
    /*
     * fig = [];
     */
    mlfAssign(&fig, _mxarray31_);
    /*
     * 
     * for i=1:nargin
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mlfScalar(nargin_));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray31_);
        } else {
            /*
             * numel = prod(size(varargin{i}));
             * if ishandle(varargin{i}) & numel == 1
             * fig = get_parent_fig(varargin{i});
             * if isempty(fig)
             * error('handle of figure or descendant required');
             * end
             * elseif isstr(varargin{i})
             * position = varargin{i};
             * if isempty(strmatch(position,POSITIONS,'exact'))
             * error('unrecognized position');
             * end
             * elseif isnumeric(varargin{i}) & numel == 2
             * position = varargin{i};
             * elseif ~isempty(gcbo) & i==2
             * continue; % skip past the event data struct, if in a callback
             * else
             * error('unrecognized input argument');
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &numel,
                  mlfProd(
                    mclVe(
                      mclFeval(
                        mclValueVarargout(),
                        mlxSize,
                        mclVe(
                          mlfIndexRef(
                            mclVsa(varargin, "varargin"),
                            "{?}",
                            mlfScalar(v_))),
                        NULL)),
                    NULL));
                {
                    mxArray * a_ = mclInitialize(
                                     mclVe(
                                       mclFeval(
                                         mclValueVarargout(),
                                         mlxIshandle,
                                         mclVe(
                                           mlfIndexRef(
                                             mclVsa(varargin, "varargin"),
                                             "{?}",
                                             mlfScalar(v_))),
                                         NULL)));
                    if (mlfTobool(a_)
                        && mlfTobool(
                             mclAnd(
                               a_,
                               mclEq(mclVv(numel, "numel"), _mxarray32_)))) {
                        mxDestroyArray(a_);
                        mlfAssign(
                          &fig,
                          mclFeval(
                            mclValueVarargout(),
                            mlxMovegui_get_parent_fig,
                            mclVe(
                              mlfIndexRef(
                                mclVsa(varargin, "varargin"),
                                "{?}",
                                mlfScalar(v_))),
                            NULL));
                        if (mlfTobool(mclVe(mlfIsempty(mclVv(fig, "fig"))))) {
                            mlfError(_mxarray33_);
                        }
                    } else {
                        mxDestroyArray(a_);
                        if (mlfTobool(
                              mclVe(
                                mclFeval(
                                  mclValueVarargout(),
                                  mlxIsstr,
                                  mclVe(
                                    mlfIndexRef(
                                      mclVsa(varargin, "varargin"),
                                      "{?}",
                                      mlfScalar(v_))),
                                  NULL)))) {
                            mlfAssign(
                              &position,
                              mlfIndexRef(
                                mclVsa(varargin, "varargin"),
                                "{?}",
                                mlfScalar(v_)));
                            if (mlfTobool(
                                  mclVe(
                                    mlfIsempty(
                                      mclVe(
                                        mlfStrmatch(
                                          mclVv(position, "position"),
                                          mclVv(POSITIONS, "POSITIONS"),
                                          _mxarray35_)))))) {
                                mlfError(_mxarray37_);
                            }
                        } else {
                            mxArray * a_0 = mclInitialize(
                                              mclVe(
                                                mclFeval(
                                                  mclValueVarargout(),
                                                  mlxIsnumeric,
                                                  mclVe(
                                                    mlfIndexRef(
                                                      mclVsa(
                                                        varargin, "varargin"),
                                                      "{?}",
                                                      mlfScalar(v_))),
                                                  NULL)));
                            if (mlfTobool(a_0)
                                && mlfTobool(
                                     mclAnd(
                                       a_0,
                                       mclEq(
                                         mclVv(numel, "numel"),
                                         _mxarray39_)))) {
                                mxDestroyArray(a_0);
                                mlfAssign(
                                  &position,
                                  mlfIndexRef(
                                    mclVsa(varargin, "varargin"),
                                    "{?}",
                                    mlfScalar(v_)));
                            } else {
                                mxDestroyArray(a_0);
                                {
                                    mxArray * a_1 = mclInitialize(
                                                      mclNot(
                                                        mclVe(
                                                          mlfIsempty(
                                                            mclVe(
                                                              mlfNGcbo(
                                                                1, NULL))))));
                                    if (mlfTobool(a_1)
                                        && mlfTobool(
                                             mclAnd(
                                               a_1,
                                               mclBoolToArray(v_ == 2)))) {
                                        mxDestroyArray(a_1);
                                    } else {
                                        mxDestroyArray(a_1);
                                        mlfError(_mxarray40_);
                                    }
                                }
                            }
                        }
                    }
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * 
     * if isempty(fig)
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(fig, "fig"))))) {
        /*
         * fig = gcbf;
         */
        mlfAssign(&fig, mlfGcbf());
        /*
         * if(isempty(fig))
         */
        if (mlfTobool(mclVe(mlfIsempty(mclVv(fig, "fig"))))) {
            /*
             * fig = gcf;
             */
            mlfAssign(&fig, mlfGcf());
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * if isempty(position)
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(position, "position"))))) {
        /*
         * position = 'onscreen';
         */
        mlfAssign(&position, _mxarray26_);
    /*
     * end
     */
    }
    /*
     * 
     * drawnow
     */
    mlfDrawnow(NULL);
    /*
     * oldposmode = get(fig,'activepositionproperty');
     */
    mlfAssign(&oldposmode, mlfNGet(1, mclVv(fig, "fig"), _mxarray42_, NULL));
    /*
     * oldfunits = get(fig, 'units');
     */
    mlfAssign(&oldfunits, mlfNGet(1, mclVv(fig, "fig"), _mxarray44_, NULL));
    /*
     * set(fig, 'units', 'pixels');
     */
    mclAssignAns(
      &ans, mlfNSet(0, mclVv(fig, "fig"), _mxarray44_, _mxarray46_, NULL));
    /*
     * inpos = get(fig,'position');
     */
    mlfAssign(&inpos, mlfNGet(1, mclVv(fig, "fig"), _mxarray48_, NULL));
    /*
     * oldpos = get(fig, 'outerposition');
     */
    mlfAssign(&oldpos, mlfNGet(1, mclVv(fig, "fig"), _mxarray50_, NULL));
    /*
     * old0units = get(0, 'units');
     */
    mlfAssign(&old0units, mlfNGet(1, _mxarray28_, _mxarray44_, NULL));
    /*
     * set(0, 'units', 'pixels');
     */
    mclAssignAns(&ans, mlfNSet(0, _mxarray28_, _mxarray44_, _mxarray46_, NULL));
    /*
     * screensize = get(0, 'screensize');
     */
    mlfAssign(&screensize, mlfNGet(1, _mxarray28_, _mxarray52_, NULL));
    /*
     * set(0, 'units', old0units);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, _mxarray28_, _mxarray44_, mclVv(old0units, "old0units"), NULL));
    /*
     * swidth = screensize(3); sheight = screensize(4);
     */
    mlfAssign(&swidth, mclIntArrayRef1(mclVsv(screensize, "screensize"), 3));
    mlfAssign(&sheight, mclIntArrayRef1(mclVsv(screensize, "screensize"), 4));
    /*
     * fwidth = min(oldpos(3), swidth); fheight = min(oldpos(4), sheight);
     */
    mlfAssign(
      &fwidth,
      mlfMin(
        NULL,
        mclVe(mclIntArrayRef1(mclVsv(oldpos, "oldpos"), 3)),
        mclVv(swidth, "swidth"),
        NULL));
    mlfAssign(
      &fheight,
      mlfMin(
        NULL,
        mclVe(mclIntArrayRef1(mclVsv(oldpos, "oldpos"), 4)),
        mclVv(sheight, "sheight"),
        NULL));
    /*
     * 
     * if isnumeric(position)
     */
    if (mlfTobool(mclVe(mlfIsnumeric(mclVv(position, "position"))))) {
        /*
         * newpos = position;
         */
        mlfAssign(&newpos, mclVsv(position, "position"));
        /*
         * if(newpos(1) < 0)	newpos(1) = swidth - fwidth + newpos(1); end
         */
        if (mclLtBool(
              mclVe(mclIntArrayRef1(mclVsv(newpos, "newpos"), 1)),
              _mxarray28_)) {
            mclIntArrayAssign1(
              &newpos,
              mclPlus(
                mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                mclVe(mclIntArrayRef1(mclVsv(newpos, "newpos"), 1))),
              1);
        }
        /*
         * if(newpos(2) < 0)	newpos(2) = sheight - fheight + newpos(2); end
         */
        if (mclLtBool(
              mclVe(mclIntArrayRef1(mclVsv(newpos, "newpos"), 2)),
              _mxarray28_)) {
            mclIntArrayAssign1(
              &newpos,
              mclPlus(
                mclMinus(mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                mclVe(mclIntArrayRef1(mclVsv(newpos, "newpos"), 2))),
              2);
        }
    /*
     * else
     */
    } else {
        /*
         * switch position
         */
        mxArray * v_ = mclInitialize(mclVv(position, "position"));
        if (mclSwitchCompare(v_, _mxarray8_)) {
            /*
             * case 'north',	newpos = [(swidth-fwidth)/2, sheight-fheight]
             */
            mlfAssign(
              &newpos,
              mlfHorzcat(
                mclMrdivide(
                  mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                  _mxarray39_),
                mclMinus(mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                NULL));
            mclPrintArray(mclVsv(newpos, "newpos"), "newpos");
        /*
         * case 'south',	newpos = [(swidth-fwidth)/2, 0];
         */
        } else if (mclSwitchCompare(v_, _mxarray10_)) {
            mlfAssign(
              &newpos,
              mlfHorzcat(
                mclMrdivide(
                  mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                  _mxarray39_),
                _mxarray28_,
                NULL));
        /*
         * case 'east',	newpos = [swidth-fwidth, (sheight-fheight)/2];
         */
        } else if (mclSwitchCompare(v_, _mxarray12_)) {
            mlfAssign(
              &newpos,
              mlfHorzcat(
                mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                mclMrdivide(
                  mclMinus(
                    mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                  _mxarray39_),
                NULL));
        /*
         * case 'west',	newpos = [0, (sheight-fheight)/2];
         */
        } else if (mclSwitchCompare(v_, _mxarray14_)) {
            mlfAssign(
              &newpos,
              mlfHorzcat(
                _mxarray28_,
                mclMrdivide(
                  mclMinus(
                    mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                  _mxarray39_),
                NULL));
        /*
         * case 'northeast',  newpos = [swidth-fwidth, sheight-fheight];
         */
        } else if (mclSwitchCompare(v_, _mxarray16_)) {
            mlfAssign(
              &newpos,
              mlfHorzcat(
                mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                mclMinus(mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                NULL));
        /*
         * case 'southeast',  newpos = [swidth-fwidth, 0];
         */
        } else if (mclSwitchCompare(v_, _mxarray18_)) {
            mlfAssign(
              &newpos,
              mlfHorzcat(
                mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                _mxarray28_,
                NULL));
        /*
         * case 'northwest',  newpos = [0, sheight-fheight];
         */
        } else if (mclSwitchCompare(v_, _mxarray20_)) {
            mlfAssign(
              &newpos,
              mlfHorzcat(
                _mxarray28_,
                mclMinus(mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                NULL));
        /*
         * case 'southwest',  newpos = [0, 0];
         */
        } else if (mclSwitchCompare(v_, _mxarray22_)) {
            mlfAssign(&newpos, _mxarray54_);
        /*
         * case 'center',	newpos = [(swidth-fwidth)/2, (sheight-fheight)/2];
         */
        } else if (mclSwitchCompare(v_, _mxarray24_)) {
            mlfAssign(
              &newpos,
              mlfHorzcat(
                mclMrdivide(
                  mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                  _mxarray39_),
                mclMrdivide(
                  mclMinus(
                    mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                  _mxarray39_),
                NULL));
        /*
         * case 'onscreen',   newpos = min(max(oldpos(1:2), [0, 0]), [swidth-fwidth, sheight-fheight]);
         */
        } else if (mclSwitchCompare(v_, _mxarray26_)) {
            mlfAssign(
              &newpos,
              mlfMin(
                NULL,
                mclVe(
                  mlfMax(
                    NULL,
                    mclVe(
                      mclArrayRef1(
                        mclVsv(oldpos, "oldpos"),
                        mlfColon(_mxarray32_, _mxarray39_, NULL))),
                    _mxarray54_,
                    NULL)),
                mlfHorzcat(
                  mclMinus(mclVv(swidth, "swidth"), mclVv(fwidth, "fwidth")),
                  mclMinus(
                    mclVv(sheight, "sheight"), mclVv(fheight, "fheight")),
                  NULL),
                NULL));
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    /*
     * end
     */
    }
    /*
     * 
     * % if the figure's outer postion is less or equal to it's position, the outer
     * % position info is not accurate yet.  this should only happen once per
     * % figure type per matlab session on unix using some window managers.  to
     * % prevent the figures from being too small, increase the width and height by
     * % reasonable defaults
     * if inpos(3) > oldpos(3) & inpos(4) > oldpos(4)
     */
    {
        mxArray * a_ = mclInitialize(
                         mclGt(
                           mclVe(mclIntArrayRef1(mclVsv(inpos, "inpos"), 3)),
                           mclVe(
                             mclIntArrayRef1(mclVsv(oldpos, "oldpos"), 3))));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclGt(
                     mclVe(mclIntArrayRef1(mclVsv(inpos, "inpos"), 4)),
                     mclVe(mclIntArrayRef1(mclVsv(oldpos, "oldpos"), 4)))))) {
            mxDestroyArray(a_);
            /*
             * fwidth = fwidth + 6;
             */
            mlfAssign(&fwidth, mclPlus(mclVv(fwidth, "fwidth"), _mxarray56_));
            /*
             * fheight = fheight + 24;
             */
            mlfAssign(
              &fheight, mclPlus(mclVv(fheight, "fheight"), _mxarray57_));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * newpos(3:4) = [fwidth, fheight];
     */
    mclArrayAssign1(
      &newpos,
      mlfHorzcat(mclVv(fwidth, "fwidth"), mclVv(fheight, "fheight"), NULL),
      mlfColon(_mxarray29_, _mxarray58_, NULL));
    /*
     * set(fig, 'outerposition', newpos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(fig, "fig"), _mxarray50_, mclVv(newpos, "newpos"), NULL));
    /*
     * set(fig, 'units', oldfunits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(fig, "fig"),
        _mxarray44_,
        mclVv(oldfunits, "oldfunits"),
        NULL));
    /*
     * set(fig, 'activepositionproperty', oldposmode);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(fig, "fig"),
        _mxarray42_,
        mclVv(oldposmode, "oldposmode"),
        NULL));
    mxDestroyArray(POSITIONS);
    mxDestroyArray(ans);
    mxDestroyArray(position);
    mxDestroyArray(fig);
    mxDestroyArray(i);
    mxDestroyArray(numel);
    mxDestroyArray(oldposmode);
    mxDestroyArray(oldfunits);
    mxDestroyArray(inpos);
    mxDestroyArray(oldpos);
    mxDestroyArray(old0units);
    mxDestroyArray(screensize);
    mxDestroyArray(swidth);
    mxDestroyArray(sheight);
    mxDestroyArray(fwidth);
    mxDestroyArray(fheight);
    mxDestroyArray(newpos);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * %----------------------------------------------------
     * function h = get_parent_fig(h)
     * while ~isempty(h) & ~strcmp(get(h,'type'), 'figure')
     * h = get(h, 'parent');
     * end
     */
}

/*
 * The function "Mmovegui_get_parent_fig" is the implementation version of the
 * "movegui/get_parent_fig" M-function from file
 * "C:\matlabR12\toolbox\matlab\uitools\movegui.m" (lines 166-170). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function h = get_parent_fig(h)
 */
static mxArray * Mmovegui_get_parent_fig(int nargout_, mxArray * h_in) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_movegui);
    mxArray * h = mclGetUninitializedArray();
    mclCopyInputArg(&h, h_in);
    /*
     * while ~isempty(h) & ~strcmp(get(h,'type'), 'figure')
     */
    for (;;) {
        mxArray * a_ = mclInitialize(mclNot(mclVe(mlfIsempty(mclVa(h, "h")))));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclNot(
                     mclVe(
                       mlfStrcmp(
                         mclVe(mlfNGet(1, mclVa(h, "h"), _mxarray59_, NULL)),
                         _mxarray61_)))))) {
            mxDestroyArray(a_);
        } else {
            mxDestroyArray(a_);
            break;
        }
        /*
         * h = get(h, 'parent');
         */
        mlfAssign(&h, mlfNGet(1, mclVa(h, "h"), _mxarray63_, NULL));
    /*
     * end
     */
    }
    mclVo(&h);
    mclValidateOutput(h, 1, nargout_, "h", "movegui/get_parent_fig");
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return h;
}
