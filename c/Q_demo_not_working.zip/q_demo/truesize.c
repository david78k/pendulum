/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "truesize.h"
#include "iptgetpref.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[134] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                'i', 'z', 'e', ' ', 'L', 'i', 'n', 'e', ':',
                                ' ', '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n',
                                ':', ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f',
                                'u', 'n', 'c', 't', 'i', 'o', 'n', ' ', '"',
                                't', 'r', 'u', 'e', 's', 'i', 'z', 'e', '"',
                                ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                'u', 't', 's', ' ', '(', '0', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                'i', 'z', 'e', '/', 'P', 'a', 'r', 's', 'e',
                                'I', 'n', 'p', 'u', 't', 's', ' ', 'L', 'i',
                                'n', 'e', ':', ' ', '5', '5', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 't', 'r', 'u', 'e', 's',
                                'i', 'z', 'e', '/', 'P', 'a', 'r', 's', 'e',
                                'I', 'n', 'p', 'u', 't', 's', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                's', ' ', '(', '6', ')', '.' };
static mxArray * _mxarray2_;

static mxChar _array5_[152] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                'i', 'z', 'e', '/', 'R', 'e', 's', 'i', 'z',
                                'e', '1', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', '7', '6', ' ', 'C', 'o', 'l', 'u', 'm',
                                'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '"', 't', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                '/', 'R', 'e', 's', 'i', 'z', 'e', '1', '"',
                                ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                'u', 't', 's', ' ', '(', '0', ')', '.' };
static mxArray * _mxarray4_;

static mxChar _array7_[151] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                'i', 'z', 'e', '/', 'R', 'e', 's', 'i', 'z',
                                'e', '1', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', '7', '6', ' ', 'C', 'o', 'l', 'u', 'm',
                                'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '"', 't', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                '/', 'R', 'e', 's', 'i', 'z', 'e', '1', '"',
                                ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u',
                                't', 's', ' ', '(', '3', ')', '.' };
static mxArray * _mxarray6_;

static mxChar _array9_[152] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                'i', 'z', 'e', '/', 'R', 'e', 's', 'i', 'z',
                                'e', '2', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '3', '1', '7', ' ', 'C', 'o', 'l', 'u', 'm',
                                'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '"', 't', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                '/', 'R', 'e', 's', 'i', 'z', 'e', '2', '"',
                                ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                'u', 't', 's', ' ', '(', '0', ')', '.' };
static mxArray * _mxarray8_;

static mxChar _array11_[151] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                 'i', 'z', 'e', '/', 'R', 'e', 's', 'i', 'z',
                                 'e', '2', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '3', '1', '7', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 't', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                 '/', 'R', 'e', 's', 'i', 'z', 'e', '2', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u',
                                 't', 's', ' ', '(', '3', ')', '.' };
static mxArray * _mxarray10_;

static mxChar _array13_[152] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                 'i', 'z', 'e', '/', 'R', 'e', 's', 'i', 'z',
                                 'e', '3', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '4', '3', '9', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 't', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                 '/', 'R', 'e', 's', 'i', 'z', 'e', '3', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                 'u', 't', 's', ' ', '(', '0', ')', '.' };
static mxArray * _mxarray12_;

static mxChar _array15_[151] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 't', 'r', 'u', 'e', 's',
                                 'i', 'z', 'e', '/', 'R', 'e', 's', 'i', 'z',
                                 'e', '3', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '4', '3', '9', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 't', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                 '/', 'R', 'e', 's', 'i', 'z', 'e', '3', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u',
                                 't', 's', ' ', '(', '4', ')', '.' };
static mxArray * _mxarray14_;
static mxArray * _mxarray16_;
static mxArray * _mxarray17_;
static mxArray * _mxarray18_;
static mxArray * _mxarray19_;
static mxArray * _mxarray20_;

static double _array22_[2] = { 1.0, 2.0 };
static mxArray * _mxarray21_;

static mxChar _array24_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray23_;

static mxChar _array26_[6] = { 'f', 'i', 'g', 'u', 'r', 'e' };
static mxArray * _mxarray25_;

static mxChar _array28_[33] = { 'F', 'I', 'G', ' ', 'm', 'u', 's', 't', ' ',
                                'b', 'e', ' ', 'a', ' ', 'v', 'a', 'l', 'i',
                                'd', ' ', 'f', 'i', 'g', 'u', 'r', 'e', ' ',
                                'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray27_;

static mxChar _array30_[11] = { 'C', 'u', 'r', 'r', 'e', 'n',
                                't', 'A', 'x', 'e', 's' };
static mxArray * _mxarray29_;

static mxChar _array32_[26] = { 'C', 'u', 'r', 'r', 'e', 'n', 't', ' ', 'f',
                                'i', 'g', 'u', 'r', 'e', ' ', 'h', 'a', 's',
                                ' ', 'n', 'o', ' ', 'a', 'x', 'e', 's' };
static mxArray * _mxarray31_;

static mxChar _array34_[31] = { 'R', 'E', 'Q', 'S', 'I', 'Z', 'E', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                'a', ' ', '1', '-', 'b', 'y', '-', '2',
                                ' ', 'v', 'e', 'c', 't', 'o', 'r' };
static mxArray * _mxarray33_;

static mxChar _array36_[6] = { 'P', 'a', 'r', 'e', 'n', 't' };
static mxArray * _mxarray35_;

static mxChar _array38_[4] = { 'T', 'y', 'p', 'e' };
static mxArray * _mxarray37_;

static mxChar _array40_[5] = { 'i', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray39_;

static mxChar _array42_[7] = { 's', 'u', 'r', 'f', 'a', 'c', 'e' };
static mxArray * _mxarray41_;

static mxChar _array44_[9] = { 'F', 'a', 'c', 'e', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray43_;

static mxChar _array46_[10] = { 't', 'e', 'x', 't', 'u',
                                'r', 'e', 'm', 'a', 'p' };
static mxArray * _mxarray45_;

static mxChar _array48_[3] = { 'T', 'a', 'g' };
static mxArray * _mxarray47_;

static mxChar _array50_[12] = { 'T', 'M', 'W', '_', 'C', 'O',
                                'L', 'O', 'R', 'B', 'A', 'R' };
static mxArray * _mxarray49_;

static mxChar _array52_[49] = { 'N', 'o', ' ', 'i', 'm', 'a', 'g', 'e', 's',
                                ' ', 'o', 'r', ' ', 't', 'e', 'x', 't', 'u',
                                'r', 'e', 'm', 'a', 'p', 'p', 'e', 'd', ' ',
                                's', 'u', 'r', 'f', 'a', 'c', 'e', 's', ' ',
                                'i', 'n', ' ', 't', 'h', 'e', ' ', 'f', 'i',
                                'g', 'u', 'r', 'e' };
static mxArray * _mxarray51_;

static mxChar _array54_[4] = { 'f', 'l', 'a', 't' };
static mxArray * _mxarray53_;

static mxChar _array56_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray55_;

static mxChar _array58_[9] = { 'u', 'i', 'c', 'o', 'n', 't', 'r', 'o', 'l' };
static mxArray * _mxarray57_;

static mxChar _array60_[7] = { 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray59_;

static mxChar _array62_[2] = { 'o', 'n' };
static mxArray * _mxarray61_;

static mxChar _array64_[6] = { 'u', 'i', 'm', 'e', 'n', 'u' };
static mxArray * _mxarray63_;

static mxChar _array66_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray65_;

static mxChar _array68_[5] = { 'C', 'D', 'a', 't', 'a' };
static mxArray * _mxarray67_;
static mxArray * _mxarray69_;

static mxChar _array71_[5] = { 'U', 'n', 'i', 't', 's' };
static mxArray * _mxarray70_;

static mxChar _array73_[6] = { 'p', 'i', 'x', 'e', 'l', 's' };
static mxArray * _mxarray72_;

static mxChar _array75_[8] = { 'P', 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray74_;
static mxArray * _mxarray76_;
static mxArray * _mxarray77_;
static mxArray * _mxarray78_;
static mxArray * _mxarray79_;

static mxChar _array81_[10] = { 'S', 'c', 'r', 'e', 'e',
                                'n', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray80_;
static double _ieee_plusinf_;
static mxArray * _mxarray82_;
static mxArray * _mxarray83_;

static mxChar _array85_[19] = { 'D', 'e', 'f', 'a', 'u', 'l', 't',
                                'A', 'x', 'e', 's', 'P', 'o', 's',
                                'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray84_;
static mxArray * _mxarray86_;

static mxChar _array88_[8] = { 'N', 'e', 'x', 't', 'P', 'l', 'o', 't' };
static mxArray * _mxarray87_;

static mxChar _array90_[15] = { 'r', 'e', 'p', 'l', 'a', 'c', 'e', 'c',
                                'h', 'i', 'l', 'd', 'r', 'e', 'n' };
static mxArray * _mxarray89_;

static mxChar _array92_[15] = { 'T', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                'W', 'a', 'r', 'n', 'i', 'n', 'g' };
static mxArray * _mxarray91_;

static mxChar _array94_[35] = { 'I', 'm', 'a', 'g', 'e', ' ', 'i', 's', ' ',
                                't', 'o', 'o', ' ', 'b', 'i', 'g', ' ', 't',
                                'o', ' ', 'f', 'i', 't', ' ', 'o', 'n', ' ',
                                's', 'c', 'r', 'e', 'e', 'n', ';', ' ' };
static mxArray * _mxarray93_;

static mxChar _array96_[25] = { 'd', 'i', 's', 'p', 'l', 'a', 'y', 'i', 'n',
                                'g', ' ', 'a', 't', ' ', '%', 'd', '%', '%',
                                ' ', 's', 'c', 'a', 'l', 'e', '.' };
static mxArray * _mxarray95_;

static double _array98_[2] = { 2.0, 1.0 };
static mxArray * _mxarray97_;
static mxArray * _mxarray99_;

static mxChar _array101_[10] = { 'n', 'o', 'r', 'm', 'a',
                                 'l', 'i', 'z', 'e', 'd' };
static mxArray * _mxarray100_;

static mxChar _array103_[48] = { 'I', 'm', 'a', 'g', 'e', ' ', 'i', 's',
                                 ' ', 't', 'o', 'o', ' ', 's', 'm', 'a',
                                 'l', 'l', ' ', 'f', 'o', 'r', ' ', 't',
                                 'r', 'u', 'e', 's', 'i', 'z', 'e', ' ',
                                 'f', 'i', 'g', 'u', 'r', 'e', ' ', 's',
                                 'c', 'a', 'l', 'i', 'n', 'g', ';', ' ' };
static mxArray * _mxarray102_;

static mxChar _array105_[27] = { 0x005c, 'n', 'd', 'i', 's', 'p', 'l', 'a', 'y',
                                 'i', 'n', 'g', ' ', 'a', 't', ' ', '%', 'd',
                                 '%', '%', ' ', 's', 'c', 'a', 'l', 'e', '.' };
static mxArray * _mxarray104_;
static mxArray * _mxarray106_;

static mxChar _array108_[8] = { 'v', 'e', 'r', 't', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray107_;

static mxChar _array110_[10] = { 'h', 'o', 'r', 'i', 'z',
                                 'o', 'n', 't', 'a', 'l' };
static mxArray * _mxarray109_;

static mxChar _array112_[21] = { 'F', 'a', 'c', 't', 'o', 'r', 'y',
                                 'F', 'i', 'g', 'u', 'r', 'e', 'P',
                                 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray111_;

static mxChar _array114_[19] = { 'F', 'a', 'c', 't', 'o', 'r', 'y',
                                 'A', 'x', 'e', 's', 'P', 'o', 's',
                                 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray113_;

void InitializeModule_truesize(void) {
    _mxarray0_ = mclInitializeString(134, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
    _mxarray4_ = mclInitializeString(152, _array5_);
    _mxarray6_ = mclInitializeString(151, _array7_);
    _mxarray8_ = mclInitializeString(152, _array9_);
    _mxarray10_ = mclInitializeString(151, _array11_);
    _mxarray12_ = mclInitializeString(152, _array13_);
    _mxarray14_ = mclInitializeString(151, _array15_);
    _mxarray16_ = mclInitializeDouble(1.0);
    _mxarray17_ = mclInitializeDouble(2.0);
    _mxarray18_ = mclInitializeDouble(3.0);
    _mxarray19_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray20_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray21_ = mclInitializeDoubleVector(1, 2, _array22_);
    _mxarray23_ = mclInitializeString(4, _array24_);
    _mxarray25_ = mclInitializeString(6, _array26_);
    _mxarray27_ = mclInitializeString(33, _array28_);
    _mxarray29_ = mclInitializeString(11, _array30_);
    _mxarray31_ = mclInitializeString(26, _array32_);
    _mxarray33_ = mclInitializeString(31, _array34_);
    _mxarray35_ = mclInitializeString(6, _array36_);
    _mxarray37_ = mclInitializeString(4, _array38_);
    _mxarray39_ = mclInitializeString(5, _array40_);
    _mxarray41_ = mclInitializeString(7, _array42_);
    _mxarray43_ = mclInitializeString(9, _array44_);
    _mxarray45_ = mclInitializeString(10, _array46_);
    _mxarray47_ = mclInitializeString(3, _array48_);
    _mxarray49_ = mclInitializeString(12, _array50_);
    _mxarray51_ = mclInitializeString(49, _array52_);
    _mxarray53_ = mclInitializeString(4, _array54_);
    _mxarray55_ = mclInitializeString(4, _array56_);
    _mxarray57_ = mclInitializeString(9, _array58_);
    _mxarray59_ = mclInitializeString(7, _array60_);
    _mxarray61_ = mclInitializeString(2, _array62_);
    _mxarray63_ = mclInitializeString(6, _array64_);
    _mxarray65_ = mclInitializeString(3, _array66_);
    _mxarray67_ = mclInitializeString(5, _array68_);
    _mxarray69_ = mclInitializeDouble(0.0);
    _mxarray70_ = mclInitializeString(5, _array71_);
    _mxarray72_ = mclInitializeString(6, _array73_);
    _mxarray74_ = mclInitializeString(8, _array75_);
    _mxarray76_ = mclInitializeDouble(10.0);
    _mxarray77_ = mclInitializeDouble(50.0);
    _mxarray78_ = mclInitializeDouble(30.0);
    _mxarray79_ = mclInitializeDouble(128.0);
    _mxarray80_ = mclInitializeString(10, _array81_);
    _ieee_plusinf_ = mclGetInf();
    _mxarray82_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray83_ = mclInitializeDouble(100.0);
    _mxarray84_ = mclInitializeString(19, _array85_);
    _mxarray86_ = mclInitializeDouble(4.0);
    _mxarray87_ = mclInitializeString(8, _array88_);
    _mxarray89_ = mclInitializeString(15, _array90_);
    _mxarray91_ = mclInitializeString(15, _array92_);
    _mxarray93_ = mclInitializeString(35, _array94_);
    _mxarray95_ = mclInitializeString(25, _array96_);
    _mxarray97_ = mclInitializeDoubleVector(1, 2, _array98_);
    _mxarray99_ = mclInitializeDouble(2.220446049250313e-16);
    _mxarray100_ = mclInitializeString(10, _array101_);
    _mxarray102_ = mclInitializeString(48, _array103_);
    _mxarray104_ = mclInitializeString(27, _array105_);
    _mxarray106_ = mclInitializeDouble(20.0);
    _mxarray107_ = mclInitializeString(8, _array108_);
    _mxarray109_ = mclInitializeString(10, _array110_);
    _mxarray111_ = mclInitializeString(21, _array112_);
    _mxarray113_ = mclInitializeString(19, _array114_);
}

void TerminateModule_truesize(void) {
    mxDestroyArray(_mxarray113_);
    mxDestroyArray(_mxarray111_);
    mxDestroyArray(_mxarray109_);
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray106_);
    mxDestroyArray(_mxarray104_);
    mxDestroyArray(_mxarray102_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray87_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray82_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfTruesize_ParseInputs(mxArray * * imHandle,
                                         mxArray * * colorbarHandle,
                                         mxArray * * imSize,
                                         mxArray * * resizeType,
                                         mxArray * * msg,
                                         ...);
static void mlxTruesize_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static void mlfTruesize_Resize1(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize);
static void mlxTruesize_Resize1(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static void mlfTruesize_Resize2(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize);
static void mlxTruesize_Resize2(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static void mlfTruesize_Resize3(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize,
                                mxArray * colorbarHandle);
static void mlxTruesize_Resize3(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static void Mtruesize(mxArray * varargin);
static mxArray * Mtruesize_ParseInputs(mxArray * * imHandle,
                                       mxArray * * colorbarHandle,
                                       mxArray * * imSize,
                                       mxArray * * resizeType,
                                       mxArray * * msg,
                                       int nargout_,
                                       mxArray * varargin);
static void Mtruesize_Resize1(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize);
static void Mtruesize_Resize2(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize);
static void Mtruesize_Resize3(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize,
                              mxArray * colorbarHandle);

static mexFunctionTableEntry local_function_table_[4]
  = { { "ParseInputs", mlxTruesize_ParseInputs, -1, 6, NULL },
      { "Resize1", mlxTruesize_Resize1, 3, 0, NULL },
      { "Resize2", mlxTruesize_Resize2, 3, 0, NULL },
      { "Resize3", mlxTruesize_Resize3, 4, 0, NULL } };

_mexLocalFunctionTable _local_function_table_truesize
  = { 4, local_function_table_ };

/*
 * The function "mlfTruesize" contains the normal interface for the "truesize"
 * M-function from file "C:\matlabR12\toolbox\images\images\truesize.m" (lines
 * 1-55). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlfTruesize(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    Mtruesize(varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxTruesize" contains the feval interface for the "truesize"
 * M-function from file "C:\matlabR12\toolbox\images\images\truesize.m" (lines
 * 1-55). The feval function calls the implementation version of truesize
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxTruesize(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    if (nlhs > 0) {
        mlfError(_mxarray0_);
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    Mtruesize(mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfTruesize_ParseInputs" contains the normal interface for the
 * "truesize/ParseInputs" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 55-176). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTruesize_ParseInputs(mxArray * * imHandle,
                                         mxArray * * colorbarHandle,
                                         mxArray * * imSize,
                                         mxArray * * resizeType,
                                         mxArray * * msg,
                                         ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * axHandle = mclGetUninitializedArray();
    mxArray * imHandle__ = mclGetUninitializedArray();
    mxArray * colorbarHandle__ = mclGetUninitializedArray();
    mxArray * imSize__ = mclGetUninitializedArray();
    mxArray * resizeType__ = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfVarargin(&varargin, msg, 0);
    mlfEnterNewContext(
      5, -1, imHandle, colorbarHandle, imSize, resizeType, msg, varargin);
    if (imHandle != NULL) {
        ++nargout;
    }
    if (colorbarHandle != NULL) {
        ++nargout;
    }
    if (imSize != NULL) {
        ++nargout;
    }
    if (resizeType != NULL) {
        ++nargout;
    }
    if (msg != NULL) {
        ++nargout;
    }
    axHandle
      = Mtruesize_ParseInputs(
          &imHandle__,
          &colorbarHandle__,
          &imSize__,
          &resizeType__,
          &msg__,
          nargout,
          varargin);
    mlfRestorePreviousContext(
      5, 0, imHandle, colorbarHandle, imSize, resizeType, msg);
    mxDestroyArray(varargin);
    if (imHandle != NULL) {
        mclCopyOutputArg(imHandle, imHandle__);
    } else {
        mxDestroyArray(imHandle__);
    }
    if (colorbarHandle != NULL) {
        mclCopyOutputArg(colorbarHandle, colorbarHandle__);
    } else {
        mxDestroyArray(colorbarHandle__);
    }
    if (imSize != NULL) {
        mclCopyOutputArg(imSize, imSize__);
    } else {
        mxDestroyArray(imSize__);
    }
    if (resizeType != NULL) {
        mclCopyOutputArg(resizeType, resizeType__);
    } else {
        mxDestroyArray(resizeType__);
    }
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(axHandle);
}

/*
 * The function "mlxTruesize_ParseInputs" contains the feval interface for the
 * "truesize/ParseInputs" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 55-176). The feval
 * function calls the implementation version of truesize/ParseInputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxTruesize_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[6];
    int i;
    if (nlhs > 6) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 6; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mtruesize_ParseInputs(
          &mplhs[1],
          &mplhs[2],
          &mplhs[3],
          &mplhs[4],
          &mplhs[5],
          nlhs,
          mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 6 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 6; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfTruesize_Resize1" contains the normal interface for the
 * "truesize/Resize1" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 176-317). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTruesize_Resize1(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize) {
    mlfEnterNewContext(0, 3, axHandle, imHandle, imSize);
    Mtruesize_Resize1(axHandle, imHandle, imSize);
    mlfRestorePreviousContext(0, 3, axHandle, imHandle, imSize);
}

/*
 * The function "mlxTruesize_Resize1" contains the feval interface for the
 * "truesize/Resize1" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 176-317). The feval
 * function calls the implementation version of truesize/Resize1 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxTruesize_Resize1(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(_mxarray4_);
    }
    if (nrhs > 3) {
        mlfError(_mxarray6_);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mtruesize_Resize1(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfTruesize_Resize2" contains the normal interface for the
 * "truesize/Resize2" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 317-439). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTruesize_Resize2(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize) {
    mlfEnterNewContext(0, 3, axHandle, imHandle, imSize);
    Mtruesize_Resize2(axHandle, imHandle, imSize);
    mlfRestorePreviousContext(0, 3, axHandle, imHandle, imSize);
}

/*
 * The function "mlxTruesize_Resize2" contains the feval interface for the
 * "truesize/Resize2" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 317-439). The feval
 * function calls the implementation version of truesize/Resize2 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxTruesize_Resize2(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(_mxarray8_);
    }
    if (nrhs > 3) {
        mlfError(_mxarray10_);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mtruesize_Resize2(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfTruesize_Resize3" contains the normal interface for the
 * "truesize/Resize3" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 439-585). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTruesize_Resize3(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize,
                                mxArray * colorbarHandle) {
    mlfEnterNewContext(0, 4, axHandle, imHandle, imSize, colorbarHandle);
    Mtruesize_Resize3(axHandle, imHandle, imSize, colorbarHandle);
    mlfRestorePreviousContext(0, 4, axHandle, imHandle, imSize, colorbarHandle);
}

/*
 * The function "mlxTruesize_Resize3" contains the feval interface for the
 * "truesize/Resize3" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 439-585). The feval
 * function calls the implementation version of truesize/Resize3 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxTruesize_Resize3(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[4];
    int i;
    if (nlhs > 0) {
        mlfError(_mxarray12_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray14_);
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    Mtruesize_Resize3(mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
}

/*
 * The function "Mtruesize" is the implementation version of the "truesize"
 * M-function from file "C:\matlabR12\toolbox\images\images\truesize.m" (lines
 * 1-55). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function truesize(varargin)
 */
static void Mtruesize(mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_truesize);
    mxArray * ans = mclGetUninitializedArray();
    mxArray * msg = mclGetUninitializedArray();
    mxArray * resizeType = mclGetUninitializedArray();
    mxArray * imSize = mclGetUninitializedArray();
    mxArray * colorbarHandle = mclGetUninitializedArray();
    mxArray * imHandle = mclGetUninitializedArray();
    mxArray * axHandle = mclGetUninitializedArray();
    mclCopyArray(&varargin);
    /*
     * %TRUESIZE Adjust display size of image.
     * %   TRUESIZE(FIG,[MROWS NCOLS]) adjusts the display size of an
     * %   image. FIG is a figure containing a single image or a single 
     * %   image with a colorbar. [MROWS MCOLS] is a 1-by-2 vector that
     * %   specifies the requested screen area (in pixels) that the
     * %   image should occupy.
     * %
     * %   TRUESIZE(FIG) uses the image height and width for 
     * %   [MROWS MCOLS]. This results in the display having one screen
     * %   pixel for each image pixel.
     * %
     * %   If you omit the figure argument, TRUESIZE works on the
     * %   current figure.
     * %
     * %   Remarks
     * %   -------
     * %   If the 'TruesizeWarning' toolbox preference is 'on', TRUESIZE
     * %   displays a warning if the image is too large to fit on the
     * %   screen. (The entire image is still displayed, but at less
     * %   than true size.) If 'TruesizeWarning' is 'off', TRUESIZE does
     * %   not display the warning. Note that this preference applies
     * %   even when you call TRUESIZE indirectly, such as through
     * %   IMSHOW.
     * %
     * %   See also IMSHOW, IPTSETPREF, IPTGETPREF.
     * 
     * %   Copyright 1993-2000 The MathWorks, Inc.
     * %   $Revision: 5.21 $  $Date: 2000/04/27 14:13:36 $
     * 
     * [axHandle, imHandle, colorbarHandle, imSize, resizeType, msg] = ...
     * ParseInputs(varargin{:});
     */
    mlfAssign(
      &axHandle,
      mlfTruesize_ParseInputs(
        &imHandle,
        &colorbarHandle,
        &imSize,
        &resizeType,
        &msg,
        mclVe(
          mlfIndexRef(
            mclVsa(varargin, "varargin"), "{?}", mlfCreateColonIndex())),
        NULL));
    /*
     * if (~isempty(msg))
     */
    if (mclNotBool(mclVe(mlfIsempty(mclVv(msg, "msg"))))) {
        /*
         * error(msg);
         */
        mlfError(mclVv(msg, "msg"));
    /*
     * end
     */
    }
    /*
     * 
     * switch resizeType
     */
    {
        mxArray * v_ = mclInitialize(mclVv(resizeType, "resizeType"));
        if (mclSwitchCompare(v_, _mxarray16_)) {
            /*
             * case 1
             * % Figure contains one image and nothing else
             * Resize1(axHandle, imHandle, imSize);
             */
            mlfTruesize_Resize1(
              mclVv(axHandle, "axHandle"),
              mclVv(imHandle, "imHandle"),
              mclVv(imSize, "imSize"));
        /*
         * 
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray17_)) {
            /*
             * % Figure contains other noncolorbar axes
             * % or uicontrols.
             * Resize2(axHandle, imHandle, imSize);
             */
            mlfTruesize_Resize2(
              mclVv(axHandle, "axHandle"),
              mclVv(imHandle, "imHandle"),
              mclVv(imSize, "imSize"));
        /*
         * 
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray18_)) {
            /*
             * % Figure contains one image and a colorbar.
             * Resize3(axHandle, imHandle, imSize, colorbarHandle);
             */
            mlfTruesize_Resize3(
              mclVv(axHandle, "axHandle"),
              mclVv(imHandle, "imHandle"),
              mclVv(imSize, "imSize"),
              mclVv(colorbarHandle, "colorbarHandle"));
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mxDestroyArray(axHandle);
    mxDestroyArray(imHandle);
    mxDestroyArray(colorbarHandle);
    mxDestroyArray(imSize);
    mxDestroyArray(resizeType);
    mxDestroyArray(msg);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %--------------------------------------------
     * % Subfunction ParseInputs
     * %--------------------------------------------
     * function [axHandle,imHandle,colorbarHandle,imSize,resizeType,msg] = ...
     * ParseInputs(varargin)
     * 
     * imSize = [];
     * colorbarHandle = [];
     * msg = '';
     * axHandle = [];
     * imHandle = [];
     * resizeType = [];
     * 
     * if (nargin == 0)
     * axHandle = gca;
     * end
     * 
     * if (nargin >= 1)
     * if ((nargin == 1) & isequal(size(varargin{1}), [1 2]))
     * % truesize([M N])
     * figHandle = gcf;
     * imSize = varargin{1};
     * 
     * else
     * % truesize(FIG, ...)
     * if (~ishandle(varargin{1}) | ~strcmp(get(varargin{1},'type'),'figure'))
     * msg = 'FIG must be a valid figure handle';
     * return;
     * else
     * figHandle = varargin{1};
     * end
     * end
     * 
     * axHandle = get(figHandle, 'CurrentAxes');
     * if (isempty(axHandle))
     * msg = 'Current figure has no axes';
     * return;
     * end
     * end
     * 
     * if (nargin >= 2)
     * imSize = varargin{2};
     * if (~isequal(size(imSize), [1 2]))
     * msg = 'REQSIZE must be a 1-by-2 vector';
     * return;
     * end
     * end
     * 
     * figHandle = get(axHandle, 'Parent');
     * 
     * % Find all the images and texturemapped surfaces
     * % in the current figure.  These are the candidates.
     * h = [findobj(figHandle, 'Type', 'image') ;
     * findobj(figHandle, 'Type', 'surface', ...
     * 'FaceColor', 'texturemap')];
     * 
     * % If there's a colorbar, ignore it.
     * colorbarHandle = findobj(figHandle, 'type', 'image', ...
     * 'Tag', 'TMW_COLORBAR');
     * if (~isempty(colorbarHandle))
     * for k = 1:length(colorbarHandle)
     * h(h == colorbarHandle(k)) = [];
     * end
     * end
     * 
     * if (isempty(h))
     * msg = 'No images or texturemapped surfaces in the figure';
     * return;
     * end
     * 
     * % Start with the first object on the list as the
     * % initial candidate.  If it's not in the current
     * % axes, look for another one that is.
     * imHandle = h(1);
     * if (get(imHandle,'Parent') ~= axHandle)
     * for k = 2:length(h)
     * if (get(h(k),'Parent') == axHandle)
     * imHandle = h(k);
     * break;
     * end
     * end
     * end
     * 
     * figKids = allchild(figHandle);
     * if ((length(findobj(figKids, 'flat', 'Type', 'axes')) == 1) & ...
     * (length(findobj(figKids, 'flat', 'Type', 'uicontrol', ...
     * 'Visible', 'on')) == 0) & ...
     * (length(imHandle) == 1))
     * % Resize type 1
     * % Figure contains only one axes object, which contains only
     * % one image.
     * resizeType = 1;
     * 
     * elseif (isempty(colorbarHandle))
     * % Figure contains other objects and not a colorbar.
     * resizeType = 2;
     * 
     * else
     * % Figure contains a colorbar.  Do we have a one image
     * % one colorbar situation?
     * if (length(colorbarHandle) > 1)
     * % No
     * resizeType = 2;
     * else
     * colorbarAxes = get(colorbarHandle, 'Parent');
     * uimenuKids = findobj(figKids, 'flat', 'Type', 'uimenu');
     * invisUicontrolKids = findobj(figKids, 'flat', 'Type', 'uicontrol', ...
     * 'Visible', 'off');
     * otherKids = setdiff(figKids, ...
     * [uimenuKids ; colorbarAxes ; axHandle ; invisUicontrolKids]);
     * if (length(otherKids) > 1)
     * % No
     * resizeType = 2;
     * else
     * % Yes, one image and one colorbar
     * resizeType = 3;
     * end
     * end
     * end
     * 
     * 
     * %--------------------------------------------
     * % Subfunction Resize1
     * %--------------------------------------------
     */
}

/*
 * The function "Mtruesize_ParseInputs" is the implementation version of the
 * "truesize/ParseInputs" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 55-176). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [axHandle,imHandle,colorbarHandle,imSize,resizeType,msg] = ...
 */
static mxArray * Mtruesize_ParseInputs(mxArray * * imHandle,
                                       mxArray * * colorbarHandle,
                                       mxArray * * imSize,
                                       mxArray * * resizeType,
                                       mxArray * * msg,
                                       int nargout_,
                                       mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_truesize);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * axHandle = mclGetUninitializedArray();
    mxArray * otherKids = mclGetUninitializedArray();
    mxArray * invisUicontrolKids = mclGetUninitializedArray();
    mxArray * uimenuKids = mclGetUninitializedArray();
    mxArray * colorbarAxes = mclGetUninitializedArray();
    mxArray * figKids = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * h = mclGetUninitializedArray();
    mxArray * figHandle = mclGetUninitializedArray();
    mclCopyArray(&varargin);
    /*
     * ParseInputs(varargin)
     * 
     * imSize = [];
     */
    mlfAssign(imSize, _mxarray19_);
    /*
     * colorbarHandle = [];
     */
    mlfAssign(colorbarHandle, _mxarray19_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray20_);
    /*
     * axHandle = [];
     */
    mlfAssign(&axHandle, _mxarray19_);
    /*
     * imHandle = [];
     */
    mlfAssign(imHandle, _mxarray19_);
    /*
     * resizeType = [];
     */
    mlfAssign(resizeType, _mxarray19_);
    /*
     * 
     * if (nargin == 0)
     */
    if (nargin_ == 0) {
        /*
         * axHandle = gca;
         */
        mlfAssign(&axHandle, mlfGca(NULL));
    /*
     * end
     */
    }
    /*
     * 
     * if (nargin >= 1)
     */
    if (nargin_ >= 1) {
        /*
         * if ((nargin == 1) & isequal(size(varargin{1}), [1 2]))
         */
        mxArray * a_ = mclInitialize(mclBoolToArray(nargin_ == 1));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclVe(
                     mlfIsequal(
                       mclVe(
                         mclFeval(
                           mclValueVarargout(),
                           mlxSize,
                           mclVe(
                             mlfIndexRef(
                               mclVsa(varargin, "varargin"),
                               "{?}",
                               _mxarray16_)),
                           NULL)),
                       _mxarray21_, NULL))))) {
            mxDestroyArray(a_);
            /*
             * % truesize([M N])
             * figHandle = gcf;
             */
            mlfAssign(&figHandle, mlfGcf());
            /*
             * imSize = varargin{1};
             */
            mlfAssign(
              imSize,
              mlfIndexRef(mclVsa(varargin, "varargin"), "{?}", _mxarray16_));
        /*
         * 
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * % truesize(FIG, ...)
             * if (~ishandle(varargin{1}) | ~strcmp(get(varargin{1},'type'),'figure'))
             */
            {
                mxArray * a_0 = mclInitialize(
                                  mclNot(
                                    mclVe(
                                      mclFeval(
                                        mclValueVarargout(),
                                        mlxIshandle,
                                        mclVe(
                                          mlfIndexRef(
                                            mclVsa(varargin, "varargin"),
                                            "{?}",
                                            _mxarray16_)),
                                        NULL))));
                if (mlfTobool(a_0)
                    || mlfTobool(
                         mclOr(
                           a_0,
                           mclNot(
                             mclVe(
                               mlfStrcmp(
                                 mclVe(
                                   mlfNGet(
                                     1,
                                     mclVe(
                                       mlfIndexRef(
                                         mclVsa(varargin, "varargin"),
                                         "{?}",
                                         _mxarray16_)),
                                     _mxarray23_,
                                     NULL)),
                                 _mxarray25_)))))) {
                    mxDestroyArray(a_0);
                    /*
                     * msg = 'FIG must be a valid figure handle';
                     */
                    mlfAssign(msg, _mxarray27_);
                    /*
                     * return;
                     */
                    goto return_;
                /*
                 * else
                 */
                } else {
                    mxDestroyArray(a_0);
                    /*
                     * figHandle = varargin{1};
                     */
                    mlfAssign(
                      &figHandle,
                      mlfIndexRef(
                        mclVsa(varargin, "varargin"), "{?}", _mxarray16_));
                }
            /*
             * end
             */
            }
        }
        /*
         * end
         * 
         * axHandle = get(figHandle, 'CurrentAxes');
         */
        mlfAssign(
          &axHandle,
          mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray29_, NULL));
        /*
         * if (isempty(axHandle))
         */
        if (mlfTobool(mclVe(mlfIsempty(mclVv(axHandle, "axHandle"))))) {
            /*
             * msg = 'Current figure has no axes';
             */
            mlfAssign(msg, _mxarray31_);
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (nargin >= 2)
     */
    if (nargin_ >= 2) {
        /*
         * imSize = varargin{2};
         */
        mlfAssign(
          imSize,
          mlfIndexRef(mclVsa(varargin, "varargin"), "{?}", _mxarray17_));
        /*
         * if (~isequal(size(imSize), [1 2]))
         */
        if (mclNotBool(
              mclVe(
                mlfIsequal(
                  mclVe(
                    mlfSize(
                      mclValueVarargout(), mclVv(*imSize, "imSize"), NULL)),
                  _mxarray21_, NULL)))) {
            /*
             * msg = 'REQSIZE must be a 1-by-2 vector';
             */
            mlfAssign(msg, _mxarray33_);
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVv(axHandle, "axHandle"), _mxarray35_, NULL));
    /*
     * 
     * % Find all the images and texturemapped surfaces
     * % in the current figure.  These are the candidates.
     * h = [findobj(figHandle, 'Type', 'image') ;
     */
    mlfAssign(
      &h,
      mlfVertcat(
        mclVe(
          mlfFindobj(
            mclVv(figHandle, "figHandle"), _mxarray37_, _mxarray39_, NULL)),
        mclVe(
          mlfFindobj(
            mclVv(figHandle, "figHandle"),
            _mxarray37_,
            _mxarray41_,
            _mxarray43_,
            _mxarray45_,
            NULL)),
        NULL));
    /*
     * findobj(figHandle, 'Type', 'surface', ...
     * 'FaceColor', 'texturemap')];
     * 
     * % If there's a colorbar, ignore it.
     * colorbarHandle = findobj(figHandle, 'type', 'image', ...
     */
    mlfAssign(
      colorbarHandle,
      mlfFindobj(
        mclVv(figHandle, "figHandle"),
        _mxarray23_,
        _mxarray39_,
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 'Tag', 'TMW_COLORBAR');
     * if (~isempty(colorbarHandle))
     */
    if (mclNotBool(
          mclVe(mlfIsempty(mclVv(*colorbarHandle, "colorbarHandle"))))) {
        /*
         * for k = 1:length(colorbarHandle)
         */
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(
                   mlfScalar(
                     mclLengthInt(mclVv(*colorbarHandle, "colorbarHandle"))));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray19_);
        } else {
            /*
             * h(h == colorbarHandle(k)) = [];
             * end
             */
            for (; ; ) {
                mlfIndexDelete(
                  &h,
                  "(?)",
                  mclEq(
                    mclVv(h, "h"),
                    mclVe(
                      mclIntArrayRef1(
                        mclVsv(*colorbarHandle, "colorbarHandle"), v_))));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (isempty(h))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(h, "h"))))) {
        /*
         * msg = 'No images or texturemapped surfaces in the figure';
         */
        mlfAssign(msg, _mxarray51_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * % Start with the first object on the list as the
     * % initial candidate.  If it's not in the current
     * % axes, look for another one that is.
     * imHandle = h(1);
     */
    mlfAssign(imHandle, mclIntArrayRef1(mclVsv(h, "h"), 1));
    /*
     * if (get(imHandle,'Parent') ~= axHandle)
     */
    if (mclNeBool(
          mclVe(mlfNGet(1, mclVv(*imHandle, "imHandle"), _mxarray35_, NULL)),
          mclVv(axHandle, "axHandle"))) {
        /*
         * for k = 2:length(h)
         */
        int v_ = mclForIntStart(2);
        int e_ = mclForIntEnd(mlfScalar(mclLengthInt(mclVv(h, "h"))));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray19_);
        } else {
            /*
             * if (get(h(k),'Parent') == axHandle)
             * imHandle = h(k);
             * break;
             * end
             * end
             */
            for (; ; ) {
                if (mclEqBool(
                      mclVe(
                        mlfNGet(
                          1,
                          mclVe(mclIntArrayRef1(mclVsv(h, "h"), v_)),
                          _mxarray35_,
                          NULL)),
                      mclVv(axHandle, "axHandle"))) {
                    mlfAssign(imHandle, mclIntArrayRef1(mclVsv(h, "h"), v_));
                    break;
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    /*
     * end
     */
    }
    /*
     * 
     * figKids = allchild(figHandle);
     */
    mlfAssign(&figKids, mlfAllchild(mclVv(figHandle, "figHandle")));
    /*
     * if ((length(findobj(figKids, 'flat', 'Type', 'axes')) == 1) & ...
     */
    if (mclLengthInt(
          mclVe(
            mlfFindobj(
              mclVv(figKids, "figKids"),
              _mxarray53_,
              _mxarray37_,
              _mxarray55_,
              NULL)))
        == 1
        && mclLengthInt(
             mclVe(
               mlfFindobj(
                 mclVv(figKids, "figKids"),
                 _mxarray53_,
                 _mxarray37_,
                 _mxarray57_,
                 _mxarray59_,
                 _mxarray61_,
                 NULL)))
           == 0
        && mclLengthInt(mclVv(*imHandle, "imHandle")) == 1) {
        /*
         * (length(findobj(figKids, 'flat', 'Type', 'uicontrol', ...
         * 'Visible', 'on')) == 0) & ...
         * (length(imHandle) == 1))
         * % Resize type 1
         * % Figure contains only one axes object, which contains only
         * % one image.
         * resizeType = 1;
         */
        mlfAssign(resizeType, _mxarray16_);
    /*
     * 
     * elseif (isempty(colorbarHandle))
     */
    } else if (mlfTobool(
                 mclVe(mlfIsempty(mclVv(*colorbarHandle, "colorbarHandle"))))) {
        /*
         * % Figure contains other objects and not a colorbar.
         * resizeType = 2;
         */
        mlfAssign(resizeType, _mxarray17_);
    /*
     * 
     * else
     */
    } else {
        /*
         * % Figure contains a colorbar.  Do we have a one image
         * % one colorbar situation?
         * if (length(colorbarHandle) > 1)
         */
        if (mclLengthInt(mclVv(*colorbarHandle, "colorbarHandle")) > 1) {
            /*
             * % No
             * resizeType = 2;
             */
            mlfAssign(resizeType, _mxarray17_);
        /*
         * else
         */
        } else {
            /*
             * colorbarAxes = get(colorbarHandle, 'Parent');
             */
            mlfAssign(
              &colorbarAxes,
              mlfNGet(
                1,
                mclVv(*colorbarHandle, "colorbarHandle"), _mxarray35_, NULL));
            /*
             * uimenuKids = findobj(figKids, 'flat', 'Type', 'uimenu');
             */
            mlfAssign(
              &uimenuKids,
              mlfFindobj(
                mclVv(figKids, "figKids"),
                _mxarray53_,
                _mxarray37_,
                _mxarray63_,
                NULL));
            /*
             * invisUicontrolKids = findobj(figKids, 'flat', 'Type', 'uicontrol', ...
             */
            mlfAssign(
              &invisUicontrolKids,
              mlfFindobj(
                mclVv(figKids, "figKids"),
                _mxarray53_,
                _mxarray37_,
                _mxarray57_,
                _mxarray59_,
                _mxarray65_,
                NULL));
            /*
             * 'Visible', 'off');
             * otherKids = setdiff(figKids, ...
             */
            mlfAssign(
              &otherKids,
              mlfSetdiff(
                NULL,
                mclVv(figKids, "figKids"),
                mlfVertcat(
                  mclVv(uimenuKids, "uimenuKids"),
                  mclVv(colorbarAxes, "colorbarAxes"),
                  mclVv(axHandle, "axHandle"),
                  mclVv(invisUicontrolKids, "invisUicontrolKids"),
                  NULL),
                NULL));
            /*
             * [uimenuKids ; colorbarAxes ; axHandle ; invisUicontrolKids]);
             * if (length(otherKids) > 1)
             */
            if (mclLengthInt(mclVv(otherKids, "otherKids")) > 1) {
                /*
                 * % No
                 * resizeType = 2;
                 */
                mlfAssign(resizeType, _mxarray17_);
            /*
             * else
             */
            } else {
                /*
                 * % Yes, one image and one colorbar
                 * resizeType = 3;
                 */
                mlfAssign(resizeType, _mxarray18_);
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * 
     * %--------------------------------------------
     * % Subfunction Resize1
     * %--------------------------------------------
     * function Resize1(axHandle, imHandle, imSize)
     */
    return_:
    mclValidateOutput(
      axHandle, 1, nargout_, "axHandle", "truesize/ParseInputs");
    mclValidateOutput(
      *imHandle, 2, nargout_, "imHandle", "truesize/ParseInputs");
    mclValidateOutput(
      *colorbarHandle, 3, nargout_, "colorbarHandle", "truesize/ParseInputs");
    mclValidateOutput(*imSize, 4, nargout_, "imSize", "truesize/ParseInputs");
    mclValidateOutput(
      *resizeType, 5, nargout_, "resizeType", "truesize/ParseInputs");
    mclValidateOutput(*msg, 6, nargout_, "msg", "truesize/ParseInputs");
    mxDestroyArray(figHandle);
    mxDestroyArray(h);
    mxDestroyArray(k);
    mxDestroyArray(figKids);
    mxDestroyArray(colorbarAxes);
    mxDestroyArray(uimenuKids);
    mxDestroyArray(invisUicontrolKids);
    mxDestroyArray(otherKids);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return axHandle;
    /*
     * % Resize figure containing a single axes
     * % object with a single image.
     * 
     * if (isempty(imSize))
     * % How big is the image?
     * imageWidth = size(get(imHandle, 'CData'), 2);
     * imageHeight = size(get(imHandle, 'CData'), 1);
     * else
     * imageWidth = imSize(2);
     * imageHeight = imSize(1);
     * end
     * 
     * if (imageWidth * imageHeight == 0)
     * % Don't try to handle the degenerate case.
     * return;
     * end
     * 
     * axUnits = get(axHandle, 'Units');
     * set(axHandle, 'Units', 'pixels');
     * axPos = get(axHandle, 'Position');
     * 
     * figHandle = get(axHandle, 'Parent');
     * figUnits = get(figHandle, 'Units');
     * rootUnits = get(0, 'Units');
     * set(figHandle, 'Units', 'pixels');
     * set(0, 'Units', 'pixels');
     * 
     * figLeftBorder = 10;  % assume left figure decorations are 10 pixels
     * figRightBorder = 10;
     * figBottomBorder = 10;
     * figTopBorder = 50;
     * figTopBorder = figTopBorder + 30;  % scribe hack
     * 
     * minFigWidth = 128; % don't try to display a figure smaller than this.
     * minFigHeight = 128;
     * 
     * % What are the gutter sizes?
     * figPos = get(figHandle, 'Position');
     * gutterLeft = max(axPos(1) - 1, 0);
     * gutterRight = max(figPos(3) - (axPos(1) + axPos(3)) + 1, 0);
     * gutterBottom = max(axPos(2) - 1, 0);
     * gutterTop = max(figPos(4) - (axPos(2) + axPos(4)) + 1, 0);
     * 
     * % What are the screen dimensions
     * screenSize = get(0, 'ScreenSize');
     * screenWidth = screenSize(3);
     * screenHeight = screenSize(4);
     * if ((screenWidth <= 1) | (screenHeight <= 1))
     * screenWidth = Inf;
     * screenHeight = Inf;
     * end
     * 
     * scale = 100;
     * done = 0;
     * defAxesPos = get(0,'DefaultAxesPosition');
     * nonzeroGutters = (gutterLeft > 0);
     * while (~done)
     * if (nonzeroGutters)
     * gutterWidth = round((1 - defAxesPos(3)) * imageWidth / defAxesPos(3));
     * gutterHeight = round((1 - defAxesPos(4)) * imageHeight / defAxesPos(4));
     * newFigWidth = imageWidth + gutterWidth;
     * newFigHeight = imageHeight + gutterHeight;
     * else
     * newFigWidth = imageWidth;
     * newFigHeight = imageHeight;
     * end
     * if (((newFigWidth + figLeftBorder + figRightBorder) > screenWidth) | ...
     * ((newFigHeight + figBottomBorder + figTopBorder) > screenHeight))
     * scale = 3 * scale / 4;
     * imageWidth = round(imageWidth * scale / 100);
     * imageHeight = round(imageHeight * scale / 100);
     * else
     * done = 1;
     * end
     * end
     * 
     * newFigWidth = max(newFigWidth, minFigWidth);
     * newFigHeight = max(newFigHeight, minFigHeight);
     * 
     * figPos(1) = max(1, figPos(1) - floor((newFigWidth - figPos(3))/2));
     * figPos(2) = max(1, figPos(2) - floor((newFigHeight - figPos(4))/2));
     * figPos(3) = newFigWidth;
     * figPos(4) = newFigHeight;
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPos(1) + figPos(3));
     * if (deltaX < 0)
     * figPos(1) = figPos(1) + deltaX;
     * end
     * deltaY = (screenSize(4) - figTopBorder) - (figPos(2) + figPos(4));
     * if (deltaY < 0)
     * figPos(2) = figPos(2) + deltaY;
     * end
     * 
     * % Figure out where to place the axes object in the
     * % resized figure
     * gutterWidth = figPos(3) - imageWidth;
     * gutterHeight = figPos(4) - imageHeight;
     * gutterLeft = floor(gutterWidth/2);
     * gutterBottom = floor(gutterHeight/2);
     * 
     * axPos(1) = gutterLeft + 1;
     * axPos(2) = gutterBottom + 1;
     * axPos(3) = imageWidth;
     * axPos(4) = imageHeight;
     * 
     * set(figHandle, 'Position', figPos)
     * set(axHandle, 'Position', axPos);
     * 
     * % Restore the units
     * drawnow;  % necessary to work around HG bug   -SLE
     * set(figHandle, 'Units', figUnits);
     * set(axHandle, 'Units', axUnits);
     * set(0, 'Units', rootUnits);
     * 
     * % Set the nextplot property of the figure so that the
     * % axes object gets deleted and replaced for the next plot.
     * % That way, the new plot gets drawn in the default position.
     * set(figHandle, 'NextPlot', 'replacechildren');
     * 
     * % Warn if the display is not truesize, unless warning is disabled
     * % according to toolbox preference setting.
     * if ((scale < 100) & strcmp(iptgetpref('TruesizeWarning'), 'on'))
     * message = ['Image is too big to fit on screen; ', ...
     * sprintf('displaying at %d%% scale.', floor(scale))];
     * warning(message);
     * end
     * 
     * %--------------------------------------------
     * % Subfunction Resize2
     * %--------------------------------------------
     * % Resize figure containing multiple axes or
     * % other objects.  Basically we're going to
     * % compute a global figure scaling factor
     * % that will bring the target image into
     * % truesize mode.  This works reasonably well
     * % for subplot-type figures as long as all
     * % the images have the same size.  This is
     * % basically the guts of truesize.m from IPT
     * % version 1.
     */
}

/*
 * The function "Mtruesize_Resize1" is the implementation version of the
 * "truesize/Resize1" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 176-317). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function Resize1(axHandle, imHandle, imSize)
 */
static void Mtruesize_Resize1(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_truesize);
    mxArray * message = mclGetUninitializedArray();
    mxArray * deltaY = mclGetUninitializedArray();
    mxArray * deltaX = mclGetUninitializedArray();
    mxArray * newFigHeight = mclGetUninitializedArray();
    mxArray * newFigWidth = mclGetUninitializedArray();
    mxArray * gutterHeight = mclGetUninitializedArray();
    mxArray * gutterWidth = mclGetUninitializedArray();
    mxArray * nonzeroGutters = mclGetUninitializedArray();
    mxArray * defAxesPos = mclGetUninitializedArray();
    mxArray * done = mclGetUninitializedArray();
    mxArray * scale = mclGetUninitializedArray();
    mxArray * screenHeight = mclGetUninitializedArray();
    mxArray * screenWidth = mclGetUninitializedArray();
    mxArray * screenSize = mclGetUninitializedArray();
    mxArray * gutterTop = mclGetUninitializedArray();
    mxArray * gutterBottom = mclGetUninitializedArray();
    mxArray * gutterRight = mclGetUninitializedArray();
    mxArray * gutterLeft = mclGetUninitializedArray();
    mxArray * figPos = mclGetUninitializedArray();
    mxArray * minFigHeight = mclGetUninitializedArray();
    mxArray * minFigWidth = mclGetUninitializedArray();
    mxArray * figTopBorder = mclGetUninitializedArray();
    mxArray * figBottomBorder = mclGetUninitializedArray();
    mxArray * figRightBorder = mclGetUninitializedArray();
    mxArray * figLeftBorder = mclGetUninitializedArray();
    mxArray * rootUnits = mclGetUninitializedArray();
    mxArray * figUnits = mclGetUninitializedArray();
    mxArray * figHandle = mclGetUninitializedArray();
    mxArray * axPos = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * axUnits = mclGetUninitializedArray();
    mxArray * imageHeight = mclGetUninitializedArray();
    mxArray * imageWidth = mclGetUninitializedArray();
    mclCopyArray(&axHandle);
    mclCopyArray(&imHandle);
    mclCopyArray(&imSize);
    /*
     * % Resize figure containing a single axes
     * % object with a single image.
     * 
     * if (isempty(imSize))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVa(imSize, "imSize"))))) {
        /*
         * % How big is the image?
         * imageWidth = size(get(imHandle, 'CData'), 2);
         */
        mlfAssign(
          &imageWidth,
          mlfSize(
            mclValueVarargout(),
            mclVe(mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray67_, NULL)),
            _mxarray17_));
        /*
         * imageHeight = size(get(imHandle, 'CData'), 1);
         */
        mlfAssign(
          &imageHeight,
          mlfSize(
            mclValueVarargout(),
            mclVe(mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray67_, NULL)),
            _mxarray16_));
    /*
     * else
     */
    } else {
        /*
         * imageWidth = imSize(2);
         */
        mlfAssign(&imageWidth, mclIntArrayRef1(mclVsa(imSize, "imSize"), 2));
        /*
         * imageHeight = imSize(1);
         */
        mlfAssign(&imageHeight, mclIntArrayRef1(mclVsa(imSize, "imSize"), 1));
    /*
     * end
     */
    }
    /*
     * 
     * if (imageWidth * imageHeight == 0)
     */
    if (mclEqBool(
          mclMtimes(
            mclVv(imageWidth, "imageWidth"), mclVv(imageHeight, "imageHeight")),
          _mxarray69_)) {
        /*
         * % Don't try to handle the degenerate case.
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * axUnits = get(axHandle, 'Units');
     */
    mlfAssign(
      &axUnits, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray70_, NULL));
    /*
     * set(axHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray70_, _mxarray72_, NULL));
    /*
     * axPos = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPos, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray74_, NULL));
    /*
     * 
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray35_, NULL));
    /*
     * figUnits = get(figHandle, 'Units');
     */
    mlfAssign(
      &figUnits, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray70_, NULL));
    /*
     * rootUnits = get(0, 'Units');
     */
    mlfAssign(&rootUnits, mlfNGet(1, _mxarray69_, _mxarray70_, NULL));
    /*
     * set(figHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray70_, _mxarray72_, NULL));
    /*
     * set(0, 'Units', 'pixels');
     */
    mclAssignAns(&ans, mlfNSet(0, _mxarray69_, _mxarray70_, _mxarray72_, NULL));
    /*
     * 
     * figLeftBorder = 10;  % assume left figure decorations are 10 pixels
     */
    mlfAssign(&figLeftBorder, _mxarray76_);
    /*
     * figRightBorder = 10;
     */
    mlfAssign(&figRightBorder, _mxarray76_);
    /*
     * figBottomBorder = 10;
     */
    mlfAssign(&figBottomBorder, _mxarray76_);
    /*
     * figTopBorder = 50;
     */
    mlfAssign(&figTopBorder, _mxarray77_);
    /*
     * figTopBorder = figTopBorder + 30;  % scribe hack
     */
    mlfAssign(
      &figTopBorder, mclPlus(mclVv(figTopBorder, "figTopBorder"), _mxarray78_));
    /*
     * 
     * minFigWidth = 128; % don't try to display a figure smaller than this.
     */
    mlfAssign(&minFigWidth, _mxarray79_);
    /*
     * minFigHeight = 128;
     */
    mlfAssign(&minFigHeight, _mxarray79_);
    /*
     * 
     * % What are the gutter sizes?
     * figPos = get(figHandle, 'Position');
     */
    mlfAssign(
      &figPos, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray74_, NULL));
    /*
     * gutterLeft = max(axPos(1) - 1, 0);
     */
    mlfAssign(
      &gutterLeft,
      mlfMax(
        NULL,
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 1)), _mxarray16_),
        _mxarray69_,
        NULL));
    /*
     * gutterRight = max(figPos(3) - (axPos(1) + axPos(3)) + 1, 0);
     */
    mlfAssign(
      &gutterRight,
      mlfMax(
        NULL,
        mclPlus(
          mclMinus(
            mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 3)),
            mclPlus(
              mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 1)),
              mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 3)))),
          _mxarray16_),
        _mxarray69_,
        NULL));
    /*
     * gutterBottom = max(axPos(2) - 1, 0);
     */
    mlfAssign(
      &gutterBottom,
      mlfMax(
        NULL,
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 2)), _mxarray16_),
        _mxarray69_,
        NULL));
    /*
     * gutterTop = max(figPos(4) - (axPos(2) + axPos(4)) + 1, 0);
     */
    mlfAssign(
      &gutterTop,
      mlfMax(
        NULL,
        mclPlus(
          mclMinus(
            mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 4)),
            mclPlus(
              mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 2)),
              mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 4)))),
          _mxarray16_),
        _mxarray69_,
        NULL));
    /*
     * 
     * % What are the screen dimensions
     * screenSize = get(0, 'ScreenSize');
     */
    mlfAssign(&screenSize, mlfNGet(1, _mxarray69_, _mxarray80_, NULL));
    /*
     * screenWidth = screenSize(3);
     */
    mlfAssign(
      &screenWidth, mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 3));
    /*
     * screenHeight = screenSize(4);
     */
    mlfAssign(
      &screenHeight, mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 4));
    /*
     * if ((screenWidth <= 1) | (screenHeight <= 1))
     */
    {
        mxArray * a_ = mclInitialize(
                         mclLe(mclVv(screenWidth, "screenWidth"), _mxarray16_));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclLe(mclVv(screenHeight, "screenHeight"), _mxarray16_)))) {
            mxDestroyArray(a_);
            /*
             * screenWidth = Inf;
             */
            mlfAssign(&screenWidth, _mxarray82_);
            /*
             * screenHeight = Inf;
             */
            mlfAssign(&screenHeight, _mxarray82_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * scale = 100;
     */
    mlfAssign(&scale, _mxarray83_);
    /*
     * done = 0;
     */
    mlfAssign(&done, _mxarray69_);
    /*
     * defAxesPos = get(0,'DefaultAxesPosition');
     */
    mlfAssign(&defAxesPos, mlfNGet(1, _mxarray69_, _mxarray84_, NULL));
    /*
     * nonzeroGutters = (gutterLeft > 0);
     */
    mlfAssign(
      &nonzeroGutters, mclGt(mclVv(gutterLeft, "gutterLeft"), _mxarray69_));
    /*
     * while (~done)
     */
    while (mclNotBool(mclVv(done, "done"))) {
        /*
         * if (nonzeroGutters)
         */
        if (mlfTobool(mclVv(nonzeroGutters, "nonzeroGutters"))) {
            /*
             * gutterWidth = round((1 - defAxesPos(3)) * imageWidth / defAxesPos(3));
             */
            mlfAssign(
              &gutterWidth,
              mlfRound(
                mclMrdivide(
                  mclMtimes(
                    mclMinus(
                      _mxarray16_,
                      mclVe(
                        mclIntArrayRef1(mclVsv(defAxesPos, "defAxesPos"), 3))),
                    mclVv(imageWidth, "imageWidth")),
                  mclVe(
                    mclIntArrayRef1(mclVsv(defAxesPos, "defAxesPos"), 3)))));
            /*
             * gutterHeight = round((1 - defAxesPos(4)) * imageHeight / defAxesPos(4));
             */
            mlfAssign(
              &gutterHeight,
              mlfRound(
                mclMrdivide(
                  mclMtimes(
                    mclMinus(
                      _mxarray16_,
                      mclVe(
                        mclIntArrayRef1(mclVsv(defAxesPos, "defAxesPos"), 4))),
                    mclVv(imageHeight, "imageHeight")),
                  mclVe(
                    mclIntArrayRef1(mclVsv(defAxesPos, "defAxesPos"), 4)))));
            /*
             * newFigWidth = imageWidth + gutterWidth;
             */
            mlfAssign(
              &newFigWidth,
              mclPlus(
                mclVv(imageWidth, "imageWidth"),
                mclVv(gutterWidth, "gutterWidth")));
            /*
             * newFigHeight = imageHeight + gutterHeight;
             */
            mlfAssign(
              &newFigHeight,
              mclPlus(
                mclVv(imageHeight, "imageHeight"),
                mclVv(gutterHeight, "gutterHeight")));
        /*
         * else
         */
        } else {
            /*
             * newFigWidth = imageWidth;
             */
            mlfAssign(&newFigWidth, mclVsv(imageWidth, "imageWidth"));
            /*
             * newFigHeight = imageHeight;
             */
            mlfAssign(&newFigHeight, mclVsv(imageHeight, "imageHeight"));
        /*
         * end
         */
        }
        /*
         * if (((newFigWidth + figLeftBorder + figRightBorder) > screenWidth) | ...
         */
        {
            mxArray * a_ = mclInitialize(
                             mclGt(
                               mclPlus(
                                 mclPlus(
                                   mclVv(newFigWidth, "newFigWidth"),
                                   mclVv(figLeftBorder, "figLeftBorder")),
                                 mclVv(figRightBorder, "figRightBorder")),
                               mclVv(screenWidth, "screenWidth")));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclGt(
                         mclPlus(
                           mclPlus(
                             mclVv(newFigHeight, "newFigHeight"),
                             mclVv(figBottomBorder, "figBottomBorder")),
                           mclVv(figTopBorder, "figTopBorder")),
                         mclVv(screenHeight, "screenHeight"))))) {
                mxDestroyArray(a_);
                /*
                 * ((newFigHeight + figBottomBorder + figTopBorder) > screenHeight))
                 * scale = 3 * scale / 4;
                 */
                mlfAssign(
                  &scale,
                  mclMrdivide(
                    mclMtimes(_mxarray18_, mclVv(scale, "scale")),
                    _mxarray86_));
                /*
                 * imageWidth = round(imageWidth * scale / 100);
                 */
                mlfAssign(
                  &imageWidth,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageWidth, "imageWidth"), mclVv(scale, "scale")),
                      _mxarray83_)));
                /*
                 * imageHeight = round(imageHeight * scale / 100);
                 */
                mlfAssign(
                  &imageHeight,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageHeight, "imageHeight"),
                        mclVv(scale, "scale")),
                      _mxarray83_)));
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * done = 1;
                 */
                mlfAssign(&done, _mxarray16_);
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * newFigWidth = max(newFigWidth, minFigWidth);
     */
    mlfAssign(
      &newFigWidth,
      mlfMax(
        NULL,
        mclVv(newFigWidth, "newFigWidth"),
        mclVv(minFigWidth, "minFigWidth"),
        NULL));
    /*
     * newFigHeight = max(newFigHeight, minFigHeight);
     */
    mlfAssign(
      &newFigHeight,
      mlfMax(
        NULL,
        mclVv(newFigHeight, "newFigHeight"),
        mclVv(minFigHeight, "minFigHeight"),
        NULL));
    /*
     * 
     * figPos(1) = max(1, figPos(1) - floor((newFigWidth - figPos(3))/2));
     */
    mclIntArrayAssign1(
      &figPos,
      mlfMax(
        NULL,
        _mxarray16_,
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 1)),
          mclVe(
            mlfFloor(
              mclMrdivide(
                mclMinus(
                  mclVv(newFigWidth, "newFigWidth"),
                  mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 3))),
                _mxarray17_)))),
        NULL),
      1);
    /*
     * figPos(2) = max(1, figPos(2) - floor((newFigHeight - figPos(4))/2));
     */
    mclIntArrayAssign1(
      &figPos,
      mlfMax(
        NULL,
        _mxarray16_,
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 2)),
          mclVe(
            mlfFloor(
              mclMrdivide(
                mclMinus(
                  mclVv(newFigHeight, "newFigHeight"),
                  mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 4))),
                _mxarray17_)))),
        NULL),
      2);
    /*
     * figPos(3) = newFigWidth;
     */
    mclIntArrayAssign1(&figPos, mclVsv(newFigWidth, "newFigWidth"), 3);
    /*
     * figPos(4) = newFigHeight;
     */
    mclIntArrayAssign1(&figPos, mclVsv(newFigHeight, "newFigHeight"), 4);
    /*
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPos(1) + figPos(3));
     */
    mlfAssign(
      &deltaX,
      mclMinus(
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 3)),
          mclVv(figRightBorder, "figRightBorder")),
        mclPlus(
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 1)),
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 3)))));
    /*
     * if (deltaX < 0)
     */
    if (mclLtBool(mclVv(deltaX, "deltaX"), _mxarray69_)) {
        /*
         * figPos(1) = figPos(1) + deltaX;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 1)),
            mclVv(deltaX, "deltaX")),
          1);
    /*
     * end
     */
    }
    /*
     * deltaY = (screenSize(4) - figTopBorder) - (figPos(2) + figPos(4));
     */
    mlfAssign(
      &deltaY,
      mclMinus(
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 4)),
          mclVv(figTopBorder, "figTopBorder")),
        mclPlus(
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 2)),
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 4)))));
    /*
     * if (deltaY < 0)
     */
    if (mclLtBool(mclVv(deltaY, "deltaY"), _mxarray69_)) {
        /*
         * figPos(2) = figPos(2) + deltaY;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 2)),
            mclVv(deltaY, "deltaY")),
          2);
    /*
     * end
     */
    }
    /*
     * 
     * % Figure out where to place the axes object in the
     * % resized figure
     * gutterWidth = figPos(3) - imageWidth;
     */
    mlfAssign(
      &gutterWidth,
      mclMinus(
        mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 3)),
        mclVv(imageWidth, "imageWidth")));
    /*
     * gutterHeight = figPos(4) - imageHeight;
     */
    mlfAssign(
      &gutterHeight,
      mclMinus(
        mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 4)),
        mclVv(imageHeight, "imageHeight")));
    /*
     * gutterLeft = floor(gutterWidth/2);
     */
    mlfAssign(
      &gutterLeft,
      mlfFloor(mclMrdivide(mclVv(gutterWidth, "gutterWidth"), _mxarray17_)));
    /*
     * gutterBottom = floor(gutterHeight/2);
     */
    mlfAssign(
      &gutterBottom,
      mlfFloor(mclMrdivide(mclVv(gutterHeight, "gutterHeight"), _mxarray17_)));
    /*
     * 
     * axPos(1) = gutterLeft + 1;
     */
    mclIntArrayAssign1(
      &axPos, mclPlus(mclVv(gutterLeft, "gutterLeft"), _mxarray16_), 1);
    /*
     * axPos(2) = gutterBottom + 1;
     */
    mclIntArrayAssign1(
      &axPos, mclPlus(mclVv(gutterBottom, "gutterBottom"), _mxarray16_), 2);
    /*
     * axPos(3) = imageWidth;
     */
    mclIntArrayAssign1(&axPos, mclVsv(imageWidth, "imageWidth"), 3);
    /*
     * axPos(4) = imageHeight;
     */
    mclIntArrayAssign1(&axPos, mclVsv(imageHeight, "imageHeight"), 4);
    /*
     * 
     * set(figHandle, 'Position', figPos)
     */
    mclPrintAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray74_,
        mclVv(figPos, "figPos"),
        NULL));
    /*
     * set(axHandle, 'Position', axPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray74_,
        mclVv(axPos, "axPos"),
        NULL));
    /*
     * 
     * % Restore the units
     * drawnow;  % necessary to work around HG bug   -SLE
     */
    mlfDrawnow(NULL);
    /*
     * set(figHandle, 'Units', figUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray70_,
        mclVv(figUnits, "figUnits"),
        NULL));
    /*
     * set(axHandle, 'Units', axUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray70_,
        mclVv(axUnits, "axUnits"),
        NULL));
    /*
     * set(0, 'Units', rootUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, _mxarray69_, _mxarray70_, mclVv(rootUnits, "rootUnits"), NULL));
    /*
     * 
     * % Set the nextplot property of the figure so that the
     * % axes object gets deleted and replaced for the next plot.
     * % That way, the new plot gets drawn in the default position.
     * set(figHandle, 'NextPlot', 'replacechildren');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray87_, _mxarray89_, NULL));
    /*
     * 
     * % Warn if the display is not truesize, unless warning is disabled
     * % according to toolbox preference setting.
     * if ((scale < 100) & strcmp(iptgetpref('TruesizeWarning'), 'on'))
     */
    {
        mxArray * a_ = mclInitialize(mclLt(mclVv(scale, "scale"), _mxarray83_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclVe(
                     mlfStrcmp(
                       mclVe(mlfIptgetpref(_mxarray91_)), _mxarray61_))))) {
            mxDestroyArray(a_);
            /*
             * message = ['Image is too big to fit on screen; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray93_,
                mclVe(
                  mlfSprintf(
                    NULL,
                    _mxarray95_,
                    mclVe(mlfFloor(mclVv(scale, "scale"))),
                    NULL)),
                NULL));
            /*
             * sprintf('displaying at %d%% scale.', floor(scale))];
             * warning(message);
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, mclVv(message, "message")));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * %--------------------------------------------
     * % Subfunction Resize2
     * %--------------------------------------------
     * % Resize figure containing multiple axes or
     * % other objects.  Basically we're going to
     * % compute a global figure scaling factor
     * % that will bring the target image into
     * % truesize mode.  This works reasonably well
     * % for subplot-type figures as long as all
     * % the images have the same size.  This is
     * % basically the guts of truesize.m from IPT
     * % version 1.
     * function Resize2(axHandle, imHandle, imSize)
     */
    return_:
    mxDestroyArray(imageWidth);
    mxDestroyArray(imageHeight);
    mxDestroyArray(axUnits);
    mxDestroyArray(ans);
    mxDestroyArray(axPos);
    mxDestroyArray(figHandle);
    mxDestroyArray(figUnits);
    mxDestroyArray(rootUnits);
    mxDestroyArray(figLeftBorder);
    mxDestroyArray(figRightBorder);
    mxDestroyArray(figBottomBorder);
    mxDestroyArray(figTopBorder);
    mxDestroyArray(minFigWidth);
    mxDestroyArray(minFigHeight);
    mxDestroyArray(figPos);
    mxDestroyArray(gutterLeft);
    mxDestroyArray(gutterRight);
    mxDestroyArray(gutterBottom);
    mxDestroyArray(gutterTop);
    mxDestroyArray(screenSize);
    mxDestroyArray(screenWidth);
    mxDestroyArray(screenHeight);
    mxDestroyArray(scale);
    mxDestroyArray(done);
    mxDestroyArray(defAxesPos);
    mxDestroyArray(nonzeroGutters);
    mxDestroyArray(gutterWidth);
    mxDestroyArray(gutterHeight);
    mxDestroyArray(newFigWidth);
    mxDestroyArray(newFigHeight);
    mxDestroyArray(deltaX);
    mxDestroyArray(deltaY);
    mxDestroyArray(message);
    mxDestroyArray(imSize);
    mxDestroyArray(imHandle);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * if (isempty(imSize))
     * imSize = size(get(imHandle, 'CData'));
     * end
     * 
     * if (prod(imSize) == 0)
     * % Don't try to handle the degenerate case.
     * return;
     * end
     * 
     * axUnits = get(axHandle, 'Units');
     * set(axHandle, 'Units', 'pixels');
     * axPosition = get(axHandle, 'Position');
     * % Do we need to do anything?
     * if norm(axPosition(3:4) - [imSize([2 1])]) < sqrt(eps)
     * set(axHandle, 'Units', axUnits)
     * return;
     * end
     * 
     * figHandle = get(axHandle, 'Parent');
     * figUnits = get(figHandle, 'Units');
     * rootUnits = get(0,'Units');
     * set(axHandle, 'Units', 'normalized');
     * axPosition = get(axHandle, 'Position');
     * set([figHandle 0], 'Units', 'pixels');
     * figPosition = get(figHandle, 'Position');
     * screenSize = get(0,'ScreenSize');
     * 
     * % What should the new figure size be?
     * dx = ceil(imSize(2)/axPosition(3) - figPosition(3));
     * dy = ceil(imSize(1)/axPosition(4) - figPosition(4));
     * newFigWidth = figPosition(3) + dx;
     * newFigHeight = figPosition(4) + dy;
     * 
     * % Is the new figure size too big or too small?
     * figLeftBorder = 10;
     * figRightBorder = 10;
     * figBottomBorder = 10;
     * figTopBorder = 50;
     * figTopBorder = figTopBorder + 30;  % scribe hack
     * minFigWidth = 128;
     * minFigHeight = 128;
     * 
     * if ((newFigWidth + figLeftBorder + figRightBorder) > screenSize(3))
     * scaleX = (screenSize(3) - figLeftBorder - figRightBorder) / newFigWidth;
     * else
     * scaleX = 1;
     * end
     * 
     * if ((newFigHeight + figBottomBorder + figTopBorder) > screenSize(4))
     * scaleY = (screenSize(4) - figBottomBorder - figTopBorder) / newFigHeight;
     * else
     * scaleY = 1;
     * end
     * 
     * if (newFigWidth < minFigWidth)
     * scaleX = minFigWidth / newFigWidth;
     * end
     * if (newFigHeight < minFigHeight)
     * scaleY = minFigHeight / newFigHeight;
     * end
     * 
     * if (min(scaleX, scaleY) < 1)
     * % Yes, the new figure is too big for the screen.
     * scale = min(scaleX, scaleY);
     * newFigWidth = floor(newFigWidth * scale);
     * newFigHeight = floor(newFigHeight * scale);
     * elseif (max(scaleX, scaleY) > 1)
     * % Yes, the new figure is too small.
     * scale = max(scaleX, scaleY);
     * newFigWidth = floor(newFigWidth * scale);
     * newFigHeight = floor(newFigHeight * scale);
     * else
     * scale = 1;
     * end
     * 
     * figPosition(3) = newFigWidth;
     * figPosition(4) = newFigHeight;
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPosition(1) + figPosition(3));
     * if (deltaX < 0)
     * figPosition(1) = figPosition(1) + deltaX;
     * end
     * deltaY = (screenSize(4) - figTopBorder) - (figPosition(2) + figPosition(4));
     * if (deltaY < 0)
     * figPosition(2) = figPosition(2) + deltaY;
     * end
     * 
     * % Change axes position to get exactly one pixel per image pixel.
     * % That is, as long as scale = 1.
     * dx = scale*imSize(2)/figPosition(3) - axPosition(3);
     * dy = scale*imSize(1)/figPosition(4) - axPosition(4);
     * axPosition = axPosition + [-dx/2 -dy/2 dx dy];
     * 
     * % OK, make the changes
     * set(axHandle, 'Position', axPosition);
     * set(figHandle, 'Position', figPosition);
     * 
     * % Restore the original units
     * set(axHandle, 'Units', axUnits);
     * set(figHandle, 'Units', figUnits);
     * set(0, 'Units', rootUnits);
     * 
     * % Warn if the display is not truesize, unless the truesize warning
     * % has been disabled according to a toolbox preference setting.
     * if (strcmp(iptgetpref('TruesizeWarning'), 'on'))
     * if (scale < 1)
     * message = ['Image is too big to fit on screen; ', ...
     * sprintf('displaying at %d%% scale.', round(100*scale))];
     * warning(message);
     * elseif (scale > 1)
     * message = ['Image is too small for truesize figure scaling; ', ...
     * sprintf('\ndisplaying at %d%% scale.', round(100*scale))];
     * warning(message);
     * end
     * end
     * 
     * %--------------------------------------------
     * % Subfunction Resize3
     * %--------------------------------------------
     */
}

/*
 * The function "Mtruesize_Resize2" is the implementation version of the
 * "truesize/Resize2" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 317-439). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function Resize2(axHandle, imHandle, imSize)
 */
static void Mtruesize_Resize2(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_truesize);
    mxArray * message = mclGetUninitializedArray();
    mxArray * deltaY = mclGetUninitializedArray();
    mxArray * deltaX = mclGetUninitializedArray();
    mxArray * scale = mclGetUninitializedArray();
    mxArray * scaleY = mclGetUninitializedArray();
    mxArray * scaleX = mclGetUninitializedArray();
    mxArray * minFigHeight = mclGetUninitializedArray();
    mxArray * minFigWidth = mclGetUninitializedArray();
    mxArray * figTopBorder = mclGetUninitializedArray();
    mxArray * figBottomBorder = mclGetUninitializedArray();
    mxArray * figRightBorder = mclGetUninitializedArray();
    mxArray * figLeftBorder = mclGetUninitializedArray();
    mxArray * newFigHeight = mclGetUninitializedArray();
    mxArray * newFigWidth = mclGetUninitializedArray();
    mxArray * dy = mclGetUninitializedArray();
    mxArray * dx = mclGetUninitializedArray();
    mxArray * screenSize = mclGetUninitializedArray();
    mxArray * figPosition = mclGetUninitializedArray();
    mxArray * rootUnits = mclGetUninitializedArray();
    mxArray * figUnits = mclGetUninitializedArray();
    mxArray * figHandle = mclGetUninitializedArray();
    mxArray * axPosition = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * axUnits = mclGetUninitializedArray();
    mclCopyArray(&axHandle);
    mclCopyArray(&imHandle);
    mclCopyArray(&imSize);
    /*
     * 
     * if (isempty(imSize))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVa(imSize, "imSize"))))) {
        /*
         * imSize = size(get(imHandle, 'CData'));
         */
        mlfAssign(
          &imSize,
          mlfSize(
            mclValueVarargout(),
            mclVe(mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray67_, NULL)),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * if (prod(imSize) == 0)
     */
    if (mclEqBool(mclVe(mlfProd(mclVa(imSize, "imSize"), NULL)), _mxarray69_)) {
        /*
         * % Don't try to handle the degenerate case.
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * axUnits = get(axHandle, 'Units');
     */
    mlfAssign(
      &axUnits, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray70_, NULL));
    /*
     * set(axHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray70_, _mxarray72_, NULL));
    /*
     * axPosition = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPosition, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray74_, NULL));
    /*
     * % Do we need to do anything?
     * if norm(axPosition(3:4) - [imSize([2 1])]) < sqrt(eps)
     */
    if (mclLtBool(
          mclVe(
            mlfNorm(
              mclMinus(
                mclVe(
                  mclArrayRef1(
                    mclVsv(axPosition, "axPosition"),
                    mlfColon(_mxarray18_, _mxarray86_, NULL))),
                mclVe(mclArrayRef1(mclVsa(imSize, "imSize"), _mxarray97_))),
              NULL)),
          mclVe(mlfSqrt(_mxarray99_)))) {
        /*
         * set(axHandle, 'Units', axUnits)
         */
        mclPrintAns(
          &ans,
          mlfNSet(
            0,
            mclVa(axHandle, "axHandle"),
            _mxarray70_,
            mclVv(axUnits, "axUnits"),
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray35_, NULL));
    /*
     * figUnits = get(figHandle, 'Units');
     */
    mlfAssign(
      &figUnits, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray70_, NULL));
    /*
     * rootUnits = get(0,'Units');
     */
    mlfAssign(&rootUnits, mlfNGet(1, _mxarray69_, _mxarray70_, NULL));
    /*
     * set(axHandle, 'Units', 'normalized');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray70_, _mxarray100_, NULL));
    /*
     * axPosition = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPosition, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray74_, NULL));
    /*
     * set([figHandle 0], 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfHorzcat(mclVv(figHandle, "figHandle"), _mxarray69_, NULL),
        _mxarray70_,
        _mxarray72_,
        NULL));
    /*
     * figPosition = get(figHandle, 'Position');
     */
    mlfAssign(
      &figPosition,
      mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray74_, NULL));
    /*
     * screenSize = get(0,'ScreenSize');
     */
    mlfAssign(&screenSize, mlfNGet(1, _mxarray69_, _mxarray80_, NULL));
    /*
     * 
     * % What should the new figure size be?
     * dx = ceil(imSize(2)/axPosition(3) - figPosition(3));
     */
    mlfAssign(
      &dx,
      mlfCeil(
        mclMinus(
          mclMrdivide(
            mclVe(mclIntArrayRef1(mclVsa(imSize, "imSize"), 2)),
            mclVe(mclIntArrayRef1(mclVsv(axPosition, "axPosition"), 3))),
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 3)))));
    /*
     * dy = ceil(imSize(1)/axPosition(4) - figPosition(4));
     */
    mlfAssign(
      &dy,
      mlfCeil(
        mclMinus(
          mclMrdivide(
            mclVe(mclIntArrayRef1(mclVsa(imSize, "imSize"), 1)),
            mclVe(mclIntArrayRef1(mclVsv(axPosition, "axPosition"), 4))),
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 4)))));
    /*
     * newFigWidth = figPosition(3) + dx;
     */
    mlfAssign(
      &newFigWidth,
      mclPlus(
        mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 3)),
        mclVv(dx, "dx")));
    /*
     * newFigHeight = figPosition(4) + dy;
     */
    mlfAssign(
      &newFigHeight,
      mclPlus(
        mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 4)),
        mclVv(dy, "dy")));
    /*
     * 
     * % Is the new figure size too big or too small?
     * figLeftBorder = 10;
     */
    mlfAssign(&figLeftBorder, _mxarray76_);
    /*
     * figRightBorder = 10;
     */
    mlfAssign(&figRightBorder, _mxarray76_);
    /*
     * figBottomBorder = 10;
     */
    mlfAssign(&figBottomBorder, _mxarray76_);
    /*
     * figTopBorder = 50;
     */
    mlfAssign(&figTopBorder, _mxarray77_);
    /*
     * figTopBorder = figTopBorder + 30;  % scribe hack
     */
    mlfAssign(
      &figTopBorder, mclPlus(mclVv(figTopBorder, "figTopBorder"), _mxarray78_));
    /*
     * minFigWidth = 128;
     */
    mlfAssign(&minFigWidth, _mxarray79_);
    /*
     * minFigHeight = 128;
     */
    mlfAssign(&minFigHeight, _mxarray79_);
    /*
     * 
     * if ((newFigWidth + figLeftBorder + figRightBorder) > screenSize(3))
     */
    if (mclGtBool(
          mclPlus(
            mclPlus(
              mclVv(newFigWidth, "newFigWidth"),
              mclVv(figLeftBorder, "figLeftBorder")),
            mclVv(figRightBorder, "figRightBorder")),
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 3)))) {
        /*
         * scaleX = (screenSize(3) - figLeftBorder - figRightBorder) / newFigWidth;
         */
        mlfAssign(
          &scaleX,
          mclMrdivide(
            mclMinus(
              mclMinus(
                mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 3)),
                mclVv(figLeftBorder, "figLeftBorder")),
              mclVv(figRightBorder, "figRightBorder")),
            mclVv(newFigWidth, "newFigWidth")));
    /*
     * else
     */
    } else {
        /*
         * scaleX = 1;
         */
        mlfAssign(&scaleX, _mxarray16_);
    /*
     * end
     */
    }
    /*
     * 
     * if ((newFigHeight + figBottomBorder + figTopBorder) > screenSize(4))
     */
    if (mclGtBool(
          mclPlus(
            mclPlus(
              mclVv(newFigHeight, "newFigHeight"),
              mclVv(figBottomBorder, "figBottomBorder")),
            mclVv(figTopBorder, "figTopBorder")),
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 4)))) {
        /*
         * scaleY = (screenSize(4) - figBottomBorder - figTopBorder) / newFigHeight;
         */
        mlfAssign(
          &scaleY,
          mclMrdivide(
            mclMinus(
              mclMinus(
                mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 4)),
                mclVv(figBottomBorder, "figBottomBorder")),
              mclVv(figTopBorder, "figTopBorder")),
            mclVv(newFigHeight, "newFigHeight")));
    /*
     * else
     */
    } else {
        /*
         * scaleY = 1;
         */
        mlfAssign(&scaleY, _mxarray16_);
    /*
     * end
     */
    }
    /*
     * 
     * if (newFigWidth < minFigWidth)
     */
    if (mclLtBool(
          mclVv(newFigWidth, "newFigWidth"),
          mclVv(minFigWidth, "minFigWidth"))) {
        /*
         * scaleX = minFigWidth / newFigWidth;
         */
        mlfAssign(
          &scaleX,
          mclMrdivide(
            mclVv(minFigWidth, "minFigWidth"),
            mclVv(newFigWidth, "newFigWidth")));
    /*
     * end
     */
    }
    /*
     * if (newFigHeight < minFigHeight)
     */
    if (mclLtBool(
          mclVv(newFigHeight, "newFigHeight"),
          mclVv(minFigHeight, "minFigHeight"))) {
        /*
         * scaleY = minFigHeight / newFigHeight;
         */
        mlfAssign(
          &scaleY,
          mclMrdivide(
            mclVv(minFigHeight, "minFigHeight"),
            mclVv(newFigHeight, "newFigHeight")));
    /*
     * end
     */
    }
    /*
     * 
     * if (min(scaleX, scaleY) < 1)
     */
    if (mclLtBool(
          mclVe(
            mlfMin(
              NULL, mclVv(scaleX, "scaleX"), mclVv(scaleY, "scaleY"), NULL)),
          _mxarray16_)) {
        /*
         * % Yes, the new figure is too big for the screen.
         * scale = min(scaleX, scaleY);
         */
        mlfAssign(
          &scale,
          mlfMin(NULL, mclVv(scaleX, "scaleX"), mclVv(scaleY, "scaleY"), NULL));
        /*
         * newFigWidth = floor(newFigWidth * scale);
         */
        mlfAssign(
          &newFigWidth,
          mlfFloor(
            mclMtimes(
              mclVv(newFigWidth, "newFigWidth"), mclVv(scale, "scale"))));
        /*
         * newFigHeight = floor(newFigHeight * scale);
         */
        mlfAssign(
          &newFigHeight,
          mlfFloor(
            mclMtimes(
              mclVv(newFigHeight, "newFigHeight"), mclVv(scale, "scale"))));
    /*
     * elseif (max(scaleX, scaleY) > 1)
     */
    } else if (mclGtBool(
                 mclVe(
                   mlfMax(
                     NULL,
                     mclVv(scaleX, "scaleX"),
                     mclVv(scaleY, "scaleY"),
                     NULL)),
                 _mxarray16_)) {
        /*
         * % Yes, the new figure is too small.
         * scale = max(scaleX, scaleY);
         */
        mlfAssign(
          &scale,
          mlfMax(NULL, mclVv(scaleX, "scaleX"), mclVv(scaleY, "scaleY"), NULL));
        /*
         * newFigWidth = floor(newFigWidth * scale);
         */
        mlfAssign(
          &newFigWidth,
          mlfFloor(
            mclMtimes(
              mclVv(newFigWidth, "newFigWidth"), mclVv(scale, "scale"))));
        /*
         * newFigHeight = floor(newFigHeight * scale);
         */
        mlfAssign(
          &newFigHeight,
          mlfFloor(
            mclMtimes(
              mclVv(newFigHeight, "newFigHeight"), mclVv(scale, "scale"))));
    /*
     * else
     */
    } else {
        /*
         * scale = 1;
         */
        mlfAssign(&scale, _mxarray16_);
    /*
     * end
     */
    }
    /*
     * 
     * figPosition(3) = newFigWidth;
     */
    mclIntArrayAssign1(&figPosition, mclVsv(newFigWidth, "newFigWidth"), 3);
    /*
     * figPosition(4) = newFigHeight;
     */
    mclIntArrayAssign1(&figPosition, mclVsv(newFigHeight, "newFigHeight"), 4);
    /*
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPosition(1) + figPosition(3));
     */
    mlfAssign(
      &deltaX,
      mclMinus(
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 3)),
          mclVv(figRightBorder, "figRightBorder")),
        mclPlus(
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 1)),
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 3)))));
    /*
     * if (deltaX < 0)
     */
    if (mclLtBool(mclVv(deltaX, "deltaX"), _mxarray69_)) {
        /*
         * figPosition(1) = figPosition(1) + deltaX;
         */
        mclIntArrayAssign1(
          &figPosition,
          mclPlus(
            mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 1)),
            mclVv(deltaX, "deltaX")),
          1);
    /*
     * end
     */
    }
    /*
     * deltaY = (screenSize(4) - figTopBorder) - (figPosition(2) + figPosition(4));
     */
    mlfAssign(
      &deltaY,
      mclMinus(
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 4)),
          mclVv(figTopBorder, "figTopBorder")),
        mclPlus(
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 2)),
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 4)))));
    /*
     * if (deltaY < 0)
     */
    if (mclLtBool(mclVv(deltaY, "deltaY"), _mxarray69_)) {
        /*
         * figPosition(2) = figPosition(2) + deltaY;
         */
        mclIntArrayAssign1(
          &figPosition,
          mclPlus(
            mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 2)),
            mclVv(deltaY, "deltaY")),
          2);
    /*
     * end
     */
    }
    /*
     * 
     * % Change axes position to get exactly one pixel per image pixel.
     * % That is, as long as scale = 1.
     * dx = scale*imSize(2)/figPosition(3) - axPosition(3);
     */
    mlfAssign(
      &dx,
      mclMinus(
        mclMrdivide(
          mclMtimes(
            mclVv(scale, "scale"),
            mclVe(mclIntArrayRef1(mclVsa(imSize, "imSize"), 2))),
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 3))),
        mclVe(mclIntArrayRef1(mclVsv(axPosition, "axPosition"), 3))));
    /*
     * dy = scale*imSize(1)/figPosition(4) - axPosition(4);
     */
    mlfAssign(
      &dy,
      mclMinus(
        mclMrdivide(
          mclMtimes(
            mclVv(scale, "scale"),
            mclVe(mclIntArrayRef1(mclVsa(imSize, "imSize"), 1))),
          mclVe(mclIntArrayRef1(mclVsv(figPosition, "figPosition"), 4))),
        mclVe(mclIntArrayRef1(mclVsv(axPosition, "axPosition"), 4))));
    /*
     * axPosition = axPosition + [-dx/2 -dy/2 dx dy];
     */
    mlfAssign(
      &axPosition,
      mclPlus(
        mclVv(axPosition, "axPosition"),
        mlfHorzcat(
          mclMrdivide(mclUminus(mclVv(dx, "dx")), _mxarray17_),
          mclMrdivide(mclUminus(mclVv(dy, "dy")), _mxarray17_),
          mclVv(dx, "dx"),
          mclVv(dy, "dy"),
          NULL)));
    /*
     * 
     * % OK, make the changes
     * set(axHandle, 'Position', axPosition);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray74_,
        mclVv(axPosition, "axPosition"),
        NULL));
    /*
     * set(figHandle, 'Position', figPosition);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray74_,
        mclVv(figPosition, "figPosition"),
        NULL));
    /*
     * 
     * % Restore the original units
     * set(axHandle, 'Units', axUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray70_,
        mclVv(axUnits, "axUnits"),
        NULL));
    /*
     * set(figHandle, 'Units', figUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray70_,
        mclVv(figUnits, "figUnits"),
        NULL));
    /*
     * set(0, 'Units', rootUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, _mxarray69_, _mxarray70_, mclVv(rootUnits, "rootUnits"), NULL));
    /*
     * 
     * % Warn if the display is not truesize, unless the truesize warning
     * % has been disabled according to a toolbox preference setting.
     * if (strcmp(iptgetpref('TruesizeWarning'), 'on'))
     */
    if (mlfTobool(
          mclVe(mlfStrcmp(mclVe(mlfIptgetpref(_mxarray91_)), _mxarray61_)))) {
        /*
         * if (scale < 1)
         */
        if (mclLtBool(mclVv(scale, "scale"), _mxarray16_)) {
            /*
             * message = ['Image is too big to fit on screen; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray93_,
                mclVe(
                  mlfSprintf(
                    NULL,
                    _mxarray95_,
                    mclVe(
                      mlfRound(mclMtimes(_mxarray83_, mclVv(scale, "scale")))),
                    NULL)),
                NULL));
            /*
             * sprintf('displaying at %d%% scale.', round(100*scale))];
             * warning(message);
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, mclVv(message, "message")));
        /*
         * elseif (scale > 1)
         */
        } else if (mclGtBool(mclVv(scale, "scale"), _mxarray16_)) {
            /*
             * message = ['Image is too small for truesize figure scaling; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray102_,
                mclVe(
                  mlfSprintf(
                    NULL,
                    _mxarray104_,
                    mclVe(
                      mlfRound(mclMtimes(_mxarray83_, mclVv(scale, "scale")))),
                    NULL)),
                NULL));
            /*
             * sprintf('\ndisplaying at %d%% scale.', round(100*scale))];
             * warning(message);
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, mclVv(message, "message")));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * %--------------------------------------------
     * % Subfunction Resize3
     * %--------------------------------------------
     * function Resize3(axHandle, imHandle, imSize, colorbarHandle)
     */
    return_:
    mxDestroyArray(axUnits);
    mxDestroyArray(ans);
    mxDestroyArray(axPosition);
    mxDestroyArray(figHandle);
    mxDestroyArray(figUnits);
    mxDestroyArray(rootUnits);
    mxDestroyArray(figPosition);
    mxDestroyArray(screenSize);
    mxDestroyArray(dx);
    mxDestroyArray(dy);
    mxDestroyArray(newFigWidth);
    mxDestroyArray(newFigHeight);
    mxDestroyArray(figLeftBorder);
    mxDestroyArray(figRightBorder);
    mxDestroyArray(figBottomBorder);
    mxDestroyArray(figTopBorder);
    mxDestroyArray(minFigWidth);
    mxDestroyArray(minFigHeight);
    mxDestroyArray(scaleX);
    mxDestroyArray(scaleY);
    mxDestroyArray(scale);
    mxDestroyArray(deltaX);
    mxDestroyArray(deltaY);
    mxDestroyArray(message);
    mxDestroyArray(imSize);
    mxDestroyArray(imHandle);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % Resize figure containing an image, a colorbar, 
     * % and nothing else.
     * 
     * if (isempty(imSize))
     * % How big is the image?
     * imageWidth = size(get(imHandle, 'CData'), 2);
     * imageHeight = size(get(imHandle, 'CData'), 1);
     * else
     * imageWidth = imSize(2);
     * imageHeight = imSize(1);
     * end
     * 
     * if (imageWidth * imageHeight == 0)
     * % Don't try to handle the degenerate case.
     * return;
     * end
     * 
     * axUnits = get(axHandle, 'Units');
     * set(axHandle, 'Units', 'pixels');
     * axPos = get(axHandle, 'Position');
     * 
     * figLeftBorder = 10;  % assume left figure decorations are 10 pixels
     * figRightBorder = 10;
     * figBottomBorder = 10;
     * figTopBorder = 50;
     * figTopBorder = figTopBorder + 30;  % scribe hack
     * 
     * minFigWidth = 128; % don't try to display a figure smaller than this.
     * minFigHeight = 128;
     * 
     * colorbarGap = 30;   % pixels
     * colorbarWidth = 20; % pixels
     * 
     * caxHandle = get(colorbarHandle, 'Parent');
     * figHandle = get(axHandle, 'Parent');
     * figUnits = get(figHandle, 'Units');
     * caxUnits = get(caxHandle, 'Units');
     * rootUnits = get(0, 'Units');
     * set(figHandle, 'Units', 'pixels');
     * set(0, 'Units', 'pixels');
     * set(caxHandle, 'Units', 'pixels');
     * 
     * caxPos = get(caxHandle, 'Position');
     * figPos = get(figHandle, 'Position');
     * 
     * if ((axPos(1) + axPos(3)) < caxPos(1))
     * orientation = 'vertical';
     * else
     * orientation = 'horizontal';
     * end
     * 
     * % Use MATLAB's default gutters
     * defFigPos = get(0,'FactoryFigurePosition');
     * defAxPos = get(0,'FactoryAxesPosition');
     * gutterLeft = round(defAxPos(1) * defFigPos(3));
     * gutterRight = round((1 - defAxPos(1) - defAxPos(3)) * defFigPos(3));
     * gutterBottom = round(defAxPos(2) * defFigPos(4));
     * gutterTop = round((1 - defAxPos(2) - defAxPos(4)) * defFigPos(4));
     * 
     * % What are the screen dimensions
     * screenSize = get(0, 'ScreenSize');
     * screenWidth = screenSize(3);
     * screenHeight = screenSize(4);
     * if ((screenWidth <= 1) | (screenHeight <= 1))
     * screenWidth = Inf;
     * screenHeight = Inf;
     * end
     * 
     * scale = 100;
     * done = 0;
     * while (~done)
     * if (strcmp(orientation, 'vertical'))
     * newFigWidth = imageWidth + gutterLeft + gutterRight + ...
     * colorbarGap + colorbarWidth;
     * newFigHeight = imageHeight + gutterBottom + gutterTop;
     * else
     * newFigWidth = imageWidth + gutterLeft + gutterRight;
     * newFigHeight = imageHeight + gutterBottom + gutterTop + ...
     * colorbarGap + colorbarWidth;
     * end
     * if (((newFigWidth + figLeftBorder + figRightBorder) > screenWidth) | ...
     * ((newFigHeight + figBottomBorder + figTopBorder) > ...
     * screenHeight))
     * scale = 3 * scale / 4;
     * imageWidth = round(imageWidth * scale / 100);
     * imageHeight = round(imageHeight * scale / 100);
     * else
     * done = 1;
     * end
     * end
     * 
     * newFigWidth = max(newFigWidth, minFigWidth);
     * newFigHeight = max(newFigHeight, minFigHeight);
     * figPos(3) = newFigWidth;
     * figPos(4) = newFigHeight;
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPos(1) + figPos(3));
     * if (deltaX < 0)
     * figPos(1) = figPos(1) + deltaX;
     * end
     * deltaY = (screenSize(4) - figTopBorder) - (figPos(2) + figPos(4));
     * if (deltaY < 0)
     * figPos(2) = figPos(2) + deltaY;
     * end
     * 
     * axPos = [gutterLeft gutterBottom imageWidth imageHeight];
     * 
     * if (strcmp(orientation, 'vertical'))
     * left = gutterLeft + imageWidth + colorbarGap;
     * bottom = gutterBottom;
     * width = colorbarWidth;
     * height = imageHeight;
     * else
     * left = gutterLeft;
     * bottom = gutterBottom;
     * width = imageWidth;
     * height = colorbarWidth;
     * axPos(2) = axPos(2) + colorbarGap + colorbarWidth;
     * end
     * caxPos = [left bottom width height];
     * 
     * set(figHandle, 'Position', figPos);
     * set(axHandle, 'Position', axPos);
     * set(caxHandle, 'Position', caxPos);
     * 
     * % Restore the units
     * drawnow;  % necessary to work around HG bug      -SLE
     * set(figHandle, 'Units', figUnits);
     * set(axHandle, 'Units', axUnits);
     * set(caxHandle, 'Units', caxUnits);
     * set(0, 'Units', rootUnits);
     * 
     * % Set the nextplot property of the figure so that the
     * % axes object gets deleted and replaced for the next plot.
     * % That way, the new plot gets drawn in the default position.
     * set(figHandle, 'NextPlot', 'replacechildren');
     * 
     * % Warn if the display is not truesize, unless the truesize warning
     * % has been disabled according to a toolbox preference setting.
     * if ((scale < 100) & strcmp(iptgetpref('TruesizeWarning'), 'on'))
     * message = ['Image is too big to fit on screen; ', ...
     * sprintf('displaying at %d%% scale.', floor(scale))];
     * warning(message);
     * end
     */
}

/*
 * The function "Mtruesize_Resize3" is the implementation version of the
 * "truesize/Resize3" M-function from file
 * "C:\matlabR12\toolbox\images\images\truesize.m" (lines 439-585). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function Resize3(axHandle, imHandle, imSize, colorbarHandle)
 */
static void Mtruesize_Resize3(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize,
                              mxArray * colorbarHandle) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_truesize);
    mxArray * message = mclGetUninitializedArray();
    mxArray * height = mclGetUninitializedArray();
    mxArray * width = mclGetUninitializedArray();
    mxArray * bottom = mclGetUninitializedArray();
    mxArray * left = mclGetUninitializedArray();
    mxArray * deltaY = mclGetUninitializedArray();
    mxArray * deltaX = mclGetUninitializedArray();
    mxArray * newFigHeight = mclGetUninitializedArray();
    mxArray * newFigWidth = mclGetUninitializedArray();
    mxArray * done = mclGetUninitializedArray();
    mxArray * scale = mclGetUninitializedArray();
    mxArray * screenHeight = mclGetUninitializedArray();
    mxArray * screenWidth = mclGetUninitializedArray();
    mxArray * screenSize = mclGetUninitializedArray();
    mxArray * gutterTop = mclGetUninitializedArray();
    mxArray * gutterBottom = mclGetUninitializedArray();
    mxArray * gutterRight = mclGetUninitializedArray();
    mxArray * gutterLeft = mclGetUninitializedArray();
    mxArray * defAxPos = mclGetUninitializedArray();
    mxArray * defFigPos = mclGetUninitializedArray();
    mxArray * orientation = mclGetUninitializedArray();
    mxArray * figPos = mclGetUninitializedArray();
    mxArray * caxPos = mclGetUninitializedArray();
    mxArray * rootUnits = mclGetUninitializedArray();
    mxArray * caxUnits = mclGetUninitializedArray();
    mxArray * figUnits = mclGetUninitializedArray();
    mxArray * figHandle = mclGetUninitializedArray();
    mxArray * caxHandle = mclGetUninitializedArray();
    mxArray * colorbarWidth = mclGetUninitializedArray();
    mxArray * colorbarGap = mclGetUninitializedArray();
    mxArray * minFigHeight = mclGetUninitializedArray();
    mxArray * minFigWidth = mclGetUninitializedArray();
    mxArray * figTopBorder = mclGetUninitializedArray();
    mxArray * figBottomBorder = mclGetUninitializedArray();
    mxArray * figRightBorder = mclGetUninitializedArray();
    mxArray * figLeftBorder = mclGetUninitializedArray();
    mxArray * axPos = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * axUnits = mclGetUninitializedArray();
    mxArray * imageHeight = mclGetUninitializedArray();
    mxArray * imageWidth = mclGetUninitializedArray();
    mclCopyArray(&axHandle);
    mclCopyArray(&imHandle);
    mclCopyArray(&imSize);
    mclCopyArray(&colorbarHandle);
    /*
     * % Resize figure containing an image, a colorbar, 
     * % and nothing else.
     * 
     * if (isempty(imSize))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVa(imSize, "imSize"))))) {
        /*
         * % How big is the image?
         * imageWidth = size(get(imHandle, 'CData'), 2);
         */
        mlfAssign(
          &imageWidth,
          mlfSize(
            mclValueVarargout(),
            mclVe(mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray67_, NULL)),
            _mxarray17_));
        /*
         * imageHeight = size(get(imHandle, 'CData'), 1);
         */
        mlfAssign(
          &imageHeight,
          mlfSize(
            mclValueVarargout(),
            mclVe(mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray67_, NULL)),
            _mxarray16_));
    /*
     * else
     */
    } else {
        /*
         * imageWidth = imSize(2);
         */
        mlfAssign(&imageWidth, mclIntArrayRef1(mclVsa(imSize, "imSize"), 2));
        /*
         * imageHeight = imSize(1);
         */
        mlfAssign(&imageHeight, mclIntArrayRef1(mclVsa(imSize, "imSize"), 1));
    /*
     * end
     */
    }
    /*
     * 
     * if (imageWidth * imageHeight == 0)
     */
    if (mclEqBool(
          mclMtimes(
            mclVv(imageWidth, "imageWidth"), mclVv(imageHeight, "imageHeight")),
          _mxarray69_)) {
        /*
         * % Don't try to handle the degenerate case.
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * axUnits = get(axHandle, 'Units');
     */
    mlfAssign(
      &axUnits, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray70_, NULL));
    /*
     * set(axHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray70_, _mxarray72_, NULL));
    /*
     * axPos = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPos, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray74_, NULL));
    /*
     * 
     * figLeftBorder = 10;  % assume left figure decorations are 10 pixels
     */
    mlfAssign(&figLeftBorder, _mxarray76_);
    /*
     * figRightBorder = 10;
     */
    mlfAssign(&figRightBorder, _mxarray76_);
    /*
     * figBottomBorder = 10;
     */
    mlfAssign(&figBottomBorder, _mxarray76_);
    /*
     * figTopBorder = 50;
     */
    mlfAssign(&figTopBorder, _mxarray77_);
    /*
     * figTopBorder = figTopBorder + 30;  % scribe hack
     */
    mlfAssign(
      &figTopBorder, mclPlus(mclVv(figTopBorder, "figTopBorder"), _mxarray78_));
    /*
     * 
     * minFigWidth = 128; % don't try to display a figure smaller than this.
     */
    mlfAssign(&minFigWidth, _mxarray79_);
    /*
     * minFigHeight = 128;
     */
    mlfAssign(&minFigHeight, _mxarray79_);
    /*
     * 
     * colorbarGap = 30;   % pixels
     */
    mlfAssign(&colorbarGap, _mxarray78_);
    /*
     * colorbarWidth = 20; % pixels
     */
    mlfAssign(&colorbarWidth, _mxarray106_);
    /*
     * 
     * caxHandle = get(colorbarHandle, 'Parent');
     */
    mlfAssign(
      &caxHandle,
      mlfNGet(1, mclVa(colorbarHandle, "colorbarHandle"), _mxarray35_, NULL));
    /*
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray35_, NULL));
    /*
     * figUnits = get(figHandle, 'Units');
     */
    mlfAssign(
      &figUnits, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray70_, NULL));
    /*
     * caxUnits = get(caxHandle, 'Units');
     */
    mlfAssign(
      &caxUnits, mlfNGet(1, mclVv(caxHandle, "caxHandle"), _mxarray70_, NULL));
    /*
     * rootUnits = get(0, 'Units');
     */
    mlfAssign(&rootUnits, mlfNGet(1, _mxarray69_, _mxarray70_, NULL));
    /*
     * set(figHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray70_, _mxarray72_, NULL));
    /*
     * set(0, 'Units', 'pixels');
     */
    mclAssignAns(&ans, mlfNSet(0, _mxarray69_, _mxarray70_, _mxarray72_, NULL));
    /*
     * set(caxHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(caxHandle, "caxHandle"), _mxarray70_, _mxarray72_, NULL));
    /*
     * 
     * caxPos = get(caxHandle, 'Position');
     */
    mlfAssign(
      &caxPos, mlfNGet(1, mclVv(caxHandle, "caxHandle"), _mxarray74_, NULL));
    /*
     * figPos = get(figHandle, 'Position');
     */
    mlfAssign(
      &figPos, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray74_, NULL));
    /*
     * 
     * if ((axPos(1) + axPos(3)) < caxPos(1))
     */
    if (mclLtBool(
          mclPlus(
            mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 1)),
            mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 3))),
          mclVe(mclIntArrayRef1(mclVsv(caxPos, "caxPos"), 1)))) {
        /*
         * orientation = 'vertical';
         */
        mlfAssign(&orientation, _mxarray107_);
    /*
     * else
     */
    } else {
        /*
         * orientation = 'horizontal';
         */
        mlfAssign(&orientation, _mxarray109_);
    /*
     * end
     */
    }
    /*
     * 
     * % Use MATLAB's default gutters
     * defFigPos = get(0,'FactoryFigurePosition');
     */
    mlfAssign(&defFigPos, mlfNGet(1, _mxarray69_, _mxarray111_, NULL));
    /*
     * defAxPos = get(0,'FactoryAxesPosition');
     */
    mlfAssign(&defAxPos, mlfNGet(1, _mxarray69_, _mxarray113_, NULL));
    /*
     * gutterLeft = round(defAxPos(1) * defFigPos(3));
     */
    mlfAssign(
      &gutterLeft,
      mlfRound(
        mclMtimes(
          mclVe(mclIntArrayRef1(mclVsv(defAxPos, "defAxPos"), 1)),
          mclVe(mclIntArrayRef1(mclVsv(defFigPos, "defFigPos"), 3)))));
    /*
     * gutterRight = round((1 - defAxPos(1) - defAxPos(3)) * defFigPos(3));
     */
    mlfAssign(
      &gutterRight,
      mlfRound(
        mclMtimes(
          mclMinus(
            mclMinus(
              _mxarray16_,
              mclVe(mclIntArrayRef1(mclVsv(defAxPos, "defAxPos"), 1))),
            mclVe(mclIntArrayRef1(mclVsv(defAxPos, "defAxPos"), 3))),
          mclVe(mclIntArrayRef1(mclVsv(defFigPos, "defFigPos"), 3)))));
    /*
     * gutterBottom = round(defAxPos(2) * defFigPos(4));
     */
    mlfAssign(
      &gutterBottom,
      mlfRound(
        mclMtimes(
          mclVe(mclIntArrayRef1(mclVsv(defAxPos, "defAxPos"), 2)),
          mclVe(mclIntArrayRef1(mclVsv(defFigPos, "defFigPos"), 4)))));
    /*
     * gutterTop = round((1 - defAxPos(2) - defAxPos(4)) * defFigPos(4));
     */
    mlfAssign(
      &gutterTop,
      mlfRound(
        mclMtimes(
          mclMinus(
            mclMinus(
              _mxarray16_,
              mclVe(mclIntArrayRef1(mclVsv(defAxPos, "defAxPos"), 2))),
            mclVe(mclIntArrayRef1(mclVsv(defAxPos, "defAxPos"), 4))),
          mclVe(mclIntArrayRef1(mclVsv(defFigPos, "defFigPos"), 4)))));
    /*
     * 
     * % What are the screen dimensions
     * screenSize = get(0, 'ScreenSize');
     */
    mlfAssign(&screenSize, mlfNGet(1, _mxarray69_, _mxarray80_, NULL));
    /*
     * screenWidth = screenSize(3);
     */
    mlfAssign(
      &screenWidth, mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 3));
    /*
     * screenHeight = screenSize(4);
     */
    mlfAssign(
      &screenHeight, mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 4));
    /*
     * if ((screenWidth <= 1) | (screenHeight <= 1))
     */
    {
        mxArray * a_ = mclInitialize(
                         mclLe(mclVv(screenWidth, "screenWidth"), _mxarray16_));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclLe(mclVv(screenHeight, "screenHeight"), _mxarray16_)))) {
            mxDestroyArray(a_);
            /*
             * screenWidth = Inf;
             */
            mlfAssign(&screenWidth, _mxarray82_);
            /*
             * screenHeight = Inf;
             */
            mlfAssign(&screenHeight, _mxarray82_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * scale = 100;
     */
    mlfAssign(&scale, _mxarray83_);
    /*
     * done = 0;
     */
    mlfAssign(&done, _mxarray69_);
    /*
     * while (~done)
     */
    while (mclNotBool(mclVv(done, "done"))) {
        /*
         * if (strcmp(orientation, 'vertical'))
         */
        if (mlfTobool(
              mclVe(
                mlfStrcmp(mclVv(orientation, "orientation"), _mxarray107_)))) {
            /*
             * newFigWidth = imageWidth + gutterLeft + gutterRight + ...
             */
            mlfAssign(
              &newFigWidth,
              mclPlus(
                mclPlus(
                  mclPlus(
                    mclPlus(
                      mclVv(imageWidth, "imageWidth"),
                      mclVv(gutterLeft, "gutterLeft")),
                    mclVv(gutterRight, "gutterRight")),
                  mclVv(colorbarGap, "colorbarGap")),
                mclVv(colorbarWidth, "colorbarWidth")));
            /*
             * colorbarGap + colorbarWidth;
             * newFigHeight = imageHeight + gutterBottom + gutterTop;
             */
            mlfAssign(
              &newFigHeight,
              mclPlus(
                mclPlus(
                  mclVv(imageHeight, "imageHeight"),
                  mclVv(gutterBottom, "gutterBottom")),
                mclVv(gutterTop, "gutterTop")));
        /*
         * else
         */
        } else {
            /*
             * newFigWidth = imageWidth + gutterLeft + gutterRight;
             */
            mlfAssign(
              &newFigWidth,
              mclPlus(
                mclPlus(
                  mclVv(imageWidth, "imageWidth"),
                  mclVv(gutterLeft, "gutterLeft")),
                mclVv(gutterRight, "gutterRight")));
            /*
             * newFigHeight = imageHeight + gutterBottom + gutterTop + ...
             */
            mlfAssign(
              &newFigHeight,
              mclPlus(
                mclPlus(
                  mclPlus(
                    mclPlus(
                      mclVv(imageHeight, "imageHeight"),
                      mclVv(gutterBottom, "gutterBottom")),
                    mclVv(gutterTop, "gutterTop")),
                  mclVv(colorbarGap, "colorbarGap")),
                mclVv(colorbarWidth, "colorbarWidth")));
        /*
         * colorbarGap + colorbarWidth;
         * end
         */
        }
        /*
         * if (((newFigWidth + figLeftBorder + figRightBorder) > screenWidth) | ...
         */
        {
            mxArray * a_ = mclInitialize(
                             mclGt(
                               mclPlus(
                                 mclPlus(
                                   mclVv(newFigWidth, "newFigWidth"),
                                   mclVv(figLeftBorder, "figLeftBorder")),
                                 mclVv(figRightBorder, "figRightBorder")),
                               mclVv(screenWidth, "screenWidth")));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclGt(
                         mclPlus(
                           mclPlus(
                             mclVv(newFigHeight, "newFigHeight"),
                             mclVv(figBottomBorder, "figBottomBorder")),
                           mclVv(figTopBorder, "figTopBorder")),
                         mclVv(screenHeight, "screenHeight"))))) {
                mxDestroyArray(a_);
                /*
                 * ((newFigHeight + figBottomBorder + figTopBorder) > ...
                 * screenHeight))
                 * scale = 3 * scale / 4;
                 */
                mlfAssign(
                  &scale,
                  mclMrdivide(
                    mclMtimes(_mxarray18_, mclVv(scale, "scale")),
                    _mxarray86_));
                /*
                 * imageWidth = round(imageWidth * scale / 100);
                 */
                mlfAssign(
                  &imageWidth,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageWidth, "imageWidth"), mclVv(scale, "scale")),
                      _mxarray83_)));
                /*
                 * imageHeight = round(imageHeight * scale / 100);
                 */
                mlfAssign(
                  &imageHeight,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageHeight, "imageHeight"),
                        mclVv(scale, "scale")),
                      _mxarray83_)));
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * done = 1;
                 */
                mlfAssign(&done, _mxarray16_);
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * newFigWidth = max(newFigWidth, minFigWidth);
     */
    mlfAssign(
      &newFigWidth,
      mlfMax(
        NULL,
        mclVv(newFigWidth, "newFigWidth"),
        mclVv(minFigWidth, "minFigWidth"),
        NULL));
    /*
     * newFigHeight = max(newFigHeight, minFigHeight);
     */
    mlfAssign(
      &newFigHeight,
      mlfMax(
        NULL,
        mclVv(newFigHeight, "newFigHeight"),
        mclVv(minFigHeight, "minFigHeight"),
        NULL));
    /*
     * figPos(3) = newFigWidth;
     */
    mclIntArrayAssign1(&figPos, mclVsv(newFigWidth, "newFigWidth"), 3);
    /*
     * figPos(4) = newFigHeight;
     */
    mclIntArrayAssign1(&figPos, mclVsv(newFigHeight, "newFigHeight"), 4);
    /*
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPos(1) + figPos(3));
     */
    mlfAssign(
      &deltaX,
      mclMinus(
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 3)),
          mclVv(figRightBorder, "figRightBorder")),
        mclPlus(
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 1)),
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 3)))));
    /*
     * if (deltaX < 0)
     */
    if (mclLtBool(mclVv(deltaX, "deltaX"), _mxarray69_)) {
        /*
         * figPos(1) = figPos(1) + deltaX;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 1)),
            mclVv(deltaX, "deltaX")),
          1);
    /*
     * end
     */
    }
    /*
     * deltaY = (screenSize(4) - figTopBorder) - (figPos(2) + figPos(4));
     */
    mlfAssign(
      &deltaY,
      mclMinus(
        mclMinus(
          mclVe(mclIntArrayRef1(mclVsv(screenSize, "screenSize"), 4)),
          mclVv(figTopBorder, "figTopBorder")),
        mclPlus(
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 2)),
          mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 4)))));
    /*
     * if (deltaY < 0)
     */
    if (mclLtBool(mclVv(deltaY, "deltaY"), _mxarray69_)) {
        /*
         * figPos(2) = figPos(2) + deltaY;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclVe(mclIntArrayRef1(mclVsv(figPos, "figPos"), 2)),
            mclVv(deltaY, "deltaY")),
          2);
    /*
     * end
     */
    }
    /*
     * 
     * axPos = [gutterLeft gutterBottom imageWidth imageHeight];
     */
    mlfAssign(
      &axPos,
      mlfHorzcat(
        mclVv(gutterLeft, "gutterLeft"),
        mclVv(gutterBottom, "gutterBottom"),
        mclVv(imageWidth, "imageWidth"),
        mclVv(imageHeight, "imageHeight"),
        NULL));
    /*
     * 
     * if (strcmp(orientation, 'vertical'))
     */
    if (mlfTobool(
          mclVe(mlfStrcmp(mclVv(orientation, "orientation"), _mxarray107_)))) {
        /*
         * left = gutterLeft + imageWidth + colorbarGap;
         */
        mlfAssign(
          &left,
          mclPlus(
            mclPlus(
              mclVv(gutterLeft, "gutterLeft"), mclVv(imageWidth, "imageWidth")),
            mclVv(colorbarGap, "colorbarGap")));
        /*
         * bottom = gutterBottom;
         */
        mlfAssign(&bottom, mclVsv(gutterBottom, "gutterBottom"));
        /*
         * width = colorbarWidth;
         */
        mlfAssign(&width, mclVsv(colorbarWidth, "colorbarWidth"));
        /*
         * height = imageHeight;
         */
        mlfAssign(&height, mclVsv(imageHeight, "imageHeight"));
    /*
     * else
     */
    } else {
        /*
         * left = gutterLeft;
         */
        mlfAssign(&left, mclVsv(gutterLeft, "gutterLeft"));
        /*
         * bottom = gutterBottom;
         */
        mlfAssign(&bottom, mclVsv(gutterBottom, "gutterBottom"));
        /*
         * width = imageWidth;
         */
        mlfAssign(&width, mclVsv(imageWidth, "imageWidth"));
        /*
         * height = colorbarWidth;
         */
        mlfAssign(&height, mclVsv(colorbarWidth, "colorbarWidth"));
        /*
         * axPos(2) = axPos(2) + colorbarGap + colorbarWidth;
         */
        mclIntArrayAssign1(
          &axPos,
          mclPlus(
            mclPlus(
              mclVe(mclIntArrayRef1(mclVsv(axPos, "axPos"), 2)),
              mclVv(colorbarGap, "colorbarGap")),
            mclVv(colorbarWidth, "colorbarWidth")),
          2);
    /*
     * end
     */
    }
    /*
     * caxPos = [left bottom width height];
     */
    mlfAssign(
      &caxPos,
      mlfHorzcat(
        mclVv(left, "left"),
        mclVv(bottom, "bottom"),
        mclVv(width, "width"),
        mclVv(height, "height"),
        NULL));
    /*
     * 
     * set(figHandle, 'Position', figPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray74_,
        mclVv(figPos, "figPos"),
        NULL));
    /*
     * set(axHandle, 'Position', axPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray74_,
        mclVv(axPos, "axPos"),
        NULL));
    /*
     * set(caxHandle, 'Position', caxPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(caxHandle, "caxHandle"),
        _mxarray74_,
        mclVv(caxPos, "caxPos"),
        NULL));
    /*
     * 
     * % Restore the units
     * drawnow;  % necessary to work around HG bug      -SLE
     */
    mlfDrawnow(NULL);
    /*
     * set(figHandle, 'Units', figUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray70_,
        mclVv(figUnits, "figUnits"),
        NULL));
    /*
     * set(axHandle, 'Units', axUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray70_,
        mclVv(axUnits, "axUnits"),
        NULL));
    /*
     * set(caxHandle, 'Units', caxUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(caxHandle, "caxHandle"),
        _mxarray70_,
        mclVv(caxUnits, "caxUnits"),
        NULL));
    /*
     * set(0, 'Units', rootUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, _mxarray69_, _mxarray70_, mclVv(rootUnits, "rootUnits"), NULL));
    /*
     * 
     * % Set the nextplot property of the figure so that the
     * % axes object gets deleted and replaced for the next plot.
     * % That way, the new plot gets drawn in the default position.
     * set(figHandle, 'NextPlot', 'replacechildren');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray87_, _mxarray89_, NULL));
    /*
     * 
     * % Warn if the display is not truesize, unless the truesize warning
     * % has been disabled according to a toolbox preference setting.
     * if ((scale < 100) & strcmp(iptgetpref('TruesizeWarning'), 'on'))
     */
    {
        mxArray * a_ = mclInitialize(mclLt(mclVv(scale, "scale"), _mxarray83_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclVe(
                     mlfStrcmp(
                       mclVe(mlfIptgetpref(_mxarray91_)), _mxarray61_))))) {
            mxDestroyArray(a_);
            /*
             * message = ['Image is too big to fit on screen; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray93_,
                mclVe(
                  mlfSprintf(
                    NULL,
                    _mxarray95_,
                    mclVe(mlfFloor(mclVv(scale, "scale"))),
                    NULL)),
                NULL));
            /*
             * sprintf('displaying at %d%% scale.', floor(scale))];
             * warning(message);
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, mclVv(message, "message")));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    return_:
    mxDestroyArray(imageWidth);
    mxDestroyArray(imageHeight);
    mxDestroyArray(axUnits);
    mxDestroyArray(ans);
    mxDestroyArray(axPos);
    mxDestroyArray(figLeftBorder);
    mxDestroyArray(figRightBorder);
    mxDestroyArray(figBottomBorder);
    mxDestroyArray(figTopBorder);
    mxDestroyArray(minFigWidth);
    mxDestroyArray(minFigHeight);
    mxDestroyArray(colorbarGap);
    mxDestroyArray(colorbarWidth);
    mxDestroyArray(caxHandle);
    mxDestroyArray(figHandle);
    mxDestroyArray(figUnits);
    mxDestroyArray(caxUnits);
    mxDestroyArray(rootUnits);
    mxDestroyArray(caxPos);
    mxDestroyArray(figPos);
    mxDestroyArray(orientation);
    mxDestroyArray(defFigPos);
    mxDestroyArray(defAxPos);
    mxDestroyArray(gutterLeft);
    mxDestroyArray(gutterRight);
    mxDestroyArray(gutterBottom);
    mxDestroyArray(gutterTop);
    mxDestroyArray(screenSize);
    mxDestroyArray(screenWidth);
    mxDestroyArray(screenHeight);
    mxDestroyArray(scale);
    mxDestroyArray(done);
    mxDestroyArray(newFigWidth);
    mxDestroyArray(newFigHeight);
    mxDestroyArray(deltaX);
    mxDestroyArray(deltaY);
    mxDestroyArray(left);
    mxDestroyArray(bottom);
    mxDestroyArray(width);
    mxDestroyArray(height);
    mxDestroyArray(message);
    mxDestroyArray(colorbarHandle);
    mxDestroyArray(imSize);
    mxDestroyArray(imHandle);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
