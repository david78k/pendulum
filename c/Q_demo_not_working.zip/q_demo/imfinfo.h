/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __imfinfo_h
#define __imfinfo_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_imfinfo(void);
extern void TerminateModule_imfinfo(void);
extern _mexLocalFunctionTable _local_function_table_imfinfo;

extern mxArray * mlfNImfinfo(int nargout,
                             mxArray * * msg,
                             mxArray * filename,
                             mxArray * format);
extern mxArray * mlfImfinfo(mxArray * * msg,
                            mxArray * filename,
                            mxArray * format);
extern void mlfVImfinfo(mxArray * filename, mxArray * format);
extern void mlxImfinfo(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
