/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "surf.h"
#include "grid.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"

static mxChar _array1_[126] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 's', 'u', 'r', 'f', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', ' ', 'C',
                                'o', 'l', 'u', 'm', 'n', ':', ' ', '1', ' ',
                                'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c', 't',
                                'i', 'o', 'n', ' ', '"', 's', 'u', 'r', 'f',
                                '"', ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l',
                                'l', 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ',
                                'm', 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n',
                                ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l',
                                'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b',
                                'e', 'r', ' ', 'o', 'f', ' ', 'o', 'u', 't',
                                'p', 'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[27] = { 'N', 'o', 't', ' ', 'e', 'n', 'o', 'u', 'g',
                               'h', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'a',
                               'r', 'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[56] = { 'I', 'n', 'p', 'u', 't', ' ', 'a', 'r', 'g', 'u',
                               'm', 'e', 'n', 't', ' ', 'm', 'u', 's', 't', ' ',
                               'b', 'e', ' ', 'a', ' ', 'm', 'a', 't', 'r', 'i',
                               'x', ' ', 'n', 'o', 't', ' ', 'a', ' ', 'v', 'e',
                               'c', 't', 'o', 'r', ' ', 'o', 'r', ' ', 'a', ' ',
                               's', 'c', 'a', 'l', 'a', 'r' };
static mxArray * _mxarray5_;

static mxChar _array8_[8] = { 'N', 'e', 'x', 't', 'P', 'l', 'o', 't' };
static mxArray * _mxarray7_;
static mxArray * _mxarray9_;

static mxChar _array11_[2] = { 'o', 'n' };
static mxArray * _mxarray10_;

void InitializeModule_surf(void) {
    _mxarray0_ = mclInitializeString(126, _array1_);
    _mxarray2_ = mclInitializeString(27, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeString(56, _array6_);
    _mxarray7_ = mclInitializeString(8, _array8_);
    _mxarray9_ = mclInitializeDouble(3.0);
    _mxarray10_ = mclInitializeString(2, _array11_);
}

void TerminateModule_surf(void) {
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Msurf(int nargout_, mxArray * varargin);

_mexLocalFunctionTable _local_function_table_surf
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNSurf" contains the nargout interface for the "surf"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph3d\surf.m" (lines
 * 1-69). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNSurf(int nargout, ...) {
    mxArray * varargin = NULL;
    mxArray * h = mclGetUninitializedArray();
    mlfVarargin(&varargin, nargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    h = Msurf(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(h);
}

/*
 * The function "mlfSurf" contains the normal interface for the "surf"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph3d\surf.m" (lines
 * 1-69). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfSurf(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * h = mclGetUninitializedArray();
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    h = Msurf(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(h);
}

/*
 * The function "mlfVSurf" contains the void interface for the "surf"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph3d\surf.m" (lines
 * 1-69). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVSurf(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * h = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    h = Msurf(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxSurf" contains the feval interface for the "surf"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph3d\surf.m" (lines
 * 1-69). The feval function calls the implementation version of surf through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxSurf(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Msurf(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Msurf" is the implementation version of the "surf" M-function
 * from file "C:\matlabR12\toolbox\matlab\graph3d\surf.m" (lines 1-69). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function h = surf(varargin)
 */
static mxArray * Msurf(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_surf);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * h = mclGetUninitializedArray();
    mxArray * next = mclGetUninitializedArray();
    mxArray * hh = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * cax = mclGetUninitializedArray();
    mclCopyArray(&varargin);
    /*
     * %SURF   3-D colored surface.
     * %   SURF(X,Y,Z,C) plots the colored parametric surface defined by
     * %   four matrix arguments.  The view point is specified by VIEW.
     * %   The axis labels are determined by the range of X, Y and Z,
     * %   or by the current setting of AXIS.  The color scaling is determined
     * %   by the range of C, or by the current setting of CAXIS.  The scaled
     * %   color values are used as indices into the current COLORMAP.
     * %   The shading model is set by SHADING.
     * %
     * %   SURF(X,Y,Z) uses C = Z, so color is proportional to surface height.
     * %
     * %   SURF(x,y,Z) and SURF(x,y,Z,C), with two vector arguments replacing
     * %   the first two matrix arguments, must have length(x) = n and
     * %   length(y) = m where [m,n] = size(Z).  In this case, the vertices
     * %   of the surface patches are the triples (x(j), y(i), Z(i,j)).
     * %   Note that x corresponds to the columns of Z and y corresponds to
     * %   the rows.
     * %
     * %   SURF(Z) and SURF(Z,C) use x = 1:n and y = 1:m.  In this case,
     * %   the height, Z, is a single-valued function, defined over a
     * %   geometrically rectangular grid.
     * %
     * %   SURF(...,'PropertyName',PropertyValue,...) sets the value of the 
     * %   specified surface property.  Multiple property values can be set
     * %   with a single statement.
     * %
     * %   SURF returns a handle to a SURFACE object.
     * %
     * %   AXIS, CAXIS, COLORMAP, HOLD, SHADING and VIEW set figure, axes, and 
     * %   surface properties which affect the display of the surface.
     * %
     * %   See also SURFC, SURFL, MESH, SHADING.
     * 
     * %-------------------------------
     * %   Additional details:
     * %
     * %   If the NextPlot axis property is REPLACE (HOLD is off), SURF resets 
     * %   all axis properties, except Position, to their default values
     * %   and deletes all axis children (line, patch, surf, image, and 
     * %   text objects).
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 5.11 $  $Date: 2000/06/01 02:53:39 $
     * 
     * %   J.N. Little 1-5-92
     * 
     * cax = newplot;
     */
    mlfAssign(&cax, mlfNNewplot(1, NULL));
    /*
     * 
     * if nargin == 0
     */
    if (nargin_ == 0) {
        /*
         * error('Not enough input arguments.')
         */
        mlfError(_mxarray2_);
    /*
     * elseif nargin == 1
     */
    } else if (nargin_ == 1) {
        /*
         * if min( size( varargin{1} ) ) == 1
         */
        if (mclEqBool(
              mclVe(
                mlfMin(
                  NULL,
                  mclVe(
                    mclFeval(
                      mclValueVarargout(),
                      mlxSize,
                      mclVe(
                        mlfIndexRef(
                          mclVsa(varargin, "varargin"), "{?}", _mxarray4_)),
                      NULL)),
                  NULL,
                  NULL)),
              _mxarray4_)) {
            /*
             * error('Input argument must be a matrix not a vector or a scalar')
             */
            mlfError(_mxarray5_);
        /*
         * else
         */
        } else {
            /*
             * hh = surface(varargin{1});
             */
            mlfAssign(
              &hh,
              mlfNSurface(
                1,
                mclVe(
                  mlfIndexRef(mclVsa(varargin, "varargin"), "{?}", _mxarray4_)),
                NULL));
        /*
         * end
         */
        }
    /*
     * else
     */
    } else {
        /*
         * hh = surface(varargin{:});
         */
        mlfAssign(
          &hh,
          mlfNSurface(
            1,
            mclVe(
              mlfIndexRef(
                mclVsa(varargin, "varargin"), "{?}", mlfCreateColonIndex())),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * next = lower(get(cax,'NextPlot'));
     */
    mlfAssign(
      &next, mlfLower(mclVe(mlfNGet(1, mclVv(cax, "cax"), _mxarray7_, NULL))));
    /*
     * if ~ishold
     */
    if (mclNotBool(mclVe(mlfIshold(NULL)))) {
        /*
         * view(3); grid on
         */
        mclAssignAns(&ans, mlfNView(0, NULL, _mxarray9_, NULL, NULL));
        mlfGrid(_mxarray10_, NULL);
    /*
     * end
     */
    }
    /*
     * if nargout == 1
     */
    if (nargout_ == 1) {
        /*
         * h = hh;
         */
        mlfAssign(&h, mclVsv(hh, "hh"));
    /*
     * end
     */
    }
    mclValidateOutput(h, 1, nargout_, "h", "surf");
    mxDestroyArray(cax);
    mxDestroyArray(ans);
    mxDestroyArray(hh);
    mxDestroyArray(next);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return h;
}
