/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readtif.h"
#include "iofun_private_rtifc_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 't', 'i', 'f', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 't', 'i', 'f', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 't', 'i', 'f', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 't', 'i', 'f', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't',
                                's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;

void InitializeModule_iofun_private_readtif(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeDouble(2.0);
    _mxarray6_ = mclInitializeDouble(65535.0);
}

void TerminateModule_iofun_private_readtif(void) {
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_readtif(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * index);

_mexLocalFunctionTable _local_function_table_iofun_private_readtif
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_readtif" contains the normal interface for
 * the "iofun/private/readtif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readtif.m" (lines 1-27). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readtif(mxArray * * map,
                                   mxArray * filename,
                                   mxArray * index) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 2, map, filename, index);
    if (map != NULL) {
        ++nargout;
    }
    X = Miofun_private_readtif(&map__, nargout, filename, index);
    mlfRestorePreviousContext(1, 2, map, filename, index);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlxIofun_private_readtif" contains the feval interface for the
 * "iofun/private/readtif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readtif.m" (lines 1-27). The
 * feval function calls the implementation version of iofun/private/readtif
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readtif(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Miofun_private_readtif(&mplhs[1], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_readtif" is the implementation version of the
 * "iofun/private/readtif" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readtif.m" (lines 1-27). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [X,map] = readtif(filename, index)
 */
static mxArray * Miofun_private_readtif(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * index) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readtif);
    int nargin_ = mclNargin(2, filename, index, NULL);
    mxArray * X = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&index);
    /*
     * %READTIF Read an image from a TIFF file.
     * %   [X,MAP] = READTIF(FILENAME) reads the first image from the
     * %   TIFF file specified by the string variable FILENAME.  X will
     * %   be a 2-D uint8 array if the specified data set contains an
     * %   8-bit image.  It will be an M-by-N-by-3 uint8 array if the
     * %   specified data set contains a 24-bit image.  MAP contains the
     * %   colormap if present; otherwise it is empty. 
     * %
     * %   [X,MAP] = READTIF(FILENAME, 'Index', N) reads the Nth image
     * %   from the file.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.8 $  $Date: 2000/06/01 04:17:08 $
     * 
     * error(nargchk(1, 2, nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray4_, _mxarray5_, mlfScalar(nargin_))));
    /*
     * 
     * if (nargin < 2)
     */
    if (nargin_ < 2) {
        /*
         * index = 1;
         */
        mlfAssign(&index, _mxarray4_);
    /*
     * end
     */
    }
    /*
     * 
     * [X,map] = rtifc(filename, index);
     */
    mlfNIofun_private_rtifc(
      0,
      mlfVarargout(&X, map, NULL),
      mclVa(filename, "filename"),
      mclVa(index, "index"),
      NULL);
    /*
     * map = double(map)/65535;
     */
    mlfAssign(
      map, mclMrdivide(mclVe(mlfDouble(mclVv(*map, "map"))), _mxarray6_));
    mclValidateOutput(X, 1, nargout_, "X", "iofun/private/readtif");
    mclValidateOutput(*map, 2, nargout_, "map", "iofun/private/readtif");
    mxDestroyArray(ans);
    mxDestroyArray(index);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
}
