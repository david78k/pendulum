/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readbmpdata.h"
#include "iofun_private_bitslice_mex_interface.h"
#include "iofun_private_bmpdrle_mex_interface.h"
#include "iofun_private_freadu8_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[168] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a',
                                't', 'a', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'i',
                                'o', 'f', 'u', 'n', '/', 'p', 'r', 'i', 'v',
                                'a', 't', 'e', '/', 'r', 'e', 'a', 'd', 'b',
                                'm', 'p', 'd', 'a', 't', 'a', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[167] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a',
                                't', 'a', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'i',
                                'o', 'f', 'u', 'n', '/', 'p', 'r', 'i', 'v',
                                'a', 't', 'e', '/', 'r', 'e', 'a', 'd', 'b',
                                'm', 'p', 'd', 'a', 't', 'a', '"', ' ', 'w',
                                'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                'o', 'f', ' ', 'i', 'n', 'p', 'u', 't', 's',
                                ' ', '(', '1', ')', '.' };
static mxArray * _mxarray2_;

static mxChar _array5_[167] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                '8', ' ', 'L', 'i', 'n', 'e', ':', ' ', '5',
                                '8', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'r',
                                'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a', 't',
                                'a', '/', 'b', 'm', 'p', 'R', 'e', 'a', 'd',
                                'D', 'a', 't', 'a', '8', '"', ' ', 'w', 'a',
                                's', ' ', 'c', 'a', 'l', 'l', 'e', 'd', ' ',
                                'w', 'i', 't', 'h', ' ', 'm', 'o', 'r', 'e',
                                ' ', 't', 'h', 'a', 'n', ' ', 't', 'h', 'e',
                                ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e', 'd',
                                ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o',
                                'f', ' ', 'o', 'u', 't', 'p', 'u', 't', 's',
                                ' ', '(', '1', ')', '.' };
static mxArray * _mxarray4_;

static mxChar _array7_[166] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                '8', ' ', 'L', 'i', 'n', 'e', ':', ' ', '5',
                                '8', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'r',
                                'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a', 't',
                                'a', '/', 'b', 'm', 'p', 'R', 'e', 'a', 'd',
                                'D', 'a', 't', 'a', '8', '"', ' ', 'w', 'a',
                                's', ' ', 'c', 'a', 'l', 'l', 'e', 'd', ' ',
                                'w', 'i', 't', 'h', ' ', 'm', 'o', 'r', 'e',
                                ' ', 't', 'h', 'a', 'n', ' ', 't', 'h', 'e',
                                ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e', 'd',
                                ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o',
                                'f', ' ', 'i', 'n', 'p', 'u', 't', 's', ' ',
                                '(', '4', ')', '.' };
static mxArray * _mxarray6_;

static mxChar _array9_[173] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                '8', 'R', 'L', 'E', ' ', 'L', 'i', 'n', 'e',
                                ':', ' ', '8', '1', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'r', 'e', 'a', 'd', 'b', 'm', 'p',
                                'd', 'a', 't', 'a', '/', 'b', 'm', 'p', 'R',
                                'e', 'a', 'd', 'D', 'a', 't', 'a', '8', 'R',
                                'L', 'E', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray8_;

static mxChar _array11_[172] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '8', 'R', 'L', 'E', ' ', 'L', 'i', 'n', 'e',
                                 ':', ' ', '8', '1', ' ', 'C', 'o', 'l', 'u',
                                 'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                 ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                 ' ', '"', 'r', 'e', 'a', 'd', 'b', 'm', 'p',
                                 'd', 'a', 't', 'a', '/', 'b', 'm', 'p', 'R',
                                 'e', 'a', 'd', 'D', 'a', 't', 'a', '8', 'R',
                                 'L', 'E', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '4', ')',
                                 '.' };
static mxArray * _mxarray10_;

static mxChar _array13_[167] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '4', ' ', 'L', 'i', 'n', 'e', ':', ' ', '9',
                                 '9', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                 ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                 'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'r',
                                 'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a', 't',
                                 'a', '/', 'b', 'm', 'p', 'R', 'e', 'a', 'd',
                                 'D', 'a', 't', 'a', '4', '"', ' ', 'w', 'a',
                                 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd', ' ',
                                 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r', 'e',
                                 ' ', 't', 'h', 'a', 'n', ' ', 't', 'h', 'e',
                                 ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e', 'd',
                                 ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o',
                                 'f', ' ', 'o', 'u', 't', 'p', 'u', 't', 's',
                                 ' ', '(', '1', ')', '.' };
static mxArray * _mxarray12_;

static mxChar _array15_[166] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '4', ' ', 'L', 'i', 'n', 'e', ':', ' ', '9',
                                 '9', ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':',
                                 ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u',
                                 'n', 'c', 't', 'i', 'o', 'n', ' ', '"', 'r',
                                 'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a', 't',
                                 'a', '/', 'b', 'm', 'p', 'R', 'e', 'a', 'd',
                                 'D', 'a', 't', 'a', '4', '"', ' ', 'w', 'a',
                                 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd', ' ',
                                 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r', 'e',
                                 ' ', 't', 'h', 'a', 'n', ' ', 't', 'h', 'e',
                                 ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e', 'd',
                                 ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'o',
                                 'f', ' ', 'i', 'n', 'p', 'u', 't', 's', ' ',
                                 '(', '4', ')', '.' };
static mxArray * _mxarray14_;

static mxChar _array17_[174] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '4', 'R', 'L', 'E', ' ', 'L', 'i', 'n', 'e',
                                 ':', ' ', '1', '2', '6', ' ', 'C', 'o', 'l',
                                 'u', 'm', 'n', ':', ' ', '1', ' ', 'T', 'h',
                                 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o',
                                 'n', ' ', '"', 'r', 'e', 'a', 'd', 'b', 'm',
                                 'p', 'd', 'a', 't', 'a', '/', 'b', 'm', 'p',
                                 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a', '4',
                                 'R', 'L', 'E', '"', ' ', 'w', 'a', 's', ' ',
                                 'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                 't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                 'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                 'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                 'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                 'o', 'u', 't', 'p', 'u', 't', 's', ' ', '(',
                                 '1', ')', '.' };
static mxArray * _mxarray16_;

static mxChar _array19_[173] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '4', 'R', 'L', 'E', ' ', 'L', 'i', 'n', 'e',
                                 ':', ' ', '1', '2', '6', ' ', 'C', 'o', 'l',
                                 'u', 'm', 'n', ':', ' ', '1', ' ', 'T', 'h',
                                 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o',
                                 'n', ' ', '"', 'r', 'e', 'a', 'd', 'b', 'm',
                                 'p', 'd', 'a', 't', 'a', '/', 'b', 'm', 'p',
                                 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a', '4',
                                 'R', 'L', 'E', '"', ' ', 'w', 'a', 's', ' ',
                                 'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                 't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                 'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                 'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                 'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                 'i', 'n', 'p', 'u', 't', 's', ' ', '(', '4',
                                 ')', '.' };
static mxArray * _mxarray18_;

static mxChar _array21_[168] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '1', ' ', 'L', 'i', 'n', 'e', ':', ' ', '1',
                                 '4', '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n',
                                 ':', ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f',
                                 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ', '"',
                                 'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a',
                                 't', 'a', '/', 'b', 'm', 'p', 'R', 'e', 'a',
                                 'd', 'D', 'a', 't', 'a', '1', '"', ' ', 'w',
                                 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                 ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                 'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray20_;

static mxChar _array23_[167] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '1', ' ', 'L', 'i', 'n', 'e', ':', ' ', '1',
                                 '4', '1', ' ', 'C', 'o', 'l', 'u', 'm', 'n',
                                 ':', ' ', '1', ' ', 'T', 'h', 'e', ' ', 'f',
                                 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ', '"',
                                 'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd', 'a',
                                 't', 'a', '/', 'b', 'm', 'p', 'R', 'e', 'a',
                                 'd', 'D', 'a', 't', 'a', '1', '"', ' ', 'w',
                                 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e', 'd',
                                 ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o', 'r',
                                 'e', ' ', 't', 'h', 'a', 'n', ' ', 't', 'h',
                                 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r', 'e',
                                 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ',
                                 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't', 's',
                                 ' ', '(', '4', ')', '.' };
static mxArray * _mxarray22_;

static mxChar _array25_[170] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '2', '4', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '1', '7', '5', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd',
                                 'a', 't', 'a', '/', 'b', 'm', 'p', 'R', 'e',
                                 'a', 'd', 'D', 'a', 't', 'a', '2', '4', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                 'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray24_;

static mxChar _array27_[169] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '2', '4', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '1', '7', '5', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd',
                                 'a', 't', 'a', '/', 'b', 'm', 'p', 'R', 'e',
                                 'a', 'd', 'D', 'a', 't', 'a', '2', '4', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u',
                                 't', 's', ' ', '(', '4', ')', '.' };
static mxArray * _mxarray26_;

static mxChar _array29_[170] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '3', '2', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '2', '0', '3', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd',
                                 'a', 't', 'a', '/', 'b', 'm', 'p', 'R', 'e',
                                 'a', 'd', 'D', 'a', 't', 'a', '3', '2', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                 'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray28_;

static mxChar _array31_[169] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'b',
                                 'm', 'p', 'd', 'a', 't', 'a', '/', 'b', 'm',
                                 'p', 'R', 'e', 'a', 'd', 'D', 'a', 't', 'a',
                                 '3', '2', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                 '2', '0', '3', ' ', 'C', 'o', 'l', 'u', 'm',
                                 'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                 '"', 'r', 'e', 'a', 'd', 'b', 'm', 'p', 'd',
                                 'a', 't', 'a', '/', 'b', 'm', 'p', 'R', 'e',
                                 'a', 'd', 'D', 'a', 't', 'a', '3', '2', '"',
                                 ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                 'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u',
                                 't', 's', ' ', '(', '4', ')', '.' };
static mxArray * _mxarray30_;

static mxChar _array33_[4] = { 'n', 'o', 'n', 'e' };
static mxArray * _mxarray32_;
static mxArray * _mxarray34_;
static mxArray * _mxarray35_;
static mxArray * _mxarray36_;
static mxArray * _mxarray37_;
static mxArray * _mxarray38_;

static mxChar _array40_[9] = { '8', '-', 'b', 'i', 't', ' ', 'R', 'L', 'E' };
static mxArray * _mxarray39_;

static mxChar _array42_[9] = { '4', '-', 'b', 'i', 't', ' ', 'R', 'L', 'E' };
static mxArray * _mxarray41_;

static mxChar _array44_[9] = { 'b', 'i', 't', 'f', 'i', 'e', 'l', 'd', 's' };
static mxArray * _mxarray43_;

static mxChar _array46_[34] = { 'B', 'i', 't', 'f', 'i', 'e', 'l', 'd', ' ',
                                'c', 'o', 'm', 'p', 'r', 'e', 's', 's', 'i',
                                'o', 'n', ' ', 'n', 'o', 't', ' ', 's', 'u',
                                'p', 'p', 'o', 'r', 't', 'e', 'd' };
static mxArray * _mxarray45_;

static mxChar _array48_[10] = { 'H', 'u', 'f', 'f', 'm',
                                'a', 'n', ' ', '1', 'D' };
static mxArray * _mxarray47_;

static mxChar _array50_[36] = { 'H', 'u', 'f', 'f', 'm', 'a', 'n', ' ', '1',
                                'D', ' ', 'c', 'o', 'm', 'p', 'r', 'e', 's',
                                's', 'i', 'o', 'n', ' ', 'n', 'o', 't', ' ',
                                's', 'u', 'p', 'p', 'o', 'r', 't', 'e', 'd' };
static mxArray * _mxarray49_;

static mxChar _array52_[10] = { '2', '4', '-', 'b', 'i',
                                't', ' ', 'R', 'L', 'E' };
static mxArray * _mxarray51_;

static mxChar _array54_[36] = { '2', '4', '-', 'b', 'i', 't', ' ', 'R', 'L',
                                'E', ' ', 'c', 'o', 'm', 'p', 'r', 'e', 's',
                                's', 'i', 'o', 'n', ' ', 'n', 'o', 't', ' ',
                                's', 'u', 'p', 'p', 'o', 'r', 't', 'e', 'd' };
static mxArray * _mxarray53_;

static mxChar _array56_[38] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'B', 'M', 'P', ' ', 'f', 'i', 'l', 'e',
                                ':', ' ', 't', 'r', 'u', 'n', 'c', 'a',
                                't', 'e', 'd', ' ', 'i', 'm', 'a', 'g',
                                'e', ' ', 'd', 'a', 't', 'a' };
static mxArray * _mxarray55_;
static mxArray * _mxarray57_;

static mxChar _array59_[4] = { 'r', 'l', 'e', '8' };
static mxArray * _mxarray58_;
static mxArray * _mxarray60_;
static mxArray * _mxarray61_;

static mxChar _array63_[4] = { 'r', 'l', 'e', '4' };
static mxArray * _mxarray62_;
static mxArray * _mxarray64_;
static mxArray * _mxarray65_;
static mxArray * _mxarray66_;

void InitializeModule_iofun_private_readbmpdata(void) {
    _mxarray0_ = mclInitializeString(168, _array1_);
    _mxarray2_ = mclInitializeString(167, _array3_);
    _mxarray4_ = mclInitializeString(167, _array5_);
    _mxarray6_ = mclInitializeString(166, _array7_);
    _mxarray8_ = mclInitializeString(173, _array9_);
    _mxarray10_ = mclInitializeString(172, _array11_);
    _mxarray12_ = mclInitializeString(167, _array13_);
    _mxarray14_ = mclInitializeString(166, _array15_);
    _mxarray16_ = mclInitializeString(174, _array17_);
    _mxarray18_ = mclInitializeString(173, _array19_);
    _mxarray20_ = mclInitializeString(168, _array21_);
    _mxarray22_ = mclInitializeString(167, _array23_);
    _mxarray24_ = mclInitializeString(170, _array25_);
    _mxarray26_ = mclInitializeString(169, _array27_);
    _mxarray28_ = mclInitializeString(170, _array29_);
    _mxarray30_ = mclInitializeString(169, _array31_);
    _mxarray32_ = mclInitializeString(4, _array33_);
    _mxarray34_ = mclInitializeDouble(1.0);
    _mxarray35_ = mclInitializeDouble(4.0);
    _mxarray36_ = mclInitializeDouble(8.0);
    _mxarray37_ = mclInitializeDouble(24.0);
    _mxarray38_ = mclInitializeDouble(32.0);
    _mxarray39_ = mclInitializeString(9, _array40_);
    _mxarray41_ = mclInitializeString(9, _array42_);
    _mxarray43_ = mclInitializeString(9, _array44_);
    _mxarray45_ = mclInitializeString(34, _array46_);
    _mxarray47_ = mclInitializeString(10, _array48_);
    _mxarray49_ = mclInitializeString(36, _array50_);
    _mxarray51_ = mclInitializeString(10, _array52_);
    _mxarray53_ = mclInitializeString(36, _array54_);
    _mxarray55_ = mclInitializeString(38, _array56_);
    _mxarray57_ = mclInitializeDouble(0.0);
    _mxarray58_ = mclInitializeString(4, _array59_);
    _mxarray60_ = mclInitializeDouble(2.0);
    _mxarray61_ = mclInitializeDouble(5.0);
    _mxarray62_ = mclInitializeString(4, _array63_);
    _mxarray64_ = mclInitializeDouble(7.0);
    _mxarray65_ = mclInitializeDouble(6.0);
    _mxarray66_ = mclInitializeDouble(3.0);
}

void TerminateModule_iofun_private_readbmpdata(void) {
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfReadbmpdata_bmpReadData8(mxArray * fname,
                                             mxArray * offset,
                                             mxArray * width,
                                             mxArray * height);
static void mlxReadbmpdata_bmpReadData8(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfReadbmpdata_bmpReadData8RLE(mxArray * fname,
                                                mxArray * offset,
                                                mxArray * width,
                                                mxArray * height);
static void mlxReadbmpdata_bmpReadData8RLE(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static mxArray * mlfReadbmpdata_bmpReadData4(mxArray * filename,
                                             mxArray * offset,
                                             mxArray * width,
                                             mxArray * height);
static void mlxReadbmpdata_bmpReadData4(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfReadbmpdata_bmpReadData4RLE(mxArray * filename,
                                                mxArray * offset,
                                                mxArray * width,
                                                mxArray * height);
static void mlxReadbmpdata_bmpReadData4RLE(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static mxArray * mlfReadbmpdata_bmpReadData1(mxArray * filename,
                                             mxArray * offset,
                                             mxArray * width,
                                             mxArray * height);
static void mlxReadbmpdata_bmpReadData1(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfReadbmpdata_bmpReadData24(mxArray * filename,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height);
static void mlxReadbmpdata_bmpReadData24(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfReadbmpdata_bmpReadData32(mxArray * filename,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height);
static void mlxReadbmpdata_bmpReadData32(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * Miofun_private_readbmpdata(int nargout_, mxArray * info);
static mxArray * Mreadbmpdata_bmpReadData8(int nargout_,
                                           mxArray * fname,
                                           mxArray * offset,
                                           mxArray * width,
                                           mxArray * height);
static mxArray * Mreadbmpdata_bmpReadData8RLE(int nargout_,
                                              mxArray * fname,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height);
static mxArray * Mreadbmpdata_bmpReadData4(int nargout_,
                                           mxArray * filename,
                                           mxArray * offset,
                                           mxArray * width,
                                           mxArray * height);
static mxArray * Mreadbmpdata_bmpReadData4RLE(int nargout_,
                                              mxArray * filename,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height);
static mxArray * Mreadbmpdata_bmpReadData1(int nargout_,
                                           mxArray * filename,
                                           mxArray * offset,
                                           mxArray * width,
                                           mxArray * height);
static mxArray * Mreadbmpdata_bmpReadData24(int nargout_,
                                            mxArray * filename,
                                            mxArray * offset,
                                            mxArray * width,
                                            mxArray * height);
static mxArray * Mreadbmpdata_bmpReadData32(int nargout_,
                                            mxArray * filename,
                                            mxArray * offset,
                                            mxArray * width,
                                            mxArray * height);

static mexFunctionTableEntry local_function_table_[7]
  = { { "bmpReadData8", mlxReadbmpdata_bmpReadData8, 4, 1, NULL },
      { "bmpReadData8RLE", mlxReadbmpdata_bmpReadData8RLE, 4, 1, NULL },
      { "bmpReadData4", mlxReadbmpdata_bmpReadData4, 4, 1, NULL },
      { "bmpReadData4RLE", mlxReadbmpdata_bmpReadData4RLE, 4, 1, NULL },
      { "bmpReadData1", mlxReadbmpdata_bmpReadData1, 4, 1, NULL },
      { "bmpReadData24", mlxReadbmpdata_bmpReadData24, 4, 1, NULL },
      { "bmpReadData32", mlxReadbmpdata_bmpReadData32, 4, 1, NULL } };

_mexLocalFunctionTable _local_function_table_iofun_private_readbmpdata
  = { 7, local_function_table_ };

/*
 * The function "mlfIofun_private_readbmpdata" contains the normal interface
 * for the "iofun/private/readbmpdata" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 1-58). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readbmpdata(mxArray * info) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, info);
    X = Miofun_private_readbmpdata(nargout, info);
    mlfRestorePreviousContext(0, 1, info);
    return mlfReturnValue(X);
}

/*
 * The function "mlxIofun_private_readbmpdata" contains the feval interface for
 * the "iofun/private/readbmpdata" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 1-58). The
 * feval function calls the implementation version of iofun/private/readbmpdata
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readbmpdata(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_readbmpdata(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfReadbmpdata_bmpReadData8" contains the normal interface for
 * the "readbmpdata/bmpReadData8" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 58-81).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfReadbmpdata_bmpReadData8(mxArray * fname,
                                             mxArray * offset,
                                             mxArray * width,
                                             mxArray * height) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, fname, offset, width, height);
    X = Mreadbmpdata_bmpReadData8(nargout, fname, offset, width, height);
    mlfRestorePreviousContext(0, 4, fname, offset, width, height);
    return mlfReturnValue(X);
}

/*
 * The function "mlxReadbmpdata_bmpReadData8" contains the feval interface for
 * the "readbmpdata/bmpReadData8" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 58-81). The
 * feval function calls the implementation version of readbmpdata/bmpReadData8
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxReadbmpdata_bmpReadData8(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray4_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray6_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mreadbmpdata_bmpReadData8(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfReadbmpdata_bmpReadData8RLE" contains the normal interface
 * for the "readbmpdata/bmpReadData8RLE" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 81-99).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfReadbmpdata_bmpReadData8RLE(mxArray * fname,
                                                mxArray * offset,
                                                mxArray * width,
                                                mxArray * height) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, fname, offset, width, height);
    X = Mreadbmpdata_bmpReadData8RLE(nargout, fname, offset, width, height);
    mlfRestorePreviousContext(0, 4, fname, offset, width, height);
    return mlfReturnValue(X);
}

/*
 * The function "mlxReadbmpdata_bmpReadData8RLE" contains the feval interface
 * for the "readbmpdata/bmpReadData8RLE" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 81-99). The
 * feval function calls the implementation version of
 * readbmpdata/bmpReadData8RLE through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxReadbmpdata_bmpReadData8RLE(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray8_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray10_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mreadbmpdata_bmpReadData8RLE(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfReadbmpdata_bmpReadData4" contains the normal interface for
 * the "readbmpdata/bmpReadData4" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 99-126).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfReadbmpdata_bmpReadData4(mxArray * filename,
                                             mxArray * offset,
                                             mxArray * width,
                                             mxArray * height) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, filename, offset, width, height);
    X = Mreadbmpdata_bmpReadData4(nargout, filename, offset, width, height);
    mlfRestorePreviousContext(0, 4, filename, offset, width, height);
    return mlfReturnValue(X);
}

/*
 * The function "mlxReadbmpdata_bmpReadData4" contains the feval interface for
 * the "readbmpdata/bmpReadData4" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 99-126).
 * The feval function calls the implementation version of
 * readbmpdata/bmpReadData4 through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxReadbmpdata_bmpReadData4(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray12_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray14_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mreadbmpdata_bmpReadData4(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfReadbmpdata_bmpReadData4RLE" contains the normal interface
 * for the "readbmpdata/bmpReadData4RLE" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 126-141).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfReadbmpdata_bmpReadData4RLE(mxArray * filename,
                                                mxArray * offset,
                                                mxArray * width,
                                                mxArray * height) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, filename, offset, width, height);
    X = Mreadbmpdata_bmpReadData4RLE(nargout, filename, offset, width, height);
    mlfRestorePreviousContext(0, 4, filename, offset, width, height);
    return mlfReturnValue(X);
}

/*
 * The function "mlxReadbmpdata_bmpReadData4RLE" contains the feval interface
 * for the "readbmpdata/bmpReadData4RLE" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 126-141).
 * The feval function calls the implementation version of
 * readbmpdata/bmpReadData4RLE through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxReadbmpdata_bmpReadData4RLE(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray16_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray18_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mreadbmpdata_bmpReadData4RLE(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfReadbmpdata_bmpReadData1" contains the normal interface for
 * the "readbmpdata/bmpReadData1" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 141-175).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfReadbmpdata_bmpReadData1(mxArray * filename,
                                             mxArray * offset,
                                             mxArray * width,
                                             mxArray * height) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, filename, offset, width, height);
    X = Mreadbmpdata_bmpReadData1(nargout, filename, offset, width, height);
    mlfRestorePreviousContext(0, 4, filename, offset, width, height);
    return mlfReturnValue(X);
}

/*
 * The function "mlxReadbmpdata_bmpReadData1" contains the feval interface for
 * the "readbmpdata/bmpReadData1" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 141-175).
 * The feval function calls the implementation version of
 * readbmpdata/bmpReadData1 through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxReadbmpdata_bmpReadData1(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray20_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray22_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mreadbmpdata_bmpReadData1(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfReadbmpdata_bmpReadData24" contains the normal interface
 * for the "readbmpdata/bmpReadData24" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 175-203).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfReadbmpdata_bmpReadData24(mxArray * filename,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height) {
    int nargout = 1;
    mxArray * RGB = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, filename, offset, width, height);
    RGB = Mreadbmpdata_bmpReadData24(nargout, filename, offset, width, height);
    mlfRestorePreviousContext(0, 4, filename, offset, width, height);
    return mlfReturnValue(RGB);
}

/*
 * The function "mlxReadbmpdata_bmpReadData24" contains the feval interface for
 * the "readbmpdata/bmpReadData24" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 175-203).
 * The feval function calls the implementation version of
 * readbmpdata/bmpReadData24 through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxReadbmpdata_bmpReadData24(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray24_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray26_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mreadbmpdata_bmpReadData24(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfReadbmpdata_bmpReadData32" contains the normal interface
 * for the "readbmpdata/bmpReadData32" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 203-226).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfReadbmpdata_bmpReadData32(mxArray * filename,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height) {
    int nargout = 1;
    mxArray * RGB = mclGetUninitializedArray();
    mlfEnterNewContext(0, 4, filename, offset, width, height);
    RGB = Mreadbmpdata_bmpReadData32(nargout, filename, offset, width, height);
    mlfRestorePreviousContext(0, 4, filename, offset, width, height);
    return mlfReturnValue(RGB);
}

/*
 * The function "mlxReadbmpdata_bmpReadData32" contains the feval interface for
 * the "readbmpdata/bmpReadData32" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 203-226).
 * The feval function calls the implementation version of
 * readbmpdata/bmpReadData32 through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxReadbmpdata_bmpReadData32(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray28_);
    }
    if (nrhs > 4) {
        mlfError(_mxarray30_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mreadbmpdata_bmpReadData32(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Miofun_private_readbmpdata" is the implementation version of
 * the "iofun/private/readbmpdata" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 1-58). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = readbmpdata(info)
 */
static mxArray * Miofun_private_readbmpdata(int nargout_, mxArray * info) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * X = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * filename = mclGetUninitializedArray();
    mxArray * height = mclGetUninitializedArray();
    mxArray * width = mclGetUninitializedArray();
    mxArray * offset = mclGetUninitializedArray();
    mclCopyArray(&info);
    /*
     * %READBMPDATA Read bitmap data
     * %   X = readbmpdata(INFO) reads image data from a BMP file.  INFO is a
     * %   structure returned by IMBMPINFO. X is a uint8 array that is 2-D for
     * %   1-bit, 4-bit, and 8-bit image data.  X is M-by-N-by-3 for 24-bit and
     * %   32-bit image data.  
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc.
     * %   $Revision: 1.2 $  $Date: 2000/03/13 21:26:36 $
     * 
     * offset = info.ImageDataOffset;
     */
    mlfAssign(&offset, mlfIndexRef(mclVsa(info, "info"), ".ImageDataOffset"));
    /*
     * width = info.Width;
     */
    mlfAssign(&width, mlfIndexRef(mclVsa(info, "info"), ".Width"));
    /*
     * height = info.Height;
     */
    mlfAssign(&height, mlfIndexRef(mclVsa(info, "info"), ".Height"));
    /*
     * filename = info.Filename;
     */
    mlfAssign(&filename, mlfIndexRef(mclVsa(info, "info"), ".Filename"));
    /*
     * 
     * switch info.CompressionType
     */
    {
        mxArray * v_ = mclInitialize(
                         mclVe(
                           mlfIndexRef(
                             mclVsa(info, "info"), ".CompressionType")));
        if (mclSwitchCompare(v_, _mxarray32_)) {
            /*
             * 
             * case 'none'
             * 
             * switch info.BitDepth
             */
            mxArray * v_0 = mclInitialize(
                              mclVe(
                                mlfIndexRef(
                                  mclVsa(info, "info"), ".BitDepth")));
            if (mclSwitchCompare(v_0, _mxarray34_)) {
                /*
                 * case 1
                 * X = logical(bmpReadData1(filename, offset, width, height));
                 */
                mlfAssign(
                  &X,
                  mlfLogical(
                    mclVe(
                      mlfReadbmpdata_bmpReadData1(
                        mclVv(filename, "filename"),
                        mclVv(offset, "offset"),
                        mclVv(width, "width"),
                        mclVv(height, "height")))));
            /*
             * 
             * case 4
             */
            } else if (mclSwitchCompare(v_0, _mxarray35_)) {
                /*
                 * X = bmpReadData4(filename, offset, width, height);
                 */
                mlfAssign(
                  &X,
                  mlfReadbmpdata_bmpReadData4(
                    mclVv(filename, "filename"),
                    mclVv(offset, "offset"),
                    mclVv(width, "width"),
                    mclVv(height, "height")));
            /*
             * 
             * case 8
             */
            } else if (mclSwitchCompare(v_0, _mxarray36_)) {
                /*
                 * X = bmpReadData8(filename, offset, width, height);
                 */
                mlfAssign(
                  &X,
                  mlfReadbmpdata_bmpReadData8(
                    mclVv(filename, "filename"),
                    mclVv(offset, "offset"),
                    mclVv(width, "width"),
                    mclVv(height, "height")));
            /*
             * 
             * case 24
             */
            } else if (mclSwitchCompare(v_0, _mxarray37_)) {
                /*
                 * X = bmpReadData24(filename, offset, width, height);
                 */
                mlfAssign(
                  &X,
                  mlfReadbmpdata_bmpReadData24(
                    mclVv(filename, "filename"),
                    mclVv(offset, "offset"),
                    mclVv(width, "width"),
                    mclVv(height, "height")));
            /*
             * 
             * case 32
             */
            } else if (mclSwitchCompare(v_0, _mxarray38_)) {
                /*
                 * X = bmpReadData32(filename, offset, width, height);
                 */
                mlfAssign(
                  &X,
                  mlfReadbmpdata_bmpReadData32(
                    mclVv(filename, "filename"),
                    mclVv(offset, "offset"),
                    mclVv(width, "width"),
                    mclVv(height, "height")));
            /*
             * 
             * end
             */
            }
            mxDestroyArray(v_0);
        /*
         * 
         * case '8-bit RLE'
         */
        } else if (mclSwitchCompare(v_, _mxarray39_)) {
            /*
             * X = bmpReadData8RLE(filename, offset, width, height);
             */
            mlfAssign(
              &X,
              mlfReadbmpdata_bmpReadData8RLE(
                mclVv(filename, "filename"),
                mclVv(offset, "offset"),
                mclVv(width, "width"),
                mclVv(height, "height")));
        /*
         * 
         * case '4-bit RLE'
         */
        } else if (mclSwitchCompare(v_, _mxarray41_)) {
            /*
             * X = bmpReadData4RLE(filename, offset, width, height);
             */
            mlfAssign(
              &X,
              mlfReadbmpdata_bmpReadData4RLE(
                mclVv(filename, "filename"),
                mclVv(offset, "offset"),
                mclVv(width, "width"),
                mclVv(height, "height")));
        /*
         * 
         * case 'bitfields'
         */
        } else if (mclSwitchCompare(v_, _mxarray43_)) {
            /*
             * error('Bitfield compression not supported');
             */
            mlfError(_mxarray45_);
        /*
         * 
         * case 'Huffman 1D'
         */
        } else if (mclSwitchCompare(v_, _mxarray47_)) {
            /*
             * error('Huffman 1D compression not supported');
             */
            mlfError(_mxarray49_);
        /*
         * 
         * case '24-bit RLE'
         */
        } else if (mclSwitchCompare(v_, _mxarray51_)) {
            /*
             * error('24-bit RLE compression not supported');
             */
            mlfError(_mxarray53_);
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(X, 1, nargout_, "X", "iofun/private/readbmpdata");
    mxDestroyArray(offset);
    mxDestroyArray(width);
    mxDestroyArray(height);
    mxDestroyArray(filename);
    mxDestroyArray(ans);
    mxDestroyArray(info);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * %%%
     * %%% bmpReadData8 --- read 8-bit bitmap data
     * %%%
     * function X = bmpReadData8(fname, offset, width, height)
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 4*ceil(width/4);
     * 
     * X = freadu8(fname, offset, paddedWidth*height);
     * count = length(X);
     * if (count ~= paddedWidth*height)
     * warning('Invalid BMP file: truncated image data');
     * % Fill in the missing values with zeros.
     * X(paddedWidth*height) = 0;
     * end
     * 
     * X = rot90(reshape(X, paddedWidth, height));
     * if (paddedWidth ~= width)
     * X = X(:,1:width);
     * end
     * 
     * 
     * 
     * %%%
     * %%% bmpReadData8RLE --- read 8-bit RLE-compressed bitmap data
     * %%%
     */
}

/*
 * The function "Mreadbmpdata_bmpReadData8" is the implementation version of
 * the "readbmpdata/bmpReadData8" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 58-81). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = bmpReadData8(fname, offset, width, height)
 */
static mxArray * Mreadbmpdata_bmpReadData8(int nargout_,
                                           mxArray * fname,
                                           mxArray * offset,
                                           mxArray * width,
                                           mxArray * height) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * X = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * paddedWidth = mclGetUninitializedArray();
    mclCopyArray(&fname);
    mclCopyArray(&offset);
    mclCopyArray(&width);
    mclCopyArray(&height);
    /*
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 4*ceil(width/4);
     */
    mlfAssign(
      &paddedWidth,
      mclMtimes(
        _mxarray35_,
        mclVe(mlfCeil(mclMrdivide(mclVa(width, "width"), _mxarray35_)))));
    /*
     * 
     * X = freadu8(fname, offset, paddedWidth*height);
     */
    mlfAssign(
      &X,
      mlfNIofun_private_freadu8(
        0,
        mclValueVarargout(),
        mclVa(fname, "fname"),
        mclVa(offset, "offset"),
        mclMtimes(mclVv(paddedWidth, "paddedWidth"), mclVa(height, "height")),
        NULL));
    /*
     * count = length(X);
     */
    mlfAssign(&count, mlfScalar(mclLengthInt(mclVv(X, "X"))));
    /*
     * if (count ~= paddedWidth*height)
     */
    if (mclNeBool(
          mclVv(count, "count"),
          mclMtimes(
            mclVv(paddedWidth, "paddedWidth"), mclVa(height, "height")))) {
        /*
         * warning('Invalid BMP file: truncated image data');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray55_));
        /*
         * % Fill in the missing values with zeros.
         * X(paddedWidth*height) = 0;
         */
        mclArrayAssign1(
          &X,
          _mxarray57_,
          mclMtimes(
            mclVv(paddedWidth, "paddedWidth"), mclVa(height, "height")));
    /*
     * end
     */
    }
    /*
     * 
     * X = rot90(reshape(X, paddedWidth, height));
     */
    mlfAssign(
      &X,
      mlfRot90(
        mclVe(
          mlfReshape(
            mclVv(X, "X"),
            mclVv(paddedWidth, "paddedWidth"), mclVa(height, "height"), NULL)),
        NULL));
    /*
     * if (paddedWidth ~= width)
     */
    if (mclNeBool(mclVv(paddedWidth, "paddedWidth"), mclVa(width, "width"))) {
        /*
         * X = X(:,1:width);
         */
        mlfAssign(
          &X,
          mclArrayRef2(
            mclVsv(X, "X"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray34_, mclVa(width, "width"), NULL)));
    /*
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "readbmpdata/bmpReadData8");
    mxDestroyArray(paddedWidth);
    mxDestroyArray(count);
    mxDestroyArray(ans);
    mxDestroyArray(height);
    mxDestroyArray(width);
    mxDestroyArray(offset);
    mxDestroyArray(fname);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * 
     * 
     * %%%
     * %%% bmpReadData8RLE --- read 8-bit RLE-compressed bitmap data
     * %%%
     * function X = bmpReadData8RLE(fname, offset, width, height)
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 4*ceil(width/4);
     * 
     * inBuffer = freadu8(fname, offset);
     * X = bmpdrle(inBuffer, paddedWidth, height, 'rle8');
     * 
     * X = rot90(X);
     * if (paddedWidth ~= width)
     * X = X(:,1:width);
     * end
     * 
     * 
     * 
     * %%%
     * %%% bmpReadData4 --- read 4-bit bitmap data
     * %%%
     */
}

/*
 * The function "Mreadbmpdata_bmpReadData8RLE" is the implementation version of
 * the "readbmpdata/bmpReadData8RLE" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 81-99). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = bmpReadData8RLE(fname, offset, width, height)
 */
static mxArray * Mreadbmpdata_bmpReadData8RLE(int nargout_,
                                              mxArray * fname,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * X = mclGetUninitializedArray();
    mxArray * inBuffer = mclGetUninitializedArray();
    mxArray * paddedWidth = mclGetUninitializedArray();
    mclCopyArray(&fname);
    mclCopyArray(&offset);
    mclCopyArray(&width);
    mclCopyArray(&height);
    /*
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 4*ceil(width/4);
     */
    mlfAssign(
      &paddedWidth,
      mclMtimes(
        _mxarray35_,
        mclVe(mlfCeil(mclMrdivide(mclVa(width, "width"), _mxarray35_)))));
    /*
     * 
     * inBuffer = freadu8(fname, offset);
     */
    mlfAssign(
      &inBuffer,
      mlfNIofun_private_freadu8(
        0,
        mclValueVarargout(),
        mclVa(fname, "fname"),
        mclVa(offset, "offset"),
        NULL));
    /*
     * X = bmpdrle(inBuffer, paddedWidth, height, 'rle8');
     */
    mlfAssign(
      &X,
      mlfNIofun_private_bmpdrle(
        0,
        mclValueVarargout(),
        mclVv(inBuffer, "inBuffer"),
        mclVv(paddedWidth, "paddedWidth"),
        mclVa(height, "height"),
        _mxarray58_,
        NULL));
    /*
     * 
     * X = rot90(X);
     */
    mlfAssign(&X, mlfRot90(mclVv(X, "X"), NULL));
    /*
     * if (paddedWidth ~= width)
     */
    if (mclNeBool(mclVv(paddedWidth, "paddedWidth"), mclVa(width, "width"))) {
        /*
         * X = X(:,1:width);
         */
        mlfAssign(
          &X,
          mclArrayRef2(
            mclVsv(X, "X"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray34_, mclVa(width, "width"), NULL)));
    /*
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "readbmpdata/bmpReadData8RLE");
    mxDestroyArray(paddedWidth);
    mxDestroyArray(inBuffer);
    mxDestroyArray(height);
    mxDestroyArray(width);
    mxDestroyArray(offset);
    mxDestroyArray(fname);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * 
     * 
     * %%%
     * %%% bmpReadData4 --- read 4-bit bitmap data
     * %%%
     * function X = bmpReadData4(filename, offset, width, height)
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 8*ceil(width/8);
     * numBytes = paddedWidth * height / 2; % evenly divides because of padding
     * 
     * XX = freadu8(filename, offset, numBytes);
     * count = length(XX);
     * if (count ~= numBytes)
     * warning('Invalid BMP file: truncated image data');
     * % Fill in the missing values with zeros.
     * X(numBytes) = 0;
     * end
     * XX = reshape(XX, paddedWidth / 2, height);
     * 
     * X = repmat(uint8(0), paddedWidth, height);
     * X(1:2:end,:) = bitslice(XX,5,8);
     * X(2:2:end,:) = bitslice(XX,1,4);
     * X = rot90(X);
     * if (paddedWidth ~= width)
     * X = X(:,1:width);
     * end
     * 
     * 
     * %%%
     * %%% bmpReadData4RLE --- read 4-bit RLE-compressed bitmap data
     * %%%
     */
}

/*
 * The function "Mreadbmpdata_bmpReadData4" is the implementation version of
 * the "readbmpdata/bmpReadData4" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 99-126). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = bmpReadData4(filename, offset, width, height)
 */
static mxArray * Mreadbmpdata_bmpReadData4(int nargout_,
                                           mxArray * filename,
                                           mxArray * offset,
                                           mxArray * width,
                                           mxArray * height) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * X = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * XX = mclGetUninitializedArray();
    mxArray * numBytes = mclGetUninitializedArray();
    mxArray * paddedWidth = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&offset);
    mclCopyArray(&width);
    mclCopyArray(&height);
    /*
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 8*ceil(width/8);
     */
    mlfAssign(
      &paddedWidth,
      mclMtimes(
        _mxarray36_,
        mclVe(mlfCeil(mclMrdivide(mclVa(width, "width"), _mxarray36_)))));
    /*
     * numBytes = paddedWidth * height / 2; % evenly divides because of padding
     */
    mlfAssign(
      &numBytes,
      mclMrdivide(
        mclMtimes(mclVv(paddedWidth, "paddedWidth"), mclVa(height, "height")),
        _mxarray60_));
    /*
     * 
     * XX = freadu8(filename, offset, numBytes);
     */
    mlfAssign(
      &XX,
      mlfNIofun_private_freadu8(
        0,
        mclValueVarargout(),
        mclVa(filename, "filename"),
        mclVa(offset, "offset"),
        mclVv(numBytes, "numBytes"),
        NULL));
    /*
     * count = length(XX);
     */
    mlfAssign(&count, mlfScalar(mclLengthInt(mclVv(XX, "XX"))));
    /*
     * if (count ~= numBytes)
     */
    if (mclNeBool(mclVv(count, "count"), mclVv(numBytes, "numBytes"))) {
        /*
         * warning('Invalid BMP file: truncated image data');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray55_));
        /*
         * % Fill in the missing values with zeros.
         * X(numBytes) = 0;
         */
        mclArrayAssign1(&X, _mxarray57_, mclVsv(numBytes, "numBytes"));
    /*
     * end
     */
    }
    /*
     * XX = reshape(XX, paddedWidth / 2, height);
     */
    mlfAssign(
      &XX,
      mlfReshape(
        mclVv(XX, "XX"),
        mclMrdivide(mclVv(paddedWidth, "paddedWidth"), _mxarray60_),
        mclVa(height, "height"),
        NULL));
    /*
     * 
     * X = repmat(uint8(0), paddedWidth, height);
     */
    mlfAssign(
      &X,
      mlfRepmat(
        mclVe(mlfUint8(_mxarray57_)),
        mclVv(paddedWidth, "paddedWidth"),
        mclVa(height, "height")));
    /*
     * X(1:2:end,:) = bitslice(XX,5,8);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray61_,
        _mxarray36_,
        NULL),
      mlfColon(
        _mxarray34_,
        _mxarray60_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(2:2:end,:) = bitslice(XX,1,4);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray34_,
        _mxarray35_,
        NULL),
      mlfColon(
        _mxarray60_,
        _mxarray60_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X = rot90(X);
     */
    mlfAssign(&X, mlfRot90(mclVv(X, "X"), NULL));
    /*
     * if (paddedWidth ~= width)
     */
    if (mclNeBool(mclVv(paddedWidth, "paddedWidth"), mclVa(width, "width"))) {
        /*
         * X = X(:,1:width);
         */
        mlfAssign(
          &X,
          mclArrayRef2(
            mclVsv(X, "X"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray34_, mclVa(width, "width"), NULL)));
    /*
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "readbmpdata/bmpReadData4");
    mxDestroyArray(paddedWidth);
    mxDestroyArray(numBytes);
    mxDestroyArray(XX);
    mxDestroyArray(count);
    mxDestroyArray(ans);
    mxDestroyArray(height);
    mxDestroyArray(width);
    mxDestroyArray(offset);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * 
     * %%%
     * %%% bmpReadData4RLE --- read 4-bit RLE-compressed bitmap data
     * %%%
     * function X = bmpReadData4RLE(filename, offset, width, height)
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 8*ceil(width/8);
     * numBytes = paddedWidth * height / 2; % evenly divides because of padding
     * 
     * X = rot90(bmpdrle(freadu8(filename, offset), paddedWidth, height, 'rle4'));
     * if (paddedWidth ~= width)
     * X = X(:,1:width);
     * end
     * 
     * 
     * %%%
     * %%% bmpReadData1 --- read 1-bit bitmap data
     * %%%
     */
}

/*
 * The function "Mreadbmpdata_bmpReadData4RLE" is the implementation version of
 * the "readbmpdata/bmpReadData4RLE" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 126-141).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = bmpReadData4RLE(filename, offset, width, height)
 */
static mxArray * Mreadbmpdata_bmpReadData4RLE(int nargout_,
                                              mxArray * filename,
                                              mxArray * offset,
                                              mxArray * width,
                                              mxArray * height) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * X = mclGetUninitializedArray();
    mxArray * numBytes = mclGetUninitializedArray();
    mxArray * paddedWidth = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&offset);
    mclCopyArray(&width);
    mclCopyArray(&height);
    /*
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 8*ceil(width/8);
     */
    mlfAssign(
      &paddedWidth,
      mclMtimes(
        _mxarray36_,
        mclVe(mlfCeil(mclMrdivide(mclVa(width, "width"), _mxarray36_)))));
    /*
     * numBytes = paddedWidth * height / 2; % evenly divides because of padding
     */
    mlfAssign(
      &numBytes,
      mclMrdivide(
        mclMtimes(mclVv(paddedWidth, "paddedWidth"), mclVa(height, "height")),
        _mxarray60_));
    /*
     * 
     * X = rot90(bmpdrle(freadu8(filename, offset), paddedWidth, height, 'rle4'));
     */
    mlfAssign(
      &X,
      mlfRot90(
        mclVe(
          mlfNIofun_private_bmpdrle(
            0,
            mclValueVarargout(),
            mclVe(
              mlfNIofun_private_freadu8(
                0,
                mclValueVarargout(),
                mclVa(filename, "filename"),
                mclVa(offset, "offset"),
                NULL)),
            mclVv(paddedWidth, "paddedWidth"),
            mclVa(height, "height"),
            _mxarray62_,
            NULL)),
        NULL));
    /*
     * if (paddedWidth ~= width)
     */
    if (mclNeBool(mclVv(paddedWidth, "paddedWidth"), mclVa(width, "width"))) {
        /*
         * X = X(:,1:width);
         */
        mlfAssign(
          &X,
          mclArrayRef2(
            mclVsv(X, "X"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray34_, mclVa(width, "width"), NULL)));
    /*
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "readbmpdata/bmpReadData4RLE");
    mxDestroyArray(paddedWidth);
    mxDestroyArray(numBytes);
    mxDestroyArray(height);
    mxDestroyArray(width);
    mxDestroyArray(offset);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * 
     * %%%
     * %%% bmpReadData1 --- read 1-bit bitmap data
     * %%%
     * function X = bmpReadData1(filename, offset, width, height)
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 32*ceil(width/32);
     * numBytes = paddedWidth * height / 8;  % evenly divides because of padding
     * 
     * XX = freadu8(filename, offset, numBytes);
     * count = length(XX);
     * if (count ~= numBytes)
     * warning('Invalid BMP file: truncated image data');
     * % Fill in the missing values with zeros.
     * XX(numBytes) = 0;
     * end
     * XX = reshape(XX, paddedWidth / 8, height);
     * 
     * X = repmat(uint8(0), paddedWidth, height);
     * X(1:8:end,:) = bitslice(XX,8,8);
     * X(2:8:end,:) = bitslice(XX,7,7);
     * X(3:8:end,:) = bitslice(XX,6,6);
     * X(4:8:end,:) = bitslice(XX,5,5);
     * X(5:8:end,:) = bitslice(XX,4,4);
     * X(6:8:end,:) = bitslice(XX,3,3);
     * X(7:8:end,:) = bitslice(XX,2,2);
     * X(8:8:end,:) = bitslice(XX,1,1);
     * 
     * X = rot90(X);
     * if (paddedWidth ~= width)
     * X = X(:,1:width);
     * end
     * 
     * 
     * %%%
     * %%% bmpReadData24 --- read 24-bit bitmap data
     * %%%
     */
}

/*
 * The function "Mreadbmpdata_bmpReadData1" is the implementation version of
 * the "readbmpdata/bmpReadData1" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 141-175).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = bmpReadData1(filename, offset, width, height)
 */
static mxArray * Mreadbmpdata_bmpReadData1(int nargout_,
                                           mxArray * filename,
                                           mxArray * offset,
                                           mxArray * width,
                                           mxArray * height) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * X = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * XX = mclGetUninitializedArray();
    mxArray * numBytes = mclGetUninitializedArray();
    mxArray * paddedWidth = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&offset);
    mclCopyArray(&width);
    mclCopyArray(&height);
    /*
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * paddedWidth = 32*ceil(width/32);
     */
    mlfAssign(
      &paddedWidth,
      mclMtimes(
        _mxarray38_,
        mclVe(mlfCeil(mclMrdivide(mclVa(width, "width"), _mxarray38_)))));
    /*
     * numBytes = paddedWidth * height / 8;  % evenly divides because of padding
     */
    mlfAssign(
      &numBytes,
      mclMrdivide(
        mclMtimes(mclVv(paddedWidth, "paddedWidth"), mclVa(height, "height")),
        _mxarray36_));
    /*
     * 
     * XX = freadu8(filename, offset, numBytes);
     */
    mlfAssign(
      &XX,
      mlfNIofun_private_freadu8(
        0,
        mclValueVarargout(),
        mclVa(filename, "filename"),
        mclVa(offset, "offset"),
        mclVv(numBytes, "numBytes"),
        NULL));
    /*
     * count = length(XX);
     */
    mlfAssign(&count, mlfScalar(mclLengthInt(mclVv(XX, "XX"))));
    /*
     * if (count ~= numBytes)
     */
    if (mclNeBool(mclVv(count, "count"), mclVv(numBytes, "numBytes"))) {
        /*
         * warning('Invalid BMP file: truncated image data');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray55_));
        /*
         * % Fill in the missing values with zeros.
         * XX(numBytes) = 0;
         */
        mclArrayAssign1(&XX, _mxarray57_, mclVsv(numBytes, "numBytes"));
    /*
     * end
     */
    }
    /*
     * XX = reshape(XX, paddedWidth / 8, height);
     */
    mlfAssign(
      &XX,
      mlfReshape(
        mclVv(XX, "XX"),
        mclMrdivide(mclVv(paddedWidth, "paddedWidth"), _mxarray36_),
        mclVa(height, "height"),
        NULL));
    /*
     * 
     * X = repmat(uint8(0), paddedWidth, height);
     */
    mlfAssign(
      &X,
      mlfRepmat(
        mclVe(mlfUint8(_mxarray57_)),
        mclVv(paddedWidth, "paddedWidth"),
        mclVa(height, "height")));
    /*
     * X(1:8:end,:) = bitslice(XX,8,8);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray36_,
        _mxarray36_,
        NULL),
      mlfColon(
        _mxarray34_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(2:8:end,:) = bitslice(XX,7,7);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray64_,
        _mxarray64_,
        NULL),
      mlfColon(
        _mxarray60_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(3:8:end,:) = bitslice(XX,6,6);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray65_,
        _mxarray65_,
        NULL),
      mlfColon(
        _mxarray66_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(4:8:end,:) = bitslice(XX,5,5);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray61_,
        _mxarray61_,
        NULL),
      mlfColon(
        _mxarray35_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(5:8:end,:) = bitslice(XX,4,4);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray35_,
        _mxarray35_,
        NULL),
      mlfColon(
        _mxarray61_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(6:8:end,:) = bitslice(XX,3,3);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray66_,
        _mxarray66_,
        NULL),
      mlfColon(
        _mxarray65_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(7:8:end,:) = bitslice(XX,2,2);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray60_,
        _mxarray60_,
        NULL),
      mlfColon(
        _mxarray64_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * X(8:8:end,:) = bitslice(XX,1,1);
     */
    mclArrayAssign2(
      &X,
      mlfNIofun_private_bitslice(
        0,
        mclValueVarargout(),
        mclVv(XX, "XX"),
        _mxarray34_,
        _mxarray34_,
        NULL),
      mlfColon(
        _mxarray36_,
        _mxarray36_,
        mlfEnd(mclVv(X, "X"), _mxarray34_, _mxarray60_)),
      mlfCreateColonIndex());
    /*
     * 
     * X = rot90(X);
     */
    mlfAssign(&X, mlfRot90(mclVv(X, "X"), NULL));
    /*
     * if (paddedWidth ~= width)
     */
    if (mclNeBool(mclVv(paddedWidth, "paddedWidth"), mclVa(width, "width"))) {
        /*
         * X = X(:,1:width);
         */
        mlfAssign(
          &X,
          mclArrayRef2(
            mclVsv(X, "X"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray34_, mclVa(width, "width"), NULL)));
    /*
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "readbmpdata/bmpReadData1");
    mxDestroyArray(paddedWidth);
    mxDestroyArray(numBytes);
    mxDestroyArray(XX);
    mxDestroyArray(count);
    mxDestroyArray(ans);
    mxDestroyArray(height);
    mxDestroyArray(width);
    mxDestroyArray(offset);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * 
     * %%%
     * %%% bmpReadData24 --- read 24-bit bitmap data
     * %%%
     * function RGB = bmpReadData24(filename, offset, width, height)
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * byteWidth = 3*width;
     * paddedByteWidth = 4*ceil(byteWidth/4);
     * numBytes = paddedByteWidth * height;
     * 
     * X = freadu8(filename, offset, numBytes);
     * count = length(X);
     * if (count ~= numBytes)
     * warning('Invalid BMP file: truncated image data');
     * % Fill in the missing values with zeros.
     * X(numBytes) = 0;
     * end
     * 
     * X = rot90(reshape(X, paddedByteWidth, height));
     * if (paddedByteWidth ~= byteWidth)
     * X = X(:,1:byteWidth);
     * end
     * 
     * RGB(1:height, 1:width, 3) = X(:,1:3:end);
     * RGB(:, :, 2) = X(:,2:3:end);
     * RGB(:, :, 1) = X(:,3:3:end);
     * 
     * 
     * %%%
     * %%% bmpReadData32 --- read 32-bit bitmap data
     * %%%
     */
}

/*
 * The function "Mreadbmpdata_bmpReadData24" is the implementation version of
 * the "readbmpdata/bmpReadData24" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 175-203).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function RGB = bmpReadData24(filename, offset, width, height)
 */
static mxArray * Mreadbmpdata_bmpReadData24(int nargout_,
                                            mxArray * filename,
                                            mxArray * offset,
                                            mxArray * width,
                                            mxArray * height) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * RGB = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * X = mclGetUninitializedArray();
    mxArray * numBytes = mclGetUninitializedArray();
    mxArray * paddedByteWidth = mclGetUninitializedArray();
    mxArray * byteWidth = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&offset);
    mclCopyArray(&width);
    mclCopyArray(&height);
    /*
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * byteWidth = 3*width;
     */
    mlfAssign(&byteWidth, mclMtimes(_mxarray66_, mclVa(width, "width")));
    /*
     * paddedByteWidth = 4*ceil(byteWidth/4);
     */
    mlfAssign(
      &paddedByteWidth,
      mclMtimes(
        _mxarray35_,
        mclVe(
          mlfCeil(mclMrdivide(mclVv(byteWidth, "byteWidth"), _mxarray35_)))));
    /*
     * numBytes = paddedByteWidth * height;
     */
    mlfAssign(
      &numBytes,
      mclMtimes(
        mclVv(paddedByteWidth, "paddedByteWidth"), mclVa(height, "height")));
    /*
     * 
     * X = freadu8(filename, offset, numBytes);
     */
    mlfAssign(
      &X,
      mlfNIofun_private_freadu8(
        0,
        mclValueVarargout(),
        mclVa(filename, "filename"),
        mclVa(offset, "offset"),
        mclVv(numBytes, "numBytes"),
        NULL));
    /*
     * count = length(X);
     */
    mlfAssign(&count, mlfScalar(mclLengthInt(mclVv(X, "X"))));
    /*
     * if (count ~= numBytes)
     */
    if (mclNeBool(mclVv(count, "count"), mclVv(numBytes, "numBytes"))) {
        /*
         * warning('Invalid BMP file: truncated image data');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray55_));
        /*
         * % Fill in the missing values with zeros.
         * X(numBytes) = 0;
         */
        mclArrayAssign1(&X, _mxarray57_, mclVsv(numBytes, "numBytes"));
    /*
     * end
     */
    }
    /*
     * 
     * X = rot90(reshape(X, paddedByteWidth, height));
     */
    mlfAssign(
      &X,
      mlfRot90(
        mclVe(
          mlfReshape(
            mclVv(X, "X"),
            mclVv(paddedByteWidth, "paddedByteWidth"),
            mclVa(height, "height"),
            NULL)),
        NULL));
    /*
     * if (paddedByteWidth ~= byteWidth)
     */
    if (mclNeBool(
          mclVv(paddedByteWidth, "paddedByteWidth"),
          mclVv(byteWidth, "byteWidth"))) {
        /*
         * X = X(:,1:byteWidth);
         */
        mlfAssign(
          &X,
          mclArrayRef2(
            mclVsv(X, "X"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray34_, mclVv(byteWidth, "byteWidth"), NULL)));
    /*
     * end
     */
    }
    /*
     * 
     * RGB(1:height, 1:width, 3) = X(:,1:3:end);
     */
    mlfIndexAssign(
      &RGB,
      "(?,?,?)",
      mlfColon(_mxarray34_, mclVa(height, "height"), NULL),
      mlfColon(_mxarray34_, mclVa(width, "width"), NULL),
      _mxarray66_,
      mclArrayRef2(
        mclVsv(X, "X"),
        mlfCreateColonIndex(),
        mlfColon(
          _mxarray34_,
          _mxarray66_,
          mlfEnd(mclVv(X, "X"), _mxarray60_, _mxarray60_))));
    /*
     * RGB(:, :, 2) = X(:,2:3:end);
     */
    mlfIndexAssign(
      &RGB,
      "(?,?,?)",
      mlfCreateColonIndex(),
      mlfCreateColonIndex(),
      _mxarray60_,
      mclArrayRef2(
        mclVsv(X, "X"),
        mlfCreateColonIndex(),
        mlfColon(
          _mxarray60_,
          _mxarray66_,
          mlfEnd(mclVv(X, "X"), _mxarray60_, _mxarray60_))));
    /*
     * RGB(:, :, 1) = X(:,3:3:end);
     */
    mlfIndexAssign(
      &RGB,
      "(?,?,?)",
      mlfCreateColonIndex(),
      mlfCreateColonIndex(),
      _mxarray34_,
      mclArrayRef2(
        mclVsv(X, "X"),
        mlfCreateColonIndex(),
        mlfColon(
          _mxarray66_,
          _mxarray66_,
          mlfEnd(mclVv(X, "X"), _mxarray60_, _mxarray60_))));
    mclValidateOutput(RGB, 1, nargout_, "RGB", "readbmpdata/bmpReadData24");
    mxDestroyArray(byteWidth);
    mxDestroyArray(paddedByteWidth);
    mxDestroyArray(numBytes);
    mxDestroyArray(X);
    mxDestroyArray(count);
    mxDestroyArray(ans);
    mxDestroyArray(height);
    mxDestroyArray(width);
    mxDestroyArray(offset);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return RGB;
    /*
     * 
     * 
     * %%%
     * %%% bmpReadData32 --- read 32-bit bitmap data
     * %%%
     * function RGB = bmpReadData32(filename, offset, width, height)
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * byteWidth = 4*width;
     * paddedByteWidth = 4*ceil(byteWidth/4);
     * numBytes = paddedByteWidth * height;
     * 
     * X = freadu8(filename, offset, numBytes);
     * count = length(X);
     * if (count ~= numBytes)
     * warning('Invalid BMP file: truncated image data');
     * % Fill in the missing values with zeros.
     * X(numBytes) = 0;
     * end
     * 
     * X = rot90(reshape(X, paddedByteWidth, height));
     * if (paddedByteWidth ~= byteWidth)
     * X = X(:,1:byteWidth);
     * end
     * 
     * RGB(1:height, 1:width, 3) = X(:,1:4:end);
     * RGB(:, :, 2) = X(:,2:4:end);
     * RGB(:, :, 1) = X(:,3:4:end);
     */
}

/*
 * The function "Mreadbmpdata_bmpReadData32" is the implementation version of
 * the "readbmpdata/bmpReadData32" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readbmpdata.m" (lines 203-226).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function RGB = bmpReadData32(filename, offset, width, height)
 */
static mxArray * Mreadbmpdata_bmpReadData32(int nargout_,
                                            mxArray * filename,
                                            mxArray * offset,
                                            mxArray * width,
                                            mxArray * height) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readbmpdata);
    mxArray * RGB = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * X = mclGetUninitializedArray();
    mxArray * numBytes = mclGetUninitializedArray();
    mxArray * paddedByteWidth = mclGetUninitializedArray();
    mxArray * byteWidth = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&offset);
    mclCopyArray(&width);
    mclCopyArray(&height);
    /*
     * 
     * % NOTE: BMP files are stored so that scanlines use a multiple of 4 bytes.
     * byteWidth = 4*width;
     */
    mlfAssign(&byteWidth, mclMtimes(_mxarray35_, mclVa(width, "width")));
    /*
     * paddedByteWidth = 4*ceil(byteWidth/4);
     */
    mlfAssign(
      &paddedByteWidth,
      mclMtimes(
        _mxarray35_,
        mclVe(
          mlfCeil(mclMrdivide(mclVv(byteWidth, "byteWidth"), _mxarray35_)))));
    /*
     * numBytes = paddedByteWidth * height;
     */
    mlfAssign(
      &numBytes,
      mclMtimes(
        mclVv(paddedByteWidth, "paddedByteWidth"), mclVa(height, "height")));
    /*
     * 
     * X = freadu8(filename, offset, numBytes);
     */
    mlfAssign(
      &X,
      mlfNIofun_private_freadu8(
        0,
        mclValueVarargout(),
        mclVa(filename, "filename"),
        mclVa(offset, "offset"),
        mclVv(numBytes, "numBytes"),
        NULL));
    /*
     * count = length(X);
     */
    mlfAssign(&count, mlfScalar(mclLengthInt(mclVv(X, "X"))));
    /*
     * if (count ~= numBytes)
     */
    if (mclNeBool(mclVv(count, "count"), mclVv(numBytes, "numBytes"))) {
        /*
         * warning('Invalid BMP file: truncated image data');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray55_));
        /*
         * % Fill in the missing values with zeros.
         * X(numBytes) = 0;
         */
        mclArrayAssign1(&X, _mxarray57_, mclVsv(numBytes, "numBytes"));
    /*
     * end
     */
    }
    /*
     * 
     * X = rot90(reshape(X, paddedByteWidth, height));
     */
    mlfAssign(
      &X,
      mlfRot90(
        mclVe(
          mlfReshape(
            mclVv(X, "X"),
            mclVv(paddedByteWidth, "paddedByteWidth"),
            mclVa(height, "height"),
            NULL)),
        NULL));
    /*
     * if (paddedByteWidth ~= byteWidth)
     */
    if (mclNeBool(
          mclVv(paddedByteWidth, "paddedByteWidth"),
          mclVv(byteWidth, "byteWidth"))) {
        /*
         * X = X(:,1:byteWidth);
         */
        mlfAssign(
          &X,
          mclArrayRef2(
            mclVsv(X, "X"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray34_, mclVv(byteWidth, "byteWidth"), NULL)));
    /*
     * end
     */
    }
    /*
     * 
     * RGB(1:height, 1:width, 3) = X(:,1:4:end);
     */
    mlfIndexAssign(
      &RGB,
      "(?,?,?)",
      mlfColon(_mxarray34_, mclVa(height, "height"), NULL),
      mlfColon(_mxarray34_, mclVa(width, "width"), NULL),
      _mxarray66_,
      mclArrayRef2(
        mclVsv(X, "X"),
        mlfCreateColonIndex(),
        mlfColon(
          _mxarray34_,
          _mxarray35_,
          mlfEnd(mclVv(X, "X"), _mxarray60_, _mxarray60_))));
    /*
     * RGB(:, :, 2) = X(:,2:4:end);
     */
    mlfIndexAssign(
      &RGB,
      "(?,?,?)",
      mlfCreateColonIndex(),
      mlfCreateColonIndex(),
      _mxarray60_,
      mclArrayRef2(
        mclVsv(X, "X"),
        mlfCreateColonIndex(),
        mlfColon(
          _mxarray60_,
          _mxarray35_,
          mlfEnd(mclVv(X, "X"), _mxarray60_, _mxarray60_))));
    /*
     * RGB(:, :, 1) = X(:,3:4:end);
     */
    mlfIndexAssign(
      &RGB,
      "(?,?,?)",
      mlfCreateColonIndex(),
      mlfCreateColonIndex(),
      _mxarray34_,
      mclArrayRef2(
        mclVsv(X, "X"),
        mlfCreateColonIndex(),
        mlfColon(
          _mxarray66_,
          _mxarray35_,
          mlfEnd(mclVv(X, "X"), _mxarray60_, _mxarray60_))));
    mclValidateOutput(RGB, 1, nargout_, "RGB", "readbmpdata/bmpReadData32");
    mxDestroyArray(byteWidth);
    mxDestroyArray(paddedByteWidth);
    mxDestroyArray(numBytes);
    mxDestroyArray(X);
    mxDestroyArray(count);
    mxDestroyArray(ans);
    mxDestroyArray(height);
    mxDestroyArray(width);
    mxDestroyArray(offset);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return RGB;
}
