/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iptgetpref.h"
#include "images_private_iptprefs.h"
#include "images_private_iptregistry_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[138] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'p', 't', 'g', 'e',
                                't', 'p', 'r', 'e', 'f', ' ', 'L', 'i', 'n',
                                'e', ':', ' ', '1', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'i', 'p', 't', 'g', 'e', 't', 'p',
                                'r', 'e', 'f', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'o', 'u', 't', 'p', 'u', 't', 's', ' ', '(',
                                '1', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[137] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'p', 't', 'g', 'e',
                                't', 'p', 'r', 'e', 'f', ' ', 'L', 'i', 'n',
                                'e', ':', ' ', '1', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'i', 'p', 't', 'g', 'e', 't', 'p',
                                'r', 'e', 'f', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'i', 'n', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;
static mxArray * _mxarray7_;

static mxChar _array9_[5] = { 'e', 'x', 'a', 'c', 't' };
static mxArray * _mxarray8_;
static mxArray * _mxarray10_;

static mxChar _array12_[4] = { 'c', 'h', 'a', 'r' };
static mxArray * _mxarray11_;

static mxChar _array14_[33] = { 'P', 'r', 'e', 'f', 'e', 'r', 'e', 'n', 'c',
                                'e', ' ', 'n', 'a', 'm', 'e', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'a', ' ', 's',
                                't', 'r', 'i', 'n', 'g', '.' };
static mxArray * _mxarray13_;

static mxChar _array16_[49] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ', 'I',
                                'm', 'a', 'g', 'e', ' ', 'P', 'r', 'o', 'c',
                                'e', 's', 's', 'i', 'n', 'g', ' ', 'T', 'o',
                                'o', 'l', 'b', 'o', 'x', ' ', 'p', 'r', 'e',
                                'f', 'e', 'r', 'e', 'n', 'c', 'e', ' ', '"',
                                '%', 's', '"', '.' };
static mxArray * _mxarray15_;

static mxChar _array18_[51] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u', 's',
                                ' ', 'I', 'm', 'a', 'g', 'e', ' ', 'P', 'r',
                                'o', 'c', 'e', 's', 's', 'i', 'n', 'g', ' ',
                                'T', 'o', 'o', 'l', 'b', 'o', 'x', ' ', 'p',
                                'r', 'e', 'f', 'e', 'r', 'e', 'n', 'c', 'e',
                                ' ', '"', '%', 's', '"', '.' };
static mxArray * _mxarray17_;

void InitializeModule_iptgetpref(void) {
    _mxarray0_ = mclInitializeString(138, _array1_);
    _mxarray2_ = mclInitializeString(137, _array3_);
    _mxarray4_ = mclInitializeDouble(0.0);
    _mxarray5_ = mclInitializeDouble(1.0);
    _mxarray6_ = mclInitializeCellVector(0, 0, (mxArray * *)NULL);
    _mxarray7_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray8_ = mclInitializeString(5, _array9_);
    _mxarray10_ = mclInitializeDouble(3.0);
    _mxarray11_ = mclInitializeString(4, _array12_);
    _mxarray13_ = mclInitializeString(33, _array14_);
    _mxarray15_ = mclInitializeString(49, _array16_);
    _mxarray17_ = mclInitializeString(51, _array18_);
}

void TerminateModule_iptgetpref(void) {
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miptgetpref(int nargout_, mxArray * prefName);

_mexLocalFunctionTable _local_function_table_iptgetpref
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIptgetpref" contains the normal interface for the
 * "iptgetpref" M-function from file
 * "C:\matlabR12\toolbox\images\images\iptgetpref.m" (lines 1-83). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIptgetpref(mxArray * prefName) {
    int nargout = 1;
    mxArray * value = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, prefName);
    value = Miptgetpref(nargout, prefName);
    mlfRestorePreviousContext(0, 1, prefName);
    return mlfReturnValue(value);
}

/*
 * The function "mlxIptgetpref" contains the feval interface for the
 * "iptgetpref" M-function from file
 * "C:\matlabR12\toolbox\images\images\iptgetpref.m" (lines 1-83). The feval
 * function calls the implementation version of iptgetpref through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxIptgetpref(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miptgetpref(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Miptgetpref" is the implementation version of the "iptgetpref"
 * M-function from file "C:\matlabR12\toolbox\images\images\iptgetpref.m"
 * (lines 1-83). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function value = iptgetpref(prefName)
 */
static mxArray * Miptgetpref(int nargout_, mxArray * prefName) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iptgetpref);
    int nargin_ = mclNargin(1, prefName, NULL);
    mxArray * value = mclGetUninitializedArray();
    mxArray * preference = mclGetUninitializedArray();
    mxArray * matchIdx = mclGetUninitializedArray();
    mxArray * lowerNames = mclGetUninitializedArray();
    mxArray * registryContainsPreference = mclGetUninitializedArray();
    mxArray * thisField = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * registryFieldNames = mclGetUninitializedArray();
    mxArray * registryStruct = mclGetUninitializedArray();
    mxArray * allNames = mclGetUninitializedArray();
    mxArray * factoryPrefs = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&prefName);
    /*
     * %IPTGETPREF Get Image Processing Toolbox preference.
     * %   VALUE = IPTGETPREF(PREFNAME) returns the value of the Image
     * %   Processing Toolbox preference specified by the string
     * %   PREFNAME.  Valid preference names are 'ImshowBorder' and
     * %   'ImshowAxesVisible'.  Preference names are case insensitive
     * %   and can be abbreviated.
     * %
     * %   IPTGETPREF without an input argument displays the current
     * %   setting of all Image Processing Toolbox preferences.
     * %
     * %   Example
     * %   -------
     * %       value = iptgetpref('ImshowAxesVisible')
     * %
     * %   See also IMSHOW, IPTSETPREF.
     * 
     * %   Copyright 1993-2000 The MathWorks, Inc.
     * %   $Revision: 1.8 $  $Date: 2000/01/21 20:16:55 $
     * 
     * error(nargchk(0,1,nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray4_, _mxarray5_, mlfScalar(nargin_))));
    /*
     * 
     * % Get IPT factory preference settings.
     * factoryPrefs = iptprefs;
     */
    mlfAssign(&factoryPrefs, mlfImages_private_iptprefs());
    /*
     * allNames = factoryPrefs(:,1);
     */
    mlfAssign(
      &allNames,
      mclArrayRef2(
        mclVsv(factoryPrefs, "factoryPrefs"),
        mlfCreateColonIndex(),
        _mxarray5_));
    /*
     * 
     * % What is currently stored in the IPT registry?
     * registryStruct = iptregistry;
     */
    mlfAssign(
      &registryStruct,
      mlfNImages_private_iptregistry(0, mclValueVarargout(), NULL));
    /*
     * if (isempty(registryStruct))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(registryStruct, "registryStruct"))))) {
        /*
         * registryFieldNames = {};
         */
        mlfAssign(&registryFieldNames, _mxarray6_);
    /*
     * else
     */
    } else {
        /*
         * registryFieldNames = fieldnames(registryStruct);
         */
        mlfAssign(
          &registryFieldNames,
          mlfFieldnames(mclVv(registryStruct, "registryStruct")));
    /*
     * end
     */
    }
    /*
     * 
     * if (nargin == 0)
     */
    if (nargin_ == 0) {
        /*
         * % Display all current preference settings.
         * value = [];
         */
        mlfAssign(&value, _mxarray7_);
        /*
         * for k = 1:length(allNames)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(
                       mlfScalar(mclLengthInt(mclVv(allNames, "allNames"))));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray7_);
            } else {
                /*
                 * thisField = allNames{k};
                 * registryContainsPreference = length(strmatch(thisField, ...
                 * registryFieldNames, 'exact')) > 0;
                 * if (registryContainsPreference)
                 * value = setfield(value, thisField, ...
                 * getfield(registryStruct, thisField));
                 * else
                 * % Use default value
                 * value = setfield(value, thisField, factoryPrefs{k,3}{1});
                 * end
                 * end
                 */
                for (; ; ) {
                    mlfAssign(
                      &thisField,
                      mlfIndexRef(
                        mclVsv(allNames, "allNames"), "{?}", mlfScalar(v_)));
                    mlfAssign(
                      &registryContainsPreference,
                      mclBoolToArray(
                        mclLengthInt(
                          mclVe(
                            mlfStrmatch(
                              mclVv(thisField, "thisField"),
                              mclVv(registryFieldNames, "registryFieldNames"),
                              _mxarray8_)))
                        > 0));
                    if (mlfTobool(
                          mclVv(
                            registryContainsPreference,
                            "registryContainsPreference"))) {
                        mlfAssign(
                          &value,
                          mlfSetfield(
                            mclVv(value, "value"),
                            mclVv(thisField, "thisField"),
                            mclVe(
                              mlfGetfield(
                                mclVv(registryStruct, "registryStruct"),
                                mclVv(thisField, "thisField"), NULL)),
                            NULL));
                    } else {
                        mlfAssign(
                          &value,
                          mlfSetfield(
                            mclVv(value, "value"),
                            mclVv(thisField, "thisField"),
                            mclVe(
                              mlfIndexRef(
                                mclVsv(factoryPrefs, "factoryPrefs"),
                                "{?,?}{?}",
                                mlfScalar(v_),
                                _mxarray10_,
                                _mxarray5_)),
                            NULL));
                    }
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
    /*
     * 
     * else
     */
    } else {
        /*
         * % Return specified setting.
         * if (~isa(prefName, 'char'))
         */
        if (mclNotBool(
              mclVe(mlfIsa(mclVa(prefName, "prefName"), _mxarray11_)))) {
            /*
             * error('Preference name must be a string.');
             */
            mlfError(_mxarray13_);
        /*
         * end
         */
        }
        /*
         * 
         * % Convert factory preference names to lower case.
         * lowerNames = cell(size(allNames));
         */
        mlfAssign(
          &lowerNames,
          mlfCell(
            mclVe(
              mlfSize(mclValueVarargout(), mclVv(allNames, "allNames"), NULL)),
            NULL));
        /*
         * for k = 1:length(lowerNames)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(
                       mlfScalar(
                         mclLengthInt(mclVv(lowerNames, "lowerNames"))));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray7_);
            } else {
                /*
                 * lowerNames{k} = lower(allNames{k});
                 * end
                 */
                for (; ; ) {
                    mlfIndexAssign(
                      &lowerNames,
                      "{?}",
                      mlfScalar(v_),
                      mclFeval(
                        mclValueVarargout(),
                        mlxLower,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(allNames, "allNames"),
                            "{?}",
                            mlfScalar(v_))),
                        NULL));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
        /*
         * 
         * matchIdx = strmatch(lower(prefName), lowerNames);
         */
        mlfAssign(
          &matchIdx,
          mlfStrmatch(
            mclVe(mlfLower(mclVa(prefName, "prefName"))),
            mclVv(lowerNames, "lowerNames"),
            NULL));
        /*
         * if (isempty(matchIdx))
         */
        if (mlfTobool(mclVe(mlfIsempty(mclVv(matchIdx, "matchIdx"))))) {
            /*
             * error(sprintf(['Unknown Image Processing ' ...
             */
            mlfError(
              mclVe(
                mlfSprintf(
                  NULL, _mxarray15_, mclVa(prefName, "prefName"), NULL)));
        /*
         * 'Toolbox preference "%s".'], prefName));
         * elseif (length(matchIdx) > 1)
         */
        } else if (mclLengthInt(mclVv(matchIdx, "matchIdx")) > 1) {
            /*
             * error(sprintf(['Ambiguous Image Processing ' ...
             */
            mlfError(
              mclVe(
                mlfSprintf(
                  NULL, _mxarray17_, mclVa(prefName, "prefName"), NULL)));
        /*
         * 'Toolbox preference "%s".'], prefName));
         * else
         */
        } else {
            /*
             * preference = allNames{matchIdx};
             */
            mlfAssign(
              &preference,
              mlfIndexRef(
                mclVsv(allNames, "allNames"),
                "{?}",
                mclVsv(matchIdx, "matchIdx")));
        /*
         * end
         */
        }
        /*
         * 
         * registryContainsPreference = length(strmatch(preference, ...
         */
        mlfAssign(
          &registryContainsPreference,
          mclBoolToArray(
            mclLengthInt(
              mclVe(
                mlfStrmatch(
                  mclVv(preference, "preference"),
                  mclVv(registryFieldNames, "registryFieldNames"),
                  _mxarray8_)))
            > 0));
        /*
         * registryFieldNames, 'exact')) > 0;
         * if (registryContainsPreference)
         */
        if (mlfTobool(
              mclVv(
                registryContainsPreference, "registryContainsPreference"))) {
            /*
             * value = getfield(registryStruct, preference);
             */
            mlfAssign(
              &value,
              mlfGetfield(
                mclVv(registryStruct, "registryStruct"),
                mclVv(preference, "preference"), NULL));
        /*
         * else
         */
        } else {
            /*
             * value = factoryPrefs{matchIdx, 3}{1};
             */
            mlfAssign(
              &value,
              mlfIndexRef(
                mclVsv(factoryPrefs, "factoryPrefs"),
                "{?,?}{?}",
                mclVsv(matchIdx, "matchIdx"),
                _mxarray10_,
                _mxarray5_));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mclValidateOutput(value, 1, nargout_, "value", "iptgetpref");
    mxDestroyArray(ans);
    mxDestroyArray(factoryPrefs);
    mxDestroyArray(allNames);
    mxDestroyArray(registryStruct);
    mxDestroyArray(registryFieldNames);
    mxDestroyArray(k);
    mxDestroyArray(thisField);
    mxDestroyArray(registryContainsPreference);
    mxDestroyArray(lowerNames);
    mxDestroyArray(matchIdx);
    mxDestroyArray(preference);
    mxDestroyArray(prefName);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return value;
    /*
     * 
     */
}
