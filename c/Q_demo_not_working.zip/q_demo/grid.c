/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "grid.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[126] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'g', 'r', 'i', 'd', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', ' ', 'C',
                                'o', 'l', 'u', 'm', 'n', ':', ' ', '1', ' ',
                                'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c', 't',
                                'i', 'o', 'n', ' ', '"', 'g', 'r', 'i', 'd',
                                '"', ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l',
                                'l', 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ',
                                'm', 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n',
                                ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l',
                                'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b',
                                'e', 'r', ' ', 'o', 'f', ' ', 'o', 'u', 't',
                                'p', 'u', 't', 's', ' ', '(', '0', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[125] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'g', 'r', 'i', 'd', ' ',
                                'L', 'i', 'n', 'e', ':', ' ', '1', ' ', 'C',
                                'o', 'l', 'u', 'm', 'n', ':', ' ', '1', ' ',
                                'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c', 't',
                                'i', 'o', 'n', ' ', '"', 'g', 'r', 'i', 'd',
                                '"', ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l',
                                'l', 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ',
                                'm', 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n',
                                ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l',
                                'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b',
                                'e', 'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p',
                                'u', 't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[38] = { 'F', 'i', 'r', 's', 't', ' ', 'a', 'r', 'g', 'u',
                               'm', 'e', 'n', 't', ' ', 'm', 'u', 's', 't', ' ',
                               'b', 'e', ' ', 'a', 'n', ' ', 'a', 'x', 'e', 's',
                               ' ', 'h', 'a', 'n', 'd', 'l', 'e', '.' };
static mxArray * _mxarray5_;

static mxChar _array8_[28] = { 'A', 'x', 'e', 's', ' ', 'h', 'a', 'n', 'd', 'l',
                               'e', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                               'a', ' ', 's', 'c', 'a', 'l', 'a', 'r' };
static mxArray * _mxarray7_;

static mxChar _array10_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray9_;

static mxChar _array12_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray11_;

static mxChar _array14_[23] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ',
                                'c', 'o', 'm', 'm', 'a', 'n', 'd', ' ',
                                'o', 'p', 't', 'i', 'o', 'n', '.' };
static mxArray * _mxarray13_;

static mxChar _array16_[5] = { 'X', 'G', 'r', 'i', 'd' };
static mxArray * _mxarray15_;

static mxChar _array18_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray17_;

static mxChar _array20_[2] = { 'o', 'n' };
static mxArray * _mxarray19_;

static mxChar _array22_[5] = { 'Y', 'G', 'r', 'i', 'd' };
static mxArray * _mxarray21_;

static mxChar _array24_[5] = { 'Z', 'G', 'r', 'i', 'd' };
static mxArray * _mxarray23_;

void InitializeModule_grid(void) {
    _mxarray0_ = mclInitializeString(126, _array1_);
    _mxarray2_ = mclInitializeString(125, _array3_);
    _mxarray4_ = mclInitializeDouble(0.0);
    _mxarray5_ = mclInitializeString(38, _array6_);
    _mxarray7_ = mclInitializeString(28, _array8_);
    _mxarray9_ = mclInitializeString(4, _array10_);
    _mxarray11_ = mclInitializeString(4, _array12_);
    _mxarray13_ = mclInitializeString(23, _array14_);
    _mxarray15_ = mclInitializeString(5, _array16_);
    _mxarray17_ = mclInitializeString(3, _array18_);
    _mxarray19_ = mclInitializeString(2, _array20_);
    _mxarray21_ = mclInitializeString(5, _array22_);
    _mxarray23_ = mclInitializeString(5, _array24_);
}

void TerminateModule_grid(void) {
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static void Mgrid(mxArray * arg1, mxArray * arg2);

_mexLocalFunctionTable _local_function_table_grid
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfGrid" contains the normal interface for the "grid"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph2d\grid.m" (lines
 * 1-81). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlfGrid(mxArray * arg1, mxArray * arg2) {
    mlfEnterNewContext(0, 2, arg1, arg2);
    Mgrid(arg1, arg2);
    mlfRestorePreviousContext(0, 2, arg1, arg2);
}

/*
 * The function "mlxGrid" contains the feval interface for the "grid"
 * M-function from file "C:\matlabR12\toolbox\matlab\graph2d\grid.m" (lines
 * 1-81). The feval function calls the implementation version of grid through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxGrid(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    int i;
    if (nlhs > 0) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    Mgrid(mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
}

/*
 * The function "Mgrid" is the implementation version of the "grid" M-function
 * from file "C:\matlabR12\toolbox\matlab\graph2d\grid.m" (lines 1-81). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function grid(arg1, arg2);
 */
static void Mgrid(mxArray * arg1, mxArray * arg2) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_grid);
    int nargin_ = mclNargin(2, arg1, arg2, NULL);
    mxArray * ans = mclGetUninitializedArray();
    mxArray * ax = mclGetUninitializedArray();
    mxArray * opt_grid = mclGetUninitializedArray();
    mclCopyArray(&arg1);
    mclCopyArray(&arg2);
    /*
     * %GRID   Grid lines.
     * %   GRID ON adds grid lines to the current axes.
     * %   GRID OFF takes them off.
     * %   GRID, by itself, toggles the grid state of the current axes.
     * %   GRID(AX,...) uses axes AX instead of the current axes.
     * %
     * %   GRID sets the XGrid, YGrid, and ZGrid properties of
     * %   the current axes.
     * %
     * %   See also TITLE, XLABEL, YLABEL, ZLABEL, AXES, PLOT.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 5.8 $  $Date: 2000/07/30 12:50:34 $
     * 
     * % To ensure the correct current handle is taken in all situations.
     * 
     * opt_grid = 0;
     */
    mlfAssign(&opt_grid, _mxarray4_);
    /*
     * if nargin == 0
     */
    if (nargin_ == 0) {
        /*
         * ax = gca;
         */
        mlfAssign(&ax, mlfGca(NULL));
    /*
     * else
     */
    } else {
        /*
         * if isempty(arg1)
         */
        if (mlfTobool(mclVe(mlfIsempty(mclVa(arg1, "arg1"))))) {
            /*
             * opt_grid = lower(arg1);
             */
            mlfAssign(&opt_grid, mlfLower(mclVa(arg1, "arg1")));
        /*
         * end
         */
        }
        /*
         * if ischar(arg1)
         */
        if (mlfTobool(mclVe(mlfIschar(mclVa(arg1, "arg1"))))) {
            /*
             * % string input (check for valid option later)
             * if nargin == 2
             */
            if (nargin_ == 2) {
                /*
                 * error('First argument must be an axes handle.')
                 */
                mlfError(_mxarray5_);
            /*
             * end
             */
            }
            /*
             * ax = gca;
             */
            mlfAssign(&ax, mlfGca(NULL));
            /*
             * opt_grid = lower(arg1);
             */
            mlfAssign(&opt_grid, mlfLower(mclVa(arg1, "arg1")));
        /*
         * else
         */
        } else {
            /*
             * % make sure non string is a scalar handle
             * if length(arg1) > 1
             */
            if (mclLengthInt(mclVa(arg1, "arg1")) > 1) {
                /*
                 * error('Axes handle must be a scalar');
                 */
                mlfError(_mxarray7_);
            /*
             * end
             */
            }
            /*
             * % handle must be a handle and axes handle
             * if ~ishandle(arg1) | ~strcmp(get(arg1, 'type'), 'axes')
             */
            {
                mxArray * a_ = mclInitialize(
                                 mclNot(
                                   mclVe(mlfIshandle(mclVa(arg1, "arg1")))));
                if (mlfTobool(a_)
                    || mlfTobool(
                         mclOr(
                           a_,
                           mclNot(
                             mclVe(
                               mlfStrcmp(
                                 mclVe(
                                   mlfNGet(
                                     1,
                                     mclVa(arg1, "arg1"), _mxarray9_, NULL)),
                                 _mxarray11_)))))) {
                    mxDestroyArray(a_);
                    /*
                     * error('First argument must be an axes handle.');
                     */
                    mlfError(_mxarray5_);
                } else {
                    mxDestroyArray(a_);
                }
            /*
             * end
             */
            }
            /*
             * ax = arg1;
             */
            mlfAssign(&ax, mclVsa(arg1, "arg1"));
            /*
             * 
             * % check for string option
             * if nargin == 2
             */
            if (nargin_ == 2) {
                /*
                 * opt_grid = lower(arg2);
                 */
                mlfAssign(&opt_grid, mlfLower(mclVa(arg2, "arg2")));
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (isempty(opt_grid))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(opt_grid, "opt_grid"))))) {
        /*
         * error('Unknown command option.');
         */
        mlfError(_mxarray13_);
    /*
     * end
     */
    }
    /*
     * 
     * if (opt_grid == 0)
     */
    if (mclEqBool(mclVv(opt_grid, "opt_grid"), _mxarray4_)) {
        /*
         * if (strcmp(get(ax,'XGrid'),'off'))
         */
        if (mlfTobool(
              mclVe(
                mlfStrcmp(
                  mclVe(mlfNGet(1, mclVv(ax, "ax"), _mxarray15_, NULL)),
                  _mxarray17_)))) {
            /*
             * set(ax,'XGrid','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(0, mclVv(ax, "ax"), _mxarray15_, _mxarray19_, NULL));
        /*
         * else
         */
        } else {
            /*
             * set(ax,'XGrid','off');
             */
            mclAssignAns(
              &ans,
              mlfNSet(0, mclVv(ax, "ax"), _mxarray15_, _mxarray17_, NULL));
        /*
         * end
         */
        }
        /*
         * if (strcmp(get(ax,'YGrid'),'off'))
         */
        if (mlfTobool(
              mclVe(
                mlfStrcmp(
                  mclVe(mlfNGet(1, mclVv(ax, "ax"), _mxarray21_, NULL)),
                  _mxarray17_)))) {
            /*
             * set(ax,'YGrid','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(0, mclVv(ax, "ax"), _mxarray21_, _mxarray19_, NULL));
        /*
         * else
         */
        } else {
            /*
             * set(ax,'YGrid','off');
             */
            mclAssignAns(
              &ans,
              mlfNSet(0, mclVv(ax, "ax"), _mxarray21_, _mxarray17_, NULL));
        /*
         * end
         */
        }
        /*
         * if (strcmp(get(ax,'ZGrid'),'off'))
         */
        if (mlfTobool(
              mclVe(
                mlfStrcmp(
                  mclVe(mlfNGet(1, mclVv(ax, "ax"), _mxarray23_, NULL)),
                  _mxarray17_)))) {
            /*
             * set(ax,'ZGrid','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(0, mclVv(ax, "ax"), _mxarray23_, _mxarray19_, NULL));
        /*
         * else
         */
        } else {
            /*
             * set(ax,'ZGrid','off');
             */
            mclAssignAns(
              &ans,
              mlfNSet(0, mclVv(ax, "ax"), _mxarray23_, _mxarray17_, NULL));
        /*
         * end
         */
        }
    /*
     * elseif (strcmp(opt_grid, 'on'))
     */
    } else if (mlfTobool(
                 mclVe(mlfStrcmp(mclVv(opt_grid, "opt_grid"), _mxarray19_)))) {
        /*
         * set(ax,'XGrid', 'on');
         */
        mclAssignAns(
          &ans, mlfNSet(0, mclVv(ax, "ax"), _mxarray15_, _mxarray19_, NULL));
        /*
         * set(ax,'YGrid', 'on');
         */
        mclAssignAns(
          &ans, mlfNSet(0, mclVv(ax, "ax"), _mxarray21_, _mxarray19_, NULL));
        /*
         * set(ax,'ZGrid', 'on');
         */
        mclAssignAns(
          &ans, mlfNSet(0, mclVv(ax, "ax"), _mxarray23_, _mxarray19_, NULL));
    /*
     * elseif (strcmp(opt_grid, 'off'))
     */
    } else if (mlfTobool(
                 mclVe(mlfStrcmp(mclVv(opt_grid, "opt_grid"), _mxarray17_)))) {
        /*
         * set(ax,'XGrid', 'off');
         */
        mclAssignAns(
          &ans, mlfNSet(0, mclVv(ax, "ax"), _mxarray15_, _mxarray17_, NULL));
        /*
         * set(ax,'YGrid', 'off');
         */
        mclAssignAns(
          &ans, mlfNSet(0, mclVv(ax, "ax"), _mxarray21_, _mxarray17_, NULL));
        /*
         * set(ax,'ZGrid', 'off');
         */
        mclAssignAns(
          &ans, mlfNSet(0, mclVv(ax, "ax"), _mxarray23_, _mxarray17_, NULL));
    /*
     * else
     */
    } else {
        /*
         * error('Unknown command option.');
         */
        mlfError(_mxarray13_);
    /*
     * end
     */
    }
    mxDestroyArray(opt_grid);
    mxDestroyArray(ax);
    mxDestroyArray(ans);
    mxDestroyArray(arg2);
    mxDestroyArray(arg1);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
