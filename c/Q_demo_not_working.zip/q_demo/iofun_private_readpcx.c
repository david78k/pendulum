/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readpcx.h"
#include "iofun_private_bitslice_mex_interface.h"
#include "iofun_private_freadu8_mex_interface.h"
#include "iofun_private_impcxinfo.h"
#include "iofun_private_pcxdrle_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'p', 'c', 'x', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'p', 'c', 'x', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'p', 'c', 'x', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'p', 'c', 'x', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't',
                                's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;
static mxArray * _mxarray7_;

static double _array9_[2] = { 1.0, 8.0 };
static mxArray * _mxarray8_;
static mxArray * _mxarray10_;
static mxArray * _mxarray11_;

static double _array13_[6] = { 0.0, 1.0, 0.0, 1.0, 0.0, 1.0 };
static mxArray * _mxarray12_;

static mxChar _array15_[58] = { 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r', 't',
                                'e', 'd', ' ', 'c', 'o', 'm', 'b', 'i', 'n',
                                'a', 't', 'i', 'o', 'n', ' ', 'o', 'f', ' ',
                                '"', 'B', 'i', 't', 'D', 'e', 'p', 't', 'h',
                                '"', ' ', 'a', 'n', 'd', ' ', '"', 'N', 'u',
                                'm', 'C', 'o', 'l', 'o', 'r', 'P', 'l', 'a',
                                'n', 'e', 's', '"' };
static mxArray * _mxarray14_;
static mxArray * _mxarray16_;

static mxChar _array18_[64] = { 'P', 'C', 'X', ' ', 'f', 'i', 'l', 'e',
                                's', ' ', 'w', 'i', 't', 'h', ' ', 'N',
                                'u', 'm', 'C', 'o', 'l', 'o', 'r', 'P',
                                'l', 'a', 'n', 'e', 's', '=', '3', ' ',
                                'a', 'n', 'd', ' ', 'B', 'i', 't', 'D',
                                'e', 'p', 't', 'h', '=', '1', ' ', 'a',
                                'r', 'e', ' ', 'n', 'o', 't', ' ', 's',
                                'u', 'p', 'p', 'o', 'r', 't', 'e', 'd' };
static mxArray * _mxarray17_;
static mxArray * _mxarray19_;

static mxChar _array21_[49] = { 'P', 'C', 'X', ' ', 'f', 'i', 'l', 'e', 's',
                                ' ', 'w', 'i', 't', 'h', ' ', 'N', 'u', 'm',
                                'C', 'o', 'l', 'o', 'r', 'P', 'l', 'a', 'n',
                                'e', 's', '=', '4', ' ', 'a', 'r', 'e', ' ',
                                'n', 'o', 't', ' ', 's', 'u', 'p', 'p', 'o',
                                'r', 't', 'e', 'd' };
static mxArray * _mxarray20_;

static mxChar _array23_[37] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                'i', 'z', 'e', 'd', ' ', 'v', 'a', 'l',
                                'u', 'e', ' ', 'f', 'o', 'r', ' ', 'N',
                                'u', 'm', 'C', 'o', 'l', 'o', 'r', 'P',
                                'l', 'a', 'n', 'e', 's' };
static mxArray * _mxarray22_;
static mxArray * _mxarray24_;
static mxArray * _mxarray25_;
static mxArray * _mxarray26_;
static mxArray * _mxarray27_;
static mxArray * _mxarray28_;
static mxArray * _mxarray29_;

static mxChar _array31_[29] = { 'N', 'o', ' ', 'c', 'o', 'l', 'o', 'r',
                                'm', 'a', 'p', ' ', 'f', 'o', 'u', 'n',
                                'd', ' ', 'i', 'n', ' ', 'P', 'C', 'X',
                                ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray30_;

void InitializeModule_iofun_private_readpcx(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
    _mxarray4_ = mclInitializeDouble(128.0);
    _mxarray5_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray6_ = mclInitializeDouble(1.0);
    _mxarray7_ = mclInitializeDouble(0.0);
    _mxarray8_ = mclInitializeDoubleVector(1, 2, _array9_);
    _mxarray10_ = mclInitializeDouble(8.0);
    _mxarray11_ = mclInitializeDouble(2.0);
    _mxarray12_ = mclInitializeDoubleVector(2, 3, _array13_);
    _mxarray14_ = mclInitializeString(58, _array15_);
    _mxarray16_ = mclInitializeDouble(3.0);
    _mxarray17_ = mclInitializeString(64, _array18_);
    _mxarray19_ = mclInitializeDouble(4.0);
    _mxarray20_ = mclInitializeString(49, _array21_);
    _mxarray22_ = mclInitializeString(37, _array23_);
    _mxarray24_ = mclInitializeDouble(12.0);
    _mxarray25_ = mclInitializeDouble(768.0);
    _mxarray26_ = mclInitializeDouble(767.0);
    _mxarray27_ = mclInitializeDouble(256.0);
    _mxarray28_ = mclInitializeDouble(255.0);
    _mxarray29_ = mclInitializeDouble(769.0);
    _mxarray30_ = mclInitializeString(29, _array31_);
}

void TerminateModule_iofun_private_readpcx(void) {
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_readpcx(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_readpcx
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNIofun_private_readpcx" contains the nargout interface for
 * the "iofun/private/readpcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpcx.m" (lines 1-90). This
 * interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNIofun_private_readpcx(int nargout,
                                    mxArray * * map,
                                    mxArray * filename) {
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, map, filename);
    X = Miofun_private_readpcx(&map__, nargout, filename);
    mlfRestorePreviousContext(1, 1, map, filename);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlfIofun_private_readpcx" contains the normal interface for
 * the "iofun/private/readpcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpcx.m" (lines 1-90). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readpcx(mxArray * * map, mxArray * filename) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, map, filename);
    if (map != NULL) {
        ++nargout;
    }
    X = Miofun_private_readpcx(&map__, nargout, filename);
    mlfRestorePreviousContext(1, 1, map, filename);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlfVIofun_private_readpcx" contains the void interface for the
 * "iofun/private/readpcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpcx.m" (lines 1-90). The void
 * interface is only produced if the M-function uses the special variable
 * "nargout", and has at least one output. The void interface function
 * specifies zero output arguments to the implementation version of the
 * function, and in the event that the implementation version still returns an
 * output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVIofun_private_readpcx(mxArray * filename) {
    mxArray * X = NULL;
    mxArray * map = NULL;
    mlfEnterNewContext(0, 1, filename);
    X = Miofun_private_readpcx(&map, 0, filename);
    mlfRestorePreviousContext(0, 1, filename);
    mxDestroyArray(X);
    mxDestroyArray(map);
}

/*
 * The function "mlxIofun_private_readpcx" contains the feval interface for the
 * "iofun/private/readpcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpcx.m" (lines 1-90). The
 * feval function calls the implementation version of iofun/private/readpcx
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readpcx(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_readpcx(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_readpcx" is the implementation version of the
 * "iofun/private/readpcx" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readpcx.m" (lines 1-90). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [X,map] = readpcx(filename)
 */
static mxArray * Miofun_private_readpcx(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readpcx);
    mxArray * X = mclGetUninitializedArray();
    mxArray * remainder = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * lookForVGAPaletteMap = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * XX = mclGetUninitializedArray();
    mxArray * lookForVGAPalette = mclGetUninitializedArray();
    mxArray * endIndex = mclGetUninitializedArray();
    mxArray * scanLineLength = mclGetUninitializedArray();
    mxArray * buffer = mclGetUninitializedArray();
    mxArray * info = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %READPCX Read image data from a PCX file.
     * %   [X,MAP] = READPCX(FILENAME) reads image data from a PCX file.
     * %   X is a uint8 array that is 2-D for indexed or grayscale image
     * %   data, and it is M-by-N-by-3 for truecolor image data. MAP is
     * %   normally an M-by-3 MATLAB colormap, but it may be empty if
     * %   the PCX file does not contain a colormap.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.9 $  $Date: 2000/06/01 04:17:01 $
     * 
     * %   Murray and vanRyper, Encyclopedia of Graphics File Formats,
     * %   2nd ed., O'Reilly, 1996.
     * 
     * info = impcxinfo(filename);
     */
    mlfAssign(
      &info, mlfIofun_private_impcxinfo(NULL, mclVa(filename, "filename")));
    /*
     * 
     * buffer = freadu8(filename, 128);
     */
    mlfAssign(
      &buffer,
      mlfNIofun_private_freadu8(
        0, mclValueVarargout(), mclVa(filename, "filename"), _mxarray4_, NULL));
    /*
     * scanLineLength = info.NumColorPlanes * info.BytesPerLine;
     */
    mlfAssign(
      &scanLineLength,
      mclFeval(
        mclValueVarargout(),
        mlxMtimes,
        mclVe(mlfIndexRef(mclVsv(info, "info"), ".NumColorPlanes")),
        mclVe(mlfIndexRef(mclVsv(info, "info"), ".BytesPerLine")),
        NULL));
    /*
     * 
     * [X, endIndex] = pcxdrle(buffer, info.Height, scanLineLength);
     */
    mlfNIofun_private_pcxdrle(
      0,
      mlfVarargout(&X, &endIndex, NULL),
      mclVv(buffer, "buffer"),
      mclVe(mlfIndexRef(mclVsv(info, "info"), ".Height")),
      mclVv(scanLineLength, "scanLineLength"),
      NULL);
    /*
     * X = X';
     */
    mlfAssign(&X, mlfCtranspose(mclVv(X, "X")));
    /*
     * 
     * map = [];
     */
    mlfAssign(map, _mxarray5_);
    /*
     * lookForVGAPalette = 1;
     */
    mlfAssign(&lookForVGAPalette, _mxarray6_);
    /*
     * switch info.NumColorPlanes
     */
    {
        mxArray * v_ = mclInitialize(
                         mclVe(
                           mlfIndexRef(
                             mclVsv(info, "info"), ".NumColorPlanes")));
        if (mclSwitchCompare(v_, _mxarray6_)) {
            /*
             * case 1
             * switch info.BitsPerPixelPerPlane
             */
            mxArray * v_0 = mclInitialize(
                              mclVe(
                                mlfIndexRef(
                                  mclVsv(info, "info"),
                                  ".BitsPerPixelPerPlane")));
            if (mclSwitchCompare(v_0, _mxarray6_)) {
                /*
                 * case 1
                 * XX = X;
                 */
                mlfAssign(&XX, mclVsv(X, "X"));
                /*
                 * X = repmat(uint8(0), size(XX) .* [1 8]);
                 */
                mlfAssign(
                  &X,
                  mlfRepmat(
                    mclVe(mlfUint8(_mxarray7_)),
                    mclTimes(
                      mclVe(
                        mlfSize(mclValueVarargout(), mclVv(XX, "XX"), NULL)),
                      _mxarray8_),
                    NULL));
                /*
                 * for k = 1:8
                 */
                {
                    int v_1 = mclForIntStart(1);
                    int e_ = mclForIntEnd(_mxarray10_);
                    if (v_1 > e_) {
                        mlfAssign(&k, _mxarray5_);
                    } else {
                        /*
                         * X(:,k:8:end) = bitslice(XX, 8-k+1, 8-k+1);
                         * end
                         */
                        for (; ; ) {
                            mclArrayAssign2(
                              &X,
                              mlfNIofun_private_bitslice(
                                0,
                                mclValueVarargout(),
                                mclVv(XX, "XX"),
                                mlfScalar(8 - v_1 + 1),
                                mlfScalar(8 - v_1 + 1),
                                NULL),
                              mlfCreateColonIndex(),
                              mlfColon(
                                mlfScalar(v_1),
                                _mxarray10_,
                                mlfEnd(
                                  mclVv(X, "X"), _mxarray11_, _mxarray11_)));
                            if (v_1 == e_) {
                                break;
                            }
                            ++v_1;
                        }
                        mlfAssign(&k, mlfScalar(v_1));
                    }
                }
                /*
                 * lookForVGAPaletteMap = 1;
                 */
                mlfAssign(&lookForVGAPaletteMap, _mxarray6_);
                /*
                 * map = [0 0 0; 1 1 1];     % In case a palette isn't found later.
                 */
                mlfAssign(map, _mxarray12_);
            /*
             * 
             * case 8
             */
            } else if (mclSwitchCompare(v_0, _mxarray10_)) {
            /*
             * % Nothing to do
             * 
             * otherwise
             */
            } else {
                /*
                 * error('Unsupported combination of "BitDepth" and "NumColorPlanes"');
                 */
                mlfError(_mxarray14_);
            /*
             * end
             */
            }
            mxDestroyArray(v_0);
        /*
         * 
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray16_)) {
            /*
             * switch info.BitsPerPixelPerPlane
             */
            mxArray * v_2 = mclInitialize(
                              mclVe(
                                mlfIndexRef(
                                  mclVsv(info, "info"),
                                  ".BitsPerPixelPerPlane")));
            if (mclSwitchCompare(v_2, _mxarray6_)) {
                /*
                 * case 1
                 * error('PCX files with NumColorPlanes=3 and BitDepth=1 are not supported');
                 */
                mlfError(_mxarray17_);
            /*
             * 
             * case 8
             */
            } else if (mclSwitchCompare(v_2, _mxarray10_)) {
                /*
                 * X = reshape(X, [size(X,1) size(X,2)/3 3]);
                 */
                mlfAssign(
                  &X,
                  mlfReshape(
                    mclVv(X, "X"),
                    mlfHorzcat(
                      mclVe(
                        mlfSize(
                          mclValueVarargout(), mclVv(X, "X"), _mxarray6_)),
                      mclMrdivide(
                        mclVe(
                          mlfSize(
                            mclValueVarargout(), mclVv(X, "X"), _mxarray11_)),
                        _mxarray16_),
                      _mxarray16_,
                      NULL),
                    NULL));
                /*
                 * lookForVGAPalette = 1;
                 */
                mlfAssign(&lookForVGAPalette, _mxarray6_);
            /*
             * 
             * otherwise
             */
            } else {
                /*
                 * error('Unsupported combination of "BitDepth" and "NumColorPlanes"');
                 */
                mlfError(_mxarray14_);
            /*
             * end
             */
            }
            mxDestroyArray(v_2);
        /*
         * 
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray19_)) {
            /*
             * error('PCX files with NumColorPlanes=4 are not supported');
             */
            mlfError(_mxarray20_);
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * error('Unrecognized value for NumColorPlanes');
             */
            mlfError(_mxarray22_);
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * if (info.Width ~= size(X,2))
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxNe,
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".Width")),
            mclVe(mlfSize(mclValueVarargout(), mclVv(X, "X"), _mxarray11_)),
            NULL))) {
        /*
         * X = X(:,1:info.Width,:);
         */
        mlfAssign(
          &X,
          mlfIndexRef(
            mclVsv(X, "X"),
            "(?,?,?)",
            mlfCreateColonIndex(),
            mclFeval(
              mclValueVarargout(),
              mlxColon,
              _mxarray6_,
              mclVe(mlfIndexRef(mclVsv(info, "info"), ".Width")),
              NULL),
            mlfCreateColonIndex()));
    /*
     * end
     */
    }
    /*
     * 
     * if (lookForVGAPalette)
     */
    if (mlfTobool(mclVv(lookForVGAPalette, "lookForVGAPalette"))) {
        /*
         * % double called in the next line because == isn't supported
         * % for uint8's in MATLAB 5.0.
         * remainder = length(buffer) - endIndex;
         */
        mlfAssign(
          &remainder,
          mclMinus(
            mlfScalar(mclLengthInt(mclVv(buffer, "buffer"))),
            mclVv(endIndex, "endIndex")));
        /*
         * if (((remainder == 769) & (double(buffer(endIndex+1)) == 12)) | ...
         */
        {
            mxArray * a_ = mclInitialize(
                             mclEq(mclVv(remainder, "remainder"), _mxarray29_));
            if (mlfTobool(a_)) {
                mlfAssign(
                  &a_,
                  mclAnd(
                    a_,
                    mclEq(
                      mclVe(
                        mlfDouble(
                          mclVe(
                            mclArrayRef1(
                              mclVsv(buffer, "buffer"),
                              mclPlus(
                                mclVv(endIndex, "endIndex"), _mxarray6_))))),
                      _mxarray24_)));
            } else {
                mlfAssign(&a_, mlfScalar(0));
            }
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclEq(mclVv(remainder, "remainder"), _mxarray25_)))) {
                mxDestroyArray(a_);
                /*
                 * (remainder == 768))
                 * % For "real" PCX files, remainder should be 769 if there's
                 * % a colormap. However, pcxwrite in IPT v1 failed to write the
                 * % 0Cx value in the byte before colormap.  For those
                 * % files, remainder will be 768 and there's no 0Cx code.  -SLE
                 * map = buffer(end-767:end);
                 */
                mlfAssign(
                  map,
                  mclArrayRef1(
                    mclVsv(buffer, "buffer"),
                    mlfColon(
                      mclMinus(
                        mlfEnd(mclVv(buffer, "buffer"), _mxarray6_, _mxarray6_),
                        _mxarray26_),
                      mlfEnd(mclVv(buffer, "buffer"), _mxarray6_, _mxarray6_),
                      NULL)));
                /*
                 * map = double(reshape(map,3,256)')/255;
                 */
                mlfAssign(
                  map,
                  mclMrdivide(
                    mclVe(
                      mlfDouble(
                        mlfCtranspose(
                          mclVe(
                            mlfReshape(
                              mclVv(*map, "map"),
                              _mxarray16_, _mxarray27_, NULL))))),
                    _mxarray28_));
            } else {
                mxDestroyArray(a_);
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ((nargout > 1) & (isempty(map)))
     */
    {
        mxArray * a_ = mclInitialize(mclBoolToArray(nargout_ > 1));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclVe(mlfIsempty(mclVv(*map, "map")))))) {
            mxDestroyArray(a_);
            /*
             * warning('No colormap found in PCX file');
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray30_));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "iofun/private/readpcx");
    mclValidateOutput(*map, 2, nargout_, "map", "iofun/private/readpcx");
    mxDestroyArray(info);
    mxDestroyArray(buffer);
    mxDestroyArray(scanLineLength);
    mxDestroyArray(endIndex);
    mxDestroyArray(lookForVGAPalette);
    mxDestroyArray(XX);
    mxDestroyArray(k);
    mxDestroyArray(lookForVGAPaletteMap);
    mxDestroyArray(ans);
    mxDestroyArray(remainder);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
}
