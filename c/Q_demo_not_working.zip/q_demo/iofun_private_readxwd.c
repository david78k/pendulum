/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readxwd.h"
#include "iofun_private_imxwdinfo.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'x', 'w', 'd', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'x', 'w', 'd', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'x', 'w', 'd', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'x', 'w', 'd', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't',
                                's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[1] = { 'r' };
static mxArray * _mxarray5_;

static mxChar _array8_[7] = { 'i', 'e', 'e', 'e', '-', 'l', 'e' };
static mxArray * _mxarray7_;
static mxArray * _mxarray9_;

static mxChar _array11_[7] = { 'i', 'e', 'e', 'e', '-', 'b', 'e' };
static mxArray * _mxarray10_;

static mxChar _array13_[37] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                'i', 'z', 'e', 'd', ' ', 'v', 'a', 'l',
                                'u', 'e', ' ', 'i', 'n', ' ', 'B', 'y',
                                't', 'e', 'O', 'r', 'd', 'e', 'r', ' ',
                                'f', 'i', 'e', 'l', 'd' };
static mxArray * _mxarray12_;
static mxArray * _mxarray14_;

static mxChar _array16_[30] = { '%', 'd', '-', 'b', 'i', 't', ' ', 'X',
                                'Y', 'p', 'i', 'x', 'm', 'a', 'p', 's',
                                ' ', 'n', 'o', 't', ' ', 's', 'u', 'p',
                                'p', 'o', 'r', 't', 'e', 'd' };
static mxArray * _mxarray15_;

static mxChar _array18_[8] = { 'X', 'Y', 'P', 'i', 'x', 'm', 'a', 'p' };
static mxArray * _mxarray17_;

static mxChar _array20_[3] = { 'b', 'o', 'f' };
static mxArray * _mxarray19_;
static mxArray * _mxarray21_;

static mxChar _array23_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray22_;
static mxArray * _mxarray24_;
static mxArray * _mxarray25_;
static mxArray * _mxarray26_;
static mxArray * _mxarray27_;

static mxChar _array29_[8] = { 'X', 'Y', 'B', 'i', 't', 'm', 'a', 'p' };
static mxArray * _mxarray28_;

static double _array31_[2] = { 1.0, 8.0 };
static mxArray * _mxarray30_;

static mxChar _array33_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray32_;

static mxChar _array35_[29] = { '%', 'd', '-', 'b', 'i', 't', ' ', 'Z',
                                'p', 'i', 'x', 'm', 'a', 'p', 's', ' ',
                                'n', 'o', 't', ' ', 's', 'u', 'p', 'p',
                                'o', 'r', 't', 'e', 'd' };
static mxArray * _mxarray34_;
static mxArray * _mxarray36_;
static mxArray * _mxarray37_;
static mxArray * _mxarray38_;

static double _array40_[8] = { 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0 };
static mxArray * _mxarray39_;

static mxChar _array42_[23] = { '%', 'd', '-', 'b', 'i', 't', ' ', '%',
                                's', ' ', 'n', 'o', 't', ' ', 's', 'u',
                                'p', 'p', 'o', 'r', 't', 'e', 'd' };
static mxArray * _mxarray41_;

static mxChar _array44_[7] = { 'Z', 'P', 'i', 'x', 'm', 'a', 'p' };
static mxArray * _mxarray43_;
static mxArray * _mxarray45_;

void InitializeModule_iofun_private_readxwd(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
    _mxarray4_ = mclInitializeDouble(0.0);
    _mxarray5_ = mclInitializeString(1, _array6_);
    _mxarray7_ = mclInitializeString(7, _array8_);
    _mxarray9_ = mclInitializeDouble(1.0);
    _mxarray10_ = mclInitializeString(7, _array11_);
    _mxarray12_ = mclInitializeString(37, _array13_);
    _mxarray14_ = mclInitializeDouble(-1.0);
    _mxarray15_ = mclInitializeString(30, _array16_);
    _mxarray17_ = mclInitializeString(8, _array18_);
    _mxarray19_ = mclInitializeString(3, _array20_);
    _mxarray21_ = mclInitializeDouble(6.0);
    _mxarray22_ = mclInitializeString(6, _array23_);
    _mxarray24_ = mclInitializeDouble(2.0);
    _mxarray25_ = mclInitializeDouble(65535.0);
    _mxarray26_ = mclInitializeDouble(3.0);
    _mxarray27_ = mclInitializeDouble(5.0);
    _mxarray28_ = mclInitializeString(8, _array29_);
    _mxarray30_ = mclInitializeDoubleVector(1, 2, _array31_);
    _mxarray32_ = mclInitializeString(5, _array33_);
    _mxarray34_ = mclInitializeString(29, _array35_);
    _mxarray36_ = mclInitializeDouble(8.0);
    _mxarray37_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray38_ = mclInitializeDouble(7.0);
    _mxarray39_ = mclInitializeDoubleVector(2, 4, _array40_);
    _mxarray41_ = mclInitializeString(23, _array42_);
    _mxarray43_ = mclInitializeString(7, _array44_);
    _mxarray45_ = mclInitializeDouble(4.0);
}

void TerminateModule_iofun_private_readxwd(void) {
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_readxwd(mxArray * * CM,
                                        int nargout_,
                                        mxArray * fname);

_mexLocalFunctionTable _local_function_table_iofun_private_readxwd
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_readxwd" contains the normal interface for
 * the "iofun/private/readxwd" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readxwd.m" (lines 1-86). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readxwd(mxArray * * CM, mxArray * fname) {
    int nargout = 1;
    mxArray * M = mclGetUninitializedArray();
    mxArray * CM__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, CM, fname);
    if (CM != NULL) {
        ++nargout;
    }
    M = Miofun_private_readxwd(&CM__, nargout, fname);
    mlfRestorePreviousContext(1, 1, CM, fname);
    if (CM != NULL) {
        mclCopyOutputArg(CM, CM__);
    } else {
        mxDestroyArray(CM__);
    }
    return mlfReturnValue(M);
}

/*
 * The function "mlxIofun_private_readxwd" contains the feval interface for the
 * "iofun/private/readxwd" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readxwd.m" (lines 1-86). The
 * feval function calls the implementation version of iofun/private/readxwd
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readxwd(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_readxwd(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_readxwd" is the implementation version of the
 * "iofun/private/readxwd" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readxwd.m" (lines 1-86). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [M,CM] = readxwd(fname)
 */
static mxArray * Miofun_private_readxwd(mxArray * * CM,
                                        int nargout_,
                                        mxArray * fname) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readxwd);
    mxArray * M = mclGetUninitializedArray();
    mxArray * i = mclGetUninitializedArray();
    mxArray * P = mclGetUninitializedArray();
    mxArray * b = mclGetUninitializedArray();
    mxArray * a = mclGetUninitializedArray();
    mxArray * pad = mclGetUninitializedArray();
    mxArray * prec = mclGetUninitializedArray();
    mxArray * tmp = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * message = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mxArray * info = mclGetUninitializedArray();
    mclCopyArray(&fname);
    /*
     * %READXWD Read image data from an XWD file.
     * %   [X,MAP] = READPCX(FILENAME) reads image data from a PCX file.
     * %   X is a 2-D uint8 array.  MAP is an M-by-3 MATLAB-style
     * %   colormap.  XWDREAD can the following types of XWD files:
     * %    1-bit or 8-bit ZPixmaps
     * %    XYBitmaps
     * %    1-bit XYPixmaps
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.8 $  $Date: 2000/06/01 04:17:05 $
     * 
     * %   Reference:  Murray and vanRyper, Encyclopedia of Graphics
     * %   File Formats, 2nd ed, O'Reilly, 1996.
     * 
     * info = imxwdinfo(fname);
     */
    mlfAssign(&info, mlfIofun_private_imxwdinfo(NULL, mclVa(fname, "fname")));
    /*
     * 
     * if (info.ByteOrder == 0)
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxEq,
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".ByteOrder")),
            _mxarray4_,
            NULL))) {
        /*
         * [fid, message] = fopen(fname, 'r', 'ieee-le');
         */
        mlfAssign(
          &fid,
          mlfFopen(
            &message, NULL, mclVa(fname, "fname"), _mxarray5_, _mxarray7_));
    /*
     * elseif (info.ByteOrder == 1)
     */
    } else if (mlfTobool(
                 mclFeval(
                   mclValueVarargout(),
                   mlxEq,
                   mclVe(mlfIndexRef(mclVsv(info, "info"), ".ByteOrder")),
                   _mxarray9_,
                   NULL))) {
        /*
         * [fid, message] = fopen(fname, 'r', 'ieee-be');
         */
        mlfAssign(
          &fid,
          mlfFopen(
            &message, NULL, mclVa(fname, "fname"), _mxarray5_, _mxarray10_));
    /*
     * else
     */
    } else {
        /*
         * error('Unrecognized value in ByteOrder field');
         */
        mlfError(_mxarray12_);
    /*
     * end
     */
    }
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray14_)) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"));
    /*
     * end
     */
    }
    /*
     * 
     * % See if it is an XYPixmap (unsupported)
     * if (strcmp(info.PixmapFormat, 'XYPixmap') & (info.PixmapDepth ~= 1))
     */
    {
        mxArray * a_ = mclInitialize(
                         mclVe(
                           mclFeval(
                             mclValueVarargout(),
                             mlxStrcmp,
                             mclVe(
                               mlfIndexRef(
                                 mclVsv(info, "info"), ".PixmapFormat")),
                             _mxarray17_,
                             NULL)));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxNe,
                     mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                     _mxarray9_,
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * message = sprintf('%d-bit XYpixmaps not supported', info.PixmapDepth);
             */
            mlfAssign(
              &message,
              mlfSprintf(
                NULL,
                _mxarray15_,
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                NULL));
            /*
             * error(message);
             */
            mlfError(mclVv(message, "message"));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * fseek(fid, info.HeaderSize, 'bof');
     */
    mclAssignAns(
      &ans,
      mclFeval(
        mclAnsVarargout(),
        mlxFseek,
        mclVv(fid, "fid"),
        mclVe(mlfIndexRef(mclVsv(info, "info"), ".HeaderSize")),
        _mxarray19_,
        NULL));
    /*
     * tmp = fread(fid,[6 info.NumColormapEntries],'uint16');
     */
    mlfAssign(
      &tmp,
      mlfFread(
        NULL,
        mclVv(fid, "fid"),
        mlfHorzcat(
          _mxarray21_,
          mclVe(mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
          NULL),
        _mxarray22_,
        NULL));
    /*
     * CM = [(tmp(2,:)+tmp(1,:)*65535)',tmp(3:5,:)'/65535];
     */
    mlfAssign(
      CM,
      mlfHorzcat(
        mlfCtranspose(
          mclPlus(
            mclVe(
              mclArrayRef2(
                mclVsv(tmp, "tmp"), _mxarray24_, mlfCreateColonIndex())),
            mclMtimes(
              mclVe(
                mclArrayRef2(
                  mclVsv(tmp, "tmp"), _mxarray9_, mlfCreateColonIndex())),
              _mxarray25_))),
        mclMrdivide(
          mlfCtranspose(
            mclVe(
              mclArrayRef2(
                mclVsv(tmp, "tmp"),
                mlfColon(_mxarray26_, _mxarray27_, NULL),
                mlfCreateColonIndex()))),
          _mxarray25_),
        NULL));
    /*
     * 
     * % What storage format is the data in?
     * if (strcmp(info.PixmapFormat, 'ZPixmap') | ...
     */
    {
        mxArray * a_ = mclInitialize(
                         mclVe(
                           mclFeval(
                             mclValueVarargout(),
                             mlxStrcmp,
                             mclVe(
                               mlfIndexRef(
                                 mclVsv(info, "info"), ".PixmapFormat")),
                             _mxarray43_,
                             NULL)));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_,
              mclOr(
                a_,
                mclVe(
                  mclFeval(
                    mclValueVarargout(),
                    mlxStrcmp,
                    mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapFormat")),
                    _mxarray28_,
                    NULL))));
        }
        if (mlfTobool(a_)) {
        } else {
            /*
             * strcmp(info.PixmapFormat, 'XYBitmap') | ...
             * (strcmp(info.PixmapFormat, 'XYPixmap') & (info.PixmapDepth == 1)))
             */
            mxArray * b_ = mclInitialize(
                             mclVe(
                               mclFeval(
                                 mclValueVarargout(),
                                 mlxStrcmp,
                                 mclVe(
                                   mlfIndexRef(
                                     mclVsv(info, "info"), ".PixmapFormat")),
                                 _mxarray17_,
                                 NULL)));
            if (mlfTobool(b_)) {
                mlfAssign(
                  &b_,
                  mclAnd(
                    b_,
                    mclFeval(
                      mclValueVarargout(),
                      mlxEq,
                      mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                      _mxarray9_,
                      NULL)));
            } else {
                mlfAssign(&b_, mlfScalar(0));
            }
            {
                unsigned char c_0 = mlfTobool(mclOr(a_, b_));
                mxDestroyArray(b_);
                if (c_0) {
                } else {
                    goto l0_;
                }
            }
        }
        mxDestroyArray(a_);
        /*
         * % ZPixmap,  XYbitmap or XYpixmap depth 1
         * % Size of pixels
         * if (ismember(info.PixmapDepth, [1 8]))
         */
        if (mlfTobool(
              mclVe(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsmember,
                  mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                  _mxarray30_,
                  NULL)))) {
            /*
             * prec = 'uint8';
             */
            mlfAssign(&prec, _mxarray32_);
        /*
         * else
         */
        } else {
            /*
             * message = sprintf('%d-bit Zpixmaps not supported', info.PixmapDepth);
             */
            mlfAssign(
              &message,
              mlfSprintf(
                NULL,
                _mxarray34_,
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                NULL));
            /*
             * error(message);
             */
            mlfError(mclVv(message, "message"));
        /*
         * end
         */
        }
        /*
         * 
         * if (info.PixmapDepth == 8), % ZPixmap with depth 8
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxEq,
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                _mxarray36_,
                NULL))) {
            /*
             * pad = ceil(info.Width/info.BitmapPad*info.PixmapDepth) * ...
             */
            mlfAssign(
              &pad,
              mclFeval(
                mclValueVarargout(),
                mlxMinus,
                mclFeval(
                  mclValueVarargout(),
                  mlxMrdivide,
                  mclFeval(
                    mclValueVarargout(),
                    mlxMtimes,
                    mclVe(
                      mlfCeil(
                        mclFeval(
                          mclValueVarargout(),
                          mlxMtimes,
                          mclFeval(
                            mclValueVarargout(),
                            mlxMrdivide,
                            mclVe(mlfIndexRef(mclVsv(info, "info"), ".Width")),
                            mclVe(
                              mlfIndexRef(mclVsv(info, "info"), ".BitmapPad")),
                            NULL),
                          mclVe(
                            mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                          NULL))),
                    mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitmapPad")),
                    NULL),
                  mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
                  NULL),
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".Width")),
                NULL));
            /*
             * info.BitmapPad/info.PixmapDepth - info.Width;
             * M = uint8(fread(fid,[info.Width+pad info.Height], prec))';
             */
            mlfAssign(
              &M,
              mlfCtranspose(
                mclVe(
                  mlfUint8(
                    mclVe(
                      mlfFread(
                        NULL,
                        mclVv(fid, "fid"),
                        mlfHorzcat(
                          mclFeval(
                            mclValueVarargout(),
                            mlxPlus,
                            mclVe(mlfIndexRef(mclVsv(info, "info"), ".Width")),
                            mclVv(pad, "pad"),
                            NULL),
                          mclVe(mlfIndexRef(mclVsv(info, "info"), ".Height")),
                          NULL),
                        mclVv(prec, "prec"),
                        NULL))))));
        /*
         * else      
         */
        } else {
            /*
             * % ZBitmap XYPitmap or XYPixmap of depth 1
             * M = fread(fid,[info.Width/8 info.Height],'uint8')';
             */
            mlfAssign(
              &M,
              mlfCtranspose(
                mclVe(
                  mlfFread(
                    NULL,
                    mclVv(fid, "fid"),
                    mlfHorzcat(
                      mclFeval(
                        mclValueVarargout(),
                        mlxMrdivide,
                        mclVe(mlfIndexRef(mclVsv(info, "info"), ".Width")),
                        _mxarray36_,
                        NULL),
                      mclVe(mlfIndexRef(mclVsv(info, "info"), ".Height")),
                      NULL),
                    _mxarray32_,
                    NULL))));
            /*
             * 
             * % Take apart bytes into 8 bits and store as a matrix of 1's and 0's
             * [a,b]=size(M);
             */
            mlfSize(mlfVarargout(&a, &b, NULL), mclVv(M, "M"), NULL);
            /*
             * P=logical(repmat(uint8(0), a, b*8));
             */
            mlfAssign(
              &P,
              mlfLogical(
                mclVe(
                  mlfRepmat(
                    mclVe(mlfUint8(_mxarray4_)),
                    mclVv(a, "a"),
                    mclMtimes(mclVv(b, "b"), _mxarray36_)))));
            /*
             * for i=7:-1:0,
             */
            {
                int v_ = mclForIntStart(7);
                int i_ = -1;
                int e_ = mclForIntIntEnd(v_, i_, _mxarray4_);
                if (e_ == mclIntMin()) {
                    mlfAssign(&i, _mxarray37_);
                } else {
                    /*
                     * tmp=find(M/2^i >= 1);
                     * if ~isempty(tmp),
                     * M(tmp)=M(tmp)-2^i;
                     * P(tmp+ceil(tmp/a)*(7*a)+(-i)*a+a*(2*i-7) * ...
                     * (~info.BitmapBitOrder)) = 1;
                     * end
                     * end
                     */
                    for (; ; ) {
                        mlfAssign(
                          &tmp,
                          mlfFind(
                            NULL,
                            NULL,
                            mclGe(
                              mclMrdivide(
                                mclVv(M, "M"),
                                mclMpower(_mxarray24_, mlfScalar(v_))),
                              _mxarray9_)));
                        if (mclNotBool(mclVe(mlfIsempty(mclVv(tmp, "tmp"))))) {
                            mclArrayAssign1(
                              &M,
                              mclMinus(
                                mclVe(
                                  mclArrayRef1(
                                    mclVsv(M, "M"), mclVsv(tmp, "tmp"))),
                                mclMpower(_mxarray24_, mlfScalar(v_))),
                              mclVsv(tmp, "tmp"));
                            mclArrayAssign1(
                              &P,
                              _mxarray9_,
                              mclPlus(
                                mclPlus(
                                  mclPlus(
                                    mclVv(tmp, "tmp"),
                                    mclMtimes(
                                      mclVe(
                                        mlfCeil(
                                          mclMrdivide(
                                            mclVv(tmp, "tmp"), mclVv(a, "a")))),
                                      mclMtimes(_mxarray38_, mclVv(a, "a")))),
                                  mclMtimes(
                                    mclUminus(mlfScalar(v_)), mclVv(a, "a"))),
                                mclMtimes(
                                  mclMtimes(
                                    mclVv(a, "a"),
                                    mclMinus(
                                      mclMtimes(_mxarray24_, mlfScalar(v_)),
                                      _mxarray38_)),
                                  mclFeval(
                                    mclValueVarargout(),
                                    mlxNot,
                                    mclVe(
                                      mlfIndexRef(
                                        mclVsv(info, "info"),
                                        ".BitmapBitOrder")),
                                    NULL))));
                        }
                        if (v_ == e_) {
                            break;
                        }
                        v_ += i_;
                    }
                    mlfAssign(&i, mlfScalar(v_));
                }
            }
            /*
             * CM=[0 1 1 1;1 0 0 0];
             */
            mlfAssign(CM, _mxarray39_);
            /*
             * M=P;
             */
            mlfAssign(&M, mclVsv(P, "P"));
        /*
         * end
         */
        }
        goto done_;
        l0_:
        mxDestroyArray(a_);
        /*
         * 
         * else
         * message = sprintf('%d-bit %s not supported', info.PixmapDepth, ...
         */
        mlfAssign(
          &message,
          mlfSprintf(
            NULL,
            _mxarray41_,
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapDepth")),
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".PixmapFormat")),
            NULL));
        /*
         * info.PixmapFormat);
         * error(message);
         */
        mlfError(mclVv(message, "message"));
        /*
         * end
         */
        done_:;
    }
    /*
     * 
     * CM=CM(:,2:4);
     */
    mlfAssign(
      CM,
      mclArrayRef2(
        mclVsv(*CM, "CM"),
        mlfCreateColonIndex(),
        mlfColon(_mxarray24_, _mxarray45_, NULL)));
    /*
     * 
     * fclose(fid);
     */
    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    mclValidateOutput(M, 1, nargout_, "M", "iofun/private/readxwd");
    mclValidateOutput(*CM, 2, nargout_, "CM", "iofun/private/readxwd");
    mxDestroyArray(info);
    mxDestroyArray(fid);
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(tmp);
    mxDestroyArray(prec);
    mxDestroyArray(pad);
    mxDestroyArray(a);
    mxDestroyArray(b);
    mxDestroyArray(P);
    mxDestroyArray(i);
    mxDestroyArray(fname);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return M;
}
