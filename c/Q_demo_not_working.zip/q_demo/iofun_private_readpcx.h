/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __iofun_private_readpcx_h
#define __iofun_private_readpcx_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_iofun_private_readpcx(void);
extern void TerminateModule_iofun_private_readpcx(void);
extern _mexLocalFunctionTable _local_function_table_iofun_private_readpcx;

extern mxArray * mlfNIofun_private_readpcx(int nargout,
                                           mxArray * * map,
                                           mxArray * filename);
extern mxArray * mlfIofun_private_readpcx(mxArray * * map, mxArray * filename);
extern void mlfVIofun_private_readpcx(mxArray * filename);
extern void mlxIofun_private_readpcx(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
