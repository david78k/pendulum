/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imhdfinfo.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'h', 'd', 'f', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'h', 'd', 'f', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'h', 'd', 'f', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'h', 'd', 'f', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;

static mxChar _array5_[156] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                'i', 'n', 'f', 'o', '/', 'h', 'd', 'f', 'e',
                                'r', 'r', 'o', 'r', ' ', 'L', 'i', 'n', 'e',
                                ':', ' ', '2', '1', '9', ' ', 'C', 'o', 'l',
                                'u', 'm', 'n', ':', ' ', '1', ' ', 'T', 'h',
                                'e', ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o',
                                'n', ' ', '"', 'i', 'm', 'h', 'd', 'f', 'i',
                                'n', 'f', 'o', '/', 'h', 'd', 'f', 'e', 'r',
                                'r', 'o', 'r', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'o', 'u', 't', 'p', 'u', 't', 's', ' ', '(',
                                '1', ')', '.' };
static mxArray * _mxarray4_;

static mxChar _array7_[155] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                'i', 'n', 'f', 'o', '/', 'h', 'd', 'f', 'e',
                                'r', 'r', 'o', 'r', ' ', 'L', 'i', 'n', 'e',
                                ':', ' ', '2', '1', '9', ' ', 'C', 'o', 'l',
                                'u', 'm', 'n', ':', ' ', '1', ' ', 'T', 'h',
                                'e', ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o',
                                'n', ' ', '"', 'i', 'm', 'h', 'd', 'f', 'i',
                                'n', 'f', 'o', '/', 'h', 'd', 'f', 'e', 'r',
                                'r', 'o', 'r', '"', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i',
                                't', 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't',
                                'h', 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd',
                                'e', 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'i', 'n', 'p', 'u', 't', 's', ' ', '(', '0',
                                ')', '.' };
static mxArray * _mxarray6_;

static mxChar _array9_[154] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                'i', 'n', 'f', 'o', '/', 'n', 'u', 'm', 'c',
                                'o', 'm', 'p', ' ', 'L', 'i', 'n', 'e', ':',
                                ' ', '2', '2', '9', ' ', 'C', 'o', 'l', 'u',
                                'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '"', 'i', 'm', 'h', 'd', 'f', 'i', 'n',
                                'f', 'o', '/', 'n', 'u', 'm', 'c', 'o', 'm',
                                'p', '"', ' ', 'w', 'a', 's', ' ', 'c', 'a',
                                'l', 'l', 'e', 'd', ' ', 'w', 'i', 't', 'h',
                                ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h', 'a',
                                'n', ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c',
                                'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm',
                                'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o', 'u',
                                't', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray8_;

static mxChar _array11_[153] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                 'i', 'n', 'f', 'o', '/', 'n', 'u', 'm', 'c',
                                 'o', 'm', 'p', ' ', 'L', 'i', 'n', 'e', ':',
                                 ' ', '2', '2', '9', ' ', 'C', 'o', 'l', 'u',
                                 'm', 'n', ':', ' ', '1', ' ', 'T', 'h', 'e',
                                 ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                 ' ', '"', 'i', 'm', 'h', 'd', 'f', 'i', 'n',
                                 'f', 'o', '/', 'n', 'u', 'm', 'c', 'o', 'm',
                                 'p', '"', ' ', 'w', 'a', 's', ' ', 'c', 'a',
                                 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't', 'h',
                                 ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h', 'a',
                                 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c',
                                 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm',
                                 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i', 'n',
                                 'p', 'u', 't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray10_;

static mxChar _array13_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                 'i', 'n', 'f', 'o', '/', 'U', 'i', 'n', 't',
                                 '1', '6', 'D', 'e', 'c', 'o', 'd', 'e', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '7', '3',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'h', 'd', 'f', 'i', 'n', 'f', 'o', '/', 'U',
                                 'i', 'n', 't', '1', '6', 'D', 'e', 'c', 'o',
                                 'd', 'e', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                 ')', '.' };
static mxArray * _mxarray12_;

static mxChar _array15_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                 'i', 'n', 'f', 'o', '/', 'U', 'i', 'n', 't',
                                 '1', '6', 'D', 'e', 'c', 'o', 'd', 'e', ' ',
                                 'L', 'i', 'n', 'e', ':', ' ', '2', '7', '3',
                                 ' ', 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ',
                                 '1', ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n',
                                 'c', 't', 'i', 'o', 'n', ' ', '"', 'i', 'm',
                                 'h', 'd', 'f', 'i', 'n', 'f', 'o', '/', 'U',
                                 'i', 'n', 't', '1', '6', 'D', 'e', 'c', 'o',
                                 'd', 'e', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                 'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                 'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                 'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                 'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                 'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                 '.' };
static mxArray * _mxarray14_;

static mxChar _array17_[162] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                 'i', 'n', 'f', 'o', '/', 'C', 'o', 'u', 'n',
                                 't', 'I', 'm', 'a', 'g', 'e', 's', ' ', 'L',
                                 'i', 'n', 'e', ':', ' ', '2', '8', '3', ' ',
                                 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                 ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                 't', 'i', 'o', 'n', ' ', '"', 'i', 'm', 'h',
                                 'd', 'f', 'i', 'n', 'f', 'o', '/', 'C', 'o',
                                 'u', 'n', 't', 'I', 'm', 'a', 'g', 'e', 's',
                                 '"', ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l',
                                 'l', 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ',
                                 'm', 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n',
                                 ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l',
                                 'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b',
                                 'e', 'r', ' ', 'o', 'f', ' ', 'o', 'u', 't',
                                 'p', 'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray16_;

static mxChar _array19_[161] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                 'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                 'l', 'e', ':', ' ', 'i', 'm', 'h', 'd', 'f',
                                 'i', 'n', 'f', 'o', '/', 'C', 'o', 'u', 'n',
                                 't', 'I', 'm', 'a', 'g', 'e', 's', ' ', 'L',
                                 'i', 'n', 'e', ':', ' ', '2', '8', '3', ' ',
                                 'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                 ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                 't', 'i', 'o', 'n', ' ', '"', 'i', 'm', 'h',
                                 'd', 'f', 'i', 'n', 'f', 'o', '/', 'C', 'o',
                                 'u', 'n', 't', 'I', 'm', 'a', 'g', 'e', 's',
                                 '"', ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l',
                                 'l', 'e', 'd', ' ', 'w', 'i', 't', 'h', ' ',
                                 'm', 'o', 'r', 'e', ' ', 't', 'h', 'a', 'n',
                                 ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c', 'l',
                                 'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b',
                                 'e', 'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p',
                                 'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray18_;
static mxArray * _mxarray20_;
static mxArray * _mxarray21_;

static mxChar _array23_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                                ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray22_;

static mxChar _array25_[1] = { 'r' };
static mxArray * _mxarray24_;

static mxChar _array27_[7] = { 'i', 'e', 'e', 'e', '-', 'b', 'e' };
static mxArray * _mxarray26_;
static mxArray * _mxarray28_;
static mxArray * _mxarray29_;

static mxChar _array31_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray30_;

static mxChar _array33_[16] = { 'T', 'r', 'u', 'n', 'c', 'a', 't', 'e',
                                'd', ' ', 'h', 'e', 'a', 'd', 'e', 'r' };
static mxArray * _mxarray32_;
static mxArray * _mxarray34_;

static mxChar _array36_[15] = { 'N', 'o', 't', ' ', 'a', 'n', ' ', 'H',
                                'D', 'F', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray35_;
static mxArray * _mxarray37_;
static mxArray * _mxarray38_;
static mxArray * _mxarray39_;

static mxChar _array41_[3] = { 'h', 'd', 'f' };
static mxArray * _mxarray40_;

static mxChar _array43_[1] = { 'H' };
static mxArray * _mxarray42_;

static mxChar _array45_[5] = { 'i', 's', 'h', 'd', 'f' };
static mxArray * _mxarray44_;

static double _array47_[4] = { 14.0, 3.0, 19.0, 1.0 };
static mxArray * _mxarray46_;

static mxChar _array49_[4] = { 'D', 'F', 'R', '8' };
static mxArray * _mxarray48_;

static mxChar _array51_[7] = { 'r', 'e', 's', 't', 'a', 'r', 't' };
static mxArray * _mxarray50_;

static mxChar _array53_[4] = { 'D', 'F', '2', '4' };
static mxArray * _mxarray52_;

static mxChar _array55_[4] = { 'o', 'p', 'e', 'n' };
static mxArray * _mxarray54_;

static mxChar _array57_[4] = { 'r', 'e', 'a', 'd' };
static mxArray * _mxarray56_;

static mxChar _array59_[14] = { 'g', 'e', 't', 'f', 'i', 'l', 'e',
                                'v', 'e', 'r', 's', 'i', 'o', 'n' };
static mxArray * _mxarray58_;

static mxChar _array61_[5] = { 'c', 'l', 'o', 's', 'e' };
static mxArray * _mxarray60_;

static mxChar _array63_[8] = { '%', 'd', '.', '%', 'd', '.', '%', 'd' };
static mxArray * _mxarray62_;

static mxChar _array65_[47] = { 'N', 'o', ' ', '8', '-', 'b', 'i', 't',
                                ' ', 'o', 'r', ' ', '2', '4', '-', 'b',
                                'i', 't', ' ', 'r', 'a', 's', 't', 'e',
                                'r', ' ', 'i', 'm', 'a', 'g', 'e', ' ',
                                'd', 'a', 't', 'a', ' ', 's', 'e', 't',
                                's', ' ', 'f', 'o', 'u', 'n', 'd' };
static mxArray * _mxarray64_;

static mxChar _array67_[9] = { 's', 't', 'a', 'r', 't', 'r', 'e', 'a', 'd' };
static mxArray * _mxarray66_;

static mxChar _array69_[8] = { 'n', 'e', 'x', 't', 'r', 'e', 'a', 'd' };
static mxArray * _mxarray68_;

static mxChar _array71_[7] = { 'c', 'u', 'r', 'r', 'e', 'n', 't' };
static mxArray * _mxarray70_;

static mxChar _array73_[9] = { 'e', 'n', 'd', 'a', 'c', 'c', 'e', 's', 's' };
static mxArray * _mxarray72_;

static mxChar _array75_[7] = { 'i', 'n', 'q', 'u', 'i', 'r', 'e' };
static mxArray * _mxarray74_;

static mxChar _array77_[7] = { 'r', 'e', 'a', 'd', 'r', 'e', 'f' };
static mxArray * _mxarray76_;

static mxChar _array79_[7] = { 'g', 'e', 't', 'd', 'i', 'm', 's' };
static mxArray * _mxarray78_;
static mxArray * _mxarray80_;

static mxChar _array82_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray81_;

static mxChar _array84_[9] = { 'g', 'r', 'a', 'y', 's', 'c', 'a', 'l', 'e' };
static mxArray * _mxarray83_;
static mxArray * _mxarray85_;
static mxArray * _mxarray86_;

static mxChar _array88_[9] = { 't', 'r', 'u', 'e', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray87_;

static mxChar _array90_[54] = { 'C', 'a', 'n', ' ', 'o', 'n', 'l', 'y', ' ',
                                'r', 'e', 'a', 'd', ' ', '1', '-', ' ', 'o',
                                'r', ' ', '3', '-', 'c', 'o', 'm', 'p', 'o',
                                'n', 'e', 'n', 't', ' ', 'r', 'a', 's', 't',
                                'e', 'r', ' ', 'i', 'm', 'a', 'g', 'e', ' ',
                                'd', 'a', 't', 'a', ' ', 's', 'e', 't', 's' };
static mxArray * _mxarray89_;

static mxChar _array92_[54] = { 'T', 'h', 'e', ' ', 'N', 'C', 'S', 'A',
                                ' ', 'H', 'D', 'F', ' ', 'l', 'i', 'b',
                                'r', 'a', 'r', 'y', ' ', 'r', 'e', 'p',
                                'o', 'r', 't', 'e', 'd', ' ', 't', 'h',
                                'e', ' ', 'f', 'o', 'l', 'l', 'o', 'w',
                                'i', 'n', 'g', ' ', 'e', 'r', 'r', 'o',
                                'r', ':', 0x005c, 'n', '%', 's' };
static mxArray * _mxarray91_;

static mxChar _array94_[2] = { 'H', 'E' };
static mxArray * _mxarray93_;

static mxChar _array96_[6] = { 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray95_;

static mxChar _array98_[5] = { 'v', 'a', 'l', 'u', 'e' };
static mxArray * _mxarray97_;
static mxArray * _mxarray99_;
static mxArray * _mxarray100_;
static mxArray * _mxarray101_;

void InitializeModule_iofun_private_imhdfinfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeString(156, _array5_);
    _mxarray6_ = mclInitializeString(155, _array7_);
    _mxarray8_ = mclInitializeString(154, _array9_);
    _mxarray10_ = mclInitializeString(153, _array11_);
    _mxarray12_ = mclInitializeString(164, _array13_);
    _mxarray14_ = mclInitializeString(163, _array15_);
    _mxarray16_ = mclInitializeString(162, _array17_);
    _mxarray18_ = mclInitializeString(161, _array19_);
    _mxarray20_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray21_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray22_ = mclInitializeString(25, _array23_);
    _mxarray24_ = mclInitializeString(1, _array25_);
    _mxarray26_ = mclInitializeString(7, _array27_);
    _mxarray28_ = mclInitializeDouble(-1.0);
    _mxarray29_ = mclInitializeDouble(1.0);
    _mxarray30_ = mclInitializeString(6, _array31_);
    _mxarray32_ = mclInitializeString(16, _array33_);
    _mxarray34_ = mclInitializeDouble(235082497.0);
    _mxarray35_ = mclInitializeString(15, _array36_);
    _mxarray37_ = mclInitializeDouble(306.0);
    _mxarray38_ = mclInitializeDouble(300.0);
    _mxarray39_ = mclInitializeDouble(0.0);
    _mxarray40_ = mclInitializeString(3, _array41_);
    _mxarray42_ = mclInitializeString(1, _array43_);
    _mxarray44_ = mclInitializeString(5, _array45_);
    _mxarray46_ = mclInitializeDoubleVector(1, 4, _array47_);
    _mxarray48_ = mclInitializeString(4, _array49_);
    _mxarray50_ = mclInitializeString(7, _array51_);
    _mxarray52_ = mclInitializeString(4, _array53_);
    _mxarray54_ = mclInitializeString(4, _array55_);
    _mxarray56_ = mclInitializeString(4, _array57_);
    _mxarray58_ = mclInitializeString(14, _array59_);
    _mxarray60_ = mclInitializeString(5, _array61_);
    _mxarray62_ = mclInitializeString(8, _array63_);
    _mxarray64_ = mclInitializeString(47, _array65_);
    _mxarray66_ = mclInitializeString(9, _array67_);
    _mxarray68_ = mclInitializeString(8, _array69_);
    _mxarray70_ = mclInitializeString(7, _array71_);
    _mxarray72_ = mclInitializeString(9, _array73_);
    _mxarray74_ = mclInitializeString(7, _array75_);
    _mxarray76_ = mclInitializeString(7, _array77_);
    _mxarray78_ = mclInitializeString(7, _array79_);
    _mxarray80_ = mclInitializeDouble(8.0);
    _mxarray81_ = mclInitializeString(7, _array82_);
    _mxarray83_ = mclInitializeString(9, _array84_);
    _mxarray85_ = mclInitializeDouble(3.0);
    _mxarray86_ = mclInitializeDouble(24.0);
    _mxarray87_ = mclInitializeString(9, _array88_);
    _mxarray89_ = mclInitializeString(54, _array90_);
    _mxarray91_ = mclInitializeString(54, _array92_);
    _mxarray93_ = mclInitializeString(2, _array94_);
    _mxarray95_ = mclInitializeString(6, _array96_);
    _mxarray97_ = mclInitializeString(5, _array98_);
    _mxarray99_ = mclInitializeDouble(2.0);
    _mxarray100_ = mclInitializeDouble(14.0);
    _mxarray101_ = mclInitializeDouble(13.0);
}

void TerminateModule_iofun_private_imhdfinfo(void) {
    mxDestroyArray(_mxarray101_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray87_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray85_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImhdfinfo_hdferror(void);
static void mlxImhdfinfo_hdferror(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]);
static mxArray * mlfImhdfinfo_numcomp(mxArray * file_id, mxArray * ref);
static void mlxImhdfinfo_numcomp(int nlhs,
                                 mxArray * plhs[],
                                 int nrhs,
                                 mxArray * prhs[]);
static mxArray * mlfImhdfinfo_Uint16Decode(mxArray * in);
static void mlxImhdfinfo_Uint16Decode(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]);
static mxArray * mlfImhdfinfo_CountImages(mxArray * file_id);
static void mlxImhdfinfo_CountImages(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * Miofun_private_imhdfinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);
static mxArray * Mimhdfinfo_hdferror(int nargout_);
static mxArray * Mimhdfinfo_numcomp(int nargout_,
                                    mxArray * file_id,
                                    mxArray * ref);
static mxArray * Mimhdfinfo_Uint16Decode(int nargout_, mxArray * in);
static mxArray * Mimhdfinfo_CountImages(int nargout_, mxArray * file_id);

static mexFunctionTableEntry local_function_table_[4]
  = { { "hdferror", mlxImhdfinfo_hdferror, 0, 1, NULL },
      { "numcomp", mlxImhdfinfo_numcomp, 2, 1, NULL },
      { "Uint16Decode", mlxImhdfinfo_Uint16Decode, 1, 1, NULL },
      { "CountImages", mlxImhdfinfo_CountImages, 1, 1, NULL } };

_mexLocalFunctionTable _local_function_table_iofun_private_imhdfinfo
  = { 4, local_function_table_ };

/*
 * The function "mlfIofun_private_imhdfinfo" contains the normal interface for
 * the "iofun/private/imhdfinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 1-219). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imhdfinfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_imhdfinfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_imhdfinfo" contains the feval interface for
 * the "iofun/private/imhdfinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 1-219). The
 * feval function calls the implementation version of iofun/private/imhdfinfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imhdfinfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imhdfinfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfImhdfinfo_hdferror" contains the normal interface for the
 * "imhdfinfo/hdferror" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 219-229).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfImhdfinfo_hdferror(void) {
    int nargout = 1;
    mxArray * str = mclGetUninitializedArray();
    mlfEnterNewContext(0, 0);
    str = Mimhdfinfo_hdferror(nargout);
    mlfRestorePreviousContext(0, 0);
    return mlfReturnValue(str);
}

/*
 * The function "mlxImhdfinfo_hdferror" contains the feval interface for the
 * "imhdfinfo/hdferror" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 219-229). The
 * feval function calls the implementation version of imhdfinfo/hdferror
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxImhdfinfo_hdferror(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]) {
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray4_);
    }
    if (nrhs > 0) {
        mlfError(_mxarray6_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mplhs[0] = Mimhdfinfo_hdferror(nlhs);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImhdfinfo_numcomp" contains the normal interface for the
 * "imhdfinfo/numcomp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 229-273).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfImhdfinfo_numcomp(mxArray * file_id, mxArray * ref) {
    int nargout = 1;
    mxArray * num = mclGetUninitializedArray();
    mlfEnterNewContext(0, 2, file_id, ref);
    num = Mimhdfinfo_numcomp(nargout, file_id, ref);
    mlfRestorePreviousContext(0, 2, file_id, ref);
    return mlfReturnValue(num);
}

/*
 * The function "mlxImhdfinfo_numcomp" contains the feval interface for the
 * "imhdfinfo/numcomp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 229-273). The
 * feval function calls the implementation version of imhdfinfo/numcomp through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImhdfinfo_numcomp(int nlhs,
                                 mxArray * plhs[],
                                 int nrhs,
                                 mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray8_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray10_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mimhdfinfo_numcomp(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImhdfinfo_Uint16Decode" contains the normal interface for
 * the "imhdfinfo/Uint16Decode" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 273-283).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfImhdfinfo_Uint16Decode(mxArray * in) {
    int nargout = 1;
    mxArray * out = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, in);
    out = Mimhdfinfo_Uint16Decode(nargout, in);
    mlfRestorePreviousContext(0, 1, in);
    return mlfReturnValue(out);
}

/*
 * The function "mlxImhdfinfo_Uint16Decode" contains the feval interface for
 * the "imhdfinfo/Uint16Decode" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 273-283). The
 * feval function calls the implementation version of imhdfinfo/Uint16Decode
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxImhdfinfo_Uint16Decode(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray12_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray14_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimhdfinfo_Uint16Decode(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImhdfinfo_CountImages" contains the normal interface for
 * the "imhdfinfo/CountImages" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 283-302).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfImhdfinfo_CountImages(mxArray * file_id) {
    int nargout = 1;
    mxArray * numImages = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, file_id);
    numImages = Mimhdfinfo_CountImages(nargout, file_id);
    mlfRestorePreviousContext(0, 1, file_id);
    return mlfReturnValue(numImages);
}

/*
 * The function "mlxImhdfinfo_CountImages" contains the feval interface for the
 * "imhdfinfo/CountImages" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 283-302). The
 * feval function calls the implementation version of imhdfinfo/CountImages
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxImhdfinfo_CountImages(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray16_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray18_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimhdfinfo_CountImages(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Miofun_private_imhdfinfo" is the implementation version of the
 * "iofun/private/imhdfinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 1-219). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imhdfinfo(filename)
 */
static mxArray * Miofun_private_imhdfinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imhdfinfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * field = mclGetUninitializedArray();
    mxArray * p = mclGetUninitializedArray();
    mxArray * fieldNames = mclGetUninitializedArray();
    mxArray * status24 = mclGetUninitializedArray();
    mxArray * il = mclGetUninitializedArray();
    mxArray * h24 = mclGetUninitializedArray();
    mxArray * w24 = mclGetUninitializedArray();
    mxArray * status8 = mclGetUninitializedArray();
    mxArray * hasmap = mclGetUninitializedArray();
    mxArray * h8 = mclGetUninitializedArray();
    mxArray * w8 = mclGetUninitializedArray();
    mxArray * ref = mclGetUninitializedArray();
    mxArray * junk = mclGetUninitializedArray();
    mxArray * h_id = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * numImages = mclGetUninitializedArray();
    mxArray * status = mclGetUninitializedArray();
    mxArray * infostr = mclGetUninitializedArray();
    mxArray * release = mclGetUninitializedArray();
    mxArray * minor0 = mclGetUninitializedArray();
    mxArray * major0 = mclGetUninitializedArray();
    mxArray * file_id = mclGetUninitializedArray();
    mxArray * all = mclGetUninitializedArray();
    mxArray * FAIL = mclGetUninitializedArray();
    mxArray * DFREF_WILDCARD = mclGetUninitializedArray();
    mxArray * DFTAG_ID = mclGetUninitializedArray();
    mxArray * DFTAG_RIG = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * val = mclGetUninitializedArray();
    mxArray * d = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMHDFINFO Get information about images in an HDF file.
     * %   [INFO,MSG] = IMHDFINFO(FILENAME) returns information about the
     * %   8-bit and 24-bit raster image data sets in an HDF file.  INFO
     * %   is a structure array with the following fields:  Width,
     * %   Height, NumComponents, HasColormap, Tag, and Reference.  The
     * %   length of the structure array equals the number of image data
     * %   sets in the file.
     * %
     * %   If any error condition is encountered, such as an error opening
     * %   the file, MSG will contain a string describing the error and
     * %   INFO will be empty.  Otherwise, MSG will be empty.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.12 $  $Date: 2000/06/01 04:17:07 $
     * 
     * % This function should not call error()!  -SLE
     * 
     * msg = '';
     */
    mlfAssign(msg, _mxarray20_);
    /*
     * info = [];
     */
    mlfAssign(&info, _mxarray21_);
    /*
     * 
     * if (~isstr(filename))
     */
    if (mclNotBool(mclVe(mlfIsstr(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray22_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * % Find full filename
     * [fid,m] = fopen(filename,'r','ieee-be');
     */
    mlfAssign(
      &fid,
      mlfFopen(
        &m, NULL, mclVa(filename, "filename"), _mxarray24_, _mxarray26_));
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray28_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray21_);
        /*
         * msg = m;
         */
        mlfAssign(msg, mclVsv(m, "m"));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * filename = fopen(fid);
     */
    mlfAssign(&filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
    /*
     * d = dir(filename);
     */
    mlfAssign(&d, mlfNDir(1, mclVa(filename, "filename")));
    /*
     * % Read in the first 4 bytes as a big-endian 32-bit number.
     * % If the number is not 235082497, then we don't have an HDF
     * % file.  By checking here, we can bail out early without
     * % loading the HDF gateway MEX-file.
     * val = fread(fid, 1, 'uint32');
     */
    mlfAssign(
      &val, mlfFread(NULL, mclVv(fid, "fid"), _mxarray29_, _mxarray30_, NULL));
    /*
     * fclose(fid);
     */
    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    /*
     * if (isempty(val))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(val, "val"))))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray21_);
        /*
         * msg = 'Truncated header';
         */
        mlfAssign(msg, _mxarray32_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * if (val ~= 235082497)
     */
    if (mclNeBool(mclVv(val, "val"), _mxarray34_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray21_);
        /*
         * msg = 'Not an HDF file';
         */
        mlfAssign(msg, _mxarray35_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * %
     * % Initialize the structure to fix the field order
     * %
     * info.Filename = [];
     */
    mlfIndexAssign(&info, ".Filename", _mxarray21_);
    /*
     * info.FileModDate = '';
     */
    mlfIndexAssign(&info, ".FileModDate", _mxarray20_);
    /*
     * info.FileSize = [];
     */
    mlfIndexAssign(&info, ".FileSize", _mxarray21_);
    /*
     * info.Format = [];
     */
    mlfIndexAssign(&info, ".Format", _mxarray21_);
    /*
     * info.FormatVersion = [];
     */
    mlfIndexAssign(&info, ".FormatVersion", _mxarray21_);
    /*
     * info.Width = [];
     */
    mlfIndexAssign(&info, ".Width", _mxarray21_);
    /*
     * info.Height = [];
     */
    mlfIndexAssign(&info, ".Height", _mxarray21_);
    /*
     * info.BitDepth = [];
     */
    mlfIndexAssign(&info, ".BitDepth", _mxarray21_);
    /*
     * info.ColorType = [];
     */
    mlfIndexAssign(&info, ".ColorType", _mxarray21_);
    /*
     * info.FormatSignature = [];
     */
    mlfIndexAssign(&info, ".FormatSignature", _mxarray21_);
    /*
     * info.NumComponents = [];
     */
    mlfIndexAssign(&info, ".NumComponents", _mxarray21_);
    /*
     * info.HasColormap = [];
     */
    mlfIndexAssign(&info, ".HasColormap", _mxarray21_);
    /*
     * info.Interlace = '';
     */
    mlfIndexAssign(&info, ".Interlace", _mxarray20_);
    /*
     * info.Tag = [];
     */
    mlfIndexAssign(&info, ".Tag", _mxarray21_);
    /*
     * info.Reference = [];
     */
    mlfIndexAssign(&info, ".Reference", _mxarray21_);
    /*
     * 
     * DFTAG_RIG = 306;
     */
    mlfAssign(&DFTAG_RIG, _mxarray37_);
    /*
     * DFTAG_ID = 300;
     */
    mlfAssign(&DFTAG_ID, _mxarray38_);
    /*
     * DFREF_WILDCARD = 0;
     */
    mlfAssign(&DFREF_WILDCARD, _mxarray39_);
    /*
     * FAIL = -1;
     */
    mlfAssign(&FAIL, _mxarray28_);
    /*
     * 
     * all.Filename = filename;
     */
    mlfIndexAssign(&all, ".Filename", mclVsa(filename, "filename"));
    /*
     * all.FileModDate = d.date;
     */
    mlfIndexAssign(&all, ".FileModDate", mlfIndexRef(mclVsv(d, "d"), ".date"));
    /*
     * all.FileSize = d.bytes;
     */
    mlfIndexAssign(&all, ".FileSize", mlfIndexRef(mclVsv(d, "d"), ".bytes"));
    /*
     * all.Format = 'hdf';
     */
    mlfIndexAssign(&all, ".Format", _mxarray40_);
    /*
     * 
     * if (~hdf('H','ishdf',filename))
     */
    if (mclNotBool(
          mclVe(
            mlfNHdf(
              0,
              mclValueVarargout(),
              _mxarray42_,
              _mxarray44_,
              mclVa(filename, "filename"),
              NULL)))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray21_);
        /*
         * msg = 'Not an HDF file';
         */
        mlfAssign(msg, _mxarray35_);
        /*
         * return;
         */
        goto return_;
    /*
     * else
     */
    } else {
        /*
         * all.FormatSignature = [14 3 19 1];
         */
        mlfIndexAssign(&all, ".FormatSignature", _mxarray46_);
    /*
     * end
     */
    }
    /*
     * 
     * hdf('DFR8','restart');
     */
    mclAssignAns(
      &ans, mlfNHdf(0, mclAnsVarargout(), _mxarray48_, _mxarray50_, NULL));
    /*
     * hdf('DF24','restart');
     */
    mclAssignAns(
      &ans, mlfNHdf(0, mclAnsVarargout(), _mxarray52_, _mxarray50_, NULL));
    /*
     * 
     * file_id = hdf('H', 'open', filename, 'read', 0);
     */
    mlfAssign(
      &file_id,
      mlfNHdf(
        0,
        mclValueVarargout(),
        _mxarray42_,
        _mxarray54_,
        mclVa(filename, "filename"),
        _mxarray56_,
        _mxarray39_,
        NULL));
    /*
     * if (file_id == FAIL)
     */
    if (mclEqBool(mclVv(file_id, "file_id"), mclVv(FAIL, "FAIL"))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray21_);
        /*
         * msg = hdferror;
         */
        mlfAssign(msg, mlfImhdfinfo_hdferror());
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * [major,minor,release,infostr,status] = hdf('H','getfileversion',file_id);
     */
    mlfNHdf(
      0,
      mlfVarargout(&major0, &minor0, &release, &infostr, &status, NULL),
      _mxarray42_,
      _mxarray58_,
      mclVv(file_id, "file_id"),
      NULL);
    /*
     * if (status == FAIL)
     */
    if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray21_);
        /*
         * msg = hdferror;
         */
        mlfAssign(msg, mlfImhdfinfo_hdferror());
        /*
         * hdf('H','close',file_id);
         */
        mclAssignAns(
          &ans,
          mlfNHdf(
            0,
            mclAnsVarargout(),
            _mxarray42_,
            _mxarray60_,
            mclVv(file_id, "file_id"),
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end    
     */
    }
    /*
     * 
     * all.FormatVersion = sprintf('%d.%d.%d', major, minor, release);
     */
    mlfIndexAssign(
      &all,
      ".FormatVersion",
      mlfSprintf(
        NULL,
        _mxarray62_,
        mclVv(major0, "major"),
        mclVv(minor0, "minor"),
        mclVv(release, "release"),
        NULL));
    /*
     * 
     * %
     * % Find number of objects in file with the Raster Image Group tag
     * %
     * % numImages = hdf('H', 'number', file_id, DFTAG_RIG);
     * numImages = CountImages(file_id);
     */
    mlfAssign(&numImages, mlfImhdfinfo_CountImages(mclVv(file_id, "file_id")));
    /*
     * if (numImages == 0)
     */
    if (mclEqBool(mclVv(numImages, "numImages"), _mxarray39_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray21_);
        /*
         * msg = 'No 8-bit or 24-bit raster image data sets found';
         */
        mlfAssign(msg, _mxarray64_);
        /*
         * hdf('H', 'close', file_id);
         */
        mclAssignAns(
          &ans,
          mlfNHdf(
            0,
            mclAnsVarargout(),
            _mxarray42_,
            _mxarray60_,
            mclVv(file_id, "file_id"),
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * %
     * % Grow the INFO structure array
     * %
     * info(numImages).Format = 'hdf';
     */
    mlfIndexAssign(
      &info, "(?).Format", mclVsv(numImages, "numImages"), _mxarray40_);
    /*
     * 
     * %
     * % Find the reference numbers for all the raster image groups
     * %
     * for k = 1:numImages
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(numImages, "numImages"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray21_);
        } else {
            /*
             * if (k == 1)
             * h_id = hdf('H', 'startread', file_id, DFTAG_RIG, DFREF_WILDCARD);
             * status = h_id;
             * else
             * status = hdf('H', 'nextread', h_id, DFTAG_RIG, DFREF_WILDCARD, ...
             * 'current');
             * end
             * if (status == FAIL)
             * hdf('H','endaccess',h_id);
             * hdf('H','close',file_id);
             * info = [];
             * msg = hdferror;
             * return;
             * end
             * [junk, junk, ref, junk, junk, junk, junk, junk, status] = ...
             * hdf('H', 'inquire', h_id);
             * 
             * if (status == FAIL)
             * hdf('H','close',file_id);
             * info = [];
             * msg = hdferror;
             * return;
             * else
             * info(k).Reference = ref;
             * end
             * 
             * info(k).NumComponents = numcomp(file_id, ref);
             * end    
             */
            for (; ; ) {
                if (mclEqBool(mlfScalar(v_), _mxarray29_)) {
                    mlfAssign(
                      &h_id,
                      mlfNHdf(
                        0,
                        mclValueVarargout(),
                        _mxarray42_,
                        _mxarray66_,
                        mclVv(file_id, "file_id"),
                        mclVv(DFTAG_RIG, "DFTAG_RIG"),
                        mclVv(DFREF_WILDCARD, "DFREF_WILDCARD"),
                        NULL));
                    mlfAssign(&status, mclVsv(h_id, "h_id"));
                } else {
                    mlfAssign(
                      &status,
                      mlfNHdf(
                        0,
                        mclValueVarargout(),
                        _mxarray42_,
                        _mxarray68_,
                        mclVv(h_id, "h_id"),
                        mclVv(DFTAG_RIG, "DFTAG_RIG"),
                        mclVv(DFREF_WILDCARD, "DFREF_WILDCARD"),
                        _mxarray70_,
                        NULL));
                }
                if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
                    mclAssignAns(
                      &ans,
                      mlfNHdf(
                        0,
                        mclAnsVarargout(),
                        _mxarray42_,
                        _mxarray72_,
                        mclVv(h_id, "h_id"),
                        NULL));
                    mclAssignAns(
                      &ans,
                      mlfNHdf(
                        0,
                        mclAnsVarargout(),
                        _mxarray42_,
                        _mxarray60_,
                        mclVv(file_id, "file_id"),
                        NULL));
                    mlfAssign(&info, _mxarray21_);
                    mlfAssign(msg, mlfImhdfinfo_hdferror());
                    goto return_;
                }
                mlfNHdf(
                  0,
                  mlfVarargout(
                    &junk,
                    &junk,
                    &ref,
                    &junk,
                    &junk,
                    &junk,
                    &junk,
                    &junk,
                    &status,
                    NULL),
                  _mxarray42_,
                  _mxarray74_,
                  mclVv(h_id, "h_id"),
                  NULL);
                if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
                    mclAssignAns(
                      &ans,
                      mlfNHdf(
                        0,
                        mclAnsVarargout(),
                        _mxarray42_,
                        _mxarray60_,
                        mclVv(file_id, "file_id"),
                        NULL));
                    mlfAssign(&info, _mxarray21_);
                    mlfAssign(msg, mlfImhdfinfo_hdferror());
                    goto return_;
                } else {
                    mlfIndexAssign(
                      &info,
                      "(?).Reference",
                      mlfScalar(v_),
                      mclVsv(ref, "ref"));
                }
                mlfIndexAssign(
                  &info,
                  "(?).NumComponents",
                  mlfScalar(v_),
                  mlfImhdfinfo_numcomp(
                    mclVv(file_id, "file_id"), mclVv(ref, "ref")));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * hdf('H','endaccess',h_id);
     */
    mclAssignAns(
      &ans,
      mlfNHdf(
        0,
        mclAnsVarargout(),
        _mxarray42_,
        _mxarray72_,
        mclVv(h_id, "h_id"),
        NULL));
    /*
     * hdf('H','close',file_id);
     */
    mclAssignAns(
      &ans,
      mlfNHdf(
        0,
        mclAnsVarargout(),
        _mxarray42_,
        _mxarray60_,
        mclVv(file_id, "file_id"),
        NULL));
    /*
     * 
     * %
     * % Use the DFR8 and DF24 interfaces to get the rest of the information
     * %
     * for k = 1:numImages
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(numImages, "numImages"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray21_);
        } else {
            /*
             * info(k).Format = 'hdf';
             * ref = info(k).Reference;
             * 
             * if (info(k).NumComponents == 1)
             * hdf('DFR8','readref',filename,ref);
             * [w8,h8,hasmap,status8] = hdf('DFR8', 'getdims', filename);
             * info(k).Width = w8;
             * info(k).Height = h8;
             * info(k).BitDepth = 8;
             * info(k).HasColormap = hasmap;
             * if (info(k).HasColormap)
             * info(k).ColorType = 'indexed';
             * else
             * info(k).ColorType = 'grayscale';
             * end
             * info(k).Tag = DFTAG_RIG;
             * 
             * elseif (info(k).NumComponents == 3)
             * hdf('DF24','readref',filename,ref);
             * [w24,h24,il,status24] = hdf('DF24', 'getdims', filename);
             * info(k).Width = w24;
             * info(k).Height = h24;
             * info(k).HasColormap = 0;
             * info(k).BitDepth = 24;
             * info(k).ColorType = 'truecolor';
             * info(k).Interlace = il;
             * info(k).Tag = DFTAG_RIG;
             * 
             * else
             * info = [];
             * msg = 'Can only read 1- or 3-component raster image data sets';
             * return;
             * end
             * 
             * end
             */
            for (; ; ) {
                mlfIndexAssign(&info, "(?).Format", mlfScalar(v_), _mxarray40_);
                mlfAssign(
                  &ref,
                  mlfIndexRef(
                    mclVsv(info, "info"), "(?).Reference", mlfScalar(v_)));
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxEq,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"),
                            "(?).NumComponents",
                            mlfScalar(v_))),
                        _mxarray29_,
                        NULL))) {
                    mclAssignAns(
                      &ans,
                      mlfNHdf(
                        0,
                        mclAnsVarargout(),
                        _mxarray48_,
                        _mxarray76_,
                        mclVa(filename, "filename"),
                        mclVv(ref, "ref"),
                        NULL));
                    mlfNHdf(
                      0,
                      mlfVarargout(&w8, &h8, &hasmap, &status8, NULL),
                      _mxarray48_,
                      _mxarray78_,
                      mclVa(filename, "filename"),
                      NULL);
                    mlfIndexAssign(
                      &info, "(?).Width", mlfScalar(v_), mclVsv(w8, "w8"));
                    mlfIndexAssign(
                      &info, "(?).Height", mlfScalar(v_), mclVsv(h8, "h8"));
                    mlfIndexAssign(
                      &info, "(?).BitDepth", mlfScalar(v_), _mxarray80_);
                    mlfIndexAssign(
                      &info,
                      "(?).HasColormap",
                      mlfScalar(v_),
                      mclVsv(hasmap, "hasmap"));
                    if (mlfTobool(
                          mclVe(
                            mlfIndexRef(
                              mclVsv(info, "info"),
                              "(?).HasColormap",
                              mlfScalar(v_))))) {
                        mlfIndexAssign(
                          &info, "(?).ColorType", mlfScalar(v_), _mxarray81_);
                    } else {
                        mlfIndexAssign(
                          &info, "(?).ColorType", mlfScalar(v_), _mxarray83_);
                    }
                    mlfIndexAssign(
                      &info,
                      "(?).Tag",
                      mlfScalar(v_),
                      mclVsv(DFTAG_RIG, "DFTAG_RIG"));
                } else if (mlfTobool(
                             mclFeval(
                               mclValueVarargout(),
                               mlxEq,
                               mclVe(
                                 mlfIndexRef(
                                   mclVsv(info, "info"),
                                   "(?).NumComponents",
                                   mlfScalar(v_))),
                               _mxarray85_,
                               NULL))) {
                    mclAssignAns(
                      &ans,
                      mlfNHdf(
                        0,
                        mclAnsVarargout(),
                        _mxarray52_,
                        _mxarray76_,
                        mclVa(filename, "filename"),
                        mclVv(ref, "ref"),
                        NULL));
                    mlfNHdf(
                      0,
                      mlfVarargout(&w24, &h24, &il, &status24, NULL),
                      _mxarray52_,
                      _mxarray78_,
                      mclVa(filename, "filename"),
                      NULL);
                    mlfIndexAssign(
                      &info, "(?).Width", mlfScalar(v_), mclVsv(w24, "w24"));
                    mlfIndexAssign(
                      &info, "(?).Height", mlfScalar(v_), mclVsv(h24, "h24"));
                    mlfIndexAssign(
                      &info, "(?).HasColormap", mlfScalar(v_), _mxarray39_);
                    mlfIndexAssign(
                      &info, "(?).BitDepth", mlfScalar(v_), _mxarray86_);
                    mlfIndexAssign(
                      &info, "(?).ColorType", mlfScalar(v_), _mxarray87_);
                    mlfIndexAssign(
                      &info, "(?).Interlace", mlfScalar(v_), mclVsv(il, "il"));
                    mlfIndexAssign(
                      &info,
                      "(?).Tag",
                      mlfScalar(v_),
                      mclVsv(DFTAG_RIG, "DFTAG_RIG"));
                } else {
                    mlfAssign(&info, _mxarray21_);
                    mlfAssign(msg, _mxarray89_);
                    goto return_;
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * 
     * % Fill in the individual image info structures with the fields
     * % that apply to all images.
     * fieldNames = fieldnames(all);
     */
    mlfAssign(&fieldNames, mlfFieldnames(mclVv(all, "all")));
    /*
     * for k = 1:length(info)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mlfScalar(mclLengthInt(mclVv(info, "info"))));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray21_);
        } else {
            /*
             * for p = 1:length(fieldNames)
             * field = fieldNames{p};
             * info(k) = setfield(info(k), field, getfield(all, field));
             * end
             * end
             */
            for (; ; ) {
                int v_0 = mclForIntStart(1);
                int e_0 = mclForIntEnd(
                            mlfScalar(
                              mclLengthInt(mclVv(fieldNames, "fieldNames"))));
                if (v_0 > e_0) {
                    mlfAssign(&p, _mxarray21_);
                } else {
                    for (; ; ) {
                        mlfAssign(
                          &field,
                          mlfIndexRef(
                            mclVsv(fieldNames, "fieldNames"),
                            "{?}",
                            mlfScalar(v_0)));
                        mclIntArrayAssign1(
                          &info,
                          mlfSetfield(
                            mclVe(mclIntArrayRef1(mclVsv(info, "info"), v_)),
                            mclVv(field, "field"),
                            mclVe(
                              mlfGetfield(
                                mclVv(all, "all"),
                                mclVv(field, "field"), NULL)),
                            NULL),
                          v_);
                        if (v_0 == e_0) {
                            break;
                        }
                        ++v_0;
                    }
                    mlfAssign(&p, mlfScalar(v_0));
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * 
     * %%%
     * %%% Function hdferror
     * %%%
     * function str = hdferror()
     */
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/imhdfinfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/imhdfinfo");
    mxDestroyArray(fid);
    mxDestroyArray(m);
    mxDestroyArray(d);
    mxDestroyArray(val);
    mxDestroyArray(ans);
    mxDestroyArray(DFTAG_RIG);
    mxDestroyArray(DFTAG_ID);
    mxDestroyArray(DFREF_WILDCARD);
    mxDestroyArray(FAIL);
    mxDestroyArray(all);
    mxDestroyArray(file_id);
    mxDestroyArray(major0);
    mxDestroyArray(minor0);
    mxDestroyArray(release);
    mxDestroyArray(infostr);
    mxDestroyArray(status);
    mxDestroyArray(numImages);
    mxDestroyArray(k);
    mxDestroyArray(h_id);
    mxDestroyArray(junk);
    mxDestroyArray(ref);
    mxDestroyArray(w8);
    mxDestroyArray(h8);
    mxDestroyArray(hasmap);
    mxDestroyArray(status8);
    mxDestroyArray(w24);
    mxDestroyArray(h24);
    mxDestroyArray(il);
    mxDestroyArray(status24);
    mxDestroyArray(fieldNames);
    mxDestroyArray(p);
    mxDestroyArray(field);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
    /*
     * %HDFERROR Return the current HDF error string.
     * 
     * str = sprintf('The NCSA HDF library reported the following error:\n%s', ...
     * hdf('HE', 'string', hdf('HE', 'value', 1)));
     * 
     * 
     * %%%
     * %%% Function numcomp
     * %%%
     */
}

/*
 * The function "Mimhdfinfo_hdferror" is the implementation version of the
 * "imhdfinfo/hdferror" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 219-229). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function str = hdferror()
 */
static mxArray * Mimhdfinfo_hdferror(int nargout_) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imhdfinfo);
    mxArray * str = mclGetUninitializedArray();
    /*
     * %HDFERROR Return the current HDF error string.
     * 
     * str = sprintf('The NCSA HDF library reported the following error:\n%s', ...
     */
    mlfAssign(
      &str,
      mlfSprintf(
        NULL,
        _mxarray91_,
        mclVe(
          mlfNHdf(
            0,
            mclValueVarargout(),
            _mxarray93_,
            _mxarray95_,
            mclVe(
              mlfNHdf(
                0,
                mclValueVarargout(),
                _mxarray93_,
                _mxarray97_,
                _mxarray29_,
                NULL)),
            NULL)),
        NULL));
    mclValidateOutput(str, 1, nargout_, "str", "imhdfinfo/hdferror");
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return str;
    /*
     * hdf('HE', 'string', hdf('HE', 'value', 1)));
     * 
     * 
     * %%%
     * %%% Function numcomp
     * %%%
     * function num = numcomp(file_id, ref)
     * %NUMCOMP Number of components in raster image group
     * 
     * FAIL = -1;
     * DFTAG_RIG = 306;
     * DFTAG_ID = 300;
     * 
     * access_id = hdf('H', 'startread', file_id, DFTAG_RIG, ref);
     * if (access_id == FAIL)
     * num = [];
     * return;
     * end
     * 
     * memberList = hdf('H', 'read', access_id, 0);
     * hdf('H', 'endaccess', access_id);
     * 
     * memberList = Uint16Decode(memberList);
     * memberTags = memberList(1:2:end);
     * memberRefs = memberList(2:2:end);
     * idx = find(memberTags == DFTAG_ID);
     * if (isempty(idx))
     * num = [];
     * return;
     * else
     * idx = idx(1);
     * end
     * 
     * access_id = hdf('H', 'startread', file_id, DFTAG_ID, memberRefs(idx));
     * if (access_id == FAIL)
     * num = [];
     * return;
     * end
     * memberList = hdf('H', 'read', access_id, 14);
     * hdf('H', 'endaccess', access_id);
     * if (length(memberList) < 14)
     * num = [];
     * return;
     * end
     * num = Uint16Decode(memberList(13:14));
     * 
     * 
     * %%%
     * %%% Uint16Decode --- turn uint8 input into uint16 integers
     * %%%
     */
}

/*
 * The function "Mimhdfinfo_numcomp" is the implementation version of the
 * "imhdfinfo/numcomp" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 229-273). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function num = numcomp(file_id, ref)
 */
static mxArray * Mimhdfinfo_numcomp(int nargout_,
                                    mxArray * file_id,
                                    mxArray * ref) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imhdfinfo);
    mxArray * num = mclGetUninitializedArray();
    mxArray * idx = mclGetUninitializedArray();
    mxArray * memberRefs = mclGetUninitializedArray();
    mxArray * memberTags = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * memberList = mclGetUninitializedArray();
    mxArray * access_id = mclGetUninitializedArray();
    mxArray * DFTAG_ID = mclGetUninitializedArray();
    mxArray * DFTAG_RIG = mclGetUninitializedArray();
    mxArray * FAIL = mclGetUninitializedArray();
    mclCopyArray(&file_id);
    mclCopyArray(&ref);
    /*
     * %NUMCOMP Number of components in raster image group
     * 
     * FAIL = -1;
     */
    mlfAssign(&FAIL, _mxarray28_);
    /*
     * DFTAG_RIG = 306;
     */
    mlfAssign(&DFTAG_RIG, _mxarray37_);
    /*
     * DFTAG_ID = 300;
     */
    mlfAssign(&DFTAG_ID, _mxarray38_);
    /*
     * 
     * access_id = hdf('H', 'startread', file_id, DFTAG_RIG, ref);
     */
    mlfAssign(
      &access_id,
      mlfNHdf(
        0,
        mclValueVarargout(),
        _mxarray42_,
        _mxarray66_,
        mclVa(file_id, "file_id"),
        mclVv(DFTAG_RIG, "DFTAG_RIG"),
        mclVa(ref, "ref"),
        NULL));
    /*
     * if (access_id == FAIL)
     */
    if (mclEqBool(mclVv(access_id, "access_id"), mclVv(FAIL, "FAIL"))) {
        /*
         * num = [];
         */
        mlfAssign(&num, _mxarray21_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * memberList = hdf('H', 'read', access_id, 0);
     */
    mlfAssign(
      &memberList,
      mlfNHdf(
        0,
        mclValueVarargout(),
        _mxarray42_,
        _mxarray56_,
        mclVv(access_id, "access_id"),
        _mxarray39_,
        NULL));
    /*
     * hdf('H', 'endaccess', access_id);
     */
    mclAssignAns(
      &ans,
      mlfNHdf(
        0,
        mclAnsVarargout(),
        _mxarray42_,
        _mxarray72_,
        mclVv(access_id, "access_id"),
        NULL));
    /*
     * 
     * memberList = Uint16Decode(memberList);
     */
    mlfAssign(
      &memberList, mlfImhdfinfo_Uint16Decode(mclVv(memberList, "memberList")));
    /*
     * memberTags = memberList(1:2:end);
     */
    mlfAssign(
      &memberTags,
      mclArrayRef1(
        mclVsv(memberList, "memberList"),
        mlfColon(
          _mxarray29_,
          _mxarray99_,
          mlfEnd(mclVv(memberList, "memberList"), _mxarray29_, _mxarray29_))));
    /*
     * memberRefs = memberList(2:2:end);
     */
    mlfAssign(
      &memberRefs,
      mclArrayRef1(
        mclVsv(memberList, "memberList"),
        mlfColon(
          _mxarray99_,
          _mxarray99_,
          mlfEnd(mclVv(memberList, "memberList"), _mxarray29_, _mxarray29_))));
    /*
     * idx = find(memberTags == DFTAG_ID);
     */
    mlfAssign(
      &idx,
      mlfFind(
        NULL,
        NULL,
        mclEq(mclVv(memberTags, "memberTags"), mclVv(DFTAG_ID, "DFTAG_ID"))));
    /*
     * if (isempty(idx))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(idx, "idx"))))) {
        /*
         * num = [];
         */
        mlfAssign(&num, _mxarray21_);
        /*
         * return;
         */
        goto return_;
    /*
     * else
     */
    } else {
        /*
         * idx = idx(1);
         */
        mlfAssign(&idx, mclIntArrayRef1(mclVsv(idx, "idx"), 1));
    /*
     * end
     */
    }
    /*
     * 
     * access_id = hdf('H', 'startread', file_id, DFTAG_ID, memberRefs(idx));
     */
    mlfAssign(
      &access_id,
      mlfNHdf(
        0,
        mclValueVarargout(),
        _mxarray42_,
        _mxarray66_,
        mclVa(file_id, "file_id"),
        mclVv(DFTAG_ID, "DFTAG_ID"),
        mclVe(
          mclArrayRef1(mclVsv(memberRefs, "memberRefs"), mclVsv(idx, "idx"))),
        NULL));
    /*
     * if (access_id == FAIL)
     */
    if (mclEqBool(mclVv(access_id, "access_id"), mclVv(FAIL, "FAIL"))) {
        /*
         * num = [];
         */
        mlfAssign(&num, _mxarray21_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * memberList = hdf('H', 'read', access_id, 14);
     */
    mlfAssign(
      &memberList,
      mlfNHdf(
        0,
        mclValueVarargout(),
        _mxarray42_,
        _mxarray56_,
        mclVv(access_id, "access_id"),
        _mxarray100_,
        NULL));
    /*
     * hdf('H', 'endaccess', access_id);
     */
    mclAssignAns(
      &ans,
      mlfNHdf(
        0,
        mclAnsVarargout(),
        _mxarray42_,
        _mxarray72_,
        mclVv(access_id, "access_id"),
        NULL));
    /*
     * if (length(memberList) < 14)
     */
    if (mclLengthInt(mclVv(memberList, "memberList")) < 14) {
        /*
         * num = [];
         */
        mlfAssign(&num, _mxarray21_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * num = Uint16Decode(memberList(13:14));
     */
    mlfAssign(
      &num,
      mlfImhdfinfo_Uint16Decode(
        mclVe(
          mclArrayRef1(
            mclVsv(memberList, "memberList"),
            mlfColon(_mxarray101_, _mxarray100_, NULL)))));
    /*
     * 
     * 
     * %%%
     * %%% Uint16Decode --- turn uint8 input into uint16 integers
     * %%%
     * function out = Uint16Decode(in)
     */
    return_:
    mclValidateOutput(num, 1, nargout_, "num", "imhdfinfo/numcomp");
    mxDestroyArray(FAIL);
    mxDestroyArray(DFTAG_RIG);
    mxDestroyArray(DFTAG_ID);
    mxDestroyArray(access_id);
    mxDestroyArray(memberList);
    mxDestroyArray(ans);
    mxDestroyArray(memberTags);
    mxDestroyArray(memberRefs);
    mxDestroyArray(idx);
    mxDestroyArray(ref);
    mxDestroyArray(file_id);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return num;
    /*
     * 
     * msb = double(in(1:2:end));
     * lsb = double(in(2:2:end));
     * 
     * out = bitshift(msb,8) + lsb;
     * 
     * %%%
     * %%% CountImages --- count number of Raster Image Groups in file
     * %%%
     */
}

/*
 * The function "Mimhdfinfo_Uint16Decode" is the implementation version of the
 * "imhdfinfo/Uint16Decode" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 273-283). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function out = Uint16Decode(in)
 */
static mxArray * Mimhdfinfo_Uint16Decode(int nargout_, mxArray * in) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imhdfinfo);
    mxArray * out = mclGetUninitializedArray();
    mxArray * lsb = mclGetUninitializedArray();
    mxArray * msb = mclGetUninitializedArray();
    mclCopyArray(&in);
    /*
     * 
     * msb = double(in(1:2:end));
     */
    mlfAssign(
      &msb,
      mlfDouble(
        mclVe(
          mclArrayRef1(
            mclVsa(in, "in"),
            mlfColon(
              _mxarray29_,
              _mxarray99_,
              mlfEnd(mclVa(in, "in"), _mxarray29_, _mxarray29_))))));
    /*
     * lsb = double(in(2:2:end));
     */
    mlfAssign(
      &lsb,
      mlfDouble(
        mclVe(
          mclArrayRef1(
            mclVsa(in, "in"),
            mlfColon(
              _mxarray99_,
              _mxarray99_,
              mlfEnd(mclVa(in, "in"), _mxarray29_, _mxarray29_))))));
    /*
     * 
     * out = bitshift(msb,8) + lsb;
     */
    mlfAssign(
      &out,
      mclPlus(
        mclVe(mlfBitshift(mclVv(msb, "msb"), _mxarray80_, NULL)),
        mclVv(lsb, "lsb")));
    mclValidateOutput(out, 1, nargout_, "out", "imhdfinfo/Uint16Decode");
    mxDestroyArray(msb);
    mxDestroyArray(lsb);
    mxDestroyArray(in);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return out;
    /*
     * 
     * %%%
     * %%% CountImages --- count number of Raster Image Groups in file
     * %%%
     * function numImages = CountImages(file_id)
     * 
     * DFTAG_RIG = 306;
     * DFREF_WILDCARD = 0;
     * 
     * numImages = 0;
     * h_id = hdf('H','startread', file_id, DFTAG_RIG, DFREF_WILDCARD);
     * if (h_id > 0)
     * status = 0;
     * else
     * status = -1;
     * end
     * 
     * while (status == 0)
     * numImages = numImages + 1;
     * status = hdf('H','nextread',h_id,DFTAG_RIG, DFREF_WILDCARD,'current');
     * end
     * hdf('H','endaccess',h_id);
     * 
     */
}

/*
 * The function "Mimhdfinfo_CountImages" is the implementation version of the
 * "imhdfinfo/CountImages" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imhdfinfo.m" (lines 283-302). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function numImages = CountImages(file_id)
 */
static mxArray * Mimhdfinfo_CountImages(int nargout_, mxArray * file_id) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imhdfinfo);
    mxArray * numImages = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * status = mclGetUninitializedArray();
    mxArray * h_id = mclGetUninitializedArray();
    mxArray * DFREF_WILDCARD = mclGetUninitializedArray();
    mxArray * DFTAG_RIG = mclGetUninitializedArray();
    mclCopyArray(&file_id);
    /*
     * 
     * DFTAG_RIG = 306;
     */
    mlfAssign(&DFTAG_RIG, _mxarray37_);
    /*
     * DFREF_WILDCARD = 0;
     */
    mlfAssign(&DFREF_WILDCARD, _mxarray39_);
    /*
     * 
     * numImages = 0;
     */
    mlfAssign(&numImages, _mxarray39_);
    /*
     * h_id = hdf('H','startread', file_id, DFTAG_RIG, DFREF_WILDCARD);
     */
    mlfAssign(
      &h_id,
      mlfNHdf(
        0,
        mclValueVarargout(),
        _mxarray42_,
        _mxarray66_,
        mclVa(file_id, "file_id"),
        mclVv(DFTAG_RIG, "DFTAG_RIG"),
        mclVv(DFREF_WILDCARD, "DFREF_WILDCARD"),
        NULL));
    /*
     * if (h_id > 0)
     */
    if (mclGtBool(mclVv(h_id, "h_id"), _mxarray39_)) {
        /*
         * status = 0;
         */
        mlfAssign(&status, _mxarray39_);
    /*
     * else
     */
    } else {
        /*
         * status = -1;
         */
        mlfAssign(&status, _mxarray28_);
    /*
     * end
     */
    }
    /*
     * 
     * while (status == 0)
     */
    while (mclEqBool(mclVv(status, "status"), _mxarray39_)) {
        /*
         * numImages = numImages + 1;
         */
        mlfAssign(
          &numImages, mclPlus(mclVv(numImages, "numImages"), _mxarray29_));
        /*
         * status = hdf('H','nextread',h_id,DFTAG_RIG, DFREF_WILDCARD,'current');
         */
        mlfAssign(
          &status,
          mlfNHdf(
            0,
            mclValueVarargout(),
            _mxarray42_,
            _mxarray68_,
            mclVv(h_id, "h_id"),
            mclVv(DFTAG_RIG, "DFTAG_RIG"),
            mclVv(DFREF_WILDCARD, "DFREF_WILDCARD"),
            _mxarray70_,
            NULL));
    /*
     * end
     */
    }
    /*
     * hdf('H','endaccess',h_id);
     */
    mclAssignAns(
      &ans,
      mlfNHdf(
        0,
        mclAnsVarargout(),
        _mxarray42_,
        _mxarray72_,
        mclVv(h_id, "h_id"),
        NULL));
    mclValidateOutput(
      numImages, 1, nargout_, "numImages", "imhdfinfo/CountImages");
    mxDestroyArray(DFTAG_RIG);
    mxDestroyArray(DFREF_WILDCARD);
    mxDestroyArray(h_id);
    mxDestroyArray(status);
    mxDestroyArray(ans);
    mxDestroyArray(file_id);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return numImages;
    /*
     * 
     */
}
