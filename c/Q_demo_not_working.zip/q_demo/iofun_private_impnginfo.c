/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_impnginfo.h"
#include "libmatlbm.h"
#include "libmwsglm.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'p', 'n', 'g', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'p', 'n', 'g', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'p', 'n', 'g', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'p', 'n', 'g', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray6_;

static mxChar _array9_[4] = { 'i', 'n', 'f', 'o' };
static mxArray * _mxarray8_;

void InitializeModule_iofun_private_impnginfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(4, _array9_);
}

void TerminateModule_iofun_private_impnginfo(void) {
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_impnginfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_impnginfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_impnginfo" contains the normal interface for
 * the "iofun/private/impnginfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\impnginfo.m" (lines 1-35). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_impnginfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_impnginfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_impnginfo" contains the feval interface for
 * the "iofun/private/impnginfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\impnginfo.m" (lines 1-35). The
 * feval function calls the implementation version of iofun/private/impnginfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_impnginfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_impnginfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_impnginfo" is the implementation version of the
 * "iofun/private/impnginfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\impnginfo.m" (lines 1-35). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = impnginfo(filename)
 */
static mxArray * Miofun_private_impnginfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_impnginfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * s = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMPNGNFO Information about a PNG file.
     * %   [INFO,MSG] = IMPNGINFO(FILENAME) returns a structure containing
     * %   information about the PNG file specified by the string
     * %   FILENAME.  
     * %
     * %   If any error condition is encountered, such as an error opening
     * %   the file, MSG will contain a string describing the error and
     * %   INFO will be empty.  Otherwise, MSG will be empty.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, August 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.3 $  $Date: 2000/06/01 04:17:15 $
     * 
     * info = [];
     */
    mlfAssign(&info, _mxarray4_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray5_);
    /*
     * 
     * if (~isstr(filename))
     */
    if (mclNotBool(mclVe(mlfIsstr(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray6_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * info = png('info',filename);
         */
        mlfAssign(
          &info,
          mlfNIofun_private_png(
            0,
            mclValueVarargout(),
            _mxarray8_,
            mclVa(filename, "filename"),
            NULL));
        /*
         * s = dir(filename);
         */
        mlfAssign(&s, mlfNDir(1, mclVa(filename, "filename")));
        /*
         * info.FileModDate = s.date;
         */
        mlfIndexAssign(
          &info, ".FileModDate", mlfIndexRef(mclVsv(s, "s"), ".date"));
        /*
         * info.FileSize = s.bytes;
         */
        mlfIndexAssign(
          &info, ".FileSize", mlfIndexRef(mclVsv(s, "s"), ".bytes"));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = lasterr;
         */
        mlfAssign(msg, mlfLasterr(NULL));
    /*
     * end
     */
    } mlfEndCatch
    /*
     * 
     */
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/impnginfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/impnginfo");
    mxDestroyArray(s);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
