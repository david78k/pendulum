/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imicoinfo.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'i', 'c', 'o', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'i', 'c', 'o', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'i', 'c', 'o', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'i', 'c', 'o', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray6_;

static mxChar _array9_[1] = { 'r' };
static mxArray * _mxarray8_;

static mxChar _array11_[7] = { 'i', 'e', 'e', 'e', '-', 'l', 'e' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;

static mxChar _array14_[3] = { 'i', 'c', 'o' };
static mxArray * _mxarray13_;
static mxArray * _mxarray15_;

static mxChar _array17_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray16_;

static mxChar _array19_[10] = { 'E', 'm', 'p', 't', 'y',
                                ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray18_;

static double _array21_[2] = { 0.0, 1.0 };
static mxArray * _mxarray20_;

static mxChar _array23_[16] = { 'N', 'o', 't', ' ', 'a', 'n', ' ', 'I',
                                'C', 'O', ' ', 'f', 'i', 'l', 'e', '.' };
static mxArray * _mxarray22_;
static mxArray * _mxarray24_;
static mxArray * _mxarray25_;
static mxArray * _mxarray26_;

static mxChar _array28_[3] = { 'b', 'o', 'f' };
static mxArray * _mxarray27_;

static mxChar _array30_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray29_;

static mxChar _array32_[3] = { 'c', 'o', 'f' };
static mxArray * _mxarray31_;

static mxChar _array34_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray33_;
static mxArray * _mxarray35_;
static mxArray * _mxarray36_;

static mxChar _array38_[23] = { 'T', 'r', 'u', 'n', 'c', 'a', 't', 'e',
                                'd', ' ', 'c', 'o', 'l', 'o', 'r', 'm',
                                'a', 'p', ' ', 'd', 'a', 't', 'a' };
static mxArray * _mxarray37_;
static mxArray * _mxarray39_;
static mxArray * _mxarray40_;

static mxChar _array42_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray41_;

static mxChar _array44_[4] = { 'n', 'o', 'n', 'e' };
static mxArray * _mxarray43_;
static mxArray * _mxarray45_;

static mxChar _array47_[39] = { 'C', 'o', 'r', 'r', 'u', 'p', 't', ' ',
                                'I', 'C', 'O', ' ', 'f', 'i', 'l', 'e',
                                ':', ' ', 'b', 'a', 'd', ' ', 'i', 'm',
                                'a', 'g', 'e', ' ', 'd', 'i', 'm', 'e',
                                'n', 's', 'i', 'o', 'n', 's', '.' };
static mxArray * _mxarray46_;

void InitializeModule_iofun_private_imicoinfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(7, _array11_);
    _mxarray12_ = mclInitializeDouble(-1.0);
    _mxarray13_ = mclInitializeString(3, _array14_);
    _mxarray15_ = mclInitializeDouble(2.0);
    _mxarray16_ = mclInitializeString(6, _array17_);
    _mxarray18_ = mclInitializeString(10, _array19_);
    _mxarray20_ = mclInitializeDoubleVector(2, 1, _array21_);
    _mxarray22_ = mclInitializeString(16, _array23_);
    _mxarray24_ = mclInitializeDouble(1.0);
    _mxarray25_ = mclInitializeDouble(6.0);
    _mxarray26_ = mclInitializeDouble(16.0);
    _mxarray27_ = mclInitializeString(3, _array28_);
    _mxarray29_ = mclInitializeString(5, _array30_);
    _mxarray31_ = mclInitializeString(3, _array32_);
    _mxarray33_ = mclInitializeString(6, _array34_);
    _mxarray35_ = mclInitializeDouble(8.0);
    _mxarray36_ = mclInitializeDouble(4.0);
    _mxarray37_ = mclInitializeString(23, _array38_);
    _mxarray39_ = mclInitializeDouble(3.0);
    _mxarray40_ = mclInitializeDouble(255.0);
    _mxarray41_ = mclInitializeString(7, _array42_);
    _mxarray43_ = mclInitializeString(4, _array44_);
    _mxarray45_ = mclInitializeDouble(0.0);
    _mxarray46_ = mclInitializeString(39, _array47_);
}

void TerminateModule_iofun_private_imicoinfo(void) {
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_imicoinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_imicoinfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_imicoinfo" contains the normal interface for
 * the "iofun/private/imicoinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imicoinfo.m" (lines 1-152). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imicoinfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_imicoinfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_imicoinfo" contains the feval interface for
 * the "iofun/private/imicoinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imicoinfo.m" (lines 1-152). The
 * feval function calls the implementation version of iofun/private/imicoinfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imicoinfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imicoinfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_imicoinfo" is the implementation version of the
 * "iofun/private/imicoinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imicoinfo.m" (lines 1-152). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imicoinfo(filename)
 */
static mxArray * Miofun_private_imicoinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imicoinfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * cmap = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * data = mclGetUninitializedArray();
    mxArray * idpos = mclGetUninitializedArray();
    mxArray * p = mclGetUninitializedArray();
    mxArray * imcount = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * d = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMICOINFO Get information about the image in an ICO file.
     * %   [INFO,MSG] = IMICOINFO(FILENAME) returns information about
     * %   the image contained in an ICO file containing one or more
     * %   Microsoft Windows icon resources.  If the attempt fails for
     * %   some reason (e.g. the file does not exist or is not an ICO
     * %   file), then INFO is empty and MSG is a string containing a
     * %   diagnostic message.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc.
     * %   $Revision: 1.3 $  $Date: 2000/06/23 15:37:51 $
     * %   $ Revision $  $ Date $
     * 
     * % This function should not call error()!
     * 
     * info = [];
     */
    mlfAssign(&info, _mxarray4_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray5_);
    /*
     * 
     * if (~ischar(filename))
     */
    if (mclNotBool(mclVe(mlfIschar(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray6_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * [fid, m] = fopen(filename, 'r', 'ieee-le');  % ICO files are little-endian
     */
    mlfAssign(
      &fid,
      mlfFopen(&m, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray10_));
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray12_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = m;
         */
        mlfAssign(msg, mclVsv(m, "m"));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * filename = fopen(fid);  % Get the full path name if not in pwd
     */
    mlfAssign(&filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
    /*
     * d = dir(filename);      % Read directory information
     */
    mlfAssign(&d, mlfNDir(1, mclVa(filename, "filename")));
    /*
     * 
     * %
     * % Initialize universal structure fields to fix the order
     * %
     * info.Filename = filename;
     */
    mlfIndexAssign(&info, ".Filename", mclVsa(filename, "filename"));
    /*
     * info.FileModDate = d.date;
     */
    mlfIndexAssign(&info, ".FileModDate", mlfIndexRef(mclVsv(d, "d"), ".date"));
    /*
     * info.FileSize = d.bytes;
     */
    mlfIndexAssign(&info, ".FileSize", mlfIndexRef(mclVsv(d, "d"), ".bytes"));
    /*
     * info.Format = 'ico';
     */
    mlfIndexAssign(&info, ".Format", _mxarray13_);
    /*
     * info.FormatVersion = [];
     */
    mlfIndexAssign(&info, ".FormatVersion", _mxarray4_);
    /*
     * info.Width = [];
     */
    mlfIndexAssign(&info, ".Width", _mxarray4_);
    /*
     * info.Height = [];
     */
    mlfIndexAssign(&info, ".Height", _mxarray4_);
    /*
     * info.BitDepth = [];
     */
    mlfIndexAssign(&info, ".BitDepth", _mxarray4_);
    /*
     * info.ColorType = [];
     */
    mlfIndexAssign(&info, ".ColorType", _mxarray4_);
    /*
     * info.FormatSignature = [];
     */
    mlfIndexAssign(&info, ".FormatSignature", _mxarray4_);
    /*
     * 
     * %
     * % Initialize ICO-specific structure fields to fix the order
     * %
     * info.NumColormapEntries = [];
     */
    mlfIndexAssign(&info, ".NumColormapEntries", _mxarray4_);
    /*
     * info.Colormap = [];
     */
    mlfIndexAssign(&info, ".Colormap", _mxarray4_);
    /*
     * 
     * % Read the resource header to verify the correct type
     * sig = fread(fid, 2, 'uint16');
     */
    mlfAssign(
      &sig, mlfFread(NULL, mclVv(fid, "fid"), _mxarray15_, _mxarray16_, NULL));
    /*
     * if (isempty(sig))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(sig, "sig"))))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'Empty file';
         */
        mlfAssign(msg, _mxarray18_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if (~isequal(sig, [0; 1]))
     */
    if (mclNotBool(mclVe(mlfIsequal(mclVv(sig, "sig"), _mxarray20_, NULL)))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'Not an ICO file.';
         */
        mlfAssign(msg, _mxarray22_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * % Find the number of icons in the file
     * imcount = fread(fid, 1, 'uint16');
     */
    mlfAssign(
      &imcount,
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray16_, NULL));
    /*
     * 
     * for p = 1:imcount
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(imcount, "imcount"));
        if (v_ > e_) {
            mlfAssign(&p, _mxarray4_);
        } else {
            /*
             * info(p).Filename = filename;
             * info(p).FileModDate = d.date;
             * info(p).FileSize = d.bytes;
             * info(p).Format = 'ico';
             * info(p).FormatSignature = sig';
             * 
             * % Offset to the current icon directory entry
             * idpos = 6 + 16*(p - 1);
             * fseek(fid, idpos, 'bof');
             * 
             * % Read the icon directory
             * info(p).Width = fread(fid, 1, 'uint8');
             * info(p).Height = fread(fid, 1, 'uint8');
             * 
             * fseek(fid, 6, 'cof');
             * 
             * info(p).ResourceSize = fread(fid, 1, 'uint32');
             * info(p).ResourceDataOffset = fread(fid, 1, 'uint32');
             * 
             * % Start reading bitmap header info
             * fseek(fid, info(p).ResourceDataOffset, 'bof');
             * 
             * info(p).BitmapHeaderSize = fread(fid, 1, 'uint32');
             * 
             * fseek(fid, 8, 'cof');
             * 
             * info(p).NumPlanes = fread(fid, 1, 'uint16');
             * info(p).BitDepth = fread(fid, 1, 'uint16');
             * 
             * fseek(fid, 4, 'cof');
             * 
             * info(p).BitmapSize = fread(fid, 1, 'uint32');
             * 
             * % Headers must be at least 40 bytes, but they may be larger.
             * % Skip ahead to the begining of the colormap data.
             * info(p).ColormapOffset = info(p).ResourceDataOffset + ...
             * info(p).BitmapHeaderSize;
             * 
             * fseek(fid, info(p).ColormapOffset, 'bof');
             * 
             * % Read the RGBQUAD colormap: [blue green red reserved]
             * info(p).NumColormapEntries = info(p).NumPlanes * ...
             * 2^(info(p).BitDepth);
             * 
             * [data, count] = fread(fid, (info(p).NumColormapEntries)*4, 'uint8');
             * 
             * if (count ~= info(p).NumColormapEntries*4)
             * info = [];
             * msg = 'Truncated colormap data';
             * fclose(fid);
             * return;
             * end
             * 
             * % Throw away the reserved byte, swap red and blue, and rescale
             * data = reshape(data, 4, info(p).NumColormapEntries)';
             * cmap = data(:,1:3);
             * cmap = fliplr(cmap);
             * cmap = cmap ./ 255;
             * 
             * info(p).Colormap = cmap;
             * 
             * info(p).ColorType = 'indexed';
             * info(p).CompressionType = 'none';
             * info(p).ImageDataOffset = ftell(fid);
             * 
             * %
             * % Other validity checks
             * %
             * if ((info(p).Width < 0) | (info(p).Height < 0))
             * info = [];
             * msg = 'Corrupt ICO file: bad image dimensions.';
             * fclose(fid);
             * return;
             * end
             * end
             */
            for (; ; ) {
                mlfIndexAssign(
                  &info,
                  "(?).Filename",
                  mlfScalar(v_),
                  mclVsa(filename, "filename"));
                mlfIndexAssign(
                  &info,
                  "(?).FileModDate",
                  mlfScalar(v_),
                  mlfIndexRef(mclVsv(d, "d"), ".date"));
                mlfIndexAssign(
                  &info,
                  "(?).FileSize",
                  mlfScalar(v_),
                  mlfIndexRef(mclVsv(d, "d"), ".bytes"));
                mlfIndexAssign(&info, "(?).Format", mlfScalar(v_), _mxarray13_);
                mlfIndexAssign(
                  &info,
                  "(?).FormatSignature",
                  mlfScalar(v_),
                  mlfCtranspose(mclVv(sig, "sig")));
                mlfAssign(
                  &idpos,
                  mclPlus(
                    _mxarray25_, mclMtimes(_mxarray26_, mlfScalar(v_ - 1))));
                mclAssignAns(
                  &ans,
                  mlfFseek(
                    mclVv(fid, "fid"), mclVv(idpos, "idpos"), _mxarray27_));
                mlfIndexAssign(
                  &info,
                  "(?).Width",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray29_, NULL));
                mlfIndexAssign(
                  &info,
                  "(?).Height",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray29_, NULL));
                mclAssignAns(
                  &ans, mlfFseek(mclVv(fid, "fid"), _mxarray25_, _mxarray31_));
                mlfIndexAssign(
                  &info,
                  "(?).ResourceSize",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray33_, NULL));
                mlfIndexAssign(
                  &info,
                  "(?).ResourceDataOffset",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray33_, NULL));
                mclAssignAns(
                  &ans,
                  mclFeval(
                    mclAnsVarargout(),
                    mlxFseek,
                    mclVv(fid, "fid"),
                    mclVe(
                      mlfIndexRef(
                        mclVsv(info, "info"),
                        "(?).ResourceDataOffset",
                        mlfScalar(v_))),
                    _mxarray27_,
                    NULL));
                mlfIndexAssign(
                  &info,
                  "(?).BitmapHeaderSize",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray33_, NULL));
                mclAssignAns(
                  &ans, mlfFseek(mclVv(fid, "fid"), _mxarray35_, _mxarray31_));
                mlfIndexAssign(
                  &info,
                  "(?).NumPlanes",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray16_, NULL));
                mlfIndexAssign(
                  &info,
                  "(?).BitDepth",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray16_, NULL));
                mclAssignAns(
                  &ans, mlfFseek(mclVv(fid, "fid"), _mxarray36_, _mxarray31_));
                mlfIndexAssign(
                  &info,
                  "(?).BitmapSize",
                  mlfScalar(v_),
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray24_, _mxarray33_, NULL));
                mlfIndexAssign(
                  &info,
                  "(?).ColormapOffset",
                  mlfScalar(v_),
                  mclFeval(
                    mclValueVarargout(),
                    mlxPlus,
                    mclVe(
                      mlfIndexRef(
                        mclVsv(info, "info"),
                        "(?).ResourceDataOffset",
                        mlfScalar(v_))),
                    mclVe(
                      mlfIndexRef(
                        mclVsv(info, "info"),
                        "(?).BitmapHeaderSize",
                        mlfScalar(v_))),
                    NULL));
                mclAssignAns(
                  &ans,
                  mclFeval(
                    mclAnsVarargout(),
                    mlxFseek,
                    mclVv(fid, "fid"),
                    mclVe(
                      mlfIndexRef(
                        mclVsv(info, "info"),
                        "(?).ColormapOffset",
                        mlfScalar(v_))),
                    _mxarray27_,
                    NULL));
                mlfIndexAssign(
                  &info,
                  "(?).NumColormapEntries",
                  mlfScalar(v_),
                  mclFeval(
                    mclValueVarargout(),
                    mlxMtimes,
                    mclVe(
                      mlfIndexRef(
                        mclVsv(info, "info"), "(?).NumPlanes", mlfScalar(v_))),
                    mclFeval(
                      mclValueVarargout(),
                      mlxMpower,
                      _mxarray15_,
                      mclVe(
                        mlfIndexRef(
                          mclVsv(info, "info"), "(?).BitDepth", mlfScalar(v_))),
                      NULL),
                    NULL));
                mlfAssign(
                  &data,
                  mlfFread(
                    &count,
                    mclVv(fid, "fid"),
                    mclFeval(
                      mclValueVarargout(),
                      mlxMtimes,
                      mclVe(
                        mlfIndexRef(
                          mclVsv(info, "info"),
                          "(?).NumColormapEntries",
                          mlfScalar(v_))),
                      _mxarray36_,
                      NULL),
                    _mxarray29_,
                    NULL));
                if (mclNeBool(
                      mclVv(count, "count"),
                      mclFeval(
                        mclValueVarargout(),
                        mlxMtimes,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"),
                            "(?).NumColormapEntries",
                            mlfScalar(v_))),
                        _mxarray36_,
                        NULL))) {
                    mlfAssign(&info, _mxarray4_);
                    mlfAssign(msg, _mxarray37_);
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    goto return_;
                }
                mlfAssign(
                  &data,
                  mlfCtranspose(
                    mclVe(
                      mlfReshape(
                        mclVv(data, "data"),
                        _mxarray36_,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"),
                            "(?).NumColormapEntries",
                            mlfScalar(v_))),
                        NULL))));
                mlfAssign(
                  &cmap,
                  mclArrayRef2(
                    mclVsv(data, "data"),
                    mlfCreateColonIndex(),
                    mlfColon(_mxarray24_, _mxarray39_, NULL)));
                mlfAssign(&cmap, mlfFliplr(mclVv(cmap, "cmap")));
                mlfAssign(&cmap, mclRdivide(mclVv(cmap, "cmap"), _mxarray40_));
                mlfIndexAssign(
                  &info, "(?).Colormap", mlfScalar(v_), mclVsv(cmap, "cmap"));
                mlfIndexAssign(
                  &info, "(?).ColorType", mlfScalar(v_), _mxarray41_);
                mlfIndexAssign(
                  &info, "(?).CompressionType", mlfScalar(v_), _mxarray43_);
                mlfIndexAssign(
                  &info,
                  "(?).ImageDataOffset",
                  mlfScalar(v_),
                  mlfFtell(mclVv(fid, "fid")));
                {
                    mxArray * a_ = mclInitialize(
                                     mclFeval(
                                       mclValueVarargout(),
                                       mlxLt,
                                       mclVe(
                                         mlfIndexRef(
                                           mclVsv(info, "info"),
                                           "(?).Width",
                                           mlfScalar(v_))),
                                       _mxarray45_,
                                       NULL));
                    if (mlfTobool(a_)
                        || mlfTobool(
                             mclOr(
                               a_,
                               mclFeval(
                                 mclValueVarargout(),
                                 mlxLt,
                                 mclVe(
                                   mlfIndexRef(
                                     mclVsv(info, "info"),
                                     "(?).Height",
                                     mlfScalar(v_))),
                                 _mxarray45_,
                                 NULL)))) {
                        mxDestroyArray(a_);
                        mlfAssign(&info, _mxarray4_);
                        mlfAssign(msg, _mxarray46_);
                        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                        goto return_;
                    } else {
                        mxDestroyArray(a_);
                    }
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&p, mlfScalar(v_));
        }
    }
    /*
     * 
     * fclose(fid);
     */
    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/imicoinfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/imicoinfo");
    mxDestroyArray(fid);
    mxDestroyArray(m);
    mxDestroyArray(d);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(imcount);
    mxDestroyArray(p);
    mxDestroyArray(idpos);
    mxDestroyArray(data);
    mxDestroyArray(count);
    mxDestroyArray(cmap);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
