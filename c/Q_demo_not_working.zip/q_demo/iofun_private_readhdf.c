/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_readhdf.h"
#include "iofun_private_imhdfinfo.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"

static mxChar _array1_[160] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'h', 'd', 'f', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'h', 'd', 'f', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p', 'u',
                                't', 's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[159] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'h', 'd', 'f', ' ', 'L',
                                'i', 'n', 'e', ':', ' ', '1', ' ', 'C', 'o',
                                'l', 'u', 'm', 'n', ':', ' ', '1', ' ', 'T',
                                'h', 'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '"', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'r', 'e', 'a', 'd', 'h', 'd', 'f', '"', ' ',
                                'w', 'a', 's', ' ', 'c', 'a', 'l', 'l', 'e',
                                'd', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'o',
                                'r', 'e', ' ', 't', 'h', 'a', 'n', ' ', 't',
                                'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a', 'r',
                                'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u', 't',
                                's', ' ', '(', '2', ')', '.' };
static mxArray * _mxarray2_;

static mxChar _array5_[152] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'h',
                                'd', 'f', '/', 'h', 'd', 'f', 'e', 'r', 'r',
                                'o', 'r', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', '0', '4', ' ', 'C', 'o', 'l', 'u', 'm',
                                'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '"', 'r', 'e', 'a', 'd', 'h', 'd', 'f', '/',
                                'h', 'd', 'f', 'e', 'r', 'r', 'o', 'r', '"',
                                ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                'r', ' ', 'o', 'f', ' ', 'o', 'u', 't', 'p',
                                'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray4_;

static mxChar _array7_[151] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'r', 'e', 'a', 'd', 'h',
                                'd', 'f', '/', 'h', 'd', 'f', 'e', 'r', 'r',
                                'o', 'r', ' ', 'L', 'i', 'n', 'e', ':', ' ',
                                '1', '0', '4', ' ', 'C', 'o', 'l', 'u', 'm',
                                'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '"', 'r', 'e', 'a', 'd', 'h', 'd', 'f', '/',
                                'h', 'd', 'f', 'e', 'r', 'r', 'o', 'r', '"',
                                ' ', 'w', 'a', 's', ' ', 'c', 'a', 'l', 'l',
                                'e', 'd', ' ', 'w', 'i', 't', 'h', ' ', 'm',
                                'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                't', 'h', 'e', ' ', 'd', 'e', 'c', 'l', 'a',
                                'r', 'e', 'd', ' ', 'n', 'u', 'm', 'b', 'e',
                                'r', ' ', 'o', 'f', ' ', 'i', 'n', 'p', 'u',
                                't', 's', ' ', '(', '0', ')', '.' };
static mxArray * _mxarray6_;
static mxArray * _mxarray8_;
static mxArray * _mxarray9_;

static mxChar _array11_[57] = { 'N', 'o', ' ', 'r', 'a', 's', 't', 'e', 'r',
                                ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'f', 'o',
                                'u', 'n', 'd', ' ', 'w', 'i', 't', 'h', ' ',
                                't', 'h', 'e', ' ', 's', 'p', 'e', 'c', 'i',
                                'f', 'i', 'e', 'd', ' ', 'r', 'e', 'f', 'e',
                                'r', 'e', 'n', 'c', 'e', ' ', 'n', 'u', 'm',
                                'b', 'e', 'r' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;

static mxChar _array14_[4] = { 'D', 'F', 'R', '8' };
static mxArray * _mxarray13_;

static mxChar _array16_[7] = { 'r', 'e', 's', 't', 'a', 'r', 't' };
static mxArray * _mxarray15_;

static mxChar _array18_[7] = { 'r', 'e', 'a', 'd', 'r', 'e', 'f' };
static mxArray * _mxarray17_;

static mxChar _array20_[8] = { 'g', 'e', 't', 'i', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray19_;
static mxArray * _mxarray21_;
static mxArray * _mxarray22_;

static mxChar _array24_[4] = { 'D', 'F', '2', '4' };
static mxArray * _mxarray23_;

static mxChar _array26_[5] = { 'r', 'e', 'q', 'i', 'l' };
static mxArray * _mxarray25_;

static mxChar _array28_[5] = { 'p', 'i', 'x', 'e', 'l' };
static mxArray * _mxarray27_;

static double _array30_[3] = { 3.0, 2.0, 1.0 };
static mxArray * _mxarray29_;

static mxChar _array32_[4] = { 'l', 'i', 'n', 'e' };
static mxArray * _mxarray31_;

static double _array34_[3] = { 3.0, 1.0, 2.0 };
static mxArray * _mxarray33_;

static mxChar _array36_[9] = { 'c', 'o', 'm', 'p', 'o', 'n', 'e', 'n', 't' };
static mxArray * _mxarray35_;

static double _array38_[3] = { 2.0, 1.0, 3.0 };
static mxArray * _mxarray37_;
static mxArray * _mxarray39_;

static mxChar _array41_[49] = { 'C', 'a', 'n', ' ', 'o', 'n', 'l', 'y', ' ',
                                'r', 'e', 'a', 'd', ' ', '1', '-', ' ', 'o',
                                'r', ' ', '3', '-', 'c', 'o', 'm', 'p', 'o',
                                'n', 'e', 'n', 't', ' ', 'H', 'D', 'F', ' ',
                                'r', 'a', 's', 't', 'e', 'r', ' ', 'i', 'm',
                                'a', 'g', 'e', 's' };
static mxArray * _mxarray40_;

static mxChar _array43_[54] = { 'T', 'h', 'e', ' ', 'N', 'C', 'S', 'A',
                                ' ', 'H', 'D', 'F', ' ', 'l', 'i', 'b',
                                'r', 'a', 'r', 'y', ' ', 'r', 'e', 'p',
                                'o', 'r', 't', 'e', 'd', ' ', 't', 'h',
                                'e', ' ', 'f', 'o', 'l', 'l', 'o', 'w',
                                'i', 'n', 'g', ' ', 'e', 'r', 'r', 'o',
                                'r', ':', 0x005c, 'n', '%', 's' };
static mxArray * _mxarray42_;

static mxChar _array45_[2] = { 'H', 'E' };
static mxArray * _mxarray44_;

static mxChar _array47_[6] = { 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray46_;

static mxChar _array49_[5] = { 'v', 'a', 'l', 'u', 'e' };
static mxArray * _mxarray48_;

void InitializeModule_iofun_private_readhdf(void) {
    _mxarray0_ = mclInitializeString(160, _array1_);
    _mxarray2_ = mclInitializeString(159, _array3_);
    _mxarray4_ = mclInitializeString(152, _array5_);
    _mxarray6_ = mclInitializeString(151, _array7_);
    _mxarray8_ = mclInitializeDouble(1.0);
    _mxarray9_ = mclInitializeDouble(2.0);
    _mxarray10_ = mclInitializeString(57, _array11_);
    _mxarray12_ = mclInitializeDouble(-1.0);
    _mxarray13_ = mclInitializeString(4, _array14_);
    _mxarray15_ = mclInitializeString(7, _array16_);
    _mxarray17_ = mclInitializeString(7, _array18_);
    _mxarray19_ = mclInitializeString(8, _array20_);
    _mxarray21_ = mclInitializeDouble(255.0);
    _mxarray22_ = mclInitializeDouble(3.0);
    _mxarray23_ = mclInitializeString(4, _array24_);
    _mxarray25_ = mclInitializeString(5, _array26_);
    _mxarray27_ = mclInitializeString(5, _array28_);
    _mxarray29_ = mclInitializeDoubleVector(1, 3, _array30_);
    _mxarray31_ = mclInitializeString(4, _array32_);
    _mxarray33_ = mclInitializeDoubleVector(1, 3, _array34_);
    _mxarray35_ = mclInitializeString(9, _array36_);
    _mxarray37_ = mclInitializeDoubleVector(1, 3, _array38_);
    _mxarray39_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray40_ = mclInitializeString(49, _array41_);
    _mxarray42_ = mclInitializeString(54, _array43_);
    _mxarray44_ = mclInitializeString(2, _array45_);
    _mxarray46_ = mclInitializeString(6, _array47_);
    _mxarray48_ = mclInitializeString(5, _array49_);
}

void TerminateModule_iofun_private_readhdf(void) {
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfReadhdf_hdferror(void);
static void mlxReadhdf_hdferror(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static mxArray * Miofun_private_readhdf(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * ref);
static mxArray * Mreadhdf_hdferror(int nargout_);

static mexFunctionTableEntry local_function_table_[1]
  = { { "hdferror", mlxReadhdf_hdferror, 0, 1, NULL } };

_mexLocalFunctionTable _local_function_table_iofun_private_readhdf
  = { 1, local_function_table_ };

/*
 * The function "mlfIofun_private_readhdf" contains the normal interface for
 * the "iofun/private/readhdf" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readhdf.m" (lines 1-104). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_readhdf(mxArray * * map,
                                   mxArray * filename,
                                   mxArray * ref) {
    int nargout = 1;
    mxArray * X = mclGetUninitializedArray();
    mxArray * map__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 2, map, filename, ref);
    if (map != NULL) {
        ++nargout;
    }
    X = Miofun_private_readhdf(&map__, nargout, filename, ref);
    mlfRestorePreviousContext(1, 2, map, filename, ref);
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlxIofun_private_readhdf" contains the feval interface for the
 * "iofun/private/readhdf" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readhdf.m" (lines 1-104). The
 * feval function calls the implementation version of iofun/private/readhdf
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_readhdf(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Miofun_private_readhdf(&mplhs[1], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfReadhdf_hdferror" contains the normal interface for the
 * "readhdf/hdferror" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readhdf.m" (lines 104-109). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfReadhdf_hdferror(void) {
    int nargout = 1;
    mxArray * str = mclGetUninitializedArray();
    mlfEnterNewContext(0, 0);
    str = Mreadhdf_hdferror(nargout);
    mlfRestorePreviousContext(0, 0);
    return mlfReturnValue(str);
}

/*
 * The function "mlxReadhdf_hdferror" contains the feval interface for the
 * "readhdf/hdferror" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readhdf.m" (lines 104-109). The
 * feval function calls the implementation version of readhdf/hdferror through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxReadhdf_hdferror(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray4_);
    }
    if (nrhs > 0) {
        mlfError(_mxarray6_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    mlfEnterNewContext(0, 0);
    mplhs[0] = Mreadhdf_hdferror(nlhs);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
}

/*
 * The function "Miofun_private_readhdf" is the implementation version of the
 * "iofun/private/readhdf" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readhdf.m" (lines 1-104). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [X,map] = readhdf(filename, ref)
 */
static mxArray * Miofun_private_readhdf(mxArray * * map,
                                        int nargout_,
                                        mxArray * filename,
                                        mxArray * ref) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readhdf);
    int nargin_ = mclNargin(2, filename, ref, NULL);
    mxArray * X = mclGetUninitializedArray();
    mxArray * status = mclGetUninitializedArray();
    mxArray * FAIL = mclGetUninitializedArray();
    mxArray * il = mclGetUninitializedArray();
    mxArray * ncomp = mclGetUninitializedArray();
    mxArray * refNums = mclGetUninitializedArray();
    mxArray * idx = mclGetUninitializedArray();
    mxArray * info = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&filename);
    mclCopyArray(&ref);
    /*
     * %READHDF Read an image from an HDF file.
     * %   [X,MAP] = READHDF(FILENAME) reads the first raster image data
     * %   set from the HDF file FILENAME.  X will be a 2-D uint8 array
     * %   if the specified data set contains an 8-bit image.  It will
     * %   be an M-by-N-by-3 uint8 array if the specified data set
     * %   contains a 24-bit image.  MAP may be empty if the data set
     * %   does not have an associated colormap.
     * %
     * %   ... = READHDF(FILENAME, 'Reference', ref) reads the raster
     * %   image data set with the specified reference number.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.10 $  $Date: 2000/06/01 04:17:06 $
     * 
     * error(nargchk(1, 2, nargin));
     */
    mlfError(mclVe(mlfNargchk(_mxarray8_, _mxarray9_, mlfScalar(nargin_))));
    /*
     * 
     * info = imhdfinfo(filename);
     */
    mlfAssign(
      &info, mlfIofun_private_imhdfinfo(NULL, mclVa(filename, "filename")));
    /*
     * 
     * if (nargin < 2)
     */
    if (nargin_ < 2) {
        /*
         * idx = 1;
         */
        mlfAssign(&idx, _mxarray8_);
        /*
         * ref = info(1).Reference;   % ref not specified, so get the first one.
         */
        mlfAssign(
          &ref, mlfIndexRef(mclVsv(info, "info"), "(?).Reference", _mxarray8_));
    /*
     * else
     */
    } else {
        /*
         * refNums = [info.Reference];            % comma-separated list syntax
         */
        mlfAssign(
          &refNums,
          mlfHorzcat(
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".Reference")), NULL));
        /*
         * idx = find(ref == refNums);
         */
        mlfAssign(
          &idx,
          mlfFind(
            NULL, NULL, mclEq(mclVa(ref, "ref"), mclVv(refNums, "refNums"))));
        /*
         * if (isempty(idx))
         */
        if (mlfTobool(mclVe(mlfIsempty(mclVv(idx, "idx"))))) {
            /*
             * error('No raster image found with the specified reference number');
             */
            mlfError(_mxarray10_);
        /*
         * end
         */
        }
        /*
         * idx = idx(1);
         */
        mlfAssign(&idx, mclIntArrayRef1(mclVsv(idx, "idx"), 1));
    /*
     * end
     */
    }
    /*
     * 
     * ref = info(idx).Reference;
     */
    mlfAssign(
      &ref,
      mlfIndexRef(mclVsv(info, "info"), "(?).Reference", mclVsv(idx, "idx")));
    /*
     * ncomp = info(idx).NumComponents;
     */
    mlfAssign(
      &ncomp,
      mlfIndexRef(
        mclVsv(info, "info"), "(?).NumComponents", mclVsv(idx, "idx")));
    /*
     * il = info(idx).Interlace;
     */
    mlfAssign(
      &il,
      mlfIndexRef(mclVsv(info, "info"), "(?).Interlace", mclVsv(idx, "idx")));
    /*
     * 
     * FAIL = -1;
     */
    mlfAssign(&FAIL, _mxarray12_);
    /*
     * 
     * if (ncomp == 1)
     */
    if (mclEqBool(mclVv(ncomp, "ncomp"), _mxarray8_)) {
        /*
         * hdf('DFR8', 'restart');
         */
        mclAssignAns(
          &ans, mlfNHdf(0, mclAnsVarargout(), _mxarray13_, _mxarray15_, NULL));
        /*
         * 
         * status = hdf('DFR8', 'readref', filename, ref);
         */
        mlfAssign(
          &status,
          mlfNHdf(
            0,
            mclValueVarargout(),
            _mxarray13_,
            _mxarray17_,
            mclVa(filename, "filename"),
            mclVa(ref, "ref"),
            NULL));
        /*
         * if (status == FAIL)
         */
        if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
            /*
             * error(hdferror);
             */
            mlfError(mclVe(mlfReadhdf_hdferror()));
        /*
         * end
         */
        }
        /*
         * 
         * [X, map, status] = hdf('DFR8', 'getimage', filename);
         */
        mlfNHdf(
          0,
          mlfVarargout(&X, map, &status, NULL),
          _mxarray13_,
          _mxarray19_,
          mclVa(filename, "filename"),
          NULL);
        /*
         * if (status == FAIL)
         */
        if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
            /*
             * error(hdferror);
             */
            mlfError(mclVe(mlfReadhdf_hdferror()));
        /*
         * end
         */
        }
        /*
         * 
         * X = X';  % HDF uses C-style dimension ordering
         */
        mlfAssign(&X, mlfCtranspose(mclVv(X, "X")));
        /*
         * map = double(map')/255;
         */
        mlfAssign(
          map,
          mclMrdivide(
            mclVe(mlfDouble(mlfCtranspose(mclVv(*map, "map")))), _mxarray21_));
    /*
     * 
     * elseif (ncomp == 3)
     */
    } else if (mclEqBool(mclVv(ncomp, "ncomp"), _mxarray22_)) {
        /*
         * hdf('DF24', 'restart');
         */
        mclAssignAns(
          &ans, mlfNHdf(0, mclAnsVarargout(), _mxarray23_, _mxarray15_, NULL));
        /*
         * 
         * %
         * % The following line is a work-around for the fact that
         * % DF24restart apparently does not reset the reqil.
         * % Also, reqil of other than 'pixel' doesn't appear
         * % to supported in HDF v4r1.
         * %
         * status = hdf('DF24', 'reqil', 'pixel');
         */
        mlfAssign(
          &status,
          mlfNHdf(
            0,
            mclValueVarargout(),
            _mxarray23_,
            _mxarray25_,
            _mxarray27_,
            NULL));
        /*
         * if (status == FAIL)
         */
        if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
            /*
             * error(hdferror);
             */
            mlfError(mclVe(mlfReadhdf_hdferror()));
        /*
         * end
         */
        }
        /*
         * 
         * status = hdf('DF24', 'readref', filename, ref);
         */
        mlfAssign(
          &status,
          mlfNHdf(
            0,
            mclValueVarargout(),
            _mxarray23_,
            _mxarray17_,
            mclVa(filename, "filename"),
            mclVa(ref, "ref"),
            NULL));
        /*
         * if (status == FAIL)
         */
        if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
            /*
             * error(hdferror);
             */
            mlfError(mclVe(mlfReadhdf_hdferror()));
        /*
         * end
         */
        }
        /*
         * 
         * [X, status] = hdf('DF24', 'getimage', filename);
         */
        mlfNHdf(
          0,
          mlfVarargout(&X, &status, NULL),
          _mxarray23_,
          _mxarray19_,
          mclVa(filename, "filename"),
          NULL);
        /*
         * if (status == FAIL)
         */
        if (mclEqBool(mclVv(status, "status"), mclVv(FAIL, "FAIL"))) {
            /*
             * error(hdferror);
             */
            mlfError(mclVe(mlfReadhdf_hdferror()));
        /*
         * end
         */
        }
        /*
         * 
         * % Compensate for file's interlace and the fact that
         * % HDF uses C-style dimension ordering
         * switch il
         */
        {
            mxArray * v_ = mclInitialize(mclVv(il, "il"));
            if (mclSwitchCompare(v_, _mxarray27_)) {
                /*
                 * case 'pixel'
                 * X = permute(X,[3 2 1]);  % HDF uses C-style dimension ordering
                 */
                mlfAssign(&X, mlfPermute(mclVv(X, "X"), _mxarray29_));
            /*
             * 
             * case 'line'
             */
            } else if (mclSwitchCompare(v_, _mxarray31_)) {
                /*
                 * X = permute(X,[3 1 2]);
                 */
                mlfAssign(&X, mlfPermute(mclVv(X, "X"), _mxarray33_));
            /*
             * 
             * case 'component'
             */
            } else if (mclSwitchCompare(v_, _mxarray35_)) {
                /*
                 * X = permute(X,[2 1 3]);
                 */
                mlfAssign(&X, mlfPermute(mclVv(X, "X"), _mxarray37_));
            /*
             * end
             */
            }
            mxDestroyArray(v_);
        }
        /*
         * 
         * map = [];
         */
        mlfAssign(map, _mxarray39_);
    /*
     * 
     * else
     */
    } else {
        /*
         * error('Can only read 1- or 3-component HDF raster images');
         */
        mlfError(_mxarray40_);
    /*
     * 
     * end
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "iofun/private/readhdf");
    mclValidateOutput(*map, 2, nargout_, "map", "iofun/private/readhdf");
    mxDestroyArray(ans);
    mxDestroyArray(info);
    mxDestroyArray(idx);
    mxDestroyArray(refNums);
    mxDestroyArray(ncomp);
    mxDestroyArray(il);
    mxDestroyArray(FAIL);
    mxDestroyArray(status);
    mxDestroyArray(ref);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * %%%
     * %%% Function hdferror
     * %%%
     * function str = hdferror()
     * %HDFERROR The current HDF error string.
     * 
     * str = sprintf('The NCSA HDF library reported the following error:\n%s', ...
     * hdf('HE', 'string', hdf('HE', 'value', 1)));
     */
}

/*
 * The function "Mreadhdf_hdferror" is the implementation version of the
 * "readhdf/hdferror" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\readhdf.m" (lines 104-109). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function str = hdferror()
 */
static mxArray * Mreadhdf_hdferror(int nargout_) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_readhdf);
    mxArray * str = mclGetUninitializedArray();
    /*
     * %HDFERROR The current HDF error string.
     * 
     * str = sprintf('The NCSA HDF library reported the following error:\n%s', ...
     */
    mlfAssign(
      &str,
      mlfSprintf(
        NULL,
        _mxarray42_,
        mclVe(
          mlfNHdf(
            0,
            mclValueVarargout(),
            _mxarray44_,
            _mxarray46_,
            mclVe(
              mlfNHdf(
                0,
                mclValueVarargout(),
                _mxarray44_,
                _mxarray48_,
                _mxarray8_,
                NULL)),
            NULL)),
        NULL));
    mclValidateOutput(str, 1, nargout_, "str", "readhdf/hdferror");
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return str;
    /*
     * hdf('HE', 'string', hdf('HE', 'value', 1)));
     */
}
