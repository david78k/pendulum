/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imbmpinfo.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'b', 'm', 'p', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'b', 'm', 'p', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'b', 'm', 'p', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'b', 'm', 'p', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray6_;

static mxChar _array9_[1] = { 'r' };
static mxArray * _mxarray8_;

static mxChar _array11_[7] = { 'i', 'e', 'e', 'e', '-', 'l', 'e' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;

static mxChar _array14_[3] = { 'b', 'm', 'p' };
static mxArray * _mxarray13_;
static mxArray * _mxarray15_;

static mxChar _array17_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray16_;

static mxChar _array19_[10] = { 'E', 'm', 'p', 't', 'y',
                                ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray18_;

static mxChar _array21_[2] = { 'B', 'M' };
static mxArray * _mxarray20_;
static mxArray * _mxarray22_;

static mxChar _array24_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray23_;
static mxArray * _mxarray25_;

static mxChar _array27_[3] = { 'c', 'o', 'f' };
static mxArray * _mxarray26_;

static mxChar _array29_[16] = { 'T', 'r', 'u', 'n', 'c', 'a', 't', 'e',
                                'd', ' ', 'h', 'e', 'a', 'd', 'e', 'r' };
static mxArray * _mxarray28_;
static mxArray * _mxarray30_;

static mxChar _array32_[5] = { 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray31_;
static mxArray * _mxarray33_;

static mxChar _array35_[24] = { 'V', 'e', 'r', 's', 'i', 'o', 'n', ' ',
                                '1', ' ', '(', 'I', 'B', 'M', ' ', 'O',
                                'S', '/', '2', ' ', '1', '.', 'x', ')' };
static mxArray * _mxarray34_;
static mxArray * _mxarray36_;

static mxChar _array38_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray37_;

static mxChar _array40_[33] = { 'V', 'e', 'r', 's', 'i', 'o', 'n', ' ', '2',
                                ' ', '(', 'M', 'i', 'c', 'r', 'o', 's', 'o',
                                'f', 't', ' ', 'W', 'i', 'n', 'd', 'o', 'w',
                                's', ' ', '2', '.', 'x', ')' };
static mxArray * _mxarray39_;
static mxArray * _mxarray41_;
static mxArray * _mxarray42_;

static mxChar _array44_[32] = { 'V', 'e', 'r', 's', 'i', 'o', 'n', ' ',
                                '3', ' ', '(', 'M', 'i', 'c', 'r', 'o',
                                's', 'o', 'f', 't', ' ', 'W', 'i', 'n',
                                'd', 'o', 'w', 's', ' ', 'N', 'T', ')' };
static mxArray * _mxarray43_;

static mxChar _array46_[33] = { 'V', 'e', 'r', 's', 'i', 'o', 'n', ' ', '3',
                                ' ', '(', 'M', 'i', 'c', 'r', 'o', 's', 'o',
                                'f', 't', ' ', 'W', 'i', 'n', 'd', 'o', 'w',
                                's', ' ', '3', '.', 'x', ')' };
static mxArray * _mxarray45_;
static mxArray * _mxarray47_;

static mxChar _array49_[32] = { 'V', 'e', 'r', 's', 'i', 'o', 'n', ' ',
                                '4', ' ', '(', 'M', 'i', 'c', 'r', 'o',
                                's', 'o', 'f', 't', ' ', 'W', 'i', 'n',
                                'd', 'o', 'w', 's', ' ', '9', '5', ')' };
static mxArray * _mxarray48_;
static mxArray * _mxarray50_;

static mxChar _array52_[24] = { 'V', 'e', 'r', 's', 'i', 'o', 'n', ' ',
                                '2', ' ', '(', 'I', 'B', 'M', ' ', 'O',
                                'S', '/', '2', ' ', '2', '.', 'x', ')' };
static mxArray * _mxarray51_;

static mxChar _array54_[16] = { 'C', 'o', 'r', 'r', 'u', 'p', 't', 'e',
                                'd', ' ', 'h', 'e', 'a', 'd', 'e', 'r' };
static mxArray * _mxarray53_;

static mxChar _array56_[4] = { 'n', 'o', 'n', 'e' };
static mxArray * _mxarray55_;

static mxChar _array58_[9] = { '8', '-', 'b', 'i', 't', ' ', 'R', 'L', 'E' };
static mxArray * _mxarray57_;

static mxChar _array60_[9] = { '4', '-', 'b', 'i', 't', ' ', 'R', 'L', 'E' };
static mxArray * _mxarray59_;

static mxChar _array62_[9] = { 'b', 'i', 't', 'f', 'i', 'e', 'l', 'd', 's' };
static mxArray * _mxarray61_;

static mxChar _array64_[10] = { 'H', 'u', 'f', 'f', 'm',
                                'a', 'n', ' ', '1', 'D' };
static mxArray * _mxarray63_;

static mxChar _array66_[10] = { '2', '4', '-', 'b', 'i',
                                't', ' ', 'R', 'L', 'E' };
static mxArray * _mxarray65_;

static mxChar _array68_[29] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                'i', 'z', 'e', 'd', ' ', 'c', 'o', 'm',
                                'p', 'r', 'e', 's', 's', 'i', 'o', 'n',
                                ' ', 't', 'y', 'p', 'e' };
static mxArray * _mxarray67_;

static mxChar _array70_[2] = { 'B', 'A' };
static mxArray * _mxarray69_;

static mxChar _array72_[47] = { 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r',
                                't', 'e', 'd', ' ', 'f', 'o', 'r', 'm',
                                'a', 't', ';', ' ', 'm', 'a', 'y', ' ',
                                'b', 'e', ' ', 'a', 'n', ' ', 'O', 'S',
                                '/', '2', ' ', 'b', 'i', 't', 'm', 'a',
                                'p', ' ', 'a', 'r', 'r', 'a', 'y' };
static mxArray * _mxarray71_;

static mxChar _array74_[14] = { 'N', 'o', 't', ' ', 'a', ' ', 'B',
                                'M', 'P', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray73_;

static mxChar _array76_[23] = { 'T', 'r', 'u', 'n', 'c', 'a', 't', 'e',
                                'd', ' ', 'c', 'o', 'l', 'o', 'r', 'm',
                                'a', 'p', ' ', 'd', 'a', 't', 'a' };
static mxArray * _mxarray75_;
static mxArray * _mxarray77_;

static mxChar _array79_[5] = { 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray78_;
static mxArray * _mxarray80_;

static mxChar _array82_[63] = { 'B', 'M', 'P', ' ', 'V', 'e', 'r', 's', 'i',
                                'o', 'n', ' ', '3', ' ', '(', 'M', 'i', 'c',
                                'r', 'o', 's', 'o', 'f', 't', ' ', 'W', 'i',
                                'n', 'd', 'o', 'w', 's', ' ', 'N', 'T', ')',
                                ' ', 'f', 'i', 'l', 'e', ' ', 'a', 'p', 'p',
                                'e', 'a', 'r', 's', ' ', 't', 'o', ' ', 'b',
                                'e', ' ', 'c', 'o', 'r', 'r', 'u', 'p', 't' };
static mxArray * _mxarray81_;
static mxArray * _mxarray83_;

static mxChar _array85_[63] = { 'B', 'M', 'P', ' ', 'V', 'e', 'r', 's', 'i',
                                'o', 'n', ' ', '4', ' ', '(', 'M', 'i', 'c',
                                'r', 'o', 's', 'o', 'f', 't', ' ', 'W', 'i',
                                'n', 'd', 'o', 'w', 's', ' ', '9', '5', ')',
                                ' ', 'f', 'i', 'l', 'e', ' ', 'a', 'p', 'p',
                                'e', 'a', 'r', 's', ' ', 't', 'o', ' ', 'b',
                                'e', ' ', 'c', 'o', 'r', 'r', 'u', 'p', 't' };
static mxArray * _mxarray84_;

static mxChar _array87_[12] = { 'p', 'i', 'x', 'e', 'l', 's',
                                '/', 'm', 'e', 't', 'e', 'r' };
static mxArray * _mxarray86_;

static mxChar _array89_[7] = { 'u', 'n', 'k', 'n', 'o', 'w', 'n' };
static mxArray * _mxarray88_;

static mxChar _array91_[15] = { 'e', 'r', 'r', 'o', 'r', ' ', 'd', 'i',
                                'f', 'f', 'u', 's', 'i', 'o', 'n' };
static mxArray * _mxarray90_;

static mxChar _array93_[5] = { 'P', 'A', 'N', 'D', 'A' };
static mxArray * _mxarray92_;

static mxChar _array95_[12] = { 's', 'u', 'p', 'e', 'r', '-',
                                'c', 'i', 'r', 'c', 'l', 'e' };
static mxArray * _mxarray94_;

static mxChar _array97_[3] = { 'R', 'G', 'B' };
static mxArray * _mxarray96_;

static mxChar _array99_[34] = { 'P', 'r', 'o', 'b', 'l', 'e', 'm', ' ', 'i',
                                'd', 'e', 'n', 't', 'i', 'f', 'y', 'i', 'n',
                                'g', ' ', 'f', 'o', 'r', 'm', 'a', 't', ' ',
                                'v', 'e', 'r', 's', 'i', 'o', 'n' };
static mxArray * _mxarray98_;

static mxChar _array101_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray100_;
static mxArray * _mxarray102_;

static mxChar _array104_[9] = { 'g', 'r', 'a', 'y', 's', 'c', 'a', 'l', 'e' };
static mxArray * _mxarray103_;

static mxChar _array106_[9] = { 't', 'r', 'u', 'e', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray105_;

static mxChar _array108_[38] = { 'C', 'o', 'r', 'r', 'u', 'p', 't', ' ',
                                 'B', 'M', 'P', ' ', 'f', 'i', 'l', 'e',
                                 ':', ' ', 'b', 'a', 'd', ' ', 'i', 'm',
                                 'a', 'g', 'e', ' ', 'd', 'i', 'm', 'e',
                                 'n', 's', 'i', 'o', 'n', 's' };
static mxArray * _mxarray107_;

void InitializeModule_iofun_private_imbmpinfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(7, _array11_);
    _mxarray12_ = mclInitializeDouble(-1.0);
    _mxarray13_ = mclInitializeString(3, _array14_);
    _mxarray15_ = mclInitializeDouble(2.0);
    _mxarray16_ = mclInitializeString(5, _array17_);
    _mxarray18_ = mclInitializeString(10, _array19_);
    _mxarray20_ = mclInitializeString(2, _array21_);
    _mxarray22_ = mclInitializeDouble(1.0);
    _mxarray23_ = mclInitializeString(6, _array24_);
    _mxarray25_ = mclInitializeDouble(4.0);
    _mxarray26_ = mclInitializeString(3, _array27_);
    _mxarray28_ = mclInitializeString(16, _array29_);
    _mxarray30_ = mclInitializeDouble(12.0);
    _mxarray31_ = mclInitializeString(5, _array32_);
    _mxarray33_ = mclInitializeDouble(0.0);
    _mxarray34_ = mclInitializeString(24, _array35_);
    _mxarray36_ = mclInitializeDouble(-4.0);
    _mxarray37_ = mclInitializeString(6, _array38_);
    _mxarray39_ = mclInitializeString(33, _array40_);
    _mxarray41_ = mclInitializeDouble(40.0);
    _mxarray42_ = mclInitializeDouble(3.0);
    _mxarray43_ = mclInitializeString(32, _array44_);
    _mxarray45_ = mclInitializeString(33, _array46_);
    _mxarray47_ = mclInitializeDouble(108.0);
    _mxarray48_ = mclInitializeString(32, _array49_);
    _mxarray50_ = mclInitializeDouble(64.0);
    _mxarray51_ = mclInitializeString(24, _array52_);
    _mxarray53_ = mclInitializeString(16, _array54_);
    _mxarray55_ = mclInitializeString(4, _array56_);
    _mxarray57_ = mclInitializeString(9, _array58_);
    _mxarray59_ = mclInitializeString(9, _array60_);
    _mxarray61_ = mclInitializeString(9, _array62_);
    _mxarray63_ = mclInitializeString(10, _array64_);
    _mxarray65_ = mclInitializeString(10, _array66_);
    _mxarray67_ = mclInitializeString(29, _array68_);
    _mxarray69_ = mclInitializeString(2, _array70_);
    _mxarray71_ = mclInitializeString(47, _array72_);
    _mxarray73_ = mclInitializeString(14, _array74_);
    _mxarray75_ = mclInitializeString(23, _array76_);
    _mxarray77_ = mclInitializeDouble(255.0);
    _mxarray78_ = mclInitializeString(5, _array79_);
    _mxarray80_ = mclInitializeDouble(32.0);
    _mxarray81_ = mclInitializeString(63, _array82_);
    _mxarray83_ = mclInitializeDouble(16.0);
    _mxarray84_ = mclInitializeString(63, _array85_);
    _mxarray86_ = mclInitializeString(12, _array87_);
    _mxarray88_ = mclInitializeString(7, _array89_);
    _mxarray90_ = mclInitializeString(15, _array91_);
    _mxarray92_ = mclInitializeString(5, _array93_);
    _mxarray94_ = mclInitializeString(12, _array95_);
    _mxarray96_ = mclInitializeString(3, _array97_);
    _mxarray98_ = mclInitializeString(34, _array99_);
    _mxarray100_ = mclInitializeString(7, _array101_);
    _mxarray102_ = mclInitializeDouble(8.0);
    _mxarray103_ = mclInitializeString(9, _array104_);
    _mxarray105_ = mclInitializeString(9, _array106_);
    _mxarray107_ = mclInitializeString(38, _array108_);
}

void TerminateModule_iofun_private_imbmpinfo(void) {
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray105_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray102_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray98_);
    mxDestroyArray(_mxarray96_);
    mxDestroyArray(_mxarray94_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray90_);
    mxDestroyArray(_mxarray88_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_imbmpinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_imbmpinfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_imbmpinfo" contains the normal interface for
 * the "iofun/private/imbmpinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imbmpinfo.m" (lines 1-470). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imbmpinfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_imbmpinfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_imbmpinfo" contains the feval interface for
 * the "iofun/private/imbmpinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imbmpinfo.m" (lines 1-470). The
 * feval function calls the implementation version of iofun/private/imbmpinfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imbmpinfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imbmpinfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_imbmpinfo" is the implementation version of the
 * "iofun/private/imbmpinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imbmpinfo.m" (lines 1-470). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imbmpinfo(filename)
 */
static mxArray * Miofun_private_imbmpinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imbmpinfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * encoding = mclGetUninitializedArray();
    mxArray * halftoning = mclGetUninitializedArray();
    mxArray * units = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * map = mclGetUninitializedArray();
    mxArray * compression = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * d = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMBMPINFO Get information about the image in a BMP file.
     * %   [INFO,MSG] = IMBMPINFO(FILENAME) returns information about
     * %   the image contained in a BMP file.  If the attempt fails for
     * %   some reason (e.g. the file does not exist or is not a BMP
     * %   file), then INFO is empty and MSG is a string containing a
     * %   diagnostic message.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.10 $  $Date: 2000/06/23 15:37:52 $
     * 
     * %   Required reading before editing this file: Encyclopedia of
     * %   Graphics File Formats, 2nd ed., pp. 572-591, pp. 630-650.
     * 
     * % This function should not call error()!  -SLE
     * 
     * info = [];
     */
    mlfAssign(&info, _mxarray4_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray5_);
    /*
     * 
     * if (~isstr(filename))
     */
    if (mclNotBool(mclVe(mlfIsstr(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray6_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * [fid,m] = fopen(filename, 'r', 'ieee-le');  % BMP files are little-endian
     */
    mlfAssign(
      &fid,
      mlfFopen(&m, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray10_));
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray12_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = m;
         */
        mlfAssign(msg, mclVsv(m, "m"));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * filename = fopen(fid);  % Get the full path name if not in pwd
     */
    mlfAssign(&filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
    /*
     * d = dir(filename);      % Read directory information
     */
    mlfAssign(&d, mlfNDir(1, mclVa(filename, "filename")));
    /*
     * 
     * %
     * % Initialize universal structure fields to fix the order
     * %
     * info.Filename = filename;
     */
    mlfIndexAssign(&info, ".Filename", mclVsa(filename, "filename"));
    /*
     * info.FileModDate = d.date;
     */
    mlfIndexAssign(&info, ".FileModDate", mlfIndexRef(mclVsv(d, "d"), ".date"));
    /*
     * info.FileSize = d.bytes;
     */
    mlfIndexAssign(&info, ".FileSize", mlfIndexRef(mclVsv(d, "d"), ".bytes"));
    /*
     * info.Format = 'bmp';
     */
    mlfIndexAssign(&info, ".Format", _mxarray13_);
    /*
     * info.FormatVersion = [];
     */
    mlfIndexAssign(&info, ".FormatVersion", _mxarray4_);
    /*
     * info.Width = [];
     */
    mlfIndexAssign(&info, ".Width", _mxarray4_);
    /*
     * info.Height = [];
     */
    mlfIndexAssign(&info, ".Height", _mxarray4_);
    /*
     * info.BitDepth = [];
     */
    mlfIndexAssign(&info, ".BitDepth", _mxarray4_);
    /*
     * info.ColorType = [];
     */
    mlfIndexAssign(&info, ".ColorType", _mxarray4_);
    /*
     * info.FormatSignature = [];
     */
    mlfIndexAssign(&info, ".FormatSignature", _mxarray4_);
    /*
     * 
     * %
     * % Initialize BMP-specific structure fields to fix the order
     * %
     * info.NumColormapEntries = [];
     */
    mlfIndexAssign(&info, ".NumColormapEntries", _mxarray4_);
    /*
     * info.Colormap = [];
     */
    mlfIndexAssign(&info, ".Colormap", _mxarray4_);
    /*
     * info.RedMask = [];
     */
    mlfIndexAssign(&info, ".RedMask", _mxarray4_);
    /*
     * info.GreenMask = [];
     */
    mlfIndexAssign(&info, ".GreenMask", _mxarray4_);
    /*
     * info.BlueMask = [];
     */
    mlfIndexAssign(&info, ".BlueMask", _mxarray4_);
    /*
     * 
     * 
     * %
     * % First we must determine which variant of BMP we have.
     * % Use the algorithm from Encyclopedia of Graphics File Formats,
     * % 2ed, pp. 584-585
     * %
     * info.FormatSignature = char(fread(fid, 2, 'uint8')');
     */
    mlfIndexAssign(
      &info,
      ".FormatSignature",
      mlfChar(
        mlfCtranspose(
          mclVe(
            mlfFread(NULL, mclVv(fid, "fid"), _mxarray15_, _mxarray16_, NULL))),
        NULL));
    /*
     * if (isempty(info.FormatSignature))
     */
    if (mlfTobool(
          mclVe(
            mclFeval(
              mclValueVarargout(),
              mlxIsempty,
              mclVe(mlfIndexRef(mclVsv(info, "info"), ".FormatSignature")),
              NULL)))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'Empty file';
         */
        mlfAssign(msg, _mxarray18_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if (strcmp(info.FormatSignature, 'BM'))
     */
    if (mlfTobool(
          mclVe(
            mclFeval(
              mclValueVarargout(),
              mlxStrcmp,
              mclVe(mlfIndexRef(mclVsv(info, "info"), ".FormatSignature")),
              _mxarray20_,
              NULL)))) {
        /*
         * % We have a single-image BMP file. It may be 
         * % a Windows or an OS/2 file.
         * info.FileSize = fread(fid, 1, 'uint32');
         */
        mlfIndexAssign(
          &info,
          ".FileSize",
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
        /*
         * fseek(fid, 4, 'cof');  % skip 2 reserved 16-bit words
         */
        mclAssignAns(
          &ans, mlfFseek(mclVv(fid, "fid"), _mxarray25_, _mxarray26_));
        /*
         * info.ImageDataOffset = fread(fid, 1, 'uint32');
         */
        mlfIndexAssign(
          &info,
          ".ImageDataOffset",
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
        /*
         * info.BitmapHeaderSize = fread(fid, 1, 'uint32');
         */
        mlfIndexAssign(
          &info,
          ".BitmapHeaderSize",
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
        /*
         * 
         * if (isempty(info.BitmapHeaderSize))
         */
        if (mlfTobool(
              mclVe(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsempty,
                  mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitmapHeaderSize")),
                  NULL)))) {
            /*
             * info = [];
             */
            mlfAssign(&info, _mxarray4_);
            /*
             * msg = 'Truncated header';
             */
            mlfAssign(msg, _mxarray28_);
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
        /*
         * 
         * compression = [];
         */
        mlfAssign(&compression, _mxarray4_);
        /*
         * switch info.BitmapHeaderSize
         */
        {
            mxArray * v_ = mclInitialize(
                             mclVe(
                               mlfIndexRef(
                                 mclVsv(info, "info"), ".BitmapHeaderSize")));
            if (mclSwitchCompare(v_, _mxarray30_)) {
                /*
                 * case 12
                 * info.Width = fread(fid, 1, 'int16');
                 */
                mlfIndexAssign(
                  &info,
                  ".Width",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray31_, NULL));
                /*
                 * info.Height = fread(fid, 1, 'int16');
                 */
                mlfIndexAssign(
                  &info,
                  ".Height",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray31_, NULL));
                /*
                 * if (isempty(info.Width) | isempty(info.Height))
                 */
                {
                    mxArray * a_ = mclInitialize(
                                     mclVe(
                                       mclFeval(
                                         mclValueVarargout(),
                                         mlxIsempty,
                                         mclVe(
                                           mlfIndexRef(
                                             mclVsv(info, "info"), ".Width")),
                                         NULL)));
                    if (mlfTobool(a_)
                        || mlfTobool(
                             mclOr(
                               a_,
                               mclVe(
                                 mclFeval(
                                   mclValueVarargout(),
                                   mlxIsempty,
                                   mclVe(
                                     mlfIndexRef(
                                       mclVsv(info, "info"), ".Height")),
                                   NULL))))) {
                        mxDestroyArray(a_);
                        /*
                         * info = [];
                         */
                        mlfAssign(&info, _mxarray4_);
                        /*
                         * msg = 'Truncated header';
                         */
                        mlfAssign(msg, _mxarray28_);
                        /*
                         * fclose(fid);
                         */
                        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                        /*
                         * return;
                         */
                        mxDestroyArray(v_);
                        goto return_;
                    } else {
                        mxDestroyArray(a_);
                    }
                /*
                 * end
                 */
                }
                /*
                 * if ((info.Width < 0) | (info.Height < 0))
                 */
                {
                    mxArray * a_ = mclInitialize(
                                     mclFeval(
                                       mclValueVarargout(),
                                       mlxLt,
                                       mclVe(
                                         mlfIndexRef(
                                           mclVsv(info, "info"), ".Width")),
                                       _mxarray33_,
                                       NULL));
                    if (mlfTobool(a_)
                        || mlfTobool(
                             mclOr(
                               a_,
                               mclFeval(
                                 mclValueVarargout(),
                                 mlxLt,
                                 mclVe(
                                   mlfIndexRef(
                                     mclVsv(info, "info"), ".Height")),
                                 _mxarray33_,
                                 NULL)))) {
                        mxDestroyArray(a_);
                        /*
                         * info.FormatVersion = 'Version 1 (IBM OS/2 1.x)';
                         */
                        mlfIndexAssign(&info, ".FormatVersion", _mxarray34_);
                        /*
                         * fseek(fid, -4, 'cof');
                         */
                        mclAssignAns(
                          &ans,
                          mlfFseek(
                            mclVv(fid, "fid"), _mxarray36_, _mxarray26_));
                        /*
                         * info.Width = fread(fid, 1, 'uint16');
                         */
                        mlfIndexAssign(
                          &info,
                          ".Width",
                          mlfFread(
                            NULL,
                            mclVv(fid, "fid"),
                            _mxarray22_,
                            _mxarray37_,
                            NULL));
                        /*
                         * info.Height = fread(fid, 1, 'uint16');
                         */
                        mlfIndexAssign(
                          &info,
                          ".Height",
                          mlfFread(
                            NULL,
                            mclVv(fid, "fid"),
                            _mxarray22_,
                            _mxarray37_,
                            NULL));
                    /*
                     * else
                     */
                    } else {
                        mxDestroyArray(a_);
                        /*
                         * info.FormatVersion = 'Version 2 (Microsoft Windows 2.x)';
                         */
                        mlfIndexAssign(&info, ".FormatVersion", _mxarray39_);
                    }
                /*
                 * end
                 */
                }
                /*
                 * 
                 * info.NumPlanes = fread(fid, 1, 'uint16');
                 */
                mlfIndexAssign(
                  &info,
                  ".NumPlanes",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray37_, NULL));
                /*
                 * info.BitDepth = fread(fid, 1, 'uint16');
                 */
                mlfIndexAssign(
                  &info,
                  ".BitDepth",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray37_, NULL));
            /*
             * 
             * case 40
             */
            } else if (mclSwitchCompare(v_, _mxarray41_)) {
                /*
                 * info.Width = fread(fid, 1, 'uint32');
                 */
                mlfIndexAssign(
                  &info,
                  ".Width",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
                /*
                 * info.Height = fread(fid, 1, 'uint32');
                 */
                mlfIndexAssign(
                  &info,
                  ".Height",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
                /*
                 * info.NumPlanes = fread(fid, 1, 'uint16');
                 */
                mlfIndexAssign(
                  &info,
                  ".NumPlanes",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray37_, NULL));
                /*
                 * info.BitDepth = fread(fid, 1, 'uint16');
                 */
                mlfIndexAssign(
                  &info,
                  ".BitDepth",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray37_, NULL));
                /*
                 * 
                 * compression = fread(fid, 1, 'uint32');
                 */
                mlfAssign(
                  &compression,
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
                /*
                 * if (isempty(compression))
                 */
                if (mlfTobool(
                      mclVe(mlfIsempty(mclVv(compression, "compression"))))) {
                    /*
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg = 'Truncated header';
                     */
                    mlfAssign(msg, _mxarray28_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                /*
                 * end
                 */
                }
                /*
                 * if (compression == 3)
                 */
                if (mclEqBool(mclVv(compression, "compression"), _mxarray42_)) {
                    /*
                     * info.FormatVersion = 'Version 3 (Microsoft Windows NT)'
                     */
                    mlfIndexAssign(&info, ".FormatVersion", _mxarray43_);
                    mclPrintArray(mclVsv(info, "info"), "info");
                /*
                 * else
                 */
                } else {
                    /*
                     * info.FormatVersion = 'Version 3 (Microsoft Windows 3.x)';
                     */
                    mlfIndexAssign(&info, ".FormatVersion", _mxarray45_);
                /*
                 * end
                 */
                }
            /*
             * 
             * case 108
             */
            } else if (mclSwitchCompare(v_, _mxarray47_)) {
                /*
                 * 
                 * info.FormatVersion = 'Version 4 (Microsoft Windows 95)';
                 */
                mlfIndexAssign(&info, ".FormatVersion", _mxarray48_);
                /*
                 * compression = fread(fid, 1, 'uint32');
                 */
                mlfAssign(
                  &compression,
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
                /*
                 * if (isempty(compression))
                 */
                if (mlfTobool(
                      mclVe(mlfIsempty(mclVv(compression, "compression"))))) {
                    /*
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg = 'Truncated header';
                     */
                    mlfAssign(msg, _mxarray28_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                /*
                 * end
                 */
                }
            /*
             * 
             * otherwise
             */
            } else {
                /*
                 * 
                 * if ((info.HeaderSize > 12) & (info.HeaderSize <= 64))
                 */
                mxArray * a_ = mclInitialize(
                                 mclFeval(
                                   mclValueVarargout(),
                                   mlxGt,
                                   mclVe(
                                     mlfIndexRef(
                                       mclVsv(info, "info"), ".HeaderSize")),
                                   _mxarray30_,
                                   NULL));
                if (mlfTobool(a_)
                    && mlfTobool(
                         mclAnd(
                           a_,
                           mclFeval(
                             mclValueVarargout(),
                             mlxLe,
                             mclVe(
                               mlfIndexRef(
                                 mclVsv(info, "info"), ".HeaderSize")),
                             _mxarray50_,
                             NULL)))) {
                    mxDestroyArray(a_);
                    /*
                     * info.FormatVersion = 'Version 2 (IBM OS/2 2.x)';
                     */
                    mlfIndexAssign(&info, ".FormatVersion", _mxarray51_);
                    /*
                     * compression = fread(fid, 1, 'uint32');
                     */
                    mlfAssign(
                      &compression,
                      mlfFread(
                        NULL,
                        mclVv(fid, "fid"),
                        _mxarray22_,
                        _mxarray23_,
                        NULL));
                    /*
                     * if (isempty(compression))
                     */
                    if (mlfTobool(
                          mclVe(
                            mlfIsempty(mclVv(compression, "compression"))))) {
                        /*
                         * info = [];
                         */
                        mlfAssign(&info, _mxarray4_);
                        /*
                         * msg = 'Truncated header';
                         */
                        mlfAssign(msg, _mxarray28_);
                        /*
                         * fclose(fid);
                         */
                        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                        /*
                         * return;
                         */
                        mxDestroyArray(v_);
                        goto return_;
                    /*
                     * end
                     */
                    }
                /*
                 * 
                 * else
                 */
                } else {
                    mxDestroyArray(a_);
                    /*
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg = 'Corrupted header';
                     */
                    mlfAssign(msg, _mxarray53_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                }
            /*
             * end
             * 
             * end
             */
            }
            mxDestroyArray(v_);
        }
        /*
         * 
         * if (~isempty(compression))
         */
        if (mclNotBool(mclVe(mlfIsempty(mclVv(compression, "compression"))))) {
            /*
             * switch compression
             */
            mxArray * v_ = mclInitialize(mclVv(compression, "compression"));
            if (mclSwitchCompare(v_, _mxarray33_)) {
                /*
                 * case 0
                 * info.CompressionType = 'none';
                 */
                mlfIndexAssign(&info, ".CompressionType", _mxarray55_);
            /*
             * 
             * case 1
             */
            } else if (mclSwitchCompare(v_, _mxarray22_)) {
                /*
                 * info.CompressionType = '8-bit RLE';
                 */
                mlfIndexAssign(&info, ".CompressionType", _mxarray57_);
            /*
             * 
             * case 2
             */
            } else if (mclSwitchCompare(v_, _mxarray15_)) {
                /*
                 * info.CompressionType = '4-bit RLE';
                 */
                mlfIndexAssign(&info, ".CompressionType", _mxarray59_);
            /*
             * 
             * case 3
             */
            } else if (mclSwitchCompare(v_, _mxarray42_)) {
                /*
                 * if (strcmp(info.FormatVersion, 'Version 3 (Microsoft Windows NT)'))
                 */
                if (mlfTobool(
                      mclVe(
                        mclFeval(
                          mclValueVarargout(),
                          mlxStrcmp,
                          mclVe(
                            mlfIndexRef(
                              mclVsv(info, "info"), ".FormatVersion")),
                          _mxarray43_,
                          NULL)))) {
                    /*
                     * info.CompressionType = 'bitfields';
                     */
                    mlfIndexAssign(&info, ".CompressionType", _mxarray61_);
                /*
                 * else
                 */
                } else {
                    /*
                     * % OS/2 2.x
                     * info.CompressionType = 'Huffman 1D';
                     */
                    mlfIndexAssign(&info, ".CompressionType", _mxarray63_);
                /*
                 * end
                 */
                }
            /*
             * 
             * case 4
             */
            } else if (mclSwitchCompare(v_, _mxarray25_)) {
                /*
                 * % Only valid for OS/2 2.x
                 * info.CompressionType = '24-bit RLE';
                 */
                mlfIndexAssign(&info, ".CompressionType", _mxarray65_);
            /*
             * 
             * otherwise
             */
            } else {
                /*
                 * info = [];
                 */
                mlfAssign(&info, _mxarray4_);
                /*
                 * msg = 'Unrecognized compression type';
                 */
                mlfAssign(msg, _mxarray67_);
                /*
                 * fclose(fid);
                 */
                mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                /*
                 * return;
                 */
                mxDestroyArray(v_);
                goto return_;
            /*
             * 
             * end
             */
            }
            mxDestroyArray(v_);
        /*
         * else
         */
        } else {
            /*
             * info.CompressionType = 'none';
             */
            mlfIndexAssign(&info, ".CompressionType", _mxarray55_);
        /*
         * end
         */
        }
    /*
     * 
     * elseif (strcmp(info.FormatSignature, 'BA'))            
     */
    } else if (mlfTobool(
                 mclVe(
                   mclFeval(
                     mclValueVarargout(),
                     mlxStrcmp,
                     mclVe(
                       mlfIndexRef(mclVsv(info, "info"), ".FormatSignature")),
                     _mxarray69_,
                     NULL)))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'Unsupported format; may be an OS/2 bitmap array';
         */
        mlfAssign(msg, _mxarray71_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * 
     * else
     */
    } else {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'Not a BMP file';
         */
        mlfAssign(msg, _mxarray73_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * 
     * end
     */
    }
    /*
     * 
     * switch info.FormatVersion
     */
    {
        mxArray * v_ = mclInitialize(
                         mclVe(
                           mlfIndexRef(
                             mclVsv(info, "info"), ".FormatVersion")));
        if (mclSwitchCompare(v_, _mxarray34_)) {
            /*
             * 
             * case 'Version 1 (IBM OS/2 1.x)'
             * 
             * info.NumColormapEntries = floor((info.ImageDataOffset - ftell(fid))/3);
             */
            mlfIndexAssign(
              &info,
              ".NumColormapEntries",
              mlfFloor(
                mclMrdivide(
                  mclFeval(
                    mclValueVarargout(),
                    mlxMinus,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".ImageDataOffset")),
                    mclVe(mlfFtell(mclVv(fid, "fid"))),
                    NULL),
                  _mxarray42_)));
            /*
             * if (info.NumColormapEntries > 0)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxGt,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    _mxarray33_,
                    NULL))) {
                /*
                 * [map,count] = fread(fid, info.NumColormapEntries*3, 'uint8');
                 */
                mlfAssign(
                  &map,
                  mlfFread(
                    &count,
                    mclVv(fid, "fid"),
                    mclFeval(
                      mclValueVarargout(),
                      mlxMtimes,
                      mclVe(
                        mlfIndexRef(
                          mclVsv(info, "info"), ".NumColormapEntries")),
                      _mxarray42_,
                      NULL),
                    _mxarray16_,
                    NULL));
                /*
                 * if (count ~= info.NumColormapEntries*3)
                 */
                if (mclNeBool(
                      mclVv(count, "count"),
                      mclFeval(
                        mclValueVarargout(),
                        mlxMtimes,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".NumColormapEntries")),
                        _mxarray42_,
                        NULL))) {
                    /*
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg = 'Truncated colormap data';
                     */
                    mlfAssign(msg, _mxarray75_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                /*
                 * end
                 */
                }
                /*
                 * map = reshape(map, 3, info.NumColormapEntries);
                 */
                mlfAssign(
                  &map,
                  mlfReshape(
                    mclVv(map, "map"),
                    _mxarray42_,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    NULL));
                /*
                 * info.Colormap = double(flipud(map)')/255;
                 */
                mlfIndexAssign(
                  &info,
                  ".Colormap",
                  mclMrdivide(
                    mclVe(
                      mlfDouble(
                        mlfCtranspose(mclVe(mlfFlipud(mclVv(map, "map")))))),
                    _mxarray77_));
            /*
             * end
             */
            }
        /*
         * 
         * case 'Version 2 (Microsoft Windows 2.x)';
         */
        } else if (mclSwitchCompare(v_, _mxarray39_)) {
            /*
             * 
             * info.NumColormapEntries = floor((info.ImageDataOffset - ftell(fid))/3);
             */
            mlfIndexAssign(
              &info,
              ".NumColormapEntries",
              mlfFloor(
                mclMrdivide(
                  mclFeval(
                    mclValueVarargout(),
                    mlxMinus,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".ImageDataOffset")),
                    mclVe(mlfFtell(mclVv(fid, "fid"))),
                    NULL),
                  _mxarray42_)));
            /*
             * 
             * if (info.NumColormapEntries > 0)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxGt,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    _mxarray33_,
                    NULL))) {
                /*
                 * [map,count] = fread(fid, info.NumColormapEntries*3, 'uint8');
                 */
                mlfAssign(
                  &map,
                  mlfFread(
                    &count,
                    mclVv(fid, "fid"),
                    mclFeval(
                      mclValueVarargout(),
                      mlxMtimes,
                      mclVe(
                        mlfIndexRef(
                          mclVsv(info, "info"), ".NumColormapEntries")),
                      _mxarray42_,
                      NULL),
                    _mxarray16_,
                    NULL));
                /*
                 * if (count ~= info.NumColormapEntries*3)
                 */
                if (mclNeBool(
                      mclVv(count, "count"),
                      mclFeval(
                        mclValueVarargout(),
                        mlxMtimes,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".NumColormapEntries")),
                        _mxarray42_,
                        NULL))) {
                    /*
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg = 'Truncated colormap data';
                     */
                    mlfAssign(msg, _mxarray75_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                /*
                 * end
                 */
                }
                /*
                 * map = reshape(map, 3, info.NumColormapEntries);
                 */
                mlfAssign(
                  &map,
                  mlfReshape(
                    mclVv(map, "map"),
                    _mxarray42_,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    NULL));
                /*
                 * info.Colormap = double(flipud(map)')/255;
                 */
                mlfIndexAssign(
                  &info,
                  ".Colormap",
                  mclMrdivide(
                    mclVe(
                      mlfDouble(
                        mlfCtranspose(mclVe(mlfFlipud(mclVv(map, "map")))))),
                    _mxarray77_));
            /*
             * end
             */
            }
        /*
         * 
         * case 'Version 3 (Microsoft Windows 3.x)';
         */
        } else if (mclSwitchCompare(v_, _mxarray45_)) {
            /*
             * 
             * info.BitmapSize = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".BitmapSize",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.HorzResolution = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".HorzResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.VertResolution = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".VertResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.NumColorsUsed = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumColorsUsed",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.NumImportantColors = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumImportantColors",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * 
             * info.NumColormapEntries = floor((info.ImageDataOffset - ftell(fid))/4);
             */
            mlfIndexAssign(
              &info,
              ".NumColormapEntries",
              mlfFloor(
                mclMrdivide(
                  mclFeval(
                    mclValueVarargout(),
                    mlxMinus,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".ImageDataOffset")),
                    mclVe(mlfFtell(mclVv(fid, "fid"))),
                    NULL),
                  _mxarray25_)));
            /*
             * if (info.NumColormapEntries > 0)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxGt,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    _mxarray33_,
                    NULL))) {
                /*
                 * [map,count] = fread(fid, info.NumColormapEntries*4, 'uint8');
                 */
                mlfAssign(
                  &map,
                  mlfFread(
                    &count,
                    mclVv(fid, "fid"),
                    mclFeval(
                      mclValueVarargout(),
                      mlxMtimes,
                      mclVe(
                        mlfIndexRef(
                          mclVsv(info, "info"), ".NumColormapEntries")),
                      _mxarray25_,
                      NULL),
                    _mxarray16_,
                    NULL));
                /*
                 * if (count ~= info.NumColormapEntries*4)
                 */
                if (mclNeBool(
                      mclVv(count, "count"),
                      mclFeval(
                        mclValueVarargout(),
                        mlxMtimes,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".NumColormapEntries")),
                        _mxarray25_,
                        NULL))) {
                    /*
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg = 'Truncated colormap data';
                     */
                    mlfAssign(msg, _mxarray75_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                /*
                 * end
                 */
                }
                /*
                 * map = reshape(map, 4, info.NumColormapEntries);
                 */
                mlfAssign(
                  &map,
                  mlfReshape(
                    mclVv(map, "map"),
                    _mxarray25_,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    NULL));
                /*
                 * info.Colormap = double(flipud(map(1:3,:))')/255;
                 */
                mlfIndexAssign(
                  &info,
                  ".Colormap",
                  mclMrdivide(
                    mclVe(
                      mlfDouble(
                        mlfCtranspose(
                          mclVe(
                            mlfFlipud(
                              mclVe(
                                mclArrayRef2(
                                  mclVsv(map, "map"),
                                  mlfColon(_mxarray22_, _mxarray42_, NULL),
                                  mlfCreateColonIndex()))))))),
                    _mxarray77_));
            /*
             * end
             */
            }
        /*
         * 
         * case 'Version 3 (Microsoft Windows NT)'
         */
        } else if (mclSwitchCompare(v_, _mxarray43_)) {
            /*
             * 
             * info.BitmapSize = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".BitmapSize",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.HorzResolution = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".HorzResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.VertResolution = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".VertResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.NumColorsUsed = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumColorsUsed",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.NumImportantColors = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumImportantColors",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * 
             * if (((info.BitDepth == 16) | (info.BitDepth == 32)) & ...
             */
            {
                mxArray * a_ = mclInitialize(
                                 mclFeval(
                                   mclValueVarargout(),
                                   mlxEq,
                                   mclVe(
                                     mlfIndexRef(
                                       mclVsv(info, "info"), ".BitDepth")),
                                   _mxarray83_,
                                   NULL));
                if (mlfTobool(a_)) {
                    mlfAssign(&a_, mlfScalar(1));
                } else {
                    mlfAssign(
                      &a_,
                      mclOr(
                        a_,
                        mclFeval(
                          mclValueVarargout(),
                          mlxEq,
                          mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitDepth")),
                          _mxarray80_,
                          NULL)));
                }
                if (mlfTobool(a_)
                    && mlfTobool(
                         mclAnd(
                           a_,
                           mclNot(
                             mclVe(
                               mclFeval(
                                 mclValueVarargout(),
                                 mlxStrcmp,
                                 mclVe(
                                   mlfIndexRef(
                                     mclVsv(info, "info"),
                                     ".CompressionType")),
                                 _mxarray61_,
                                 NULL)))))) {
                    mxDestroyArray(a_);
                    /*
                     * (~strcmp(info.CompressionType,'bitfields')))
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg= 'BMP Version 3 (Microsoft Windows NT) file appears to be corrupt';
                     */
                    mlfAssign(msg, _mxarray81_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                } else {
                    mxDestroyArray(a_);
                }
            /*
             * end
             */
            }
            /*
             * 
             * if (strcmp(info.CompressionType, 'bitfields'))
             */
            if (mlfTobool(
                  mclVe(
                    mclFeval(
                      mclValueVarargout(),
                      mlxStrcmp,
                      mclVe(
                        mlfIndexRef(mclVsv(info, "info"), ".CompressionType")),
                      _mxarray61_,
                      NULL)))) {
                /*
                 * info.NumColormapEntries = 0;
                 */
                mlfIndexAssign(&info, ".NumColormapEntries", _mxarray33_);
                /*
                 * info.Colormap = [];
                 */
                mlfIndexAssign(&info, ".Colormap", _mxarray4_);
                /*
                 * 
                 * info.RedMask = fread(fid, 1, 'uint32');
                 */
                mlfIndexAssign(
                  &info,
                  ".RedMask",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
                /*
                 * info.GreenMask = fread(fid, 1, 'uint32');
                 */
                mlfIndexAssign(
                  &info,
                  ".GreenMask",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
                /*
                 * info.BlueMask = fread(fid, 1, 'uint32');
                 */
                mlfIndexAssign(
                  &info,
                  ".BlueMask",
                  mlfFread(
                    NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * 
             * else
             */
            } else {
                /*
                 * info.NumColormapEntries = floor((info.ImageDataOffset - ftell(fid))/4);
                 */
                mlfIndexAssign(
                  &info,
                  ".NumColormapEntries",
                  mlfFloor(
                    mclMrdivide(
                      mclFeval(
                        mclValueVarargout(),
                        mlxMinus,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".ImageDataOffset")),
                        mclVe(mlfFtell(mclVv(fid, "fid"))),
                        NULL),
                      _mxarray25_)));
                /*
                 * if (info.NumColormapEntries > 0)
                 */
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxGt,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".NumColormapEntries")),
                        _mxarray33_,
                        NULL))) {
                    /*
                     * [map,count] = fread(fid, info.NumColormapEntries*4, 'uint8');
                     */
                    mlfAssign(
                      &map,
                      mlfFread(
                        &count,
                        mclVv(fid, "fid"),
                        mclFeval(
                          mclValueVarargout(),
                          mlxMtimes,
                          mclVe(
                            mlfIndexRef(
                              mclVsv(info, "info"), ".NumColormapEntries")),
                          _mxarray25_,
                          NULL),
                        _mxarray16_,
                        NULL));
                    /*
                     * if (count ~= info.NumColormapEntries*4)
                     */
                    if (mclNeBool(
                          mclVv(count, "count"),
                          mclFeval(
                            mclValueVarargout(),
                            mlxMtimes,
                            mclVe(
                              mlfIndexRef(
                                mclVsv(info, "info"), ".NumColormapEntries")),
                            _mxarray25_,
                            NULL))) {
                        /*
                         * info = [];
                         */
                        mlfAssign(&info, _mxarray4_);
                        /*
                         * msg = 'Truncated colormap data';
                         */
                        mlfAssign(msg, _mxarray75_);
                        /*
                         * fclose(fid);
                         */
                        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                        /*
                         * return;
                         */
                        mxDestroyArray(v_);
                        goto return_;
                    /*
                     * end
                     */
                    }
                    /*
                     * map = reshape(map, 4, info.NumColormapEntries);
                     */
                    mlfAssign(
                      &map,
                      mlfReshape(
                        mclVv(map, "map"),
                        _mxarray25_,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".NumColormapEntries")),
                        NULL));
                    /*
                     * info.Colormap = double(flipud(map(1:3,:))')/255;
                     */
                    mlfIndexAssign(
                      &info,
                      ".Colormap",
                      mclMrdivide(
                        mclVe(
                          mlfDouble(
                            mlfCtranspose(
                              mclVe(
                                mlfFlipud(
                                  mclVe(
                                    mclArrayRef2(
                                      mclVsv(map, "map"),
                                      mlfColon(_mxarray22_, _mxarray42_, NULL),
                                      mlfCreateColonIndex()))))))),
                        _mxarray77_));
                /*
                 * end
                 */
                }
            /*
             * 
             * end
             */
            }
        /*
         * 
         * case 'Version 4 (Microsoft Windows 95)';
         */
        } else if (mclSwitchCompare(v_, _mxarray48_)) {
            /*
             * 
             * info.BitmapSize = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".BitmapSize",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.HorzResolution = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".HorzResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.VertResolution = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".VertResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.NumColorsUsed = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumColorsUsed",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.NumImportantColors = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumImportantColors",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * 
             * % Fields added for Version 4
             * info.RedMask = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".RedMask",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.GreenMask = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".GreenMask",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.BlueMask = fread(fid, 1,  'uint32');
             */
            mlfIndexAssign(
              &info,
              ".BlueMask",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.AlphaMask = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".AlphaMask",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.ColorspaceType = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".ColorspaceType",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.RedX = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".RedX",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.RedY = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".RedY",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.RedZ = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".RedZ",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.GreenX = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".GreenX",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.GreenY = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".GreenY",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.GreenZ = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".GreenZ",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.BlueX = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".BlueX",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.BlueY = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".BlueY",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.BlueZ = fread(fid, 1, 'int32');
             */
            mlfIndexAssign(
              &info,
              ".BlueZ",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray78_, NULL));
            /*
             * info.GammaRed = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".GammaRed",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.GammaGreen = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".GammaGreen",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.GammaBlue = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".GammaBlue",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * 
             * if (((info.BitDepth == 16) | (info.BitDepth == 32)) & ...
             */
            {
                mxArray * a_ = mclInitialize(
                                 mclFeval(
                                   mclValueVarargout(),
                                   mlxEq,
                                   mclVe(
                                     mlfIndexRef(
                                       mclVsv(info, "info"), ".BitDepth")),
                                   _mxarray83_,
                                   NULL));
                if (mlfTobool(a_)) {
                    mlfAssign(&a_, mlfScalar(1));
                } else {
                    mlfAssign(
                      &a_,
                      mclOr(
                        a_,
                        mclFeval(
                          mclValueVarargout(),
                          mlxEq,
                          mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitDepth")),
                          _mxarray80_,
                          NULL)));
                }
                if (mlfTobool(a_)
                    && mlfTobool(
                         mclAnd(
                           a_,
                           mclNot(
                             mclVe(
                               mclFeval(
                                 mclValueVarargout(),
                                 mlxStrcmp,
                                 mclVe(
                                   mlfIndexRef(
                                     mclVsv(info, "info"),
                                     ".CompressionType")),
                                 _mxarray61_,
                                 NULL)))))) {
                    mxDestroyArray(a_);
                    /*
                     * (~strcmp(info.CompressionType,'bitfields')))
                     * info = [];
                     */
                    mlfAssign(&info, _mxarray4_);
                    /*
                     * msg= 'BMP Version 4 (Microsoft Windows 95) file appears to be corrupt';
                     */
                    mlfAssign(msg, _mxarray84_);
                    /*
                     * fclose(fid);
                     */
                    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                    /*
                     * return;
                     */
                    mxDestroyArray(v_);
                    goto return_;
                } else {
                    mxDestroyArray(a_);
                }
            /*
             * end
             */
            }
            /*
             * 
             * if (strcmp(info.CompressionType, 'bitfields'))
             */
            if (mlfTobool(
                  mclVe(
                    mclFeval(
                      mclValueVarargout(),
                      mlxStrcmp,
                      mclVe(
                        mlfIndexRef(mclVsv(info, "info"), ".CompressionType")),
                      _mxarray61_,
                      NULL)))) {
                /*
                 * info.NumColormapEntries = 0;
                 */
                mlfIndexAssign(&info, ".NumColormapEntries", _mxarray33_);
                /*
                 * info.Colormap = [];
                 */
                mlfIndexAssign(&info, ".Colormap", _mxarray4_);
            /*
             * 
             * else
             */
            } else {
                /*
                 * info.NumColormapEntries = floor((info.ImageDataOffset - ftell(fid))/4);
                 */
                mlfIndexAssign(
                  &info,
                  ".NumColormapEntries",
                  mlfFloor(
                    mclMrdivide(
                      mclFeval(
                        mclValueVarargout(),
                        mlxMinus,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".ImageDataOffset")),
                        mclVe(mlfFtell(mclVv(fid, "fid"))),
                        NULL),
                      _mxarray25_)));
                /*
                 * if (info.NumColormapEntries > 0)
                 */
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxGt,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".NumColormapEntries")),
                        _mxarray33_,
                        NULL))) {
                    /*
                     * [map,count] = fread(fid, info.NumColormapEntries*4, 'uint8');
                     */
                    mlfAssign(
                      &map,
                      mlfFread(
                        &count,
                        mclVv(fid, "fid"),
                        mclFeval(
                          mclValueVarargout(),
                          mlxMtimes,
                          mclVe(
                            mlfIndexRef(
                              mclVsv(info, "info"), ".NumColormapEntries")),
                          _mxarray25_,
                          NULL),
                        _mxarray16_,
                        NULL));
                    /*
                     * if (count ~= info.NumColormapEntries*4)
                     */
                    if (mclNeBool(
                          mclVv(count, "count"),
                          mclFeval(
                            mclValueVarargout(),
                            mlxMtimes,
                            mclVe(
                              mlfIndexRef(
                                mclVsv(info, "info"), ".NumColormapEntries")),
                            _mxarray25_,
                            NULL))) {
                        /*
                         * info = [];
                         */
                        mlfAssign(&info, _mxarray4_);
                        /*
                         * msg = 'Truncated colormap data';
                         */
                        mlfAssign(msg, _mxarray75_);
                        /*
                         * fclose(fid);
                         */
                        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                        /*
                         * return;
                         */
                        mxDestroyArray(v_);
                        goto return_;
                    /*
                     * end
                     */
                    }
                    /*
                     * map = reshape(map, 4, info.NumColormapEntries);
                     */
                    mlfAssign(
                      &map,
                      mlfReshape(
                        mclVv(map, "map"),
                        _mxarray25_,
                        mclVe(
                          mlfIndexRef(
                            mclVsv(info, "info"), ".NumColormapEntries")),
                        NULL));
                    /*
                     * info.Colormap = double(flipud(map(1:3,:))')/255;
                     */
                    mlfIndexAssign(
                      &info,
                      ".Colormap",
                      mclMrdivide(
                        mclVe(
                          mlfDouble(
                            mlfCtranspose(
                              mclVe(
                                mlfFlipud(
                                  mclVe(
                                    mclArrayRef2(
                                      mclVsv(map, "map"),
                                      mlfColon(_mxarray22_, _mxarray42_, NULL),
                                      mlfCreateColonIndex()))))))),
                        _mxarray77_));
                /*
                 * end
                 */
                }
            /*
             * 
             * end
             */
            }
        /*
         * 
         * 
         * case 'Version 2 (IBM OS/2 2.x)'
         */
        } else if (mclSwitchCompare(v_, _mxarray51_)) {
            /*
             * 
             * info.BitmapSize = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".BitmapSize",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.HorzResolution = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".HorzResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.VertResolution = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".VertResolution",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.NumColorsUsed = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumColorsUsed",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.NumImportantColors = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".NumImportantColors",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * units = fread(fid, 1, 'uint16');
             */
            mlfAssign(
              &units,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray37_, NULL));
            /*
             * if (isempty(units))
             */
            if (mlfTobool(mclVe(mlfIsempty(mclVv(units, "units"))))) {
                /*
                 * info = [];
                 */
                mlfAssign(&info, _mxarray4_);
                /*
                 * msg = 'Truncated header';
                 */
                mlfAssign(msg, _mxarray28_);
                /*
                 * fclose(fid);
                 */
                mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                /*
                 * return;
                 */
                mxDestroyArray(v_);
                goto return_;
            /*
             * end
             */
            }
            /*
             * if (units == 0)
             */
            if (mclEqBool(mclVv(units, "units"), _mxarray33_)) {
                /*
                 * info.Units = 'pixels/meter';
                 */
                mlfIndexAssign(&info, ".Units", _mxarray86_);
            /*
             * else
             */
            } else {
                /*
                 * info.Units = 'unknown';
                 */
                mlfIndexAssign(&info, ".Units", _mxarray88_);
            /*
             * end
             */
            }
            /*
             * fseek(fid, 2, 'cof');  % skip 2-byte pad
             */
            mclAssignAns(
              &ans, mlfFseek(mclVv(fid, "fid"), _mxarray15_, _mxarray26_));
            /*
             * info.Recording = fread(fid, 1, 'uint16');
             */
            mlfIndexAssign(
              &info,
              ".Recording",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray37_, NULL));
            /*
             * 
             * halftoning = fread(fid, 1, 'uint16');
             */
            mlfAssign(
              &halftoning,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray37_, NULL));
            /*
             * if (isempty(halftoning))
             */
            if (mlfTobool(mclVe(mlfIsempty(mclVv(halftoning, "halftoning"))))) {
                /*
                 * info = [];
                 */
                mlfAssign(&info, _mxarray4_);
                /*
                 * msg = 'Truncated header';
                 */
                mlfAssign(msg, _mxarray28_);
                /*
                 * fclose(fid);
                 */
                mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                /*
                 * return;
                 */
                mxDestroyArray(v_);
                goto return_;
            /*
             * end
             */
            }
            /*
             * 
             * switch halftoning
             */
            {
                mxArray * v_0 = mclInitialize(mclVv(halftoning, "halftoning"));
                if (mclSwitchCompare(v_0, _mxarray33_)) {
                    /*
                     * case 0
                     * info.HalftoningAlgorithm = 'none';
                     */
                    mlfIndexAssign(&info, ".HalftoningAlgorithm", _mxarray55_);
                /*
                 * 
                 * case 1
                 */
                } else if (mclSwitchCompare(v_0, _mxarray22_)) {
                    /*
                     * info.HalftoningAlgorithm = 'error diffusion';
                     */
                    mlfIndexAssign(&info, ".HalftoningAlgorithm", _mxarray90_);
                /*
                 * 
                 * case 2
                 */
                } else if (mclSwitchCompare(v_0, _mxarray15_)) {
                    /*
                     * info.HalftoningAlgorithm = 'PANDA';
                     */
                    mlfIndexAssign(&info, ".HalftoningAlgorithm", _mxarray92_);
                /*
                 * 
                 * case 3
                 */
                } else if (mclSwitchCompare(v_0, _mxarray42_)) {
                    /*
                     * info.HalftoningAlgorithm = 'super-circle';
                     */
                    mlfIndexAssign(&info, ".HalftoningAlgorithm", _mxarray94_);
                /*
                 * 
                 * otherwise
                 */
                } else {
                    /*
                     * info.HalftoningAlgorithm = 'unknown';
                     */
                    mlfIndexAssign(&info, ".HalftoningAlgorithm", _mxarray88_);
                /*
                 * 
                 * end
                 */
                }
                mxDestroyArray(v_0);
            }
            /*
             * 
             * info.HalftoneField1 = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".HalftoneField1",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * info.HalftoneField2 = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".HalftoneField2",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * 
             * encoding = fread(fid, 1, 'uint32');
             */
            mlfAssign(
              &encoding,
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * if (isempty(encoding))
             */
            if (mlfTobool(mclVe(mlfIsempty(mclVv(encoding, "encoding"))))) {
                /*
                 * info = [];
                 */
                mlfAssign(&info, _mxarray4_);
                /*
                 * msg = 'Truncated header';
                 */
                mlfAssign(msg, _mxarray28_);
                /*
                 * fclose(fid);
                 */
                mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
                /*
                 * return;
                 */
                mxDestroyArray(v_);
                goto return_;
            /*
             * end
             */
            }
            /*
             * 
             * if (encoding == 0)
             */
            if (mclEqBool(mclVv(encoding, "encoding"), _mxarray33_)) {
                /*
                 * info.ColorEncoding = 'RGB';
                 */
                mlfIndexAssign(&info, ".ColorEncoding", _mxarray96_);
            /*
             * else
             */
            } else {
                /*
                 * info.ColorEncoding = 'unknown';
                 */
                mlfIndexAssign(&info, ".ColorEncoding", _mxarray88_);
            /*
             * end
             */
            }
            /*
             * 
             * info.ApplicationIdentifier = fread(fid, 1, 'uint32');
             */
            mlfIndexAssign(
              &info,
              ".ApplicationIdentifier",
              mlfFread(
                NULL, mclVv(fid, "fid"), _mxarray22_, _mxarray23_, NULL));
            /*
             * 
             * info.NumColormapEntries = floor((info.ImageDataOffset - ftell(fid))/4);
             */
            mlfIndexAssign(
              &info,
              ".NumColormapEntries",
              mlfFloor(
                mclMrdivide(
                  mclFeval(
                    mclValueVarargout(),
                    mlxMinus,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".ImageDataOffset")),
                    mclVe(mlfFtell(mclVv(fid, "fid"))),
                    NULL),
                  _mxarray25_)));
            /*
             * if (info.NumColormapEntries > 0)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxGt,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    _mxarray33_,
                    NULL))) {
                /*
                 * map = fread(fid, info.NumColormapEntries*4, 'uint8');
                 */
                mlfAssign(
                  &map,
                  mlfFread(
                    NULL,
                    mclVv(fid, "fid"),
                    mclFeval(
                      mclValueVarargout(),
                      mlxMtimes,
                      mclVe(
                        mlfIndexRef(
                          mclVsv(info, "info"), ".NumColormapEntries")),
                      _mxarray25_,
                      NULL),
                    _mxarray16_,
                    NULL));
                /*
                 * map = reshape(map, 4, info.NumColormapEntries);
                 */
                mlfAssign(
                  &map,
                  mlfReshape(
                    mclVv(map, "map"),
                    _mxarray25_,
                    mclVe(
                      mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
                    NULL));
                /*
                 * info.Colormap = double(flipud(map(1:3,:))')/255;
                 */
                mlfIndexAssign(
                  &info,
                  ".Colormap",
                  mclMrdivide(
                    mclVe(
                      mlfDouble(
                        mlfCtranspose(
                          mclVe(
                            mlfFlipud(
                              mclVe(
                                mclArrayRef2(
                                  mclVsv(map, "map"),
                                  mlfColon(_mxarray22_, _mxarray42_, NULL),
                                  mlfCreateColonIndex()))))))),
                    _mxarray77_));
            /*
             * end
             */
            }
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * info = [];
             */
            mlfAssign(&info, _mxarray4_);
            /*
             * msg = 'Problem identifying format version';
             */
            mlfAssign(msg, _mxarray98_);
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
            /*
             * return;
             */
            mxDestroyArray(v_);
            goto return_;
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * fclose(fid);
     */
    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    /*
     * 
     * if (isempty(info.NumColormapEntries))
     */
    if (mlfTobool(
          mclVe(
            mclFeval(
              mclValueVarargout(),
              mlxIsempty,
              mclVe(mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
              NULL)))) {
        /*
         * info.NumColormapEntries = 0;
         */
        mlfIndexAssign(&info, ".NumColormapEntries", _mxarray33_);
    /*
     * end
     */
    }
    /*
     * 
     * if (info.NumColormapEntries > 0)
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxGt,
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
            _mxarray33_,
            NULL))) {
        /*
         * info.ColorType = 'indexed';
         */
        mlfIndexAssign(&info, ".ColorType", _mxarray100_);
    /*
     * 
     * else
     */
    } else {
        /*
         * if (info.BitDepth <= 8)
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxLe,
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitDepth")),
                _mxarray102_,
                NULL))) {
            /*
             * info.ColorType = 'grayscale';
             */
            mlfIndexAssign(&info, ".ColorType", _mxarray103_);
        /*
         * else
         */
        } else {
            /*
             * info.ColorType = 'truecolor';
             */
            mlfIndexAssign(&info, ".ColorType", _mxarray105_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * 
     * %
     * % Other validity checks
     * %
     * if ((info.Width < 0) | (info.Height < 0))
     */
    {
        mxArray * a_ = mclInitialize(
                         mclFeval(
                           mclValueVarargout(),
                           mlxLt,
                           mclVe(mlfIndexRef(mclVsv(info, "info"), ".Width")),
                           _mxarray33_,
                           NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxLt,
                     mclVe(mlfIndexRef(mclVsv(info, "info"), ".Height")),
                     _mxarray33_,
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * info = [];
             */
            mlfAssign(&info, _mxarray4_);
            /*
             * msg = 'Corrupt BMP file: bad image dimensions';
             */
            mlfAssign(msg, _mxarray107_);
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * return;
     * end
     */
    }
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/imbmpinfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/imbmpinfo");
    mxDestroyArray(fid);
    mxDestroyArray(m);
    mxDestroyArray(d);
    mxDestroyArray(ans);
    mxDestroyArray(compression);
    mxDestroyArray(map);
    mxDestroyArray(count);
    mxDestroyArray(units);
    mxDestroyArray(halftoning);
    mxDestroyArray(encoding);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
