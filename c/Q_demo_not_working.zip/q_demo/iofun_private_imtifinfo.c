/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imtifinfo.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 't', 'i', 'f', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 't', 'i', 'f', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 't', 'i', 'f', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 't', 'i', 'f', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray6_;

static mxChar _array9_[1] = { 'r' };
static mxArray * _mxarray8_;

static mxChar _array11_[7] = { 'i', 'e', 'e', 'e', '-', 'l', 'e' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;
static mxArray * _mxarray13_;

static mxChar _array15_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray14_;

static double _array17_[4] = { 77.0, 77.0, 0.0, 42.0 };
static mxArray * _mxarray16_;

static mxChar _array19_[15] = { 'N', 'o', 't', ' ', 'a', ' ', 'T', 'I',
                                'F', 'F', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray18_;

static double _array21_[4] = { 73.0, 73.0, 42.0, 0.0 };
static mxArray * _mxarray20_;
static mxArray * _mxarray22_;

static mxChar _array24_[13] = { 'l', 'i', 't', 't', 'l', 'e', '-',
                                'e', 'n', 'd', 'i', 'a', 'n' };
static mxArray * _mxarray23_;

static mxChar _array26_[10] = { 'b', 'i', 'g', '-', 'e',
                                'n', 'd', 'i', 'a', 'n' };
static mxArray * _mxarray25_;

static mxChar _array28_[7] = { 'i', 'e', 'e', 'e', '-', 'b', 'e' };
static mxArray * _mxarray27_;

static mxChar _array30_[3] = { 'b', 'o', 'f' };
static mxArray * _mxarray29_;
static mxArray * _mxarray31_;

static mxChar _array33_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray32_;
static mxArray * _mxarray34_;

static mxChar _array36_[3] = { 't', 'i', 'f' };
static mxArray * _mxarray35_;

static mxChar _array38_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray37_;

static mxChar _array40_[12] = { 'U', 'n', 'c', 'o', 'm', 'p',
                                'r', 'e', 's', 's', 'e', 'd' };
static mxArray * _mxarray39_;

static mxChar _array42_[4] = { 'I', 'n', 'c', 'h' };
static mxArray * _mxarray41_;
static mxArray * _mxarray43_;

static mxChar _array45_[6] = { 'C', 'h', 'u', 'n', 'k', 'y' };
static mxArray * _mxarray44_;
static mxArray * _mxarray46_;
static mxArray * _mxarray47_;
static mxArray * _mxarray48_;

static mxChar _array50_[3] = { 'c', 'o', 'f' };
static mxArray * _mxarray49_;
static mxArray * _mxarray51_;
static mxArray * _mxarray52_;
static mxArray * _mxarray53_;
static mxArray * _mxarray54_;
static mxArray * _mxarray55_;
static mxArray * _mxarray56_;

static mxChar _array58_[8] = { 'C', 'C', 'I', 'T', 'T', ' ', '1', 'D' };
static mxArray * _mxarray57_;

static mxChar _array60_[11] = { 'G', 'r', 'o', 'u', 'p', ' ',
                                '3', ' ', 'F', 'a', 'x' };
static mxArray * _mxarray59_;

static mxChar _array62_[11] = { 'G', 'r', 'o', 'u', 'p', ' ',
                                '4', ' ', 'F', 'a', 'x' };
static mxArray * _mxarray61_;
static mxArray * _mxarray63_;

static mxChar _array65_[3] = { 'L', 'Z', 'W' };
static mxArray * _mxarray64_;

static mxChar _array67_[4] = { 'J', 'P', 'E', 'G' };
static mxArray * _mxarray66_;
static mxArray * _mxarray68_;

static mxChar _array70_[8] = { 'P', 'a', 'c', 'k', 'B', 'i', 't', 's' };
static mxArray * _mxarray69_;

static mxChar _array72_[7] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n' };
static mxArray * _mxarray71_;
static mxArray * _mxarray73_;

static mxChar _array75_[11] = { 'W', 'h', 'i', 't', 'e', 'I',
                                's', 'Z', 'e', 'r', 'o' };
static mxArray * _mxarray74_;

static mxChar _array77_[11] = { 'B', 'l', 'a', 'c', 'k', 'I',
                                's', 'Z', 'e', 'r', 'o' };
static mxArray * _mxarray76_;

static mxChar _array79_[3] = { 'R', 'G', 'B' };
static mxArray * _mxarray78_;

static mxChar _array81_[11] = { 'R', 'G', 'B', ' ', 'P', 'a',
                                'l', 'e', 't', 't', 'e' };
static mxArray * _mxarray80_;

static mxChar _array83_[17] = { 'T', 'r', 'a', 'n', 's', 'p', 'a', 'r', 'e',
                                'n', 'c', 'y', ' ', 'm', 'a', 's', 'k' };
static mxArray * _mxarray82_;

static mxChar _array85_[4] = { 'C', 'M', 'Y', 'K' };
static mxArray * _mxarray84_;

static mxChar _array87_[5] = { 'Y', 'C', 'b', 'C', 'r' };
static mxArray * _mxarray86_;
static mxArray * _mxarray88_;

static mxChar _array90_[6] = { 'C', 'I', 'E', 'L', 'a', 'b' };
static mxArray * _mxarray89_;
static mxArray * _mxarray91_;
static mxArray * _mxarray92_;
static mxArray * _mxarray93_;
static mxArray * _mxarray94_;
static mxArray * _mxarray95_;
static mxArray * _mxarray96_;
static mxArray * _mxarray97_;
static mxArray * _mxarray98_;
static mxArray * _mxarray99_;
static mxArray * _mxarray100_;
static mxArray * _mxarray101_;
static mxArray * _mxarray102_;
static mxArray * _mxarray103_;
static mxArray * _mxarray104_;
static mxArray * _mxarray105_;
static mxArray * _mxarray106_;
static mxArray * _mxarray107_;

static mxChar _array109_[6] = { 'P', 'l', 'a', 'n', 'a', 'r' };
static mxArray * _mxarray108_;
static mxArray * _mxarray110_;
static mxArray * _mxarray111_;
static mxArray * _mxarray112_;
static mxArray * _mxarray113_;
static mxArray * _mxarray114_;
static mxArray * _mxarray115_;
static mxArray * _mxarray116_;
static mxArray * _mxarray117_;
static mxArray * _mxarray118_;

static mxChar _array120_[4] = { 'N', 'o', 'n', 'e' };
static mxArray * _mxarray119_;

static mxChar _array122_[10] = { 'C', 'e', 'n', 't', 'i',
                                 'm', 'e', 't', 'e', 'r' };
static mxArray * _mxarray121_;
static mxArray * _mxarray123_;
static mxArray * _mxarray124_;
static mxArray * _mxarray125_;
static mxArray * _mxarray126_;
static mxArray * _mxarray127_;
static mxArray * _mxarray128_;
static mxArray * _mxarray129_;
static mxArray * _mxarray130_;
static mxArray * _mxarray131_;
static mxArray * _mxarray132_;
static mxArray * _mxarray133_;
static mxArray * _mxarray134_;
static mxArray * _mxarray135_;

static mxChar _array137_[16] = { 'U', 'n', 's', 'i', 'g', 'n', 'e', 'd',
                                 ' ', 'i', 'n', 't', 'e', 'g', 'e', 'r' };
static mxArray * _mxarray136_;

static mxChar _array139_[31] = { 'T', 'w', 'o', 0x0027, 's', ' ', 'c',
                                 'o', 'm', 'p', 'l', 'e', 'm', 'e', 'n',
                                 't', ' ', 's', 'i', 'g', 'n', 'e', 'd',
                                 ' ', 'i', 'n', 't', 'e', 'g', 'e', 'r' };
static mxArray * _mxarray138_;

static mxChar _array141_[19] = { 'I', 'E', 'E', 'E', ' ', 'f', 'l',
                                 'o', 'a', 't', 'i', 'n', 'g', ' ',
                                 'p', 'o', 'i', 'n', 't' };
static mxArray * _mxarray140_;

static mxChar _array143_[9] = { 'U', 'n', 'd', 'e', 'f', 'i', 'n', 'e', 'd' };
static mxArray * _mxarray142_;
static mxArray * _mxarray144_;
static mxArray * _mxarray145_;
static mxArray * _mxarray146_;

static mxChar _array148_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray147_;

static mxChar _array150_[9] = { 'g', 'r', 'a', 'y', 's', 'c', 'a', 'l', 'e' };
static mxArray * _mxarray149_;

static mxChar _array152_[9] = { 't', 'r', 'u', 'e', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray151_;

static mxChar _array154_[7] = { 'u', 'n', 'k', 'n', 'o', 'w', 'n' };
static mxArray * _mxarray153_;

static mxChar _array156_[28] = { 'N', 'o', ' ', 'i', 'm', 'a', 'g',
                                 'e', 's', ' ', 'f', 'o', 'u', 'n',
                                 'd', ' ', 'i', 'n', ' ', 'T', 'I',
                                 'F', 'F', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray155_;

void InitializeModule_iofun_private_imtifinfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(7, _array11_);
    _mxarray12_ = mclInitializeDouble(-1.0);
    _mxarray13_ = mclInitializeDouble(4.0);
    _mxarray14_ = mclInitializeString(5, _array15_);
    _mxarray16_ = mclInitializeDoubleVector(1, 4, _array17_);
    _mxarray18_ = mclInitializeString(15, _array19_);
    _mxarray20_ = mclInitializeDoubleVector(1, 4, _array21_);
    _mxarray22_ = mclInitializeDouble(73.0);
    _mxarray23_ = mclInitializeString(13, _array24_);
    _mxarray25_ = mclInitializeString(10, _array26_);
    _mxarray27_ = mclInitializeString(7, _array28_);
    _mxarray29_ = mclInitializeString(3, _array30_);
    _mxarray31_ = mclInitializeDouble(1.0);
    _mxarray32_ = mclInitializeString(6, _array33_);
    _mxarray34_ = mclInitializeDouble(0.0);
    _mxarray35_ = mclInitializeString(3, _array36_);
    _mxarray37_ = mclInitializeString(6, _array38_);
    _mxarray39_ = mclInitializeString(12, _array40_);
    _mxarray41_ = mclInitializeString(4, _array42_);
    _mxarray43_ = mclInitializeDouble(.01);
    _mxarray44_ = mclInitializeString(6, _array45_);
    _mxarray46_ = mclInitializeDouble(32.0);
    _mxarray47_ = mclInitializeDouble(254.0);
    _mxarray48_ = mclInitializeDouble(6.0);
    _mxarray49_ = mclInitializeString(3, _array50_);
    _mxarray51_ = mclInitializeDouble(256.0);
    _mxarray52_ = mclInitializeDouble(3.0);
    _mxarray53_ = mclInitializeDouble(257.0);
    _mxarray54_ = mclInitializeDouble(258.0);
    _mxarray55_ = mclInitializeDouble(2.0);
    _mxarray56_ = mclInitializeDouble(259.0);
    _mxarray57_ = mclInitializeString(8, _array58_);
    _mxarray59_ = mclInitializeString(11, _array60_);
    _mxarray61_ = mclInitializeString(11, _array62_);
    _mxarray63_ = mclInitializeDouble(5.0);
    _mxarray64_ = mclInitializeString(3, _array65_);
    _mxarray66_ = mclInitializeString(4, _array67_);
    _mxarray68_ = mclInitializeDouble(32773.0);
    _mxarray69_ = mclInitializeString(8, _array70_);
    _mxarray71_ = mclInitializeString(7, _array72_);
    _mxarray73_ = mclInitializeDouble(262.0);
    _mxarray74_ = mclInitializeString(11, _array75_);
    _mxarray76_ = mclInitializeString(11, _array77_);
    _mxarray78_ = mclInitializeString(3, _array79_);
    _mxarray80_ = mclInitializeString(11, _array81_);
    _mxarray82_ = mclInitializeString(17, _array83_);
    _mxarray84_ = mclInitializeString(4, _array85_);
    _mxarray86_ = mclInitializeString(5, _array87_);
    _mxarray88_ = mclInitializeDouble(7.0);
    _mxarray89_ = mclInitializeString(6, _array90_);
    _mxarray91_ = mclInitializeDouble(263.0);
    _mxarray92_ = mclInitializeDouble(264.0);
    _mxarray93_ = mclInitializeDouble(265.0);
    _mxarray94_ = mclInitializeDouble(266.0);
    _mxarray95_ = mclInitializeDouble(270.0);
    _mxarray96_ = mclInitializeDouble(271.0);
    _mxarray97_ = mclInitializeDouble(272.0);
    _mxarray98_ = mclInitializeDouble(273.0);
    _mxarray99_ = mclInitializeDouble(274.0);
    _mxarray100_ = mclInitializeDouble(277.0);
    _mxarray101_ = mclInitializeDouble(278.0);
    _mxarray102_ = mclInitializeDouble(279.0);
    _mxarray103_ = mclInitializeDouble(280.0);
    _mxarray104_ = mclInitializeDouble(281.0);
    _mxarray105_ = mclInitializeDouble(282.0);
    _mxarray106_ = mclInitializeDouble(283.0);
    _mxarray107_ = mclInitializeDouble(284.0);
    _mxarray108_ = mclInitializeString(6, _array109_);
    _mxarray110_ = mclInitializeDouble(288.0);
    _mxarray111_ = mclInitializeDouble(289.0);
    _mxarray112_ = mclInitializeDouble(290.0);
    _mxarray113_ = mclInitializeDouble(.1);
    _mxarray114_ = mclInitializeDouble(.001);
    _mxarray115_ = mclInitializeDouble(.0001);
    _mxarray116_ = mclInitializeDouble(1e-05);
    _mxarray117_ = mclInitializeDouble(291.0);
    _mxarray118_ = mclInitializeDouble(296.0);
    _mxarray119_ = mclInitializeString(4, _array120_);
    _mxarray121_ = mclInitializeString(10, _array122_);
    _mxarray123_ = mclInitializeDouble(305.0);
    _mxarray124_ = mclInitializeDouble(306.0);
    _mxarray125_ = mclInitializeDouble(20.0);
    _mxarray126_ = mclInitializeDouble(315.0);
    _mxarray127_ = mclInitializeDouble(316.0);
    _mxarray128_ = mclInitializeDouble(320.0);
    _mxarray129_ = mclInitializeDouble(65535.0);
    _mxarray130_ = mclInitializeDouble(322.0);
    _mxarray131_ = mclInitializeDouble(323.0);
    _mxarray132_ = mclInitializeDouble(324.0);
    _mxarray133_ = mclInitializeDouble(325.0);
    _mxarray134_ = mclInitializeDouble(338.0);
    _mxarray135_ = mclInitializeDouble(339.0);
    _mxarray136_ = mclInitializeString(16, _array137_);
    _mxarray138_ = mclInitializeString(31, _array139_);
    _mxarray140_ = mclInitializeString(19, _array141_);
    _mxarray142_ = mclInitializeString(9, _array143_);
    _mxarray144_ = mclInitializeDouble(33432.0);
    _mxarray145_ = mclInitializeDouble(34675.0);
    _mxarray146_ = mclInitializeDouble(12.0);
    _mxarray147_ = mclInitializeString(7, _array148_);
    _mxarray149_ = mclInitializeString(9, _array150_);
    _mxarray151_ = mclInitializeString(9, _array152_);
    _mxarray153_ = mclInitializeString(7, _array154_);
    _mxarray155_ = mclInitializeString(28, _array156_);
}

void TerminateModule_iofun_private_imtifinfo(void) {
    mxDestroyArray(_mxarray155_);
    mxDestroyArray(_mxarray153_);
    mxDestroyArray(_mxarray151_);
    mxDestroyArray(_mxarray149_);
    mxDestroyArray(_mxarray147_);
    mxDestroyArray(_mxarray146_);
    mxDestroyArray(_mxarray145_);
    mxDestroyArray(_mxarray144_);
    mxDestroyArray(_mxarray142_);
    mxDestroyArray(_mxarray140_);
    mxDestroyArray(_mxarray138_);
    mxDestroyArray(_mxarray136_);
    mxDestroyArray(_mxarray135_);
    mxDestroyArray(_mxarray134_);
    mxDestroyArray(_mxarray133_);
    mxDestroyArray(_mxarray132_);
    mxDestroyArray(_mxarray131_);
    mxDestroyArray(_mxarray130_);
    mxDestroyArray(_mxarray129_);
    mxDestroyArray(_mxarray128_);
    mxDestroyArray(_mxarray127_);
    mxDestroyArray(_mxarray126_);
    mxDestroyArray(_mxarray125_);
    mxDestroyArray(_mxarray124_);
    mxDestroyArray(_mxarray123_);
    mxDestroyArray(_mxarray121_);
    mxDestroyArray(_mxarray119_);
    mxDestroyArray(_mxarray118_);
    mxDestroyArray(_mxarray117_);
    mxDestroyArray(_mxarray116_);
    mxDestroyArray(_mxarray115_);
    mxDestroyArray(_mxarray114_);
    mxDestroyArray(_mxarray113_);
    mxDestroyArray(_mxarray112_);
    mxDestroyArray(_mxarray111_);
    mxDestroyArray(_mxarray110_);
    mxDestroyArray(_mxarray108_);
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray106_);
    mxDestroyArray(_mxarray105_);
    mxDestroyArray(_mxarray104_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray102_);
    mxDestroyArray(_mxarray101_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray98_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray96_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray94_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray88_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray82_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_imtifinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_imtifinfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_imtifinfo" contains the normal interface for
 * the "iofun/private/imtifinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imtifinfo.m" (lines 1-695). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imtifinfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_imtifinfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_imtifinfo" contains the feval interface for
 * the "iofun/private/imtifinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imtifinfo.m" (lines 1-695). The
 * feval function calls the implementation version of iofun/private/imtifinfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imtifinfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imtifinfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_imtifinfo" is the implementation version of the
 * "iofun/private/imtifinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imtifinfo.m" (lines 1-695). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imtifinfo(filename)
 */
static mxArray * Miofun_private_imtifinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imtifinfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * numImages = mclGetUninitializedArray();
    mxArray * q = mclGetUninitializedArray();
    mxArray * SampleFormat = mclGetUninitializedArray();
    mxArray * data = mclGetUninitializedArray();
    mxArray * map = mclGetUninitializedArray();
    mxArray * den = mclGetUninitializedArray();
    mxArray * num = mclGetUninitializedArray();
    mxArray * _T0_ = mclGetUninitializedArray();
    mxArray * value = mclGetUninitializedArray();
    mxArray * offset = mclGetUninitializedArray();
    mxArray * count = mclGetUninitializedArray();
    mxArray * type = mclGetUninitializedArray();
    mxArray * tagID = mclGetUninitializedArray();
    mxArray * p = mclGetUninitializedArray();
    mxArray * tagPos = mclGetUninitializedArray();
    mxArray * tagCount = mclGetUninitializedArray();
    mxArray * status = mclGetUninitializedArray();
    mxArray * k = mclGetUninitializedArray();
    mxArray * nextIFDOffset = mclGetUninitializedArray();
    mxArray * pos = mclGetUninitializedArray();
    mxArray * byteOrder = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * sig = mclGetUninitializedArray();
    mxArray * d = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMTIFINFO Information about a TIFF file.
     * %   [INFO,MSG] = IMTIFINFO(FILENAME) returns a structure containing
     * %   information about the TIFF file specified by the string
     * %   FILENAME.  If the TIFF file contains more than one image,
     * %   INFO will be a structure array; each element of INFO contains
     * %   information about one image in the TIFF file.
     * %
     * %   If any error condition is encountered, such as an error opening
     * %   the file, MSG will contain a string describing the error and
     * %   INFO will be empty.  Otherwise, MSG will be empty.
     * %
     * %   See also IMREAD, IMWRITE, IMFINFO.
     * 
     * %   Steven L. Eddins, August 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.13 $  $Date: 2000/06/01 04:17:02 $
     * 
     * % This function should not call error()!  -SLE
     * 
     * % This function is an M-file that does *not* use a libtiff-based
     * % MEX-file because the im*info functions are used when trying to
     * % guess the format of an input file because the user didn't
     * % specify the format.  We don't want to take the memory hit of
     * % loading a big MEX-file just to see if we have a TIFF file.
     * 
     * info = [];
     */
    mlfAssign(&info, _mxarray4_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray5_);
    /*
     * 
     * if (~isstr(filename))
     */
    if (mclNotBool(mclVe(mlfIsstr(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray6_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * % TIFF files might be little-endian or big-endian.  Start with
     * % little-endian.  If we're wrong, we'll catch it down below and
     * % reopen the file.
     * [fid,m] = fopen(filename, 'r', 'ieee-le');
     */
    mlfAssign(
      &fid,
      mlfFopen(&m, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray10_));
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray12_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = m;
         */
        mlfAssign(msg, mclVsv(m, "m"));
        /*
         * return;
         */
        goto return_;
    /*
     * else
     */
    } else {
        /*
         * filename = fopen(fid);
         */
        mlfAssign(
          &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Read directory information about the file
     * d = dir(filename);
     */
    mlfAssign(&d, mlfNDir(1, mclVa(filename, "filename")));
    /*
     * 
     * %
     * % Initialize universal structure fields to fix the order
     * %
     * info.Filename = '';
     */
    mlfIndexAssign(&info, ".Filename", _mxarray5_);
    /*
     * info.FileModDate = '';
     */
    mlfIndexAssign(&info, ".FileModDate", _mxarray5_);
    /*
     * info.FileSize = [];
     */
    mlfIndexAssign(&info, ".FileSize", _mxarray4_);
    /*
     * info.Format = '';
     */
    mlfIndexAssign(&info, ".Format", _mxarray5_);
    /*
     * info.FormatVersion = [];
     */
    mlfIndexAssign(&info, ".FormatVersion", _mxarray4_);
    /*
     * info.Width = [];
     */
    mlfIndexAssign(&info, ".Width", _mxarray4_);
    /*
     * info.Height = [];
     */
    mlfIndexAssign(&info, ".Height", _mxarray4_);
    /*
     * info.BitDepth = [];
     */
    mlfIndexAssign(&info, ".BitDepth", _mxarray4_);
    /*
     * info.ColorType = [];
     */
    mlfIndexAssign(&info, ".ColorType", _mxarray4_);
    /*
     * info.FormatSignature = [];
     */
    mlfIndexAssign(&info, ".FormatSignature", _mxarray4_);
    /*
     * 
     * info.ByteOrder = [];
     */
    mlfIndexAssign(&info, ".ByteOrder", _mxarray4_);
    /*
     * 
     * %
     * % Initialize the baseline tags
     * %
     * info.NewSubfileType = [];
     */
    mlfIndexAssign(&info, ".NewSubfileType", _mxarray4_);
    /*
     * info.BitsPerSample = [];
     */
    mlfIndexAssign(&info, ".BitsPerSample", _mxarray4_);
    /*
     * info.Compression = [];
     */
    mlfIndexAssign(&info, ".Compression", _mxarray4_);
    /*
     * info.PhotometricInterpretation = [];
     */
    mlfIndexAssign(&info, ".PhotometricInterpretation", _mxarray4_);
    /*
     * info.StripOffsets = [];
     */
    mlfIndexAssign(&info, ".StripOffsets", _mxarray4_);
    /*
     * info.SamplesPerPixel = [];
     */
    mlfIndexAssign(&info, ".SamplesPerPixel", _mxarray4_);
    /*
     * info.RowsPerStrip = [];
     */
    mlfIndexAssign(&info, ".RowsPerStrip", _mxarray4_);
    /*
     * info.StripByteCounts = [];
     */
    mlfIndexAssign(&info, ".StripByteCounts", _mxarray4_);
    /*
     * info.XResolution = [];
     */
    mlfIndexAssign(&info, ".XResolution", _mxarray4_);
    /*
     * info.YResolution = [];
     */
    mlfIndexAssign(&info, ".YResolution", _mxarray4_);
    /*
     * info.ResolutionUnit = [];
     */
    mlfIndexAssign(&info, ".ResolutionUnit", _mxarray4_);
    /*
     * info.Colormap = [];
     */
    mlfIndexAssign(&info, ".Colormap", _mxarray4_);
    /*
     * info.PlanarConfiguration = [];
     */
    mlfIndexAssign(&info, ".PlanarConfiguration", _mxarray4_);
    /*
     * info.TileWidth = [];
     */
    mlfIndexAssign(&info, ".TileWidth", _mxarray4_);
    /*
     * info.TileLength = [];
     */
    mlfIndexAssign(&info, ".TileLength", _mxarray4_);
    /*
     * info.TileOffsets = [];
     */
    mlfIndexAssign(&info, ".TileOffsets", _mxarray4_);
    /*
     * info.TileByteCounts = [];
     */
    mlfIndexAssign(&info, ".TileByteCounts", _mxarray4_);
    /*
     * 
     * 
     * sig = fread(fid, 4, 'uint8')';
     */
    mlfAssign(
      &sig,
      mlfCtranspose(
        mclVe(
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray13_, _mxarray14_, NULL))));
    /*
     * if (~isequal(sig, [73 73 42 0]) & ...
     */
    {
        mxArray * a_ = mclInitialize(
                         mclNot(
                           mclVe(
                             mlfIsequal(
                               mclVv(sig, "sig"), _mxarray20_, NULL))));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclNot(
                     mclVe(
                       mlfIsequal(mclVv(sig, "sig"), _mxarray16_, NULL)))))) {
            mxDestroyArray(a_);
            /*
             * ~isequal(sig, [77 77 0 42]))
             * info = [];
             */
            mlfAssign(&info, _mxarray4_);
            /*
             * msg = 'Not a TIFF file';
             */
            mlfAssign(msg, _mxarray18_);
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
            /*
             * return;
             */
            goto return_;
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (sig(1) == 73)
     */
    if (mclEqBool(mclVe(mclIntArrayRef1(mclVsv(sig, "sig"), 1)), _mxarray22_)) {
        /*
         * byteOrder = 'little-endian';
         */
        mlfAssign(&byteOrder, _mxarray23_);
    /*
     * else
     */
    } else {
        /*
         * byteOrder = 'big-endian';
         */
        mlfAssign(&byteOrder, _mxarray25_);
    /*
     * end
     */
    }
    /*
     * 
     * if (strcmp(byteOrder, 'big-endian'))
     */
    if (mlfTobool(
          mclVe(mlfStrcmp(mclVv(byteOrder, "byteOrder"), _mxarray25_)))) {
        /*
         * % Whoops!  Must reopen the file.
         * pos = ftell(fid);
         */
        mlfAssign(&pos, mlfFtell(mclVv(fid, "fid")));
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * fid = fopen(filename, 'r', 'ieee-be');
         */
        mlfAssign(
          &fid,
          mlfFopen(
            NULL, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray27_));
        /*
         * fseek(fid, pos, 'bof');
         */
        mclAssignAns(
          &ans, mlfFseek(mclVv(fid, "fid"), mclVv(pos, "pos"), _mxarray29_));
    /*
     * end
     */
    }
    /*
     * 
     * nextIFDOffset = fread(fid, 1, 'uint32');
     */
    mlfAssign(
      &nextIFDOffset,
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray31_, _mxarray32_, NULL));
    /*
     * k = 0;  % number of images
     */
    mlfAssign(&k, _mxarray34_);
    /*
     * 
     * while (nextIFDOffset ~= 0)
     */
    while (mclNeBool(mclVv(nextIFDOffset, "nextIFDOffset"), _mxarray34_)) {
        /*
         * status = fseek(fid, nextIFDOffset, 'bof');
         */
        mlfAssign(
          &status,
          mlfFseek(
            mclVv(fid, "fid"),
            mclVv(nextIFDOffset, "nextIFDOffset"),
            _mxarray29_));
        /*
         * if (status ~= 0)
         */
        if (mclNeBool(mclVv(status, "status"), _mxarray34_)) {
            /*
             * % The seek to find the next IFD just failed.  This is probably
             * % because of a nonconforming TIFF file that didn't store the
             * % offset to the next IDF correctly at the end of the last IFD.
             * % The best we can do here is assume there aren't any more IFD's.
             * break;
             */
            break;
        /*
         * end
         */
        }
        /*
         * 
         * k = k + 1;
         */
        mlfAssign(&k, mclPlus(mclVv(k, "k"), _mxarray31_));
        /*
         * info(k).Filename = filename;
         */
        mlfIndexAssign(
          &info, "(?).Filename", mclVsv(k, "k"), mclVsa(filename, "filename"));
        /*
         * info(k).FileModDate = d.date;
         */
        mlfIndexAssign(
          &info,
          "(?).FileModDate",
          mclVsv(k, "k"),
          mlfIndexRef(mclVsv(d, "d"), ".date"));
        /*
         * info(k).FileSize = d.bytes;
         */
        mlfIndexAssign(
          &info,
          "(?).FileSize",
          mclVsv(k, "k"),
          mlfIndexRef(mclVsv(d, "d"), ".bytes"));
        /*
         * info(k).Format = 'tif';
         */
        mlfIndexAssign(&info, "(?).Format", mclVsv(k, "k"), _mxarray35_);
        /*
         * info(k).FormatSignature = sig;
         */
        mlfIndexAssign(
          &info, "(?).FormatSignature", mclVsv(k, "k"), mclVsv(sig, "sig"));
        /*
         * info(k).ByteOrder = byteOrder;
         */
        mlfIndexAssign(
          &info,
          "(?).ByteOrder",
          mclVsv(k, "k"),
          mclVsv(byteOrder, "byteOrder"));
        /*
         * 
         * tagCount = fread(fid, 1, 'uint16');
         */
        mlfAssign(
          &tagCount,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray31_, _mxarray37_, NULL));
        /*
         * tagPos = ftell(fid);
         */
        mlfAssign(&tagPos, mlfFtell(mclVv(fid, "fid")));
        /*
         * 
         * %
         * % Default tag values
         * %
         * info(k).Compression = 'Uncompressed';
         */
        mlfIndexAssign(&info, "(?).Compression", mclVsv(k, "k"), _mxarray39_);
        /*
         * info(k).Orientation = 1;
         */
        mlfIndexAssign(&info, "(?).Orientation", mclVsv(k, "k"), _mxarray31_);
        /*
         * info(k).ResolutionUnit = 'Inch';
         */
        mlfIndexAssign(
          &info, "(?).ResolutionUnit", mclVsv(k, "k"), _mxarray41_);
        /*
         * info(k).SamplesPerPixel = 1;
         */
        mlfIndexAssign(
          &info, "(?).SamplesPerPixel", mclVsv(k, "k"), _mxarray31_);
        /*
         * info(k).BitsPerSample = ones(1, info(k).SamplesPerPixel);
         */
        mlfIndexAssign(
          &info,
          "(?).BitsPerSample",
          mclVsv(k, "k"),
          mlfOnes(
            _mxarray31_,
            mclVe(
              mlfIndexRef(
                mclVsv(info, "info"), "(?).SamplesPerPixel", mclVsv(k, "k"))),
            NULL));
        /*
         * info(k).FillOrder = 1;
         */
        mlfIndexAssign(&info, "(?).FillOrder", mclVsv(k, "k"), _mxarray31_);
        /*
         * info(k).GrayResponseUnit = 0.01;
         */
        mlfIndexAssign(
          &info, "(?).GrayResponseUnit", mclVsv(k, "k"), _mxarray43_);
        /*
         * info(k).MaxSampleValue = [];  % can't be set yet; see end of for-loop
         */
        mlfIndexAssign(&info, "(?).MaxSampleValue", mclVsv(k, "k"), _mxarray4_);
        /*
         * info(k).MinSampleValue = 0;
         */
        mlfIndexAssign(
          &info, "(?).MinSampleValue", mclVsv(k, "k"), _mxarray34_);
        /*
         * info(k).NewSubfileType = 0;
         */
        mlfIndexAssign(
          &info, "(?).NewSubfileType", mclVsv(k, "k"), _mxarray34_);
        /*
         * info(k).PlanarConfiguration = 'Chunky';
         */
        mlfIndexAssign(
          &info, "(?).PlanarConfiguration", mclVsv(k, "k"), _mxarray44_);
        /*
         * info(k).RowsPerStrip = pow2(32)-1;
         */
        mlfIndexAssign(
          &info,
          "(?).RowsPerStrip",
          mclVsv(k, "k"),
          mclMinus(mclVe(mlfPow2(_mxarray46_, NULL)), _mxarray31_));
        /*
         * info(k).Thresholding = 1;
         */
        mlfIndexAssign(&info, "(?).Thresholding", mclVsv(k, "k"), _mxarray31_);
        /*
         * 
         * %
         * % Process the tags
         * %
         * for p = 1:tagCount
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclVv(tagCount, "tagCount"));
            if (v_ > e_) {
                mlfAssign(&p, _mxarray4_);
            } else {
                /*
                 * fseek(fid, tagPos, 'bof');
                 * tagID = fread(fid, 1, 'uint16');
                 * 
                 * switch tagID
                 * 
                 * case 254
                 * % NewSubfileType
                 * fseek(fid, 6, 'cof');
                 * info(k).NewSubFileType = fread(fid, 1, 'uint32');
                 * 
                 * case 256
                 * % ImageWidth
                 * type = fread(fid, 1, 'uint16');
                 * fseek(fid, 4, 'cof');
                 * if (type == 3)
                 * info(k).Width = fread(fid, 1, 'uint16');
                 * else
                 * info(k).Width = fread(fid,  1, 'uint32');
                 * end
                 * 
                 * case 257
                 * % ImageLength
                 * type = fread(fid, 1, 'uint16');
                 * fseek(fid, 4, 'cof');
                 * if (type == 3)
                 * info(k).Height = fread(fid, 1, 'uint16');
                 * else
                 * info(k).Height = fread(fid, 1, 'uint32');
                 * end
                 * 
                 * case 258
                 * % BitsPerSample
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 2)
                 * info(k).BitsPerSample = fread(fid, count, 'uint16')';
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).BitsPerSample = fread(fid, count, 'uint16')';
                 * end
                 * 
                 * case 259
                 * % Compression
                 * fseek(fid, 6, 'cof');
                 * value = fread(fid, 1, 'uint16');
                 * switch value
                 * case 1
                 * info(k).Compression = 'Uncompressed';
                 * case 2
                 * info(k).Compression = 'CCITT 1D';
                 * case 3
                 * info(k).Compression = 'Group 3 Fax';
                 * case 4
                 * info(k).Compression = 'Group 4 Fax';
                 * case 5
                 * info(k).Compression = 'LZW';
                 * case 6
                 * info(k).Compression = 'JPEG';
                 * case 32773
                 * info(k).Compression = 'PackBits';
                 * otherwise
                 * info(k).Compression = 'Unknown';
                 * end
                 * 
                 * 
                 * case 262
                 * % PhotometricInterpretation
                 * fseek(fid, 6, 'cof');
                 * value = fread(fid, 1, 'uint16');
                 * switch (value)
                 * case 0
                 * info(k).PhotometricInterpretation = 'WhiteIsZero';
                 * case 1
                 * info(k).PhotometricInterpretation = 'BlackIsZero';
                 * case 2
                 * info(k).PhotometricInterpretation = 'RGB';
                 * case 3
                 * info(k).PhotometricInterpretation = 'RGB Palette';
                 * case 4
                 * info(k).PhotometricInterpretation = 'Transparency mask';
                 * case 5
                 * info(k).PhotometricInterpretation = 'CMYK';
                 * case 6
                 * info(k).PhotometricInterpretation = 'YCbCr';
                 * case 7
                 * info(k).PhotometricInterpretation = 'CIELab';
                 * otherwise
                 * info(k).PhotometricInterpretation = 'Unknown';
                 * end
                 * 
                 * case 263
                 * % Thresholding
                 * fseek(fid, 6, 'cof');
                 * info(k).Thresholding = fread(fid, 1, 'uint16');
                 * 
                 * case 264
                 * % CellWidth
                 * fseek(fid, 6, 'cof');
                 * info(k).CellWidth = fread(fid, 1, 'uint16');
                 * 
                 * case 265
                 * % CellLength
                 * fseek(fid, 6, 'cof');
                 * info(k).CellLength = fread(fid, 1, 'uint16');
                 * 
                 * case 266
                 * % FillOrder
                 * fseek(fid, 6, 'cof');
                 * info(k).FillOrder = fread(fid, 1, 'uint16');
                 * 
                 * case 270
                 * % ImageDescription
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 4)
                 * info(k).ImageDescription = char(fread(fid, count, 'uint8')');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).ImageDescription = char(fread(fid, count, 'uint8')');
                 * end
                 * 
                 * % don't use null-terminated strings in MATLAB
                 * if (info(k).ImageDescription(end) == 0)
                 * info(k).ImageDescription(end) = [];
                 * end
                 * 
                 * case 271
                 * % Make
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 4)
                 * info(k).Make = char(fread(fid, count, 'uint8')');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).Make = char(fread(fid, count, 'uint8')');
                 * end
                 * 
                 * 
                 * case 272
                 * % Model
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 4)
                 * info(k).Model = char(fread(fid, count, 'uint8')');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).Model = char(fread(fid, count, 'uint8')');
                 * end
                 * 
                 * case 273
                 * % StripOffsets
                 * type = fread(fid, 1, 'uint16');
                 * count = fread(fid, 1, 'uint32');
                 * if (type == 3)
                 * if (count <= 2)
                 * info(k).StripOffsets = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).StripOffsets = fread(fid, count, 'uint16');
                 * end
                 * else
                 * if (count <= 1)
                 * info(k).StripOffsets = fread(fid, count, 'uint32');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).StripOffsets = fread(fid, count, 'uint32');
                 * end
                 * end
                 * 
                 * case 274
                 * % Orientation
                 * fseek(fid, 6, 'cof');
                 * info(k).Orientation = fread(fid, 1, 'uint16');
                 * 
                 * case 277
                 * % SamplesPerPixel
                 * fseek(fid, 6, 'cof');
                 * info(k).SamplesPerPixel = fread(fid, 1, 'uint16');
                 * 
                 * case 278
                 * % RowsPerStrip
                 * type = fread(fid, 1, 'uint16');
                 * fseek(fid, 4, 'cof');
                 * if (type == 3)
                 * info(k).RowsPerStrip = fread(fid, 1, 'uint16');
                 * else
                 * info(k).RowsPerStrip = fread(fid, 1, 'uint32');
                 * end
                 * 
                 * case 279
                 * % StripByteCounts
                 * type = fread(fid, 1, 'uint16');
                 * count = fread(fid, 1, 'uint32');
                 * if (type == 3)
                 * if (count <= 2)
                 * info(k).StripByteCounts = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).StripByteCounts = fread(fid, count, 'uint16');
                 * end
                 * else
                 * if (count <= 1)
                 * info(k).StripByteCounts = fread(fid, count, 'uint32');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).StripByteCounts = fread(fid, count, 'uint32');
                 * end
                 * end
                 * 
                 * case 280
                 * % MinSampleValue
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 2)
                 * info(k).MinSampleValue = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).MinSampleValue = fread(fid, count, 'uint16');
                 * end
                 * 
                 * case 281
                 * % MaxSampleValue
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 2)
                 * info(k).MaxSampleValue = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).MaxSampleValue = fread(fid, count, 'uint16');
                 * end
                 * 
                 * case 282
                 * % XResolution
                 * fseek(fid, 6, 'cof');
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * num = fread(fid, 1, 'uint32');
                 * den = fread(fid, 1, 'uint32');
                 * info(k).XResolution = num/den;
                 * 
                 * case 283
                 * % YResolution
                 * fseek(fid, 6, 'cof');
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * num = fread(fid, 1, 'uint32');
                 * den = fread(fid, 1, 'uint32');
                 * info(k).YResolution = num/den;
                 * 
                 * case 284
                 * % PlanarConfiguration
                 * fseek(fid, 6, 'cof');
                 * value = fread(fid, 1, 'uint16');
                 * if (value == 1)
                 * info(k).PlanarConfiguration = 'Chunky';
                 * else
                 * info(k).PlanarConfiguration = 'Planar';
                 * end
                 * 
                 * case 288
                 * % FreeOffsets
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 1)
                 * info(k).FreeOffsets = fread(fid, 1, 'uint32');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).FreeOffsets = fread(fid, count, 'uint32');
                 * end
                 * 
                 * case 289
                 * % FreeByteCounts
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 1)
                 * info(k).FreeByteCounts = fread(fid, 1, 'uint32');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).FreeByteCounts = fread(fid, count, 'uint32');
                 * end
                 * 
                 * case 290
                 * % GrayResponseUnit
                 * fseek(fid, 6, 'cof');
                 * value = fread(fid, 1, 'uint16');
                 * switch (value)
                 * case 1
                 * info(k).GrayResponseUnit = 0.1;
                 * case 2
                 * info(k).GrayResponseUnit = 0.01;
                 * case 3
                 * info(k).GrayResponseUnit = 0.001;
                 * case 4
                 * info(k).GrayResponseUnit = 0.0001;
                 * case 5
                 * info(k).GrayResponseUnit = 0.00001;
                 * end
                 * 
                 * case 291
                 * % GrayResponseCurve
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 2)
                 * info(k).GrayResponseCurve = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).GrayResponseCurve = fread(fid, count, 'uint16');
                 * end
                 * 
                 * case 296
                 * % ResolutionUnit
                 * fseek(fid, 6, 'cof');
                 * value = fread(fid, 1, 'uint16');
                 * switch (value)
                 * case 1
                 * info(k).ResolutionUnit = 'None';
                 * case 2
                 * info(k).ResolutionUnit = 'Inch';
                 * case 3
                 * info(k).ResolutionUnit = 'Centimeter';
                 * end
                 * 
                 * case 305
                 * % Software
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 4)
                 * info(k).Software = char(fread(fid, count, 'uint8')');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).Software = char(fread(fid, count, 'uint8')');
                 * end
                 * 
                 * case 306
                 * % DateTime
                 * fseek(fid, 6, 'cof');
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).DateTime = char(fread(fid, 20, 'uint8')');
                 * 
                 * case 315
                 * % Artist
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 4)
                 * info(k).Artist = char(fread(fid, count, 'uint8')');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).Artist = char(fread(fid, count, 'uint8')');
                 * end
                 * 
                 * case 316
                 * % HostComputer
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 4)
                 * info(k).HostComputer = char(fread(fid, count, 'uint8')');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).HostComputer = char(fread(fid, count, 'uint8')');
                 * end
                 * 
                 * case 320
                 * % ColorMap
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * map = fread(fid, count, 'uint16');
                 * num = count / 3;
                 * info(k).Colormap = reshape(map, num, 3) / 65535;
                 * 
                 * case 322
                 * % TileWidth
                 * type = fread(fid, 1, 'uint16');
                 * fseek(fid, 4, 'cof');
                 * if (type == 3)
                 * info(k).TileWidth = fread(fid, 1, 'uint16');
                 * else
                 * info(k).TileWidth = fread(fid, 1, 'uint32');
                 * end
                 * 
                 * case 323
                 * % TileLength
                 * type = fread(fid, 1, 'uint16');
                 * fseek(fid, 4, 'cof');
                 * if (type == 3)
                 * info(k).TileLength = fread(fid, 1, 'uint16');
                 * else
                 * info(k).TileLength = fread(fid, 1, 'uint32');
                 * end
                 * 
                 * case 324
                 * % TileOffsets
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 1)
                 * info(k).TileOffsets = fread(fid, count, 'uint32');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).TileOffsets = fread(fid, count, 'uint32');
                 * end
                 * 
                 * case 325
                 * % TileByteCounts
                 * type = fread(fid, 1, 'uint16');
                 * count = fread(fid, 1, 'uint32');
                 * if (type == 3)
                 * if (count <= 2)
                 * info(k).TileByteCounts = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).TileByteCounts = fread(fid, count, 'uint16');
                 * end
                 * else
                 * if (count <= 1)
                 * info(k).TileByteCounts = fread(fid, count, 'uint32');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).TileByteCounts = fread(fid, count, 'uint32');
                 * end
                 * end
                 * 
                 * case 338
                 * % ExtraSamples
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 2)
                 * info(k).ExtraSamples = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).ExtraSamples = fread(fid, count, 'uint16');
                 * end
                 * 
                 * case 339
                 * % SampleFormat
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 2)
                 * data = fread(fid, count, 'uint16');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * data = fread(fid, count, 'uint16');
                 * end
                 * SampleFormat = num2cell(data);
                 * for q = 1:count
                 * switch (data(q))
                 * case 1
                 * SampleFormat{q} = 'Unsigned integer';
                 * case 2
                 * SampleFormat{q} = 'Two''s complement signed integer';
                 * case 3
                 * SampleFormat{q} = 'IEEE floating point';
                 * case 4
                 * SampleFormat{q} = 'Undefined';
                 * end
                 * end
                 * if (count == 1)
                 * SampleFormat = SampleFormat{1};
                 * end
                 * info(k).SampleFormat = SampleFormat;
                 * 
                 * case 33432
                 * fseek(fid, 2, 'cof');
                 * count = fread(fid, 1, 'uint32');
                 * if (count <= 4)
                 * info(k).Copyright = char(fread(fid, count, 'uint8')');
                 * else
                 * offset = fread(fid, 1, 'uint32');
                 * fseek(fid, offset, 'bof');
                 * info(k).Copyright = char(fread(fid, count, 'uint8')');
                 * end
                 * 
                 * case 34675
                 * fseek(fid, 6, 'cof');
                 * info(k).ICCProfileOffset = fread(fid, 1, 'uint32');
                 * 
                 * end  %%%% switch
                 * 
                 * tagPos = tagPos + 12;
                 * 
                 * end  %%%% for
                 */
                for (; ; ) {
                    mclAssignAns(
                      &ans,
                      mlfFseek(
                        mclVv(fid, "fid"),
                        mclVv(tagPos, "tagPos"),
                        _mxarray29_));
                    mlfAssign(
                      &tagID,
                      mlfFread(
                        NULL,
                        mclVv(fid, "fid"),
                        _mxarray31_,
                        _mxarray37_,
                        NULL));
                    {
                        mxArray * v_0 = mclInitialize(mclVv(tagID, "tagID"));
                        if (mclSwitchCompare(v_0, _mxarray47_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).NewSubFileType",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray51_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray13_, _mxarray49_));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Width",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Width",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray53_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray13_, _mxarray49_));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Height",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Height",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray54_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray55_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).BitsPerSample",
                                  mclVsv(k, "k"),
                                  mlfCtranspose(
                                    mclVe(
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL))));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).BitsPerSample",
                                  mclVsv(k, "k"),
                                  mlfCtranspose(
                                    mclVe(
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL))));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray56_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &value,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            {
                                mxArray * v_1 = mclInitialize(
                                                  mclVv(value, "value"));
                                if (mclSwitchCompare(v_1, _mxarray31_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray39_);
                                } else if (mclSwitchCompare(v_1, _mxarray55_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray57_);
                                } else if (mclSwitchCompare(v_1, _mxarray52_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray59_);
                                } else if (mclSwitchCompare(v_1, _mxarray13_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray61_);
                                } else if (mclSwitchCompare(v_1, _mxarray63_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray64_);
                                } else if (mclSwitchCompare(v_1, _mxarray48_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray66_);
                                } else if (mclSwitchCompare(v_1, _mxarray68_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray69_);
                                } else {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).Compression",
                                      mclVsv(k, "k"),
                                      _mxarray71_);
                                }
                                mxDestroyArray(v_1);
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray73_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &value,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            {
                                mxArray * v_2 = mclInitialize(
                                                  mclVv(value, "value"));
                                if (mclSwitchCompare(v_2, _mxarray34_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray74_);
                                } else if (mclSwitchCompare(v_2, _mxarray31_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray76_);
                                } else if (mclSwitchCompare(v_2, _mxarray55_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray78_);
                                } else if (mclSwitchCompare(v_2, _mxarray52_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray80_);
                                } else if (mclSwitchCompare(v_2, _mxarray13_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray82_);
                                } else if (mclSwitchCompare(v_2, _mxarray63_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray84_);
                                } else if (mclSwitchCompare(v_2, _mxarray48_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray86_);
                                } else if (mclSwitchCompare(v_2, _mxarray88_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray89_);
                                } else {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).PhotometricInterpretation",
                                      mclVsv(k, "k"),
                                      _mxarray71_);
                                }
                                mxDestroyArray(v_2);
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray91_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).Thresholding",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray92_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).CellWidth",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray93_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).CellLength",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray94_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).FillOrder",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray95_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray13_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).ImageDescription",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).ImageDescription",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            }
                            mlfAssign(&_T0_, mclVv(k, "k"));
                            if (mlfTobool(
                                  mclFeval(
                                    mclValueVarargout(),
                                    mlxEq,
                                    mclVe(
                                      mlfIndexRef(
                                        mclVsv(info, "info"),
                                        "(?).ImageDescription(?)",
                                        _T0_,
                                        mclFeval(
                                          mclValueVarargout(),
                                          mlxEnd,
                                          mclVe(
                                            mlfIndexRef(
                                              mclVsv(info, "info"),
                                              "(?).ImageDescription",
                                              _T0_)),
                                          _mxarray31_,
                                          _mxarray31_,
                                          NULL))),
                                    _mxarray34_,
                                    NULL))) {
                                mlfAssign(&_T0_, mclVv(k, "k"));
                                mlfIndexDelete(
                                  &info,
                                  "(?).ImageDescription(?)",
                                  _T0_,
                                  mclFeval(
                                    mclValueVarargout(),
                                    mlxEnd,
                                    mclVe(
                                      mlfIndexRef(
                                        mclVsv(info, "info"),
                                        "(?).ImageDescription",
                                        _T0_)),
                                    _mxarray31_,
                                    _mxarray31_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray96_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray13_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Make",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).Make",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray97_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray13_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Model",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).Model",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray98_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                if (mclLeBool(
                                      mclVv(count, "count"), _mxarray55_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripOffsets",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL));
                                } else {
                                    mlfAssign(
                                      &offset,
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        _mxarray31_,
                                        _mxarray32_,
                                        NULL));
                                    mclAssignAns(
                                      &ans,
                                      mlfFseek(
                                        mclVv(fid, "fid"),
                                        mclVv(offset, "offset"),
                                        _mxarray29_));
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripOffsets",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL));
                                }
                            } else {
                                if (mclLeBool(
                                      mclVv(count, "count"), _mxarray31_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripOffsets",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray32_,
                                        NULL));
                                } else {
                                    mlfAssign(
                                      &offset,
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        _mxarray31_,
                                        _mxarray32_,
                                        NULL));
                                    mclAssignAns(
                                      &ans,
                                      mlfFseek(
                                        mclVv(fid, "fid"),
                                        mclVv(offset, "offset"),
                                        _mxarray29_));
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripOffsets",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray32_,
                                        NULL));
                                }
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray99_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).Orientation",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray100_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).SamplesPerPixel",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray101_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray13_, _mxarray49_));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).RowsPerStrip",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfIndexAssign(
                                  &info,
                                  "(?).RowsPerStrip",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray102_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                if (mclLeBool(
                                      mclVv(count, "count"), _mxarray55_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL));
                                } else {
                                    mlfAssign(
                                      &offset,
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        _mxarray31_,
                                        _mxarray32_,
                                        NULL));
                                    mclAssignAns(
                                      &ans,
                                      mlfFseek(
                                        mclVv(fid, "fid"),
                                        mclVv(offset, "offset"),
                                        _mxarray29_));
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL));
                                }
                            } else {
                                if (mclLeBool(
                                      mclVv(count, "count"), _mxarray31_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray32_,
                                        NULL));
                                } else {
                                    mlfAssign(
                                      &offset,
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        _mxarray31_,
                                        _mxarray32_,
                                        NULL));
                                    mclAssignAns(
                                      &ans,
                                      mlfFseek(
                                        mclVv(fid, "fid"),
                                        mclVv(offset, "offset"),
                                        _mxarray29_));
                                    mlfIndexAssign(
                                      &info,
                                      "(?).StripByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray32_,
                                        NULL));
                                }
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray103_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray55_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).MinSampleValue",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).MinSampleValue",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray104_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray55_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).MaxSampleValue",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).MaxSampleValue",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray105_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &offset,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"),
                                mclVv(offset, "offset"),
                                _mxarray29_));
                            mlfAssign(
                              &num,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mlfAssign(
                              &den,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mlfIndexAssign(
                              &info,
                              "(?).XResolution",
                              mclVsv(k, "k"),
                              mclMrdivide(
                                mclVv(num, "num"), mclVv(den, "den")));
                        } else if (mclSwitchCompare(v_0, _mxarray106_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &offset,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"),
                                mclVv(offset, "offset"),
                                _mxarray29_));
                            mlfAssign(
                              &num,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mlfAssign(
                              &den,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mlfIndexAssign(
                              &info,
                              "(?).YResolution",
                              mclVsv(k, "k"),
                              mclMrdivide(
                                mclVv(num, "num"), mclVv(den, "den")));
                        } else if (mclSwitchCompare(v_0, _mxarray107_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &value,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            if (mclEqBool(mclVv(value, "value"), _mxarray31_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).PlanarConfiguration",
                                  mclVsv(k, "k"),
                                  _mxarray44_);
                            } else {
                                mlfIndexAssign(
                                  &info,
                                  "(?).PlanarConfiguration",
                                  mclVsv(k, "k"),
                                  _mxarray108_);
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray110_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray31_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).FreeOffsets",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).FreeOffsets",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray111_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray31_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).FreeByteCounts",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).FreeByteCounts",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray112_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &value,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            {
                                mxArray * v_3 = mclInitialize(
                                                  mclVv(value, "value"));
                                if (mclSwitchCompare(v_3, _mxarray31_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).GrayResponseUnit",
                                      mclVsv(k, "k"),
                                      _mxarray113_);
                                } else if (mclSwitchCompare(v_3, _mxarray55_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).GrayResponseUnit",
                                      mclVsv(k, "k"),
                                      _mxarray43_);
                                } else if (mclSwitchCompare(v_3, _mxarray52_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).GrayResponseUnit",
                                      mclVsv(k, "k"),
                                      _mxarray114_);
                                } else if (mclSwitchCompare(v_3, _mxarray13_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).GrayResponseUnit",
                                      mclVsv(k, "k"),
                                      _mxarray115_);
                                } else if (mclSwitchCompare(v_3, _mxarray63_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).GrayResponseUnit",
                                      mclVsv(k, "k"),
                                      _mxarray116_);
                                }
                                mxDestroyArray(v_3);
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray117_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray55_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).GrayResponseCurve",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).GrayResponseCurve",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray118_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &value,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            {
                                mxArray * v_4 = mclInitialize(
                                                  mclVv(value, "value"));
                                if (mclSwitchCompare(v_4, _mxarray31_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).ResolutionUnit",
                                      mclVsv(k, "k"),
                                      _mxarray119_);
                                } else if (mclSwitchCompare(v_4, _mxarray55_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).ResolutionUnit",
                                      mclVsv(k, "k"),
                                      _mxarray41_);
                                } else if (mclSwitchCompare(v_4, _mxarray52_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).ResolutionUnit",
                                      mclVsv(k, "k"),
                                      _mxarray121_);
                                }
                                mxDestroyArray(v_4);
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray123_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray13_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Software",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).Software",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray124_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfAssign(
                              &offset,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"),
                                mclVv(offset, "offset"),
                                _mxarray29_));
                            mlfIndexAssign(
                              &info,
                              "(?).DateTime",
                              mclVsv(k, "k"),
                              mlfChar(
                                mlfCtranspose(
                                  mclVe(
                                    mlfFread(
                                      NULL,
                                      mclVv(fid, "fid"),
                                      _mxarray125_,
                                      _mxarray14_,
                                      NULL))),
                                NULL));
                        } else if (mclSwitchCompare(v_0, _mxarray126_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray13_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Artist",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).Artist",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray127_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray13_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).HostComputer",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).HostComputer",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray128_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mlfAssign(
                              &offset,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"),
                                mclVv(offset, "offset"),
                                _mxarray29_));
                            mlfAssign(
                              &map,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                mclVv(count, "count"),
                                _mxarray37_,
                                NULL));
                            mlfAssign(
                              &num,
                              mclMrdivide(mclVv(count, "count"), _mxarray52_));
                            mlfIndexAssign(
                              &info,
                              "(?).Colormap",
                              mclVsv(k, "k"),
                              mclMrdivide(
                                mclVe(
                                  mlfReshape(
                                    mclVv(map, "map"),
                                    mclVv(num, "num"), _mxarray52_, NULL)),
                                _mxarray129_));
                        } else if (mclSwitchCompare(v_0, _mxarray130_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray13_, _mxarray49_));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).TileWidth",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfIndexAssign(
                                  &info,
                                  "(?).TileWidth",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray131_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray13_, _mxarray49_));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).TileLength",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfIndexAssign(
                                  &info,
                                  "(?).TileLength",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray132_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray31_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).TileOffsets",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray32_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).TileOffsets",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray32_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray133_)) {
                            mlfAssign(
                              &type,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray37_,
                                NULL));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclEqBool(mclVv(type, "type"), _mxarray52_)) {
                                if (mclLeBool(
                                      mclVv(count, "count"), _mxarray55_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).TileByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL));
                                } else {
                                    mlfAssign(
                                      &offset,
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        _mxarray31_,
                                        _mxarray32_,
                                        NULL));
                                    mclAssignAns(
                                      &ans,
                                      mlfFseek(
                                        mclVv(fid, "fid"),
                                        mclVv(offset, "offset"),
                                        _mxarray29_));
                                    mlfIndexAssign(
                                      &info,
                                      "(?).TileByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray37_,
                                        NULL));
                                }
                            } else {
                                if (mclLeBool(
                                      mclVv(count, "count"), _mxarray31_)) {
                                    mlfIndexAssign(
                                      &info,
                                      "(?).TileByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray32_,
                                        NULL));
                                } else {
                                    mlfAssign(
                                      &offset,
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        _mxarray31_,
                                        _mxarray32_,
                                        NULL));
                                    mclAssignAns(
                                      &ans,
                                      mlfFseek(
                                        mclVv(fid, "fid"),
                                        mclVv(offset, "offset"),
                                        _mxarray29_));
                                    mlfIndexAssign(
                                      &info,
                                      "(?).TileByteCounts",
                                      mclVsv(k, "k"),
                                      mlfFread(
                                        NULL,
                                        mclVv(fid, "fid"),
                                        mclVv(count, "count"),
                                        _mxarray32_,
                                        NULL));
                                }
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray134_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray55_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).ExtraSamples",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).ExtraSamples",
                                  mclVsv(k, "k"),
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray135_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray55_)) {
                                mlfAssign(
                                  &data,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfAssign(
                                  &data,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    mclVv(count, "count"),
                                    _mxarray37_,
                                    NULL));
                            }
                            mlfAssign(
                              &SampleFormat,
                              mlfNum2cell(mclVv(data, "data"), NULL));
                            {
                                int v_5 = mclForIntStart(1);
                                int e_0 = mclForIntEnd(mclVv(count, "count"));
                                if (v_5 > e_0) {
                                    mlfAssign(&q, _mxarray4_);
                                } else {
                                    for (; ; ) {
                                        mxArray * v_6 = mclInitialize(
                                                          mclVe(
                                                            mclIntArrayRef1(
                                                              mclVsv(
                                                                data, "data"),
                                                              v_5)));
                                        if (mclSwitchCompare(
                                              v_6, _mxarray31_)) {
                                            mlfIndexAssign(
                                              &SampleFormat,
                                              "{?}",
                                              mlfScalar(v_5),
                                              _mxarray136_);
                                        } else if (mclSwitchCompare(
                                                     v_6, _mxarray55_)) {
                                            mlfIndexAssign(
                                              &SampleFormat,
                                              "{?}",
                                              mlfScalar(v_5),
                                              _mxarray138_);
                                        } else if (mclSwitchCompare(
                                                     v_6, _mxarray52_)) {
                                            mlfIndexAssign(
                                              &SampleFormat,
                                              "{?}",
                                              mlfScalar(v_5),
                                              _mxarray140_);
                                        } else if (mclSwitchCompare(
                                                     v_6, _mxarray13_)) {
                                            mlfIndexAssign(
                                              &SampleFormat,
                                              "{?}",
                                              mlfScalar(v_5),
                                              _mxarray142_);
                                        }
                                        mxDestroyArray(v_6);
                                        if (v_5 == e_0) {
                                            break;
                                        }
                                        ++v_5;
                                    }
                                    mlfAssign(&q, mlfScalar(v_5));
                                }
                            }
                            if (mclEqBool(mclVv(count, "count"), _mxarray31_)) {
                                mlfAssign(
                                  &SampleFormat,
                                  mlfIndexRef(
                                    mclVsv(SampleFormat, "SampleFormat"),
                                    "{?}",
                                    _mxarray31_));
                            }
                            mlfIndexAssign(
                              &info,
                              "(?).SampleFormat",
                              mclVsv(k, "k"),
                              mclVsv(SampleFormat, "SampleFormat"));
                        } else if (mclSwitchCompare(v_0, _mxarray144_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray55_, _mxarray49_));
                            mlfAssign(
                              &count,
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                            if (mclLeBool(mclVv(count, "count"), _mxarray13_)) {
                                mlfIndexAssign(
                                  &info,
                                  "(?).Copyright",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            } else {
                                mlfAssign(
                                  &offset,
                                  mlfFread(
                                    NULL,
                                    mclVv(fid, "fid"),
                                    _mxarray31_,
                                    _mxarray32_,
                                    NULL));
                                mclAssignAns(
                                  &ans,
                                  mlfFseek(
                                    mclVv(fid, "fid"),
                                    mclVv(offset, "offset"),
                                    _mxarray29_));
                                mlfIndexAssign(
                                  &info,
                                  "(?).Copyright",
                                  mclVsv(k, "k"),
                                  mlfChar(
                                    mlfCtranspose(
                                      mclVe(
                                        mlfFread(
                                          NULL,
                                          mclVv(fid, "fid"),
                                          mclVv(count, "count"),
                                          _mxarray14_,
                                          NULL))),
                                    NULL));
                            }
                        } else if (mclSwitchCompare(v_0, _mxarray145_)) {
                            mclAssignAns(
                              &ans,
                              mlfFseek(
                                mclVv(fid, "fid"), _mxarray48_, _mxarray49_));
                            mlfIndexAssign(
                              &info,
                              "(?).ICCProfileOffset",
                              mclVsv(k, "k"),
                              mlfFread(
                                NULL,
                                mclVv(fid, "fid"),
                                _mxarray31_,
                                _mxarray32_,
                                NULL));
                        }
                        mxDestroyArray(v_0);
                    }
                    mlfAssign(
                      &tagPos, mclPlus(mclVv(tagPos, "tagPos"), _mxarray146_));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&p, mlfScalar(v_));
            }
        }
        /*
         * 
         * %
         * % Set more defaults; these depend on other tag values and so
         * % couldn't be set above.
         * %
         * if (isempty(info(k).MaxSampleValue))
         */
        if (mlfTobool(
              mclVe(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsempty,
                  mclVe(
                    mlfIndexRef(
                      mclVsv(info, "info"),
                      "(?).MaxSampleValue",
                      mclVsv(k, "k"))),
                  NULL)))) {
            /*
             * info(k).MaxSampleValue = pow2(info(k).BitsPerSample) - 1;
             */
            mlfIndexAssign(
              &info,
              "(?).MaxSampleValue",
              mclVsv(k, "k"),
              mclMinus(
                mclVe(
                  mclFeval(
                    mclValueVarargout(),
                    mlxPow2,
                    mclVe(
                      mlfIndexRef(
                        mclVsv(info, "info"),
                        "(?).BitsPerSample",
                        mclVsv(k, "k"))),
                    NULL)),
                _mxarray31_));
        /*
         * end
         */
        }
        /*
         * 
         * info(k).BitDepth = sum(info(k).BitsPerSample);
         */
        mlfIndexAssign(
          &info,
          "(?).BitDepth",
          mclVsv(k, "k"),
          mclFeval(
            mclValueVarargout(),
            mlxSum,
            mclVe(
              mlfIndexRef(
                mclVsv(info, "info"), "(?).BitsPerSample", mclVsv(k, "k"))),
            NULL));
        /*
         * if (~isempty(info(k).Colormap))
         */
        if (mclNotBool(
              mclVe(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsempty,
                  mclVe(
                    mlfIndexRef(
                      mclVsv(info, "info"), "(?).Colormap", mclVsv(k, "k"))),
                  NULL)))) {
            /*
             * info(k).ColorType = 'indexed';
             */
            mlfIndexAssign(
              &info, "(?).ColorType", mclVsv(k, "k"), _mxarray147_);
        /*
         * elseif (strcmp(info(k).PhotometricInterpretation, 'WhiteIsZero'))
         */
        } else if (mlfTobool(
                     mclVe(
                       mclFeval(
                         mclValueVarargout(),
                         mlxStrcmp,
                         mclVe(
                           mlfIndexRef(
                             mclVsv(info, "info"),
                             "(?).PhotometricInterpretation",
                             mclVsv(k, "k"))),
                         _mxarray74_,
                         NULL)))) {
            /*
             * info(k).ColorType = 'grayscale';
             */
            mlfIndexAssign(
              &info, "(?).ColorType", mclVsv(k, "k"), _mxarray149_);
        /*
         * elseif (strcmp(info(k).PhotometricInterpretation, 'BlackIsZero'))
         */
        } else if (mlfTobool(
                     mclVe(
                       mclFeval(
                         mclValueVarargout(),
                         mlxStrcmp,
                         mclVe(
                           mlfIndexRef(
                             mclVsv(info, "info"),
                             "(?).PhotometricInterpretation",
                             mclVsv(k, "k"))),
                         _mxarray76_,
                         NULL)))) {
            /*
             * info(k).ColorType = 'grayscale';
             */
            mlfIndexAssign(
              &info, "(?).ColorType", mclVsv(k, "k"), _mxarray149_);
        /*
         * elseif (strcmp(info(k).PhotometricInterpretation, 'RGB'))
         */
        } else if (mlfTobool(
                     mclVe(
                       mclFeval(
                         mclValueVarargout(),
                         mlxStrcmp,
                         mclVe(
                           mlfIndexRef(
                             mclVsv(info, "info"),
                             "(?).PhotometricInterpretation",
                             mclVsv(k, "k"))),
                         _mxarray78_,
                         NULL)))) {
            /*
             * info(k).ColorType = 'truecolor';
             */
            mlfIndexAssign(
              &info, "(?).ColorType", mclVsv(k, "k"), _mxarray151_);
        /*
         * else
         */
        } else {
            /*
             * info(k).ColorType = 'unknown';
             */
            mlfIndexAssign(
              &info, "(?).ColorType", mclVsv(k, "k"), _mxarray153_);
        /*
         * end
         */
        }
        /*
         * 
         * fseek(fid, tagPos, 'bof');
         */
        mclAssignAns(
          &ans,
          mlfFseek(mclVv(fid, "fid"), mclVv(tagPos, "tagPos"), _mxarray29_));
        /*
         * nextIFDOffset = fread(fid, 1, 'uint32');
         */
        mlfAssign(
          &nextIFDOffset,
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray31_, _mxarray32_, NULL));
    /*
     * 
     * end  %%%% while
     */
    }
    /*
     * 
     * numImages = k;
     */
    mlfAssign(&numImages, mclVsv(k, "k"));
    /*
     * if (numImages == 0)
     */
    if (mclEqBool(mclVv(numImages, "numImages"), _mxarray34_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray4_);
        /*
         * msg = 'No images found in TIFF file';
         */
        mlfAssign(msg, _mxarray155_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * fclose(fid);
     */
    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/imtifinfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/imtifinfo");
    mxDestroyArray(fid);
    mxDestroyArray(m);
    mxDestroyArray(d);
    mxDestroyArray(sig);
    mxDestroyArray(ans);
    mxDestroyArray(byteOrder);
    mxDestroyArray(pos);
    mxDestroyArray(nextIFDOffset);
    mxDestroyArray(k);
    mxDestroyArray(status);
    mxDestroyArray(tagCount);
    mxDestroyArray(tagPos);
    mxDestroyArray(p);
    mxDestroyArray(tagID);
    mxDestroyArray(type);
    mxDestroyArray(count);
    mxDestroyArray(offset);
    mxDestroyArray(value);
    mxDestroyArray(_T0_);
    mxDestroyArray(num);
    mxDestroyArray(den);
    mxDestroyArray(map);
    mxDestroyArray(data);
    mxDestroyArray(SampleFormat);
    mxDestroyArray(q);
    mxDestroyArray(numImages);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
