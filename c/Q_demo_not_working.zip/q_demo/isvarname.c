/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:44 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "isvarname.h"
#include "iskeyword.h"
#include "libmatlbm.h"

static mxChar _array1_[136] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 's', 'v', 'a', 'r',
                                'n', 'a', 'm', 'e', ' ', 'L', 'i', 'n', 'e',
                                ':', ' ', '1', ' ', 'C', 'o', 'l', 'u', 'm',
                                'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '"', 'i', 's', 'v', 'a', 'r', 'n', 'a', 'm',
                                'e', '"', ' ', 'w', 'a', 's', ' ', 'c', 'a',
                                'l', 'l', 'e', 'd', ' ', 'w', 'i', 't', 'h',
                                ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h', 'a',
                                'n', ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c',
                                'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm',
                                'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o', 'u',
                                't', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[135] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 's', 'v', 'a', 'r',
                                'n', 'a', 'm', 'e', ' ', 'L', 'i', 'n', 'e',
                                ':', ' ', '1', ' ', 'C', 'o', 'l', 'u', 'm',
                                'n', ':', ' ', '1', ' ', 'T', 'h', 'e', ' ',
                                'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '"', 'i', 's', 'v', 'a', 'r', 'n', 'a', 'm',
                                'e', '"', ' ', 'w', 'a', 's', ' ', 'c', 'a',
                                'l', 'l', 'e', 'd', ' ', 'w', 'i', 't', 'h',
                                ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h', 'a',
                                'n', ' ', 't', 'h', 'e', ' ', 'd', 'e', 'c',
                                'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u', 'm',
                                'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i', 'n',
                                'p', 'u', 't', 's', ' ', '(', '1', ')', '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[1] = { '_' };
static mxArray * _mxarray5_;

static mxChar _array8_[1] = { '0' };
static mxArray * _mxarray7_;

static mxChar _array10_[1] = { '9' };
static mxArray * _mxarray9_;

void InitializeModule_isvarname(void) {
    _mxarray0_ = mclInitializeString(136, _array1_);
    _mxarray2_ = mclInitializeString(135, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeString(1, _array6_);
    _mxarray7_ = mclInitializeString(1, _array8_);
    _mxarray9_ = mclInitializeString(1, _array10_);
}

void TerminateModule_isvarname(void) {
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Misvarname(int nargout_, mxArray * s);

_mexLocalFunctionTable _local_function_table_isvarname
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIsvarname" contains the normal interface for the
 * "isvarname" M-function from file
 * "C:\matlabR12\toolbox\matlab\lang\isvarname.m" (lines 1-17). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfIsvarname(mxArray * s) {
    int nargout = 1;
    mxArray * t = mclGetUninitializedArray();
    mlfEnterNewContext(0, 1, s);
    t = Misvarname(nargout, s);
    mlfRestorePreviousContext(0, 1, s);
    return mlfReturnValue(t);
}

/*
 * The function "mlxIsvarname" contains the feval interface for the "isvarname"
 * M-function from file "C:\matlabR12\toolbox\matlab\lang\isvarname.m" (lines
 * 1-17). The feval function calls the implementation version of isvarname
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIsvarname(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Misvarname(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Misvarname" is the implementation version of the "isvarname"
 * M-function from file "C:\matlabR12\toolbox\matlab\lang\isvarname.m" (lines
 * 1-17). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = isvarname(s)
 */
static mxArray * Misvarname(int nargout_, mxArray * s) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_isvarname);
    mxArray * t = mclGetUninitializedArray();
    mclCopyArray(&s);
    /*
     * %ISVARNAME True for valid variable name.
     * %   ISVARNAME(S) is true if S is a valid MATLAB variable name.
     * %   A valid variable name is a character string of letters, digits and
     * %   underscores, with length <= 31 and the first character a letter.
     * %
     * %   See also ISKEYWORD.
     * 
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.4 $  $Date: 2000/06/01 04:26:43 $
     * 
     * t = ischar(s) & size(s,1) == 1 & length(s) <= 31;
     */
    mlfAssign(
      &t,
      mclAnd(
        mclAnd(
          mclVe(mlfIschar(mclVa(s, "s"))),
          mclEq(
            mclVe(mlfSize(mclValueVarargout(), mclVa(s, "s"), _mxarray4_)),
            _mxarray4_)),
        mclBoolToArray(mclLengthInt(mclVa(s, "s")) <= 31)));
    /*
     * if t
     */
    if (mlfTobool(mclVv(t, "t"))) {
        /*
         * t = isletter(s(1)) & all(isletter(s) | s == '_' | ('0' <= s & s <= '9'));
         */
        mlfAssign(
          &t,
          mclAnd(
            mclVe(mlfIsletter(mclVe(mclIntArrayRef1(mclVsa(s, "s"), 1)))),
            mclVe(
              mlfAll(
                mclOr(
                  mclOr(
                    mclVe(mlfIsletter(mclVa(s, "s"))),
                    mclEq(mclVa(s, "s"), _mxarray5_)),
                  mclAnd(
                    mclLe(_mxarray7_, mclVa(s, "s")),
                    mclLe(mclVa(s, "s"), _mxarray9_))),
                NULL))));
        /*
         * t = t & ~iskeyword(s); 
         */
        mlfAssign(
          &t,
          mclAnd(mclVv(t, "t"), mclNot(mclVe(mlfIskeyword(mclVa(s, "s"))))));
    /*
     * end
     */
    }
    mclValidateOutput(t, 1, nargout_, "t", "isvarname");
    mxDestroyArray(s);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
}
