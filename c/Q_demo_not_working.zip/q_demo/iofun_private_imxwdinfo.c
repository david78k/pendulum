/*
 * MATLAB Compiler: 2.1
 * Date: Thu Oct 17 12:10:45 2002
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-B" "sgl" "-m" "-W"
 * "main" "-L" "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "q_demo.m" 
 */
#include "iofun_private_imxwdinfo.h"
#include "libmatlbm.h"

static mxChar _array1_[164] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'x', 'w', 'd', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'x', 'w', 'd', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '2',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[163] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'i', 'o', 'f', 'u', 'n',
                                '/', 'p', 'r', 'i', 'v', 'a', 't', 'e', '/',
                                'i', 'm', 'x', 'w', 'd', 'i', 'n', 'f', 'o',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '1', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'i', 'o', 'f',
                                'u', 'n', '/', 'p', 'r', 'i', 'v', 'a', 't',
                                'e', '/', 'i', 'm', 'x', 'w', 'd', 'i', 'n',
                                'f', 'o', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '1', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;

static mxChar _array7_[25] = { 'F', 'I', 'L', 'E', 'N', 'A', 'M', 'E', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                               ' ', 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray6_;

static mxChar _array9_[1] = { 'r' };
static mxArray * _mxarray8_;

static mxChar _array11_[7] = { 'i', 'e', 'e', 'e', '-', 'b', 'e' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;

static mxChar _array14_[3] = { 'x', 'w', 'd' };
static mxArray * _mxarray13_;
static mxArray * _mxarray15_;

static mxChar _array17_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray16_;

static mxChar _array19_[16] = { 'T', 'r', 'u', 'n', 'c', 'a', 't', 'e',
                                'd', ' ', 'h', 'e', 'a', 'd', 'e', 'r' };
static mxArray * _mxarray18_;
static mxArray * _mxarray20_;
static mxArray * _mxarray21_;

static mxChar _array23_[7] = { 'i', 'e', 'e', 'e', '-', 'l', 'e' };
static mxArray * _mxarray22_;

static mxChar _array25_[19] = { 'N', 'o', 't', ' ', 'a', 'n', ' ',
                                'X', '1', '1', ' ', 'X', 'W', 'D',
                                ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray24_;
static mxArray * _mxarray26_;

static mxChar _array28_[8] = { 'X', 'Y', 'B', 'i', 't', 'm', 'a', 'p' };
static mxArray * _mxarray27_;

static mxChar _array30_[8] = { 'X', 'Y', 'P', 'i', 'x', 'm', 'a', 'p' };
static mxArray * _mxarray29_;

static mxChar _array32_[7] = { 'Z', 'P', 'i', 'x', 'm', 'a', 'p' };
static mxArray * _mxarray31_;

static mxChar _array34_[7] = { 'u', 'n', 'k', 'n', 'o', 'w', 'n' };
static mxArray * _mxarray33_;

static mxChar _array36_[5] = { 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray35_;

static mxChar _array38_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray37_;

static mxChar _array40_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray39_;
static mxArray * _mxarray41_;

static mxChar _array43_[9] = { 'g', 'r', 'a', 'y', 's', 'c', 'a', 'l', 'e' };
static mxArray * _mxarray42_;

static mxChar _array45_[9] = { 't', 'r', 'u', 'e', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray44_;

void InitializeModule_iofun_private_imxwdinfo(void) {
    _mxarray0_ = mclInitializeString(164, _array1_);
    _mxarray2_ = mclInitializeString(163, _array3_);
    _mxarray4_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray5_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(7, _array11_);
    _mxarray12_ = mclInitializeDouble(-1.0);
    _mxarray13_ = mclInitializeString(3, _array14_);
    _mxarray15_ = mclInitializeDouble(2.0);
    _mxarray16_ = mclInitializeString(6, _array17_);
    _mxarray18_ = mclInitializeString(16, _array19_);
    _mxarray20_ = mclInitializeDouble(1.0);
    _mxarray21_ = mclInitializeDouble(7.0);
    _mxarray22_ = mclInitializeString(7, _array23_);
    _mxarray24_ = mclInitializeString(19, _array25_);
    _mxarray26_ = mclInitializeDouble(0.0);
    _mxarray27_ = mclInitializeString(8, _array28_);
    _mxarray29_ = mclInitializeString(8, _array30_);
    _mxarray31_ = mclInitializeString(7, _array32_);
    _mxarray33_ = mclInitializeString(7, _array34_);
    _mxarray35_ = mclInitializeString(5, _array36_);
    _mxarray37_ = mclInitializeString(5, _array38_);
    _mxarray39_ = mclInitializeString(7, _array40_);
    _mxarray41_ = mclInitializeDouble(8.0);
    _mxarray42_ = mclInitializeString(9, _array43_);
    _mxarray44_ = mclInitializeString(9, _array45_);
}

void TerminateModule_iofun_private_imxwdinfo(void) {
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miofun_private_imxwdinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename);

_mexLocalFunctionTable _local_function_table_iofun_private_imxwdinfo
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIofun_private_imxwdinfo" contains the normal interface for
 * the "iofun/private/imxwdinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imxwdinfo.m" (lines 1-145). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIofun_private_imxwdinfo(mxArray * * msg, mxArray * filename) {
    int nargout = 1;
    mxArray * info = mclGetUninitializedArray();
    mxArray * msg__ = mclGetUninitializedArray();
    mlfEnterNewContext(1, 1, msg, filename);
    if (msg != NULL) {
        ++nargout;
    }
    info = Miofun_private_imxwdinfo(&msg__, nargout, filename);
    mlfRestorePreviousContext(1, 1, msg, filename);
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(info);
}

/*
 * The function "mlxIofun_private_imxwdinfo" contains the feval interface for
 * the "iofun/private/imxwdinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imxwdinfo.m" (lines 1-145). The
 * feval function calls the implementation version of iofun/private/imxwdinfo
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIofun_private_imxwdinfo(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 1) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miofun_private_imxwdinfo(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Miofun_private_imxwdinfo" is the implementation version of the
 * "iofun/private/imxwdinfo" M-function from file
 * "C:\matlabR12\toolbox\matlab\iofun\private\imxwdinfo.m" (lines 1-145). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [info,msg] = imxwdinfo(filename)
 */
static mxArray * Miofun_private_imxwdinfo(mxArray * * msg,
                                          int nargout_,
                                          mxArray * filename) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_iofun_private_imxwdinfo);
    mxArray * info = mclGetUninitializedArray();
    mxArray * format = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mxArray * d = mclGetUninitializedArray();
    mxArray * m = mclGetUninitializedArray();
    mxArray * fid = mclGetUninitializedArray();
    mclCopyArray(&filename);
    /*
     * %IMXWDINFO Get information about the image in an XWD file.
     * %   [INFO,MSG] = IMXWDINFO(FILENAME) returns information about
     * %   the image contained in an XWD file.  If an error occurs, INFO
     * %   is returned as [] and an error message is returned in MSG.
     * %
     * %   See also IMREAD, IMWRITE, and IMFINFO.
     * 
     * %   Steven L. Eddins, June 1996
     * %   Copyright 1984-2000 The MathWorks, Inc. 
     * %   $Revision: 1.8 $  $Date: 2000/06/01 04:17:03 $
     * 
     * %   Reference:  Murray and vanRyper, Encyclopedia of Graphics
     * %   File Formats, 2nd ed, O'Reilly, 1996.
     * 
     * % This function should not call error()!.
     * 
     * msg = '';
     */
    mlfAssign(msg, _mxarray4_);
    /*
     * info = [];
     */
    mlfAssign(&info, _mxarray5_);
    /*
     * 
     * if (~isstr(filename))
     */
    if (mclNotBool(mclVe(mlfIsstr(mclVa(filename, "filename"))))) {
        /*
         * msg = 'FILENAME must be a string';
         */
        mlfAssign(msg, _mxarray6_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * [fid,m] = fopen(filename, 'r', 'ieee-be');
     */
    mlfAssign(
      &fid,
      mlfFopen(&m, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray10_));
    /*
     * if (fid == -1)
     */
    if (mclEqBool(mclVv(fid, "fid"), _mxarray12_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray5_);
        /*
         * msg = m;
         */
        mlfAssign(msg, mclVsv(m, "m"));
        /*
         * return;
         */
        goto return_;
    /*
     * else
     */
    } else {
        /*
         * filename = fopen(fid);
         */
        mlfAssign(
          &filename, mlfFopen(NULL, NULL, mclVv(fid, "fid"), NULL, NULL));
        /*
         * d = dir(filename);
         */
        mlfAssign(&d, mlfNDir(1, mclVa(filename, "filename")));
    /*
     * end
     */
    }
    /*
     * 
     * % Initialize the standard fields to fix the order.
     * info.Filename = filename;
     */
    mlfIndexAssign(&info, ".Filename", mclVsa(filename, "filename"));
    /*
     * info.FileModDate = d.date;
     */
    mlfIndexAssign(&info, ".FileModDate", mlfIndexRef(mclVsv(d, "d"), ".date"));
    /*
     * info.FileSize = d.bytes;
     */
    mlfIndexAssign(&info, ".FileSize", mlfIndexRef(mclVsv(d, "d"), ".bytes"));
    /*
     * info.Format = 'xwd';
     */
    mlfIndexAssign(&info, ".Format", _mxarray13_);
    /*
     * info.FormatVersion = [];
     */
    mlfIndexAssign(&info, ".FormatVersion", _mxarray5_);
    /*
     * info.Width = [];
     */
    mlfIndexAssign(&info, ".Width", _mxarray5_);
    /*
     * info.Height = [];
     */
    mlfIndexAssign(&info, ".Height", _mxarray5_);
    /*
     * info.BitDepth = [];
     */
    mlfIndexAssign(&info, ".BitDepth", _mxarray5_);
    /*
     * info.ColorType = [];
     */
    mlfIndexAssign(&info, ".ColorType", _mxarray5_);
    /*
     * info.FormatSignature = [];
     */
    mlfIndexAssign(&info, ".FormatSignature", _mxarray5_);
    /*
     * 
     * % The file may be written as big-endian or little-endian.
     * % If the second uint value we read is not 7, re-open the file as
     * % little-endian.
     * info.FormatSignature = fread(fid, 2, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".FormatSignature",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray15_, _mxarray16_, NULL));
    /*
     * if (length(info.FormatSignature) < 2)
     */
    if (mclLtBool(
          mclVe(
            mclFeval(
              mclValueVarargout(),
              mlxLength,
              mclVe(mlfIndexRef(mclVsv(info, "info"), ".FormatSignature")),
              NULL)),
          _mxarray15_)) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray5_);
        /*
         * msg = 'Truncated header';
         */
        mlfAssign(msg, _mxarray18_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * info.HeaderSize = info.FormatSignature(1);
     */
    mlfIndexAssign(
      &info,
      ".HeaderSize",
      mlfIndexRef(mclVsv(info, "info"), ".FormatSignature(?)", _mxarray20_));
    /*
     * info.FormatVersion = info.FormatSignature(2);
     */
    mlfIndexAssign(
      &info,
      ".FormatVersion",
      mlfIndexRef(mclVsv(info, "info"), ".FormatSignature(?)", _mxarray15_));
    /*
     * if (info.FormatVersion ~= 7)
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxNe,
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".FormatVersion")),
            _mxarray21_,
            NULL))) {
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * [fid,m] = fopen(filename, 'r', 'ieee-le');
         */
        mlfAssign(
          &fid,
          mlfFopen(
            &m, NULL, mclVa(filename, "filename"), _mxarray8_, _mxarray22_));
        /*
         * if (fid == -1)
         */
        if (mclEqBool(mclVv(fid, "fid"), _mxarray12_)) {
            /*
             * info = [];
             */
            mlfAssign(&info, _mxarray5_);
            /*
             * msg = m;
             */
            mlfAssign(msg, mclVsv(m, "m"));
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
        /*
         * info.FormatSignature = fread(fid, 2, 'uint32');
         */
        mlfIndexAssign(
          &info,
          ".FormatSignature",
          mlfFread(NULL, mclVv(fid, "fid"), _mxarray15_, _mxarray16_, NULL));
        /*
         * info.HeaderSize = info.FormatSignature(1);
         */
        mlfIndexAssign(
          &info,
          ".HeaderSize",
          mlfIndexRef(
            mclVsv(info, "info"), ".FormatSignature(?)", _mxarray20_));
        /*
         * info.FormatVersion = info.FormatSignature(2);
         */
        mlfIndexAssign(
          &info,
          ".FormatVersion",
          mlfIndexRef(
            mclVsv(info, "info"), ".FormatSignature(?)", _mxarray15_));
        /*
         * if (info.FormatVersion ~= 7)
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxNe,
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".FormatVersion")),
                _mxarray21_,
                NULL))) {
            /*
             * info = [];
             */
            mlfAssign(&info, _mxarray5_);
            /*
             * msg = 'Not an X11 XWD file';
             */
            mlfAssign(msg, _mxarray24_);
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * format = fread(fid, 1, 'uint32');
     */
    mlfAssign(
      &format,
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * if (isempty(format))
     */
    if (mlfTobool(mclVe(mlfIsempty(mclVv(format, "format"))))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray5_);
        /*
         * msg = 'Truncated header';
         */
        mlfAssign(msg, _mxarray18_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * switch format
     */
    {
        mxArray * v_ = mclInitialize(mclVv(format, "format"));
        if (mclSwitchCompare(v_, _mxarray26_)) {
            /*
             * case 0
             * info.PixmapFormat = 'XYBitmap';
             */
            mlfIndexAssign(&info, ".PixmapFormat", _mxarray27_);
        /*
         * case 1
         */
        } else if (mclSwitchCompare(v_, _mxarray20_)) {
            /*
             * info.PixmapFormat = 'XYPixmap';
             */
            mlfIndexAssign(&info, ".PixmapFormat", _mxarray29_);
        /*
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray15_)) {
            /*
             * info.PixmapFormat = 'ZPixmap';
             */
            mlfIndexAssign(&info, ".PixmapFormat", _mxarray31_);
        /*
         * otherwise
         */
        } else {
            /*
             * info.PixmapFormat = 'unknown';
             */
            mlfIndexAssign(&info, ".PixmapFormat", _mxarray33_);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * info.PixmapDepth = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".PixmapDepth",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.Width = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".Width",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.Height = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".Height",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.XOffset = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".XOffset",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.ByteOrder = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".ByteOrder",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.BitmapUnit = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".BitmapUnit",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.BitmapBitOrder = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".BitmapBitOrder",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.BitmapPad = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".BitmapPad",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.BitDepth = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".BitDepth",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.BytesPerLine = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".BytesPerLine",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.VisualClass = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".VisualClass",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.RedMask = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".RedMask",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.GreenMask = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".GreenMask",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.BlueMask = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".BlueMask",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.BitsPerRgb = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".BitsPerRgb",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.NumberOfColors = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".NumberOfColors",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.NumColormapEntries = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".NumColormapEntries",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.WindowWidth = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".WindowWidth",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.WindowHeight = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".WindowHeight",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.WindowX = fread(fid, 1, 'int32');
     */
    mlfIndexAssign(
      &info,
      ".WindowX",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray35_, NULL));
    /*
     * info.WindowY = fread(fid, 1, 'int32');
     */
    mlfIndexAssign(
      &info,
      ".WindowY",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray35_, NULL));
    /*
     * info.WindowBorderWidth = fread(fid, 1, 'uint32');
     */
    mlfIndexAssign(
      &info,
      ".WindowBorderWidth",
      mlfFread(NULL, mclVv(fid, "fid"), _mxarray20_, _mxarray16_, NULL));
    /*
     * info.Name = char(fread(fid, info.HeaderSize - ftell(fid), 'uint8')');
     */
    mlfIndexAssign(
      &info,
      ".Name",
      mlfChar(
        mlfCtranspose(
          mclVe(
            mlfFread(
              NULL,
              mclVv(fid, "fid"),
              mclFeval(
                mclValueVarargout(),
                mlxMinus,
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".HeaderSize")),
                mclVe(mlfFtell(mclVv(fid, "fid"))),
                NULL),
              _mxarray37_,
              NULL))),
        NULL));
    /*
     * 
     * if (isempty(info.NumColormapEntries))
     */
    if (mlfTobool(
          mclVe(
            mclFeval(
              mclValueVarargout(),
              mlxIsempty,
              mclVe(mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
              NULL)))) {
        /*
         * info = [];
         */
        mlfAssign(&info, _mxarray5_);
        /*
         * msg = 'Truncated header';
         */
        mlfAssign(msg, _mxarray18_);
        /*
         * fclose(fid);
         */
        mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if (info.NumColormapEntries > 0)
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxGt,
            mclVe(mlfIndexRef(mclVsv(info, "info"), ".NumColormapEntries")),
            _mxarray26_,
            NULL))) {
        /*
         * info.ColorType = 'indexed';
         */
        mlfIndexAssign(&info, ".ColorType", _mxarray39_);
    /*
     * 
     * else
     */
    } else {
        /*
         * if (isempty(info.BitDepth))
         */
        if (mlfTobool(
              mclVe(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsempty,
                  mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitDepth")),
                  NULL)))) {
            /*
             * info = [];
             */
            mlfAssign(&info, _mxarray5_);
            /*
             * msg = 'Truncated header';
             */
            mlfAssign(msg, _mxarray18_);
            /*
             * fclose(fid);
             */
            mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
        /*
         * if (info.BitDepth <= 8)
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxLe,
                mclVe(mlfIndexRef(mclVsv(info, "info"), ".BitDepth")),
                _mxarray41_,
                NULL))) {
            /*
             * info.ColorType = 'grayscale';
             */
            mlfIndexAssign(&info, ".ColorType", _mxarray42_);
        /*
         * else
         */
        } else {
            /*
             * info.ColorType = 'truecolor';
             */
            mlfIndexAssign(&info, ".ColorType", _mxarray44_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * fclose(fid);
     */
    mclAssignAns(&ans, mlfFclose(mclVv(fid, "fid")));
    return_:
    mclValidateOutput(info, 1, nargout_, "info", "iofun/private/imxwdinfo");
    mclValidateOutput(*msg, 2, nargout_, "msg", "iofun/private/imxwdinfo");
    mxDestroyArray(fid);
    mxDestroyArray(m);
    mxDestroyArray(d);
    mxDestroyArray(ans);
    mxDestroyArray(format);
    mxDestroyArray(filename);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return info;
}
