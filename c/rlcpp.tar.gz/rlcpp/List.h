#ifndef LIST
#define LIST

struct List {
    int length;
    double * contents;
};

#endif //LIST
