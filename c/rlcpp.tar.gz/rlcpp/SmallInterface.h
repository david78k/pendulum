# ifndef SMALLINTERFACE_H
# define SMALLINTERFACE_H

# include "Experiment.h"
# include "SmallMaze.h"

class SmallInterface : public Experiment {

    public:
        SmallInterface( const char * ) ;
        ~SmallInterface() {};

};

# endif //SMALLINTERFACE_H
