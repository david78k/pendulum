"""
RLearning is a library for simple reiforcement learning in python

It aims to be very simple to use, and suitable for people
new to reinforcement learning algorithms.


"""

version = "1.0.0"

__all__ = ['RLBasic']


