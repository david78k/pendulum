function [] = cp_vis(x,E,u,fh)
% cp_vis(x,E,u,fh)
%       Cart-pole visualization.
%
%       x     ... state of the cart-pole.
%       E     ... cart-pole model parameters.
%       u     ... force on the cart
%       fh    ... figure handle used for output


xc = x(1);
xp = x(1)+E.l*sin(x(3));
yp = E.l*cos(x(3));

figure(fh)
clf
hold on
% cart
rectangle('Position',[xc-E.cw/2 -E.ch/2 E.cw E.ch])
plot(xc+3/9*[-E.cw +E.cw], [-E.ch/2 -E.ch/2],'k.','markersize',30)

%pole
plot([xc,xp],[0
,yp],'k','linewidth',3)
plot([xp],[yp],'b.','markersize',30)

%force
plot([xc,xc+u*E.cw],[0 0],'m-','linewidth',5)

xlim([-1 1])
ylim([-1 1])

drawnow
