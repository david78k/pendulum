function [cost] = cost_func(w,DISPLAY)
% [cost] = cost_func(x,DISPLAY)
%     Simulates a cart-pole for a time interval specified in
%     model.Tmax and assigns a total error (cost) to the 
%     movement of the cart-pole. The cart-pole is controlled
%     by a neural network with network.nneurons hidden neurons.
%
%     If DISPLAY is set to an arbitrary value the movement of the
%     cart-pole is visualized. (omit DISPLAY for no output)
%
%     Uses two global variables: model, network

% For simpler access to the model and the neural network
global model network



% initialize neural network

... HOMEWORK ... (use variables w and network)

% initialize model
e = zeros(1,round(model.Tmax/model.dt)); % error at each time step

x = zeros(4,round(model.Tmax/model.dt)); % state at each time step
x(:,1) = [0 0 pi 0]'; % initial state



for i = 2:size(x,2)

  % simulate network to get the force on the cart

  ... HOMEWORK ...

  u = ...

  % simulate the dynamics of the cart
  x(:,i) = cp_dyn(model,x(:,i-1),u);  


  % calculate the current error at time step i

  ... HOMEWORK ...

  e(i) = ...


  % assign inf error if the cart leavies a certain interval
  if (x(1,i) < model.x_bounds(1))|(x(1,i) > model.x_bounds(2))
     e(i) = Inf;
     break
  end

  if nargin>1
     cp_vis(x(:,i),model,u/10,1)
  end

end


cost = ... HOMEWORK ...  % should be calculated from e