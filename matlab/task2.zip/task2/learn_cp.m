% MLB KU WS10

clear all
close all


% For simpler access for all optimization algorithms
global model network

% cart-pole parameters
model.dt = 0.02; % simulation time step
model.Tmax = 10; % simulated time interval
model.RK = 0;    % integration methode (Runge Kutta integrator)
model.mp = 0.1;  % mass of the pole
model.mc = 1;    % mass of the cart
model.muc = 0;   % friction cart
model.mup = 0;   % friction pole
model.l = 0.1;   % pole length
model.g = 9.81;  % gravity constant

model.cw = 0.03*5; % cart width
model.ch = 0.014*5;% cart height

model.x_bounds = [-1 1]*1; % allowed position for the cart
model.u_bounds = [-1 1]*10;   % maximum forces


% parameter of the neural network

network.nneurons = 10; 


... HOMEWORK ... % (set network parameters if needed) 




% apply optimization algorithm to minimize the output of the 
% function cost_func
%
% e.g. for ga use the function string 'cost_func(x)'

... HOMEWORK ...

wbest = ... 


% visualize the best movement of the cart
cost_func(wbest,1)



