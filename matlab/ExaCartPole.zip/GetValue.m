function [ V ] = GetValue( Q , knn , p )
%GETVALUE Summary of this function goes here
%   Detailed explanation goes here


 
V  = max(Q(knn,:),[],2)' * p;
 


end


