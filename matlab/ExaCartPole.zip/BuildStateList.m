function [ states ] = BuildStateList
%BuildStateList builds a state list from a state matrix

x1  = linspace(-4.5, 4.5,3);
x2  = linspace(-3,3,5);
%x3  = linspace(-deg2rad(45),deg2rad(45),11);
%x4  = linspace(-deg2rad(45),deg2rad(45),5);

x3  = linspace(-(pi/180.0)*45,(pi/180.0)*45,11);
x4  = linspace(-(pi/180.0)*45,(pi/180.0)*45,5);

states = setprod(x1,x2,x3,x4);

end
