function [ actions ] = BuildActionList
%BuildActionList

%actions for the Cart Pole Problem.
actions = linspace(-1,1,11);
%actions  = actions';
