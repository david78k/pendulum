
Continous Cart-Pole Problem with the Ex<a> Reinforcement Learning Algorithm.
 Author:      Jose Antonio Martin H. (JAMH) 
 Contact:     <jamartin@dia.fi.upm.es>

 Created:     17/03/2010
 Last modify: 7/5/2010
 Copyright:   (c) Jose Antonio Martin H. 2010

Algortihm initially described in:
Jos� Antonio Martin H. & Javier de Lope (2009),"Ex<a> : An Effective Algorithm for Continuous Actions Reinforcement Learning Problems",
In Proceedings of 35th Annual Conference of the IEEE Industrial Electronics Society (IECON 2009). Oporto, Portugal. November 2009.,
pp. 2063 - 2068. IEEE. DOI: (http://dx.doi.org/10.1109/IECON.2009.5415084).


 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
-------------------------------------------------------------------------------


enjoy it!!!
To run the demo use:


>> Demo <enter>  %"<enter> means that you must press the enter key in your keyboard!!!









