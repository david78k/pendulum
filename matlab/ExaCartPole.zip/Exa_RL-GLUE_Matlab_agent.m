%  Copyright 2010 Jose Antonio Martin H.
%  
%  jamartinh@fdi.ucm.es
%  RLGLUE version
%  
%  Licensed under the Apache License, Version 2.0 (the "License");
%  you may not use this file except in compliance with the License.
%   You may obtain a copy of the License at
%  
%       http://www.apache.org/licenses/LICENSE-2.0
%  
%   Unless required by applicable law or agreed to in writing, software
%   distributed under the License is distributed on an "AS IS" BASIS,
%   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%   See the License for the specific language governing permissions and
%   limitations under the License.


function theAgent=Exa_Matlab_agent()
    theAgent.agent_init=@agent_init;
    theAgent.agent_start=@agent_start;
    theAgent.agent_step=@agent_step;
    theAgent.agent_end=@agent_end;
    theAgent.agent_cleanup=@agent_cleanup;
    theAgent.agent_message=@agent_message;
end

function agent_init(taskSpec)
%This is a persistent struct we will use to store things
%that we want to keep around
    global agent;
    agent.statelist   = BuildStateList();  % the list of states
    agent.actionlist  = BuildActionList(); % the list of actions

    agent.nstates     = size(statelist,1);
    agent.nactions    = size(actionlist,2);
    agent.Q           = BuildQTable( nstates,nactions );  % the Qtable
    agent.trace       = BuildQTable( nstates,nactions ).*0;  % the Qtable

    agent.alpha       = 1.2;   % learning rate
    agent.gamma       = 1.0;   % discount factor
    agent.lambda      = 0.90;  % probability trace
    agent.epsilon     = 0.000; % probability of a random action selection
    agent.k           = 8;     % k neighbors  
    
    agent.theAction = org.rlcommunity.rlglue.codec.types.Action();

end    

function theAction=agent_start(theObservation)
%This is a persistent struct we will use to store things
%that we want to keep around
    global agent;    
    
    agent.trace = agent.trace.*=0;
    
    %perceive
    x = theObservation.doubleArray;
    [agent.knn , agent.p]     = GetkNNSet( x, agent.statelist, agent.k );
    agent.V                   = GetValue( agent.Q , agent.knn , agent.p );
    [agent.action , agent.a]  = GetActionList(agent.Q, agent.knn, agent.p, agent.epsilon, agent.actionlist );    
	
    %action
    theAction.doubleArray     = [agent.action];	
    
    
end

function theAction=agent_step(theReward, theObservation)
	%This is a persistent struct we will use to store things
	%that we want to keep around
	    global agent;
        
        %perceive
        xp = theObservation.doubleArray;
        [agent.knn2 , agent.p2]     = GetkNNSet( xp, agent.statelist, agent.k );
        agent.V2                    = GetValue( agent.Q , agent.knn2 , agent.p2 );
        [agent.action , agent.ap]   = GetActionList(agent.Q, agent.knn2, agent.p2, agent.epsilon, agent.actionlist );    
        
        %action
        theAction.doubleArray       = [agent.action];        
        
        %learn
        agent.trace(agent.knn,:)       = 0.0; %optional trace reset
        agent.trace(agent.knn,agent.a) = repmat(agent.p,1,size(agent.knn,1));
        
        delta        =  ( theReward + agent.gamma .* agent.V2 ) - agent.V; 
        agent.Q      =  agent.Q  + agent.alpha .* agent.delta .* agent.trace; 
        agent.trace  =  agent.gamma * agent.lambda .* agent.trace;
        
        
        %last value of variables
        agent.a      =  agent.ap;
        agent.knn    =  agent.knn2;
        agent.p      =  agent.p2;
        

	
end

function agent_end(theReward)
%This is a persistent struct we will use to store things
	%that we want to keep around
	   global agent;

       %learn
        agent.trace(agent.knn,:)       = 0.0; %optional trace reset
        agent.trace(agent.knn,agent.a) = repmat(agent.p,1,size(agent.knn,1));
        
        delta        =  theReward - agent.V; 
        agent.Q      =  agent.Q  + agent.alpha .* agent.delta .* agent.trace; 
        agent.trace  =  agent.gamma * agent.lambda .* agent.trace;
        
        
end

function returnMessage=agent_message(theMessageJavaObject)
%Java strings are objects, and we want a Matlab string
    inMessage=char(theMessageJavaObject);

	if strcmp(inMessage,'what is your name?')==1
		returnMessage='my name is agent, Matlab edition!';
    else
		returnMessage='I don\''t know how to respond to your message';
	end
end

function agent_cleanup()
    global agent;
    
end