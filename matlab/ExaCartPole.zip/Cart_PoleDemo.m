function  Cart_PoleDemo( maxepisodes )
%Continous Cart pole demo, the main function of the demo
%maxepisodes: maximum number of episodes to run the demo

% Continous Cart Pole control demo 
% Programmed by:
% Jose Antonio Martin H. <jamartinh@fdi.ucm.es>

global grafica



maxsteps    = 1000;              % maximum number of steps per episode
statelist   = BuildStateList();  % the list of states
actionlist  = BuildActionList(); % the list of actions

nstates     = size(statelist,1);
nactions    = size(actionlist,2);
Q           = BuildQTable( nstates,nactions );  % the Qtable
trace       = BuildQTable( nstates,nactions ).*0;  % the Qtable

alpha       = 1.2;   % learning rate
gamma       = 1.0;   % discount factor
lambda      = 0.90;  % probability trace
epsilon     = 0.000;  % probability of a random action selection
k           = 8;         
grafica     = false; % indicates if display the graphical interface

xpoints     = [];
ypoints     = [];

for i=1:maxepisodes    
    
    [total_reward,steps,Q,trace,td_error ] = Episode( maxsteps, Q, trace, alpha, gamma, epsilon,lambda,statelist,actionlist,k); 
    trace = trace.*0;
    disp(['Espisode: ',int2str(i),'  Steps:',int2str(steps),'  Reward:',num2str(total_reward),' epsilon: ',num2str(epsilon)', ' td_error_sum: ',num2str(td_error)])
    
    epsilon = epsilon * 0.99;
    
    xpoints(i)=i-1;
    ypoints(i)=total_reward;%steps;    
    f2 = subplot(2,1,2);    
    plot(xpoints,ypoints)      
    axis(f2,[0 i -1000 50])
    title(['Episode: ',int2str(i),' epsilon: ',num2str(epsilon)])  
    xlabel('Episode')
    ylabel('Reward')    
    drawnow
    
    if (i>2000)
        grafica=true;
    end
end






