function [ action, actionlist ] = GetActionList(Q, knn, p, epsilon, actions )
%GETACTIONLIST Summary of this function goes here
%   Detailed explanation goes here
nactions = size(Q,2);

[Values, max_actions] = max(Q(knn,:),[],2);

rnd_dist              = rand(size(max_actions)) > epsilon;
%rnd_actions           = randi(nactions,size(max_actions));
[y rnd_actions]       = max(rand(nactions,size(max_actions,1),size(max_actions,2)));

actionlist            = max_actions;
actionlist(rnd_dist)  = max_actions(rnd_dist);
actionlist(~rnd_dist) = rnd_actions(~rnd_dist);

actionvalues          = actions(actionlist);
action                = actionvalues * p;

end

    