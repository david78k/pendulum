function [ total_reward,steps,Q, trace,td_error ] = Episode( maxsteps, Q, trace, alpha, gamma, epsilon,lambda,statelist,actionlist,k)
%MountainCarEpisode do one episode of the mountain car with sarsa learning
% maxstepts: the maximum number of steps per episode
% Q: the current QTable
% alpha: the current learning rate
% gamma: the current discount factor
% epsilon: probablity of a random action
% statelist: the list of states
% actionlist: the list of actions

global grafica
% state variables x,x_dot,theta,theta_dot
x            = [0 0 0 0.01];
steps        = 0;
total_reward = 0;


[knn,p]      = GetkNNSet( x, statelist, k );
V            = GetValue( Q , knn , p );
[action, a]  = GetActionList(Q, knn, p, epsilon, actionlist );
td_error=0;

for i=1:maxsteps
        
    %do the selected action and get the next car state    
    xp  = DoAction( action , x );
        
    % observe the reward at state xp and the final state flag
    [r,f]   = GetReward(xp);
    total_reward = total_reward + r;
    
    % convert the continous state variables in [xp] to an index of the statelist    
    [knn2,p2] = GetkNNSet( xp, statelist, k );
   
    % get the values for current state
    V2        = GetValue( Q , knn2 , p2 );
    
    % select action prime
    [action, ap]       =  GetActionList(Q, knn2, p2, epsilon, actionlist );
    
    
    % Update the Qtable, that is,  learn from the experience
    [Q, trace,delta] = Update(Q , V , V2, knn , p , r , a, trace, alpha, gamma, lambda ,f );
    td_error= td_error + delta;
    
    
    
    %update the current variables   
    a   = ap;
    x   = xp;
    knn = knn2;
    p   = p2;
    V   = V2;
    
    
    %increment the step counter.
    steps=steps+1;
    
   
    % Plot of the mountain car problem
    if (grafica==true)               
       plot_Cart_Pole(x,action,steps); 
    end
    
    % if the pole fall down break the episode.
    if (f==true)
        break
    end
    
end


