function stopsim()
global sim

disp('stopping')
sim.running = 0;