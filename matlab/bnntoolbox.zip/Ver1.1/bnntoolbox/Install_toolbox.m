%% Installation program for Biological Neural Networks Toolbox
%   
%   Version:    1.0
%   ----------------------------------
%   Amir Reza Saffari Azar, August 2004
%   amir@ymer.org
%   http://www.ymer.org
%   http://ee.sut.ac.ir/faculty/saffari/main.index

%% updating path
toolbox_home    = pwd;
toolbox_path    = genpath(pwd);
addpath(toolbox_path);