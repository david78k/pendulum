function initial_state = cifar_initialize_state(simulator)

initial_state = feval(simulator);
