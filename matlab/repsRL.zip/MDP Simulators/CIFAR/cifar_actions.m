function numa = cifar_actions()

numa = 2; 
