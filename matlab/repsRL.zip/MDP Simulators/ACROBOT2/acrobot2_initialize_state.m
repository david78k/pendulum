function initial_state = acrobot2_initialize_state(simulator)
 
  initial_state = feval(simulator);

  
  return
