function y = nnsigmoid(x)
%  y = nnsigmoid(x)

% Copyright (C) 1998 Charles W. Anderson

y = 1 ./ (1 + exp(-x));
