function net = nninit(ni,nh,no,rh,ro,rm,iw)
% net = nninit(ni,nh,no,rh,ro,rm,iw)
% Example:
% net = nninit(2,5,1,5,2,0,0.1);
% d = [1 1 0.1; 1 0 0.9; 0 1 0.9; 0 0 0.1];
% net = nntrain(net,[d;d+randn(4,3)*0.1;d+randn(4,3)*0.1],4,4,4,500);
% plot([net.perftrain' net.perfvalidate'])

% Copyright (C) 1998 Charles W. Anderson

net.ni = ni;
net.nh = nh;
net.no = no;
net.hr = rh;
net.or = ro;
net.mr = rm;

net.wh = (rand(ni+1,nh) * 2 - 1) * iw;
net.whmom = zeros(ni+1,nh);
net.wo = (rand(nh+1,no) * 2 - 1) * iw;
net.womom = zeros(nh+1,no);

net.in = [];
net.out = [];
net.error = [];
net.dh = [];
net.do = [];

net.epoch = 0;
net.perftrain = [];
net.perfvalidate = [];
net.perftest = [];
