function net = nnupdatewts(net)
% net = nnupdatewts(net)

% Copyright (C) 1998 Charles W. Anderson

% deltas
net.do = net.error .* net.out .* (1-net.out);
net.dh = net.do * net.wo(1:net.nh,:)' .* net.hid .* (1-net.hid);

% New weights
net.womom = net.or * ([net.hid 1]' * net.do + net.mr * net.womom);
%net.wo = net.wo + net.ro * [net.hid 1]' * net.do;
net.wo = net.wo + net.womom;
net.whmom = net.hr * ([net.in 1]' * net.dh + net.mr * net.whmom);
%net.wh = net.wh + net.rh * [net.in 1]' * net.dh;
net.wh = net.wh + net.whmom;

