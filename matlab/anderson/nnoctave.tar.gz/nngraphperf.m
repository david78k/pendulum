function nngraphperf(net)
plot([net.perftrain' net.perfvalidate']);
hold on;
line([net.epoch net.epoch],[0 net.perftrain(1)]);
legend('Train','Validate');