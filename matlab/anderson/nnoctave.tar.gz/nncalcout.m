function net = nncalcout(net,input)
% net = nncalcout(net,input)
%  input can be multiple rows, one row per input pattern

% Copyright (C) 1998 Charles W. Anderson

net.in = input;
net.hid = nnsigmoid([input ones(size(input,1),1)]*net.wh);
net.out = nnsigmoid([net.hid ones(size(input,1),1)]*net.wo);


