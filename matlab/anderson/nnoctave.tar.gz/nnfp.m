function net = nnfp(net,inout)
% One forward pass for each i/o pattern in each row of inout.

% Copyright (C) 1998 Charles W. Anderson

net = nncalcout(net,inout(:,1:net.ni));
net.error = inout(:,net.ni+1:net.ni+net.no) - net.out;

