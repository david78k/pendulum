m1=2500;
m2=320;
k1=80000;
k2=500000;
b1 = 350;
b2 = 15020;

A=[0                 1   0                                              0
  -(b1*b2)/(m1*m2)   0   ((b1/m1)*((b1/m1)+(b1/m2)+(b2/m2)))-(k1/m1) -(b1/m1)
  b2/m2             0  -((b1/m1)+(b1/m2)+(b2/m2))                      1
  k2/m2             0  -((k1/m1)+(k1/m2)+(k2/m2))                     0]; 
B=[0                 0
  1/m1              (b1*b2)/(m1*m2)
  0                -(b2/m2)
  (1/m1)+(1/m2)    -(k2/m2)];
C=[0   0   1   0];
D=[0    0];


%nump=[(m1+m2) b2 k2];
%denp=[(m1*m2) (m1*(b1+b2))+(m2*b1) (m1*(k1+k2))+(m2*k1)+(b1*b2) (b1*k2)+(b2*k1) k1*k2];
%'G(s)1'
%printsys(nump,denp)

%num1=[-(m1*b2) -(m1*k2) 0 0];
%den1=[(m1*m2) (m1*(b1+b2))+(m2*b1) (m1*(k1+k2))+(m2*k1)+(b1*b2) (b1*k2)+(b2*k1) k1*k2];
%'G(s)2'
%printsys(0.1*num1,den1)

%step(0.1*num1,den1)

%step(A,B,C,D,1)

s = [0;0;0;0];

input = [0;1];

%we can observe s(3).

result = [];
u = 0;
for i=1:1000
  input = [u;1]; %sin(i/30.0)];
  ds = A * s + B * input;
  s = s + 0.01 * ds;
  u = u + randn(1,1)*10;
  result = [result; s' u];
end
subplot(2,1,1);
plot(result);
legend('x1','x1d','x2','x2d','u');
subplot(2,1,2);
plot(result(:,[3 5]));
legend('y','u');



