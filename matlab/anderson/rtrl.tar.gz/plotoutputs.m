function plotoutputs(outputs,no,nu,minout,maxout)
% plotoutputs(outputs,no,nu,minout,maxout)

%minout = 0;
%maxout = 0.9;

%Remove constant columns (usually just the constant input)
%constants = find(var(outputs)==0);
%outputs(:,constants)=[];
[r,c] = size(outputs);
for t=1:r
  %scale to be between 0 and 1
  onetime = (outputs(t,:) - minout) ./ (maxout - minout) ...
      * 1 + 0;
  %* 0.8 + 0.1;
  x = repmat(t,2,c);
  ymid = [1:c]-0.5;
  y = [ymid + onetime * .5; ymid - onetime * 0.5];
  line(x,y,'LineWidth',2);
  hold on
end
line([0 r]',[no+nu no+nu]','Color','black','LineWidth',2);
line([0 r]',[nu nu]','Color','black','LineWidth',2);
line([0 r]',[nu-no nu-no]','Color','black');

axis off
hold off
