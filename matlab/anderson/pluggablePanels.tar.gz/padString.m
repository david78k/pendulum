function newstr = padString(str,nspaces)
% newstr = padString(str)
%  padString('abcde') = '   abcde   '

%nspaces = round(length(str)*0.5);
sp = ['%' num2str(nspaces) 's'];

newstr= sprintf([sp '%s' sp],'',str,'');
