function value = getUserData(fieldName)
%  value = getUserData(fieldName)

userData = get(gcf,'UserData');
if isfield(userData,fieldName)
  value = getfield(userData,fieldName);
else
  error(['Field ' fieldName ' not found in UserData']);
  value = [];
end
