function [features,remainingEeg] = originalEEG(eeg,state)
%  [features,remainingEeg] = originalEEG(eeg,state)
%
%  eeg: nChannels x nSamples
% state.originalEEG.:
%   .channels  list of channel indices into rows of eeg
%
%  features:
%    nFeatures x nWindows

mystate = state.originalEEG;

data = eeg(mystate.channels,:);

features = data;

remainingEeg = [];
