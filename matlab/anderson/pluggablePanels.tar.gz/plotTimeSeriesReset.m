function state = plotTimeSeriesReset(state)
%  state = plotTimeSeriesReset(state)
%   state.axes   axes
%        .labels cell array (1 x nComponents) of strings for each component
%        .ranges matrix (nComponents x 2)  min, max each row
%        .lastx  x axis value for last plotted point (in seconds)
%        .lasty  nComponents x 1  last y values
%        .secondsPerSample  
%        .totalSeconds  width of plot in seconds
%   reset  1 to reset the graph (optional, default is 1)
%
%  See  help plotTimeSeries
%   

state.reset = 1;
