function value = setUserData(fieldName,value)
%  value = setUserData(fieldName,value)

userData = get(gcf,'UserData');
userData = setfield(userData,fieldName,value);
set(gcf,'UserData',userData);
