function newstr = depadString(str)
% newstr = depadString(str)
%  depadString('  abcde  ') = 'abcde'

nonspaces = find(str ~= ' ');
keep = nonspaces(1) : nonspaces(end);
newstr = str(keep);

