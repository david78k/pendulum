set(0,'Units','character');
screen_s = get(0,'ScreenSize');
figwidth = round(screen_s(3)*0.9);
figheight = round(screen_s(4)*0.9);
figx = round(0.05*screen_s(3));
figy = round(0.05*screen_s(4));
figure('Units','character','Position',[figx figy figwidth figheight]);

uicontrol('Style','text',...
    'String','Example of Pluggable Panels in Matlab (by C. Anderson, Colorado State Univ.)',...
     'FontSize',16,'Units','character','FontWeight','bold',...
     'Position',[figwidth*0.1 figheight-3.5 figwidth*0.8 3],...
     'HorizontalAlignment','center',...
     'BackgroundColor',[0.8 0.8 0.8],...
     'ForegroundColor',[0.0 0.0 1.0]);

panelChannels('Create','on');
panelMonitor('Create','off');
panelArtifacts('Create','off');
panelFeatures('Create','off');
panelClassifier('Create','off');
panelTrain('Create','off');
