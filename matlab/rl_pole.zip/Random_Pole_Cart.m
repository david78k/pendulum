function [r]=Random_Pole_Cart()

r=( rand / (power(2,31) - 1));