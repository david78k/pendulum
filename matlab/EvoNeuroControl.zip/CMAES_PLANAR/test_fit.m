function [ f ] = test_fit( x )

f = sum(sin(x));