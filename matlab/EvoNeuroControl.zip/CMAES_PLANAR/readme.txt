Neuro-Evolution experiment for learning inverse kinematocs of multi-link robots

Programmed in Matlab by:
 Jose Antonio Martin H. <jamartinh@fdi.ucm.es>
Copyrigth Jose Antonio Martin H. (2008)





To run the demo use:



>> Demo <enter>



