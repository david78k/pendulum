function [ actions ] = BuildActionList
%BuildActionList

%actions for the Cart Pole Problem.
actions = -1.0:0.1:1.0;
actions = actions;
actions  = actions';
