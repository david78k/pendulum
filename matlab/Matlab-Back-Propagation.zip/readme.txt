A Matlab implementation of a MultiLayer perceptron with
backpropagation training with momentum.


by: Jos� Antonio Mart�n H. <jamartinh [*AT*] fdi ucm es>


Placed in the public domain. August 23, 2008.



This implementation is specially well suited for evolutionary approaches

since the entire network is represented as a vector from which then the 
weights matcies
are extracted.






There is a simple demo program called Test.m

so

type:

>> Tess <enter> "to see an example running"

or 

type:
>> edit Test.m <enter> "to see the code of the example program"


This implementation is fast, easy to follow, and nice !!!


Enjoy it !!!.


JAMH.
