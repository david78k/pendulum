% (see comments in each script's header)

% format RGC spike list
concatSL
clear all

% LGN stage
LGN
clear all

% V1 stage (STDP-based RF learning)
delete('../mat/weight*.txt')
V1

% plot RF
plots
