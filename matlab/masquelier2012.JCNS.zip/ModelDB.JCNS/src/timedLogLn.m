function timedLogLn(str)
disp(' ');
timedLog(str);
