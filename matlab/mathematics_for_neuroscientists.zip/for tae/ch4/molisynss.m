%
% Gabbiani & Cox, Mathematics for Neuroscientists
%
% molisynss 
% 
% compute the steady state potential for the Moli system as
% as a function of the steady excitatory synaptic conductance
%
% usage:  molisynss(gsyn)
%
% e.g.:   molisynss([0:.001:.073])
%

function molisynss(gsyn)

g = struct('K',7,'Na',30,'L',1,'A',16); 
g0 = g;  g0.A = 0;
E = struct('K',-90,'Na',45,'L', -70);  

N = length(gsyn);
Vss = zeros(1,N);
Vss0 = Vss;

Vss(1) = fsolve(@(v) irest(v,g,E,gsyn(1)),-75);
Vss0(1) = fsolve(@(v) irest(v,g0,E,gsyn(1)),-75);

for n=2:N,

    Vss(n) = fsolve(@(v) irest(v,g,E,gsyn(n)),Vss(n-1));
    Vss0(n) = fsolve(@(v) irest(v,g0,E,gsyn(n)),Vss0(n-1));

end

plot(gsyn,Vss,'k')
hold on
plot(gsyn,Vss0,'r')
hold off
set(gca,'tickdir','out')
box off
xlabel('g_{syn}  (mS)','fontsize',14)
ylabel('V_{ss}  (mV)','fontsize',14)

return

function val = irest(v,g,E,gsyn)
val = g.Na*minf(v).*hinf(v).*(v-E.Na) + g.K*ninf(v).*(v-E.K) + ...
      g.A*ainf(v).*binf(v).*(v-E.K) + g.L*(v-E.L) + gsyn*v;

% Na functionals

function val = minf(v)
val = 1./(1+exp(-(v+35)/4));

function val = hinf(v)
val = 1./(1+exp((v+35)/4));

function val = tauh(v)
val = 2*232*28./(4*pi*(v+74).^2+28^2) - 0.15;

% K functionals

function val = ninf(v)
val = 1./(1+exp(-(v+35)/4));

function val = taun(v)
val = 0.5;

% A type K functionals

function val = ainf(v)
val = 1./(1+exp(-(v+27)/8.8));

function val = binf(v)
val = 1./(1+exp((v+68)/6.6));

function val = taub(v)
val = 15;

