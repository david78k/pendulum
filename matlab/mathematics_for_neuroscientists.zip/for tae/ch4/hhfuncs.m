%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  draw the 6 HH functionals and I_ion
%
%  hhfuncs
%

v = -29:.01:120;
v = v-71;

figure(1)
an = (10-v-71)./100./(exp(1-(v+71)/10)-1);
bn = exp(-(v+71)/80)/8;
taun = 1./(an+bn);
ninf = an.*taun;

[ax,h1,h2]=plotyy(v,ninf,v,taun);
%set(h1,'linewidth',2)
set(h2,'linestyle','--')
set(ax(1),'xtick',[-100 -75 -50 -25 0 25 50])
set(ax(1),'ytick',[0 0.2 0.4 0.6 0.8 1.0])
set(ax(1),'ycolor','k')
set(ax(2),'ycolor','k')
set(ax(2),'ytick',[0 1 2 3 4 5 6])
legend('\tau_n','n_\infty','location','best')
ylim(ax(2),[0 6])
xlabel('v  (mV)','fontsize',16)
ylabel(ax(1),'n_\infty','fontsize',16)
ylabel(ax(2),'\tau_n  (ms)','fontsize',16)
%text(-20,.65,'\tau_n','fontsize',16)
%text(60,.82,'n_\infty','fontsize',16)

figure(2)
am = .1*(25-(v+71))./(exp(2.5-(v+71)/10)-1);
bm = 4*exp(-(v+71)/18);
taum = 1./(am+bm);
minf = am.*taum;

[ax,h1,h2]=plotyy(v,minf,v,taum);
%set(h1,'linewidth',2)
set(h2,'linestyle','--')
set(ax(1),'xtick',[-100 -75 -50 -25 0 25 50])
set(ax(1),'ytick',[0 0.2 0.4 0.6 0.8 1.0])
set(ax(1),'ycolor','k')
set(ax(2),'ycolor','k')
set(ax(2),'ytick',[0 .1 .2 .3 .4 .5 .6])
legend('\tau_m','m_\infty','location','best')
ylim(ax(2),[0 0.6])
xlabel('v  (mV)','fontsize',16)
ylabel(ax(1),'m_\infty','fontsize',16)
ylabel(ax(2),'\tau_m  (ms)','fontsize',16)

figure(3)
ah  = 0.07*exp(-(v+71)/20);
bh = 1./(exp(3-(v+71)/10)+1);
tauh = 1./(ah+bh);
hinf = ah.*tauh;

[ax,h1,h2]=plotyy(v,hinf,v,tauh);
%set(h1,'linewidth',2)
set(h2,'linestyle','--')
set(ax(1),'xtick',[-100 -75 -50 -25 0 25 50])
set(ax(1),'ytick',[0 0.2 0.4 0.6 0.8 1.0])
set(ax(1),'ycolor','k')
set(ax(2),'ycolor','k')
set(ax(2),'ytick',[0 2 4 6 8 10])
legend('\tau_h','h_\infty','location','best')
ylim(ax(2),[0 10])
xlabel('v  (mV)','fontsize',16)
ylabel(ax(1),'h_\infty','fontsize',16)
ylabel(ax(2),'\tau_h  (ms)','fontsize',16)

figure(4)
Iion = 36*ninf.^4.*(v+77) + 120*minf.^3.*hinf.*(v-56) + 0.3*(v+68);
plot(v,Iion,'linewidth',2)
ylim([-10 10])
grid
xlabel('v  (mV)','fontsize',16)
ylabel('I_{ion}  (\muA/cm^2)','fontsize',16)
