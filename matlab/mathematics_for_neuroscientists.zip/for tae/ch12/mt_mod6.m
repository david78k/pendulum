%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires mt_mod7.m

function varargout = mt_mod6(varargin)
% MT_MOD6 M-file for mt_mod6.fig
%      MT_MOD6, by itself, creates a new MT_MOD6 or raises the existing
%      singleton*.
%
%      H = MT_MOD6 returns the handle to a new MT_MOD6 or the handle to
%      the existing singleton*.
%
%      MT_MOD6('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MT_MOD6.M with the given input arguments.
%
%      MT_MOD6('Property','Value',...) creates a new MT_MOD6 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mt_mod6_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mt_mod6_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mt_mod6

% Last Modified by GUIDE v2.5 23-Jun-2009 16:52:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mt_mod6_OpeningFcn, ...
                   'gui_OutputFcn',  @mt_mod6_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mt_mod6 is made visible.
function mt_mod6_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mt_mod6 (see VARARGIN)

% Choose default command line output for mt_mod6
handles.output = hObject;

plot_intermediate = 1;

%stimulation frequencies
stim_freq = [1 2:2:40];
nstim_freq = length(stim_freq);

freq_q = zeros(1,nstim_freq);
freq_v = zeros(1,nstim_freq);
freq_m = zeros(1,nstim_freq);

for j = 1:nstim_freq
%for j = 6:6
    [tv, Pv, Vv, Qv, ind_v] = mt_mod7(stim_freq(j),5000);

    ind_max = length(tv);

    ind_ss = find(ind_v > 2000);
    nind_ss = length(ind_ss);

    Q_vals = zeros(1,nind_ss);
    V_vals = zeros(1,nind_ss);

    for i = 1:nind_ss-1
        Q_vals(i) = max(Qv(ind_v(ind_ss(i)):ind_v(ind_ss(i+1))));
        V_vals(i) = max(Vv(ind_v(ind_ss(i)):ind_v(ind_ss(i+1))));
    end;

    Q_vals(nind_ss) = max(Qv(ind_v(ind_ss(nind_ss)):ind_max));
    V_vals(nind_ss) = max(Vv(ind_v(ind_ss(nind_ss)):ind_max));

    freq_q(j) = mean(Q_vals);
    freq_v(j) = mean(V_vals);

    freq_m(j) = mean(Vv(ind_ss(1):ind_max));

    if ( (j == 6) & (plot_intermediate == 1) )
        line('Parent',handles.axes1,'XDAta',tv,'YData',Pv);
        set(handles.axes1,'XLim',[0 1000]);
        
        for i = 1:length(ind_v)
            line('Parent',handles.axes2,'XData',[tv(ind_v(i)) tv(ind_v(i))],'YData',[0 1]);
        end;
        set(handles.axes2,'XLim',[0 1000]);
        
        line('Parent',handles.axes3,'XDAta',tv,'YData',Vv);
        set(handles.axes3,'XLim',[0 1000]);
        ylabel(handles.axes3,'Vm (mV)');
        
        line('Parent',handles.axes4,'XDAta',tv,'YData',Qv);
        set(handles.axes4,'XLim',[0 1000]);
        xlabel(handles.axes4,'time (ms)');
        ylabel(handles.axes4,'charge (pC)')
    end;
end;

line('Parent',handles.axes6,'XData',stim_freq,'YData',freq_q);
ylabel(handles.axes6,'charge (pC)');
line('Parent',handles.axes7,'XData',stim_freq,'YData',freq_v);
ylabel(handles.axes7,'peak Vm (mV)');
line('Parent',handles.axes8,'XData',stim_freq,'YData',freq_m);
xlabel(handles.axes8,'stimulation frequency (Hz)');
ylabel(handles.axes8,'average Vm (mV)');


%theoretical curves
qmax = 1.5; %pC
p = 0.55;
tau_rec = 800; %ms
tau_rec_sec = tau_rec *1e-3; %in seconds

v_e = exp(-1./(stim_freq*tau_rec_sec));

q_ss = (qmax*p)*(1-v_e)./(1-(1-p)*v_e);

line('Parent',handles.axes6,'XData',stim_freq,'YData',q_ss,...
    'LineStyle','none','Marker','o','MarkerFaceColor','none',...
    'MarkerEdgeColor','r','MarkerSize',4);

Rin = 250; %MOhm
tm = 50; %ms
tm_sec = tm*1e-3; %in seconds

v_e2 = 1./(1-exp(-1./(stim_freq*tm_sec)));

v_ss = (q_ss*Rin/tm).*v_e2;

line('Parent',handles.axes7,'XData',stim_freq,'YData',v_ss,...
    'LineStyle','none','Marker','o','MarkerFaceColor','none',...
    'MarkerEdgeColor','r','MarkerSize',4);

v_av = q_ss*Rin .* stim_freq*1e-3;
line('Parent',handles.axes8,'XData',stim_freq,'YData',v_av,...
    'LineStyle','none','Marker','o','MarkerFaceColor','none',...
    'MarkerEdgeColor','r','MarkerSize',4);

lim_val = qmax*Rin/tau_rec;

line('Parent',handles.axes7,'XData',[0 40],'YData',[lim_val lim_val],...
    'LineStyle','--');

line('Parent',handles.axes8,'XData',[0 40],'YData',[lim_val lim_val],...
    'LineStyle','--');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes mt_mod6 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = mt_mod6_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','mt_mod6.eps');

