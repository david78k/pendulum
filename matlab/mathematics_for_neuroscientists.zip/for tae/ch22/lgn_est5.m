%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = lgn_est5(varargin)
% LGN_EST5 M-file for lgn_est5.fig
%      LGN_EST5, by itself, creates a new LGN_EST5 or raises the existing
%      singleton*.
%
%      H = LGN_EST5 returns the handle to a new LGN_EST5 or the handle to
%      the existing singleton*.
%
%      LGN_EST5('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LGN_EST5.M with the given input arguments.
%
%      LGN_EST5('Property','Value',...) creates a new LGN_EST5 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lgn_est5_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lgn_est5_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lgn_est5

% Last Modified by GUIDE v2.5 09-Jul-2009 21:51:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lgn_est5_OpeningFcn, ...
                   'gui_OutputFcn',  @lgn_est5_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lgn_est5 is made visible.
function lgn_est5_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lgn_est5 (see VARARGIN)

% Choose default command line output for lgn_est5
handles.output = hObject;

%linear estimation of LGN transfer function from firing rate
fc = 5.5; %Hz
fc1 = 2*pi*fc*1e-3; %converts to kHz and circular frequency

%sampling step in msec
dt = 10;
fs = 1/(dt*1e-3); %sampling frequency
fn = fs/2; %nyquist frequency
nlgn = 32;
t_lgn = (0:nlgn-1)*dt; %in msec
v_lgn1 = exp(-fc1*t_lgn);
v_lgn = t_lgn.*v_lgn1 - (fc1/2) * (t_lgn.^2) .* v_lgn1;

max_fr = 50;
v_lgn = max_fr*(v_lgn./max(v_lgn));


ni = 128;
nfft = 64;
nw = ni*nfft;
sigma_w = 0.25;
w_n = sigma_w*randn(1,nw);


%the matlab definition of the convolution requires the lgn 
%filter to be first and the stimulus to be second. To get
%no phase delay we need to take the full wave form and truncate
%it, as seen by convolving v_lgn with a [1 0 0 ... 0] sequence
f_v = conv(v_lgn,w_n);
f_v = f_v(1:length(w_n));


%[tlgn,flgn] = tfestimate(w_n,f_v,nfft,nfft/2,nfft,fs,'twosided');
%glgn = real(ifft(tlgn));

%generates an ni by nfft matrix, with each line being
%l_1:  e_1 ... e_nfft
%l_ni: e_((ni-1)*nfft + 1) ... e(ni*nfft)
wn2 = reshape(w_n',nfft,ni)';

%compute the covariance of the WN
cwn2 = cov(wn2);

%compute the covariance of the firing rate
fv2 = zeros(ni,nfft);
for i = 1:ni
    m_inter = conv(v_lgn,wn2(i,:));
    fv2(i,:) = m_inter(1:nfft);
end;

c_fv2_wn2 = fv2(1,:)'*wn2(1,:);
for i = 2:ni
    c_fv2_wn2 = c_fv2_wn2 + fv2(i,:)'*wn2(i,:);
end;

c_fv2_wn2 = c_fv2_wn2/(ni-1);

%compute the reconstruction matrix
h_mat = c_fv2_wn2*inv(cwn2);


%compute the mean across diagonals and plot individual 
%diagonal elements
glgn2 = zeros(1,nlgn);
for i = 1:nlgn
    d_v = diag(h_mat,1-i);
    glgn2(i) = mean(d_v);
    
    line('Parent',handles.axes2,'XData',t_lgn(i)*ones(size(d_v)),'YData',d_v,...
        'LineStyle','none','Marker','.','MarkerSize',4);    
end;

line('Parent',handles.axes2,'XData',t_lgn,'YData',v_lgn);
line('Parent',handles.axes2,'XData',t_lgn,'YData',glgn2,'Color','r');
set(handles.axes2,'XLim',[0 320],'YLim',[-30 60]);
xlabel(handles.axes2,'time (ms)');
ylabel(handles.axes2,'firing rate change (spk/s)');

%test to make sure we got everything right
pred = h_mat*wn2(1,:)';

%plot the raw data and reconstruction
line('Parent',handles.axes3,'XData',(0:nfft-1)*dt,'YData',wn2(1,:));
line('Parent',handles.axes4,'XData',(0:nfft-1)*dt,'YData',fv2(1,:));
line('Parent',handles.axes4,'XData',(0:nfft-1)*dt,'YData',pred,'Color','r');
set(handles.axes3,'XLim',[0 640]);
set(handles.axes4,'XLim',[0 640],'YLim',[-60 60]);
xlabel(handles.axes4,'time (ms)');
ylabel(handles.axes4,'firing rate change (spk/s)');

axes(handles.axes1);
colormap('gray');
imagesc(h_mat);
colorbar;
%surf(handles.axes1,h_mat');
%colormap(handles.axes1,'gray');
%axes(handles.axes1);
%view(90,90);
%colorbar;
set(handles.axes1,'XLim',[1 64],'YLim',[1 64],'TickDir','out');
xlabel(handles.axes1,'column index');
ylabel(handles.axes1,'row index');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes lgn_est5 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = lgn_est5_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','lgn_est5.eps');
