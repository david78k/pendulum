%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = lgn_est3(varargin)
% LGN_EST3 M-file for lgn_est3.fig
%      LGN_EST3, by itself, creates a new LGN_EST3 or raises the existing
%      singleton*.
%
%      H = LGN_EST3 returns the handle to a new LGN_EST3 or the handle to
%      the existing singleton*.
%
%      LGN_EST3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LGN_EST3.M with the given input arguments.
%
%      LGN_EST3('Property','Value',...) creates a new LGN_EST3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lgn_est3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lgn_est3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lgn_est3

% Last Modified by GUIDE v2.5 08-Jul-2009 16:05:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lgn_est3_OpeningFcn, ...
                   'gui_OutputFcn',  @lgn_est3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lgn_est3 is made visible.
function lgn_est3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lgn_est3 (see VARARGIN)

% Choose default command line output for lgn_est3
handles.output = hObject;

fc = 5.5; %Hz
fc1 = 2*pi*fc*1e-3; %converts to kHz and circular frequency

%sampling step in msec
dt = 1;
fs = 1/(dt*1e-3); %sampling frequency
fn = fs/2; %nyquist frequency
nlgn = 512;
t_lgn = (0:nlgn-1)*dt; %in msec
v_lgn1 = exp(-fc1*t_lgn);
v_lgn = t_lgn.*v_lgn1 - (fc1/2) * (t_lgn.^2) .* v_lgn1;

max_fr = 50;
v_lgn = max_fr*(v_lgn./max(v_lgn));

nfft = 1024;
nw = 32*nfft;
sigma_w = 0.25;
w_n = sigma_w*randn(1,nw);

%the matlab definition of the convolution requires the lgn 
%filter to be first and the stimulus to be second. To get
%no phase delay we need to take the full wave form and truncate
%it, as seen by convolving v_lgn with a [1 0 0 ... 0] sequence
f_v = conv(v_lgn,w_n);
f_v = f_v(1:length(w_n));

[gf_lgn,f_lgn] = tfestimate(w_n,f_v,nfft,nfft/2,nfft,fs,'twosided');

gt_lgn = ifft(gf_lgn);

line('Parent',handles.axes3,'XData',t_lgn,'YData',gt_lgn(1:nlgn));
line('Parent',handles.axes3,'XData',t_lgn,'YData',v_lgn,...
    'LineStyle','--','Color','r');
set(handles.axes3,'XLim',[0 t_lgn(256)],'YLim',[-20 60]);


%static non-linearity
s2 = 10;
x = 0:1:200;
y = 100*x./(s2 + x);

f_vp = max(0,f_v);
f_vn = 100*f_vp./(s2 + f_vp);

nplot = 1000;
line('Parent',handles.axes1,'XData',(1:nplot)*dt,'YData',w_n(1:nplot));
line('Parent',handles.axes2,'XData',(1:nplot)*dt,'YData',f_v(1:nplot));
line('Parent',handles.axes2,'XData',(1:nplot)*dt,'YData',f_vn(1:nplot),...
    'Color','r');
set(handles.axes2,'YLim',[-180 180]);

[gf2_lgn,f_lgn] = tfestimate(w_n,f_vn,nfft,nfft/2,nfft,fs,'twosided');
 
gt2_lgn = ifft(gf2_lgn);

%proportionality factor
alpha = mean(f_v.*f_vn)/var(f_v);
gt2_lgn = gt2_lgn/alpha;

line('Parent',handles.axes4,'XData',t_lgn,'YData',gt2_lgn(1:nlgn));
line('Parent',handles.axes4,'XData',t_lgn,'YData',v_lgn,...
    'LineStyle','--','Color','r');
set(handles.axes4,'XLim',[0 t_lgn(256)],'YLim',[-20 60]);

%recovery of the static non-linearity
f_v2 = conv(gt2_lgn,w_n);
f_v2 = f_v2(1:length(w_n));

my = mean(f_v2);
sy = std(f_v2);
yv = my-5*sy:sy/100:my+5*sy;
fy = normcdf(yv,my,sy);

[n, xout] = hist(f_vn,100);
nn = n/sum(n);
cpdfz = cumsum(nn);

snl = zeros(size(yv));

for i = 1:length(snl)
    if ( fy(i) < cpdfz(1) )
       snl(i) = xout(1);
    elseif ( fy(i) > cpdfz(end) )
        snl(i) = xout(end);
    else
        %inbetween value
        snl(i) = interp1(cpdfz,xout,fy(i));
    end;
end;
 
line('Parent',handles.axes5,'XData',yv,'YData',snl);
line('Parent',handles.axes5,'XData',x,'YData',y, ...
    'Color','r','LineStyle','--');
set(handles.axes5,'XLim',[0 200]);

xlabel(handles.axes1,'time (ms)');
xlabel(handles.axes2,'time (ms)');
ylabel(handles.axes2,'firing rate (spk/s)');
xlabel(handles.axes3,'time (ms)');
ylabel(handles.axes3,'firing rate change (spk/s)');
xlabel(handles.axes4,'time (ms)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes lgn_est3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = lgn_est3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','lgn_est3.eps');
