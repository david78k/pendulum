%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = ou_f1(varargin)
% OU_F1 M-file for ou_f1.fig
%      OU_F1, by itself, creates a new OU_F1 or raises the existing
%      singleton*.
%
%      H = OU_F1 returns the handle to a new OU_F1 or the handle to
%      the existing singleton*.
%
%      OU_F1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OU_F1.M with the given input arguments.
%
%      OU_F1('Property','Value',...) creates a new OU_F1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ou_f1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ou_f1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ou_f1

% Last Modified by GUIDE v2.5 20-Jan-2009 16:49:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ou_f1_OpeningFcn, ...
                   'gui_OutputFcn',  @ou_f1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    
    
    
    
    
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ou_f1 is made visible.
function ou_f1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ou_f1 (see VARARGIN)

% Choose default command line output for ou_f1
handles.output = hObject;

%
%simulate three Ornstein-Uhlenbeck processes
%

%relaxation time constant
tau = sqrt(2); %ms

%diffusion parameter
c = sqrt(2); %mu S

sig = sqrt(tau*c/2); % equal to 1;

%time step and time vector
dt = 0.05; %ms
t_v = 0:dt:100;
n_t_v = length(t_v);

%SD relaxation
std_v = (1-exp(-2*t_v/tau));

%numerical simulation factors
ef_1 = exp(-dt/tau);
ef_2 = sqrt(1-exp(-2*dt/tau));

%
%first simulation
%

%initial value
x0 = 0;

%random white noise increment
w_v1 = normrnd(0,1,1,n_t_v);
u_v1 = sig*ef_2*w_v1;

%save space for random vector
x_v1 = zeros(1,n_t_v);

%initial condition
x_v1(1) = x0;

for i =2:n_t_v
    %stochastic update
    x_v1(i) = x_v1(i-1)*ef_1 + u_v1(i);
end;

line('Parent',handles.axes1,'XData',t_v,'YData',x_v1);
line('Parent',handles.axes1,'XData',t_v,'YData',std_v,'LineStyle',':');
line('Parent',handles.axes1,'XData',t_v,'YData',-std_v,'LineStyle',':');
title(' \tau = c = \surd 2','interpreter','default','Parent',handles.axes1);
set(handles.axes1,'YLim',[-4 4]);

%
%second simulation
%
%relaxation time constant
tau = sqrt(2)/3; %ms

%diffusion parameter
c = 3*sqrt(2); %mu S

%the ratio c/tau = 9
sig = sqrt(tau*c/2); % equal to 1;

%SD relaxation
std_v = (1-exp(-2*t_v/tau));

%numerical simulation factors
ef_1 = exp(-dt/tau);
ef_2 = sqrt(1-exp(-2*dt/tau));

%initial value
x0 = 0;

%random white noise increment
w_v1 = normrnd(0,1,1,n_t_v);
u_v1 = sig*ef_2*w_v1;

%save space for random vector
x_v1 = zeros(1,n_t_v);

%initial condition
x_v1(1) = x0;

for i =2:n_t_v
    %stochastic update
    x_v1(i) = x_v1(i-1)*ef_1 + u_v1(i);
end;

line('Parent',handles.axes2,'XData',t_v,'YData',x_v1);
line('Parent',handles.axes2,'XData',t_v,'YData',std_v,'LineStyle',':');
line('Parent',handles.axes2,'XData',t_v,'YData',-std_v,'LineStyle',':');
title(' \tau = \surd 2/3, c = 3 \surd 2','interpreter','default','Parent',handles.axes2);
set(handles.axes2,'YLim',[-4 4]);

%
%third simulation
%
%relaxation time constant
tau = 3*sqrt(2); %ms

%diffusion parameter
c = sqrt(2)/3; %mu S

%the ratio c/tau = 1/9
sig = sqrt(tau*c/2); % equal to 1;

%SD relaxation
std_v = (1-exp(-2*t_v/tau));

%numerical simulation factors
ef_1 = exp(-dt/tau);
ef_2 = sqrt(1-exp(-2*dt/tau));

%initial value
x0 = 0;

%random white noise increment
w_v1 = normrnd(0,1,1,n_t_v);
u_v1 = sig*ef_2*w_v1;

%save space for random vector
x_v1 = zeros(1,n_t_v);

%initial condition
x_v1(1) = x0;

for i =2:n_t_v
    %stochastic update
    x_v1(i) = x_v1(i-1)*ef_1 + u_v1(i);
end;

line('Parent',handles.axes3,'XData',t_v,'YData',x_v1);
line('Parent',handles.axes3,'XData',t_v,'YData',std_v,'LineStyle',':');
line('Parent',handles.axes3,'XData',t_v,'YData',-std_v,'LineStyle',':');
title(' \tau = 3 \surd 2, c = \surd 2/3','interpreter','default','Parent',handles.axes3);
set(handles.axes3,'YLim',[-4 4]);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ou_f1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ou_f1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','ou_f1.eps');

