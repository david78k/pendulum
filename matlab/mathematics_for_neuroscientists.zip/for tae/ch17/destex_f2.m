%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires destexhy2.m dest_f2.m dest_f2b.m dest_f2c.m

function varargout = destex_f2(varargin)
% DESTEX_F2 M-file for destex_f2.fig
%      DESTEX_F2, by itself, creates a new DESTEX_F2 or raises the existing
%      singleton*.
%
%      H = DESTEX_F2 returns the handle to a new DESTEX_F2 or the handle to
%      the existing singleton*.
%
%      DESTEX_F2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DESTEX_F2.M with the given input arguments.
%
%      DESTEX_F2('Property','Value',...) creates a new DESTEX_F2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before destex_f2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to destex_f2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help destex_f2

% Last Modified by GUIDE v2.5 27-Jan-2009 12:58:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @destex_f2_OpeningFcn, ...
                   'gui_OutputFcn',  @destex_f2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before destex_f2 is made visible.
function destex_f2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to destex_f2 (see VARARGIN)

% Choose default command line output for destex_f2
handles.output = hObject;

 dt = 0.05;
 v = destexhy2(dt,10,1010,1020,5);
 N = length(v);
 t = (1:N)*dt;
 
 line('Parent',handles.axes1,'XData',t,'YData',v)
 set(handles.axes1,'XLim',[200 800],'YLim',[-80 50]);
 xlabel(handles.axes1,'time (ms)');
 ylabel(handles.axes1,'Vm (mV)');
 
 disp('computing 1st panel...');
 [n_mean s_mean m_isis c_isis] = dest_f2;
 line('Parent',handles.axes2,'XData',m_isis,'YData',c_isis,'Marker','o',...
    'LineStyle','none','MarkerFaceColor','k','MarkerSize',4);
 set(handles.axes2,'XLim',[0 1500],'YLim', [0 1.1]);
 xlabel(handles.axes2,'mean ISI (ms)');
 ylabel(handles.axes2,'CV');
 

 disp('computing 2nd panel...');
 [currents n_mean n_mean2 n_mean3] = dest_f2b;
 line('Parent',handles.axes3,'XData',currents,'YData',n_mean,...
     'Marker','o','MarkerFaceColor','k','MarkerSize',4);
 line('Parent',handles.axes3,'XData',currents,'YData',n_mean2,...
     'Marker','o','MarkerFaceColor','r','MarkerSize',4);
 line('Parent',handles.axes3,'XData',currents,'YData',n_mean3,...
     'Marker','o','MarkerFaceColor','w','MarkerSize',4);
 set(handles.axes3,'YLim',[0 300]);
 xlabel(handles.axes3,'current (muA/cm2)');
 ylabel(handles.axes3,'firing frequency (spk/s)');
 
 disp('computing 3rd panel...');
 [currents n_mean n_mean2 n_mean3] = dest_f2c;
 line('Parent',handles.axes4,'XData',currents,'YData',n_mean,...
     'Marker','o','MarkerFaceColor','k','MarkerSize',4);
 line('Parent',handles.axes4,'XData',currents,'YData',n_mean2,...
     'Marker','o','MarkerFaceColor','r','MarkerSize',4);
 line('Parent',handles.axes4,'XData',currents,'YData',n_mean3,...
     'Marker','o','MarkerFaceColor','w','MarkerSize',4);
 set(handles.axes4,'YLim',[0 300]);
 xlabel(handles.axes4,'current (muA/cm2)');
 
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes destex_f2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = destex_f2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','destex_f2.eps');
