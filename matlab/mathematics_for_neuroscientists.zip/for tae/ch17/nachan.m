%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = nachan(varargin)
% NACHAN M-file for nachan.fig
%      NACHAN, by itself, creates a new NACHAN or raises the existing
%      singleton*.
%
%      H = NACHAN returns the handle to a new NACHAN or the handle to
%      the existing singleton*.
%
%      NACHAN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NACHAN.M with the given input arguments.
%
%      NACHAN('Property','Value',...) creates a new NACHAN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before nachan_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to nachan_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help nachan

% Last Modified by GUIDE v2.5 16-Oct-2009 15:50:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @nachan_OpeningFcn, ...
                   'gui_OutputFcn',  @nachan_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before nachan is made visible.
function nachan_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to nachan (see VARARGIN)

% Choose default command line output for nachan
handles.output = hObject;

%target membrane potential
v_v = -37.94;

am_v = .1*(25-(v_v+71))./(exp(2.5-(v_v+71)/10)-1);
bm_v = 4*exp(-(v_v+71)/18);
taum_v = 1./(am_v+bm_v);
minf_v = am_v.*taum_v;

ah_v  = 0.07*exp(-(v_v+71)/20);
bh_v = 1./(exp(3-(v_v+71)/10)+1);
tauh_v = 1./(ah_v+bh_v);
hinf_v = ah_v.*tauh_v;

%rates, converted in 1/s = Hz from 1/ms = kHz
am = am_v*1e3;
bm = bm_v*1e3;
ah = ah_v*1e3;
bh = bh_v*1e3;

%these are the mean of the corresponding exponential distributions 
%given by 1/a and 1/b, respectively
m_am = 1/am;
m_bm = 1/bm;

m_ah = 1/ah;
m_bh = 1/bh;

t_sim = 1; %in s, 1000 ms
%simulate m gates. Since average time between transitions is 1.6ms and
%we want 1000 ms of data simulate at least (2000*1.6 = 3200 ms) on average
n_transm = 2000;

%state vector
s_vectm = zeros(3,n_transm);
s_vectm(1:3,1) = rand(3,1) < 0.5;

%transition times
t_vectm = zeros(3,n_transm);

for j = 1:3
    for i = 2: n_transm
        if ( s_vectm(j,i-1) == 0 )
            %closed, duration determined by alpha
            tnext = exprnd(m_am);
            s_vectm(j,i) = 1;
            t_vectm(j,i) = t_vectm(j,i-1) + tnext;
        else
            %open, duration determined by beta
            tnext = exprnd(m_bm);
            s_vectm(j,i) = 0;
            t_vectm(j,i) = t_vectm(j,i-1) + tnext;
        end;
    end;
end;

%figure; handles.axes1 = axes;
color_vect = ['k' 'k' 'k'];
hdl_vect = [handles.axes1 handles.axes2 handles.axes3];
for j = 1:3
    for i = 2:n_transm
        line('Parent',hdl_vect(j),'XData',[t_vectm(j,i-1) t_vectm(j,i)],'YData',[s_vectm(j,i-1) s_vectm(j,i-1)],...
            'Color',color_vect(j));
        line('Parent',hdl_vect(j),'XData',[t_vectm(j,i) t_vectm(j,i)],'YData',[s_vectm(j,i-1) s_vectm(j,i)],...
            'Color',color_vect(j));
    end;
    set(hdl_vect(j),'XLim',[0 t_sim]); %1000 ms 
end;

if ( ~isempty(find(t_vectm(:,n_transm) < t_sim)) )
    disp('less than 100 ms of data for the m-gate, exiting...');
    guidata(hObject,handles);
    return;
end;

ylabel(handles.axes3,'channel state');
%Build vector for m-gates
dt = 0.00005;
t_max = t_sim-dt;
t_vect = 0:dt:t_max;
ind_max = length(t_vect);

s_vm  = zeros(3,ind_max);
for j = 1:3
    i = 2;
    ind_start = 1;
    while  ( t_vectm(j,i) < t_max )
        ind_end = floor(t_vectm(j,i)/dt) + 1;
        s_vm(j,ind_start:ind_end) = s_vectm(j,i-1);
        ind_start = ind_end;
        i = i + 1;
    end;
    s_vm(j,ind_start:ind_max) = s_vectm(j,i-1);
    %figure; plot(t_vect,s_vm(1,:));    
end;

%simulate h gate
n_transh = 100;

s_vecth = zeros(1,n_transh);
s_vecth(1) = rand(1) < 0.5;

t_vecth = zeros(1,n_transh);

for i = 2: n_transh
    if ( s_vecth(i-1) == 0 )
        %closed, duration determined by alpha
        tnext = exprnd(m_ah);
        s_vecth(i) = 1;
        t_vecth(i) = t_vecth(i-1) + tnext;
    else
        %open, duration determined by beta
        tnext = exprnd(m_bh);
        s_vecth(i) = 0;
        t_vecth(i) = t_vecth(i-1) + tnext;
    end;
end;

%figure; handles.axesn = axes;
for i = 2:n_transh
    line('Parent',handles.axes4,'XData',[t_vecth(i-1) t_vecth(i)],'YData',[s_vecth(i-1) s_vecth(i-1)]);
    line('Parent',handles.axes4,'XData',[t_vecth(i) t_vecth(i)],'YData',[s_vecth(i-1) s_vecth(i)]);
end;
set(handles.axes4,'XLim',[0 t_sim]); %100 ms 
xlabel(handles.axes4,'time (s)');

if (t_vecth(n_transh) < t_sim)
    disp('less than 100 ms of data for the h-gate, exiting...');
    guidata(hObject,handles);
    return;
end;

%Build vector for h-gate
s_vh  = zeros(1,ind_max);
i = 2;
ind_start = 1;
while  ( t_vecth(i) < t_max )
    ind_end = floor(t_vecth(i)/dt) + 1;
    s_vh(ind_start:ind_end) = s_vecth(i-1);
    ind_start = ind_end;
    i = i + 1;
end;
s_vh(ind_start:ind_max) = s_vectm(i-1);
%figure; plot(t_vect,s_vm(1,:));    

%compute open probability
%o_v = s_vm(1,:).*s_vm(2,:).*s_vm(3,:).*s_vh(1,:);
%figure;plot(t_vect,o_v);
%line('Parent',handles.axes5,'XData',t_vect,'YData',o_v);
%set(handles.axes5,'XLim',[0 t_sim]);

cum_s = 1 + s_vm(1,:) + s_vm(2,:) + s_vm(3,:) + 4*s_vh(1,:);
%figure; plot(t_vect,cum_s);
line('Parent',handles.axes6,'XData',t_vect,'YData',cum_s);
set(handles.axes6,'XLim',[0 t_sim]);

%carry out single channel simulation using multi-state variable
%build the transition matrix for the entire channel
n_st = 8; %number of states
Qna = zeros(n_st,n_st);

%fill in the non-zero diagonal elements
Qna(1,2) = 3*am;
Qna(1,5) = ah;

Qna(2,1) = bm; 
Qna(2,3) = 2*am;
Qna(2,6) = ah;

Qna(3,2) = 2*bm;
Qna(3,4) = am;
Qna(3,7) = ah;

Qna(4,3) = 3*bm;
Qna(4,8) = ah;

Qna(5,1) = bh;
Qna(5,6) = 3*am;

Qna(6,2) = bh;
Qna(6,5) = bm;
Qna(6,7) = 2*am;

Qna(7,3) = bh;
Qna(7,6) = 2*bm;
Qna(7,8) = am;

Qna(8,4) = bh;
Qna(8,7) = 3*bm;

%sets the diagonal element values as the escape rates from 
%state i
for i = 1:n_st
    Qna(i,i) = sum(Qna(i,:));
end;

%compute the mean escape times
m_escape = 1./diag(Qna);

%cumulative transition probabilities
cQna = zeros(n_st,n_st-1);

%rescale the probabilities to be the conditional
%probabilities given an escape from state i
Qna(1,2:n_st) = Qna(1,2:n_st)/Qna(1,1);
cQna(1,:) = cumsum(Qna(1,2:n_st));

for i = 2:n_st-1
    Qna(i,1:i-1) = Qna(i,1:i-1)/Qna(i,i);
    Qna(i,i+1:n_st) = Qna(i,i+1:n_st)/Qna(i,i);
    cQna(i,:) = cumsum([Qna(i,1:i-1) Qna(i,i+1:n_st)]); 
end;

Qna(n_st,1:n_st-1) = Qna(n_st,1:n_st-1)/Qna(n_st,n_st);
cQna(n_st,:) = cumsum(Qna(n_st,1:n_st-1));


%number of transitions
n_transna = 2000;

s_vectna = zeros(1,n_transna);

%cumulative distribution of the uniform distr. over 8 states
cu_v = [1:8]/8;
%assign equally to each of the possible states
s_vectna(1) = find(rand(1) <= cu_v,1);

t_vectna = zeros(1,n_transna);

for i = 2: n_transna
    c_state = s_vectna(i-1);
    tnext = exprnd(m_escape(c_state));
    t_vectna(i) = t_vectna(i-1) + tnext;
    n_state = find(rand(1)<= cQna(c_state,:),1);
    if ( n_state >= c_state )
        n_state = n_state + 1;
    end;
    s_vectna(i) = n_state;
end;

%figure; handles.axesn = axes;
for i = 2:n_transna
    line('Parent',handles.axes7,'XData',[t_vectna(i-1) t_vectna(i)],'YData',[s_vectna(i-1) s_vectna(i-1)],'Color','r');
    line('Parent',handles.axes7,'XData',[t_vectna(i) t_vectna(i)],'YData',[s_vectna(i-1) s_vectna(i)],'Color','r');
end;
set(handles.axes7,'XLim',[0 t_sim]); %1000 ms 
xlabel(handles.axes7,'time (s)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes nachan wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = nachan_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','nachan.eps');


% --------------------------------------------------------------------
function toggle_lims_Callback(hObject, eventdata, handles)
% hObject    handle to toggle_lims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

x_v = get(handles.axes1,'XLim');

if ( x_v(2) == 1 )
    new_lim1 = 0.1;
    new_lim2 = 0.2;
else 
    new_lim1 = 1;
    new_lim2 = 1;
end;


set(handles.axes1,'XLim',[0 new_lim1]);
set(handles.axes2,'XLim',[0 new_lim1]);
set(handles.axes3,'XLim',[0 new_lim1]);
set(handles.axes4,'XLim',[0 new_lim1]);
set(handles.axes6,'XLim',[0 new_lim2]);
set(handles.axes7,'XLim',[0 new_lim2]);

guidata(hObject, handles);