%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires destexhy.m destexhy2.m

function varargout = destex_f1(varargin)
% DESTEX_F1 M-file for destex_f1.fig
%      DESTEX_F1, by itself, creates a new DESTEX_F1 or raises the existing
%      singleton*.
%
%      H = DESTEX_F1 returns the handle to a new DESTEX_F1 or the handle to
%      the existing singleton*.
%
%      DESTEX_F1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DESTEX_F1.M with the given input arguments.
%
%      DESTEX_F1('Property','Value',...) creates a new DESTEX_F1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before destex_f1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to destex_f1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help destex_f1

% Last Modified by GUIDE v2.5 22-Jan-2009 18:06:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @destex_f1_OpeningFcn, ...
                   'gui_OutputFcn',  @destex_f1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before destex_f1 is made visible.
function destex_f1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to destex_f1 (see VARARGIN)

% Choose default command line output for destex_f1
handles.output = hObject;

%compute the distribution of the membrane potential
dt = 0.05;
v_stat = destexhy2(dt,10,100,2000,0);

%skip the first 50 ms
n1 = ceil(50/dt);
mv = mean(v_stat(n1:end));
sv = std(v_stat(n1:end));

text_str = sprintf('mean vm: %.3g std: %.3g',mv,sv);
disp(text_str);

%histogram of values
[nv, xoutv] = hist(v_stat(n1:end),50);

bar(handles.axes2,xoutv,nv,'r');
set(handles.axes2,'TickDir','out','XLim',[-80 -60]);
xlabel(handles.axes2,'Vm (mV)');
ylabel(handles.axes2,'number of occurrences');

%plot sample noise trace
t = (1:length(v_stat))*dt;
inds = find( (t>500)&(t<1000));
line('Parent',handles.axes1,'XData',t(inds),'YData',v_stat(inds));
set(handles.axes1,'XLim',[500 1000]);

vn = destexhy(dt,150,350,550,-0.25);
N = length(vn);
t = (1:N)*dt;
line('Parent',handles.axes3,'XData',t,'YData',vn);
xlabel(handles.axes3,'time (ms)');
ylabel(handles.axes3,'Vm (mv)');

reps = 1000;
vb = zeros(N,reps);

disp('iterating 1000 times. This may take a while...');
for i = 1:reps
    if ( mod(i,100) == 0 )
        info_str = sprintf('at iteration %i',i);
        disp(info_str);
    end;
    
    vb(:,i) = destexhy2(dt,150,350,550,-0.25);
end;
vba = mean(vb,2);
line('Parent',handles.axes4,'XData',t,'YData',vba);
xlabel(handles.axes4,'time (ms)');

inds1 = find( (t>40) & (t<140) );
inds2 = find( (t>200) & (t<300) );

vpre = mean(vba(inds1));
vpul = mean(vba(inds2));
vdiff = vpre-vpul;

text_str2 = sprintf('mean vm prepulse: %.2g during: %.2g difference: %.2g',vpre,vpul,vdiff);
disp(text_str2);

vpren = mean(vn(inds1));
vpuln = mean(vn(inds2));
vdiffn = vpren-vpuln;

text_str3 = sprintf('mean vm prepulse: %.2g during: %.2g difference: %.2g',vpren,vpuln,vdiffn);
disp(text_str3);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes destex_f1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = destex_f1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','destex_f1.eps');
