%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = coherence_est(varargin)
% COHERENCE_EST M-file for coherence_est.fig
%      COHERENCE_EST, by itself, creates a new COHERENCE_EST or raises the existing
%      singleton*.
%
%      H = COHERENCE_EST returns the handle to a new COHERENCE_EST or the handle to
%      the existing singleton*.
%
%      COHERENCE_EST('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COHERENCE_EST.M with the given input arguments.
%
%      COHERENCE_EST('Property','Value',...) creates a new COHERENCE_EST or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before coherence_est_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to coherence_est_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help coherence_est

% Last Modified by GUIDE v2.5 07-Jul-2009 17:18:08

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @coherence_est_OpeningFcn, ...
                   'gui_OutputFcn',  @coherence_est_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before coherence_est is made visible.
function coherence_est_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to coherence_est (see VARARGIN)

% Choose default command line output for coherence_est
handles.output = hObject;

%relaxation time constant and steady-state SD
tau_ou = 2.7; %ms
sig_ou = 0.55; %mu S

%time step and time vector
dt = 0.5; %ms
fs = 1/(dt*1e-3); %sampling freq
fn = fs/2; %nyquist freq

%this gives 16 segments to average over for the 
%power spectrum
n_seg = 32;
seg_len = 2048;
n_v = 0:(n_seg*seg_len-1);
t_v = n_v*dt;
n_t_v = length(t_v);

%numerical simulation factors
nsf_1 = exp(-dt/tau_ou);
nsf_2 = sqrt(1-exp(-2*dt/tau_ou));

%initial value of the random conductance variable
x0 = 0;

%random white noise increment
w_vou = normrnd(0,1,1,n_t_v);
u_vou = sig_ou*nsf_2*w_vou;

%save space for random vector
x_vou = zeros(1,n_t_v);

%initial condition
x_vou(1) = x0;

for i =2:n_t_v
    %stochastic update
    x_vou(i) = x_vou(i-1)*nsf_1 + u_vou(i);
end;

%white noise
sigma_w = 1;
y_vw = randn(size(x_vou));

z = x_vou + y_vw;

%show data
line('Parent',handles.axes1,'XData',t_v(1:250),'YData',z(1:250));
line('Parent',handles.axes1,'XData',t_v(1:250),'YData',x_vou(1:250),'Color','r');
set(handles.axes1,'XLim',[0 125],'YLim',[-3 3]);
xlabel(handles.axes1,'time (ms)');

%debug
%2048 = window length (hamming)
%1024 = overlap (50 percent)
%2048 = number of samples for fft
%2000 = sampling frequency (0.5 ms = 2kHz)
%[px_w,f_w] = pwelch(x_vou,seg_len,seg_len/2,seg_len,fs,'twosided');
%line('Parent',handles.axes4,'XData',f_w(1:seg_len/2 + 1),'YData',px_w(1:seg_len/2+1),'Color','r');

%[py_w,f_w] = pwelch(y_vw,seg_len,seg_len/2,seg_len,fs,'twosided');
%line('Parent',handles.axes4,'XData',f_w(1:seg_len/2 + 1),'YData',py_w(1:seg_len/2+1));

%[pz_w,f_w] = pwelch(z,seg_len,seg_len/2,seg_len,fs,'twosided');
%line('Parent',handles.axes4,'XData',f_w(1:seg_len/2 + 1),'YData',pz_w(1:seg_len/2+1),'Color','k');

%theoretical power spectrum OU process
f = 0:0.1:1000;
pfou = 2*sig_ou^2*tau_ou*1e-3./(1 + (2*pi*f*tau_ou*1e-3).^2);
%line('Parent',handles.axes4,'XData',f,'YData',pfou,'Color','g');

%theoretical power spectrum white noise
pfw = sigma_w^2/(2*fn)*ones(size(f));

%line('Parent',handles.axes4,'XData',f,'YData',pfw,'Color','b');

%theoretical power spectrum sum of OU and white noise
pfz = pfw + pfou;
%line('Parent',handles.axes4,'XData',f,'YData',pfz,'Color','r');

%top_ylim = 10e-8;
%set(handles.axes4,'XLim',[0 200]); %,'YLim',[0 top_ylim]);

nfft = 2048;
noverlap = 1024;
window = 2048;
[Cxy,F] = mscohere(z,x_vou,window,noverlap,nfft,fs);
line('Parent',handles.axes2,'XData',F,'YData',Cxy);
xlabel(handles.axes2,'frequency (Hz)');
ylabel(handles.axes2,'coherence');

%theoretical mean square coherence
cxy_t = pfou./pfz;
line('Parent',handles.axes2,'XData',f,'YData',cxy_t,'Color','r');

%
% modified from whiten1
%

% Generate an oversampled white noise segment in the frequency domain
% Passes the white noise through a static non-linearity. Computes 
% autocorrelations of the input and outpout, cross correlation and 
% corresponding quantities in the Fourier domain. Analytical results
% are plotted as well.
   

%
% Generate the white noise
%

stddev = 1;
fc = 100; %cut-off frequency Hz
deltat = 1e-3; %sampling step, converts from msec in sec
fs = 1/deltat; %sampling frequency
seg_len = 1024;
n = 32*seg_len; %number of samples
sigma = sqrt((stddev^2*n)/(4*fc*deltat));
 
%typically, a random seed controls the state of the random number 
%generator. To make the following sequence reproducible it should
%be initialized here 

whitef = zeros(1,n);
   
%zero frequency component
ai = randn(1) * sigma;
whitef(1) = complex(ai,0);

%all component except for nyquist
for i=2:n/2
    if ( i/(n*deltat) < fc )
        ai = randn(1) * sigma;
        bi = randn(1) * sigma;
        whitef(i) = complex(ai,bi);
        whitef(n-i+2) = complex(ai,-bi);
    end;
end;

ai = randn(1) * sigma;
whitef(n/2+1) = complex(ai,0);

whitet = fft(whitef);
whitet = whitet/n;
whitet = real(whitet);

%
%autocorrelation function of the input
%

%analytical formula
n_tp = 128;
t_v = (-n_tp:n_tp)* deltat;
ind_z = find(t_v == 0);
auto_th = sin(2*pi*fc*t_v)./(2*pi*fc*t_v);
auto_th(ind_z) = 1;

%
%power spectrum of input
%

%computed from the FT of the autocorrelation
df = 1/(2*n_tp*deltat);
f_auto = (0:2*n_tp-1)*df;
auto_sf = circshift(auto_th(2:end),[0 -(n_tp-1)]);
ps_est1 = real(fft(auto_sf))*deltat;

%
% static non-linearity
%

%gaussian signal
x = -5:0.01:5;
y = normpdf(x,0,1);

l2 = 1/10;
nl2 = erf(x/(sqrt(2)*l2));
nw2 = erf(whitet/(sqrt(2)*l2));

[n,xout] = hist(whitet,100);
dxout = xout(2) - xout(1);
n = n/(sum(n*dxout));
bar(handles.axes5,xout,n);
line('Parent',handles.axes5,'XData',x,'YData',y,'Color','r');
set(handles.axes5,'TickDir','out');

line('Parent',handles.axes6,'XData',x,'YData',nl2);
set(handles.axes6,'XLim',[-1 1]);

[n,xout] = hist(nw2,100);
dxout = xout(2) - xout(1);
n = n/(sum(n*dxout));
bar(handles.axes7,xout,n);
set(handles.axes7,'XLim',[-1.1 1.1],'YLim',[0 25],'TickDir','out');

n_pts = 250;
t_v_ex = (1:n_pts)*dt;
line('Parent',handles.axes3,'XData',t_v_ex,'YData',whitet(1:n_pts),'Color','r');
line('Parent',handles.axes3,'XData',t_v_ex,'YData',nw2(1:n_pts),'Color','k');
set(handles.axes3,'XLim',[0 125],'YLim',[-3 3]);
xlabel(handles.axes3,'time (ms)');


%
%autocorrelation of output
%
% %analytical formula
auto_th2 = (2/pi)*asin(auto_th/(1 + l2^2));

%
%power spectrum of output
%

%analytical forumula from autocorrelation function
auto_sf2 = circshift(auto_th2(2:end),[0 -(n_tp-1)]);
ps_est2 = real(fft(auto_sf2))*deltat;

%
%cross correlation
%
cross_th2 = (sqrt(2)/sqrt(pi))*(1/sqrt(1 + l2^2))*auto_th;

%
%cross spectrum
%

%value from cross correlation
cross_sf = circshift(cross_th2(2:end),[0 -(n_tp-1)]);
cs_est = (abs(fft(cross_sf))*deltat).^2;

%
%mean squared coherence
%

%seg_len = window 
%seg_len/2 = noverlap
%seg_len = nfft
[Cxy,F] = mscohere(nw2,whitet,seg_len,seg_len/2,seg_len,1000);
 
%theoretical value
coh_th = cs_est./(ps_est1.*ps_est2);
% 
%plot ms coherence
line('Parent',handles.axes4,'XData',F,'YData',Cxy);
line('Parent',handles.axes4,'XData',f_auto(1:n_tp+1),'YData',coh_th(1:n_tp+1),'Color','r');
set(handles.axes4,'YLim',[0 1]);
xlabel(handles.axes4,'frequency (Hz)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes coherence_est wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = coherence_est_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','coherence_est.eps');
