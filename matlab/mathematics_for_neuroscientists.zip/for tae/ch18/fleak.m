%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = fleak(varargin)
% FLEAK M-file for fleak.fig
%      FLEAK, by itself, creates a new FLEAK or raises the existing
%      singleton*.
%
%      H = FLEAK returns the handle to a new FLEAK or the handle to
%      the existing singleton*.
%
%      FLEAK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FLEAK.M with the given input arguments.
%
%      FLEAK('Property','Value',...) creates a new FLEAK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fleak_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fleak_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fleak

% Last Modified by GUIDE v2.5 01-Jul-2009 14:25:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fleak_OpeningFcn, ...
                   'gui_OutputFcn',  @fleak_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fleak is made visible.
function fleak_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fleak (see VARARGIN)

% Choose default command line output for fleak
handles.output = hObject;

N = 32;

x = 0:N-1;
x_fine = 0:0.01:N-1;

f_osc = 1/4;
y = cos( 2*pi*x*f_osc );
y_fine = cos( 2*pi*x_fine*f_osc );

msize = 3;

line('Parent',handles.axes1,'XData',x,'YData',y,'LineStyle','none','Marker','o',...
    'MarkerFaceColor','k','MarkerSize',msize);
line('Parent',handles.axes1,'XData',x_fine,'YData',y_fine,'LineStyle','-','Marker','none');
set(handles.axes1,'XLim',[0 N]);
xlabel(handles.axes1,'time (normalized)');

z = fft(y);
mz2 = (1/N)*(z.*conj(z));
mz2_c = circshift(mz2,[0 15]); %line vector

%debug: normalized such that sum(y.^2) = sum(mz2)
%sy2 = sum(y.^2)
%smz2 = sum(mz2)

%compute discrete spheroidal sequence of order zero
[e,v] = dpss(32,1);
dpss_win = e(:,1);

[pxx, w] = periodogram(y,dpss_win,N,1,'twosided');
pxxc = circshift(pxx,[15 0]); %column vector

%debug: same normalization as above sum(pxx) = sum(y.^2)
%spxx = sum(pxx)

df = 1/N;
f = (0:N-1)*df;
f_corr = (-N/2+1:N/2)*df;
i_res1 = find(f == f_osc);
i_res2 = find(f == f_osc + 0.5);
inds_lin = [i_res1-1:i_res1+1 i_res2-1:i_res2+1];

i_res3 = find(f_corr == f_osc);
i_res4 = find(f_corr == -f_osc);
inds_linc = [i_res4-1:i_res4+1 i_res3-1:i_res3+1];

%linear scale
line('Parent',handles.axes2,'XData',f_corr,'YData',mz2_c,'LineStyle','none','Marker','o',...
    'MarkerFaceColor','k','MarkerSize',msize);
line('Parent',handles.axes2,'XData',f_corr(inds_linc),'YData',pxxc(inds_linc),'LineStyle','none','Marker','x',...
    'MarkerEdgeColor','r','MarkerSize',msize);
set(handles.axes2,'XLim',[-0.5 0.5],'YLim',[0 10]);
ylabel(handles.axes2,'power (normalized)');


%log scale
line('Parent',handles.axes5,'XData',f_corr,'YData',pow2db(mz2_c),'LineStyle','none','Marker','o',...
    'MarkerFaceColor','k','MarkerSize',msize);
line('Parent',handles.axes5,'XData',f_corr,'YData',pow2db(pxxc),'LineStyle','none','Marker','x',...
    'MarkerEdgeColor','r','MarkerSize',msize);
set(handles.axes5,'XLim',[-0.5 0.5],'YLim',[-50 25]);
xlabel(handles.axes5,'frequency (normalized)','Color','k');
ylabel(handles.axes5,'dB(power)');

%debug
%figure; subplot(2,1,1); plot(f,mz2); hold on; plot(w,pxx,'xr');
%subplot(2,1,2); plot(f,pow2db(mz2)); hold on; plot(w,pow2db(pxx),'xr');

%line('Parent',handles.axes5,'XData',f,'YData',mz2,'LineStyle','none','Marker','o',...
%    'MarkerFaceColor','k','MarkerSize',msize);
%set(handles.axes5,'XLim',[0 1],'YLim',[200 300]);

f1 = f_osc + 0.5*df;
y1 = cos( 2*pi*f1*x );
y1_fine = cos( 2*pi*f1*x_fine );

line('Parent',handles.axes3,'XData',x,'YData',y1,'LineStyle','none','Marker','o', ...
    'MarkerFaceColor','k','MarkerSize',msize);
line('Parent',handles.axes3,'XData',x_fine,'YData',y1_fine,'LineStyle','-','Marker','none');
set(handles.axes3,'XLim',[0 N]);
xlabel(handles.axes3,'time (normalized)');

z1 = fft(y1);
mz12 = (1/N)*(z1.*conj(z1));
mz12_c = circshift(mz12,[0 15]); %line vector

%debug: normalized so that sum(y1.^2) = sum(mz12)
%sy12 = sum(y1.^2)
%smz12 = sum(mz12)

[pxx2, w2] = periodogram(y1,dpss_win,N,1,'twosided');
pxx2c = circshift(pxx2,[15 0]); %column vector
%debug: same normalization as above sum(pxx) = sum(y.^2)
%spxx2 = sum(pxx2)

%linear scale
line('Parent',handles.axes4,'XData',f_corr,'YData',mz12_c,'LineStyle','none','Marker','o',...
    'MarkerFaceColor','k','MarkerSize',msize);
line('Parent',handles.axes4,'XData',f_corr(inds_linc),'YData',pxx2c(inds_linc),'LineStyle','none','Marker','x',...
    'MarkerEdgeColor','r','MarkerSize',msize);
set(handles.axes4,'XLim',[-0.5 0.5],'YLim',[0 10]);

%log scale
line('Parent',handles.axes6,'XData',f_corr,'YData',pow2db(mz12_c),'LineStyle','none','Marker','o',...
    'MarkerFaceColor','k','MarkerSize',msize);
line('Parent',handles.axes6,'XData',f_corr,'YData',pow2db(pxx2c),'LineStyle','none','Marker','x',...
    'MarkerEdgeColor','r','MarkerSize',msize);
set(handles.axes6,'XLim',[-0.5 0.5],'YLim',[-50 25]);
xlabel(handles.axes6,'frequency (normalized)');

%debug
%figure; subplot(2,1,1); plot(f,mz12); hold on; plot(w,pxx2,'xr');
%subplot(2,1,2); plot(f,pow2db(mz12)); hold on; plot(w,pow2db(pxx2),'xr');

%line('Parent',handles.axes6,'XData',f,'YData',mz12,'LineStyle','none','Marker','o', ...
%    'MarkerFaceColor','k','MarkerSize',msize);
%set(handles.axes6,'XLim',[0 1],'YLim',[200 300]);

%time and frequency domain kernels
%dt = 1 so T = N = 32
T = 32;
omega = -0.5:0.001:0.5;
ind0 = (length(omega)-1)/2 + 1;

%continuous (Fejer) kernel
ghat = sin(pi*omega*T).^2./(T*pi^2*omega.^2);
ghat(ind0) = T;

%discrete (Dirichlet) kernel
%ghat2 = sin(pi*omega*T).^2./(T*sin(pi*omega).^2);
%ghat2(ind0) = T;

[e,v] = dpss(32,1);
e_win = e(:,1);

%column vector
ehat = zeros(size(omega));
k_vect = 0:31;

for i = 1:length(ehat)
    arg_exp = (-1)*k_vect*2*pi*omega(i);
    arg_comp = complex(cos(arg_exp),sin(arg_exp));
    ehat(i) = arg_comp*e_win;
end;

ehat = ehat.*conj(ehat);

line('Parent',handles.axes7,'XData',1:32,'YData',e_win,'Color','r');
line('Parent',handles.axes7,'XData',[1 1 32 32],'YData',[0 1/sqrt(32) 1/sqrt(32) 0]);
set(handles.axes7,'XLim',[0 32]);
xlabel(handles.axes7,'time (normalized)');

line('Parent',handles.axes8,'XData',omega,'YData',pow2db(ghat)); 
line('Parent',handles.axes8,'XData',omega,'YData',pow2db(ehat),'Color','r');
line('Parent',handles.axes8,'XData',[0.5/32 0.5/32],'YData',[-25 10],'LineStyle','--');
line('Parent',handles.axes8,'XData',[-0.5/32 -0.5/32],'YData',[-25 10],'LineStyle','--');
set(handles.axes8,'XLim',[-0.15 0.15],'YLim',[-25 20],'XTick',[-0.15 -0.1 -0.05 0 0.05 0.1 0.15]);
xlabel(handles.axes8,'frequency (normalized)');
ylabel(handles.axes8,'dB');

%figure; plot(omega,pow2db(ghat));
%hold on; plot(omega,pow2db(ghat2),'r');
%plot(omega,pow2db(ehat),'g');
%set(gca,'YLim',[-25 25]);



% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fleak wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fleak_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','fleak.eps');
