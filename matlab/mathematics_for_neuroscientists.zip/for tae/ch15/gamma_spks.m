%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = gamma_spks(varargin)
% GAMMA_SPKS M-file for gamma_spks.fig
%      GAMMA_SPKS, by itself, creates a new GAMMA_SPKS or raises the existing
%      singleton*.
%
%      H = GAMMA_SPKS returns the handle to a new GAMMA_SPKS or the handle to
%      the existing singleton*.
%
%      GAMMA_SPKS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GAMMA_SPKS.M with the given input arguments.
%
%      GAMMA_SPKS('Property','Value',...) creates a new GAMMA_SPKS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gamma_spks_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gamma_spks_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gamma_spks

% Last Modified by GUIDE v2.5 16-Jun-2009 18:20:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gamma_spks_OpeningFcn, ...
                   'gui_OutputFcn',  @gamma_spks_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gamma_spks is made visible.
function gamma_spks_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gamma_spks (see VARARGIN)

% Choose default command line output for gamma_spks
handles.output = hObject;

n_samples = 10000;

m_isi = 10; %in ms (without ref period)
tref = 2; %in ms

max_plot = 400;

%10 ms isi, n_samples samples
v_1 = exprnd(m_isi,n_samples,1);

%add a 2ms refractory period
v_1r = v_1 + tref;

%compute spike times
spk_1r = cumsum(v_1r);

inds = find(spk_1r <= max_plot);

for i = 1:length(inds);
    line('Parent',handles.axes1,'XData',[spk_1r(inds(i)) spk_1r(inds(i))],'YData',[0 1]);
end;
set(handles.axes1,'XLim',[0 max_plot]);

[n, xout] = hist(v_1r,[0:60]);
bar(handles.axes2,xout,n/n_samples);
set(handles.axes2,'XLim',[0 60],'TickDir','out');
m_v1r = mean(v_1r);
s_v1r = std(v_1r);
cv_1 = s_v1r/m_v1r;
info_str = sprintf('n = 1 mean ISI: %.2g',mean(v_1r));
disp(info_str);
title(handles.axes2,sprintf('n = 1 CV = %.2g',cv_1));

y = exppdf(xout-2,m_isi);
y = y/sum(y);
line('Parent',handles.axes2,'XData',xout,'YData',y','Color','r');

%gamma of order 2

a = 2; 

%10 ms isi, n_samples samples
v_2 = gamrnd(a,m_isi/a,n_samples,1);

%add a 2ms refractory period
v_2r = v_2 + tref;

%compute spike times
spk_2r = cumsum(v_2r);

inds = find(spk_2r <= max_plot);

for i = 1:length(inds);
    line('Parent',handles.axes3,'XData',[spk_2r(inds(i)) spk_2r(inds(i))],'YData',[0 1]);
end;
set(handles.axes3,'XLim',[0 max_plot]);

[n, xout] = hist(v_2r,[0:60]);
bar(handles.axes4,xout,n/n_samples);
set(handles.axes4,'XLim',[0 60],'TickDir','out');
m_v2r = mean(v_2r);
s_v2r = std(v_2r);
cv_2 = s_v2r/m_v2r;
info_str = sprintf('n = 2 mean ISI: %.2g',mean(v_2r));
disp(info_str);
title(handles.axes4,sprintf('n = 2 CV = %.2g',cv_2));

y = gampdf(xout-2,a,m_isi/a);
y = y/sum(y);
line('Parent',handles.axes4,'XData',xout,'YData',y','Color','r');

%gamma of order 5

a = 5;

%10 ms isi, n_samples samples
v_5 = gamrnd(a,m_isi/a,n_samples,1);

%add a 2ms refractory period
v_5r = v_5 + tref;

%compute spike times
spk_5r = cumsum(v_5r);

inds = find(spk_5r <= max_plot);

for i = 1:length(inds);
    line('Parent',handles.axes5,'XData',[spk_5r(inds(i)) spk_5r(inds(i))],'YData',[0 1]);
end;
set(handles.axes5,'XLim',[0 max_plot]);

[n, xout] = hist(v_5r,[0:60]);
bar(handles.axes6,xout,n/n_samples);
set(handles.axes6,'XLim',[0 60],'TickDir','out');
m_v5r = mean(v_5r);
s_v5r = std(v_5r);
cv_5 = s_v5r/m_v5r;
info_str = sprintf('n = 5 mean ISI: %.2g',mean(v_5r));
disp(info_str);
title(handles.axes6,sprintf('n = 5 CV = %.2g',cv_5));

y = gampdf(xout-2,a,m_isi/a);
y = y/sum(y);
line('Parent',handles.axes6,'XData',xout,'YData',y','Color','r');

%gamma of order 10

a = 10;

%10 ms isi, n_samples samples
v_10 = gamrnd(a,m_isi/a,n_samples,1);

%add a 2ms refractory period
v_10r = v_10 + tref;

%compute spike times
spk_10r = cumsum(v_10r);

inds = find(spk_10r <= max_plot);

for i = 1:length(inds);
    line('Parent',handles.axes7,'XData',[spk_10r(inds(i)) spk_10r(inds(i))],'YData',[0 1]);
end;
set(handles.axes7,'XLim',[0 max_plot]);

[n, xout] = hist(v_10r,[0:60]);
bar(handles.axes8,xout,n/n_samples);
set(handles.axes8,'XLim',[0 60],'TickDir','out');
m_v10r = mean(v_10r);
s_v10r = std(v_10r);
cv_10 = s_v10r/m_v10r;
info_str = sprintf('n = 10 mean ISI: %.2g',mean(v_10r));
disp(info_str);
title(handles.axes8,sprintf('n = 10 CV = %.2g',cv_10));

y = gampdf(xout-2,a,m_isi/a);
y = y/sum(y);
line('Parent',handles.axes8,'XData',xout,'YData',y','Color','r');

%perfect integrator

n_spk = ceil(max_plot/(m_isi + tref));
spk_infr = (m_isi + tref)*[0:1:n_spk+1];
inds = find(spk_infr <= max_plot);

for i = 1:length(inds);
    line('Parent',handles.axes9,'XData',[spk_infr(inds(i)) spk_infr(inds(i))],'YData',[0 1]);
end;
set(handles.axes9,'XLim',[0 max_plot]);

line('Parent',handles.axes10,'XData',[m_isi+tref m_isi+tref],'YData',[0 1]);
set(handles.axes10,'XLim',[0 60],'TickDir','out');
info_str = sprintf('n = infinity mean ISI: 12');
disp(info_str);
title(handles.axes10,sprintf('n = \\infty CV = 0'));

xlabel(handles.axes9,'time (ms)');
xlabel(handles.axes10,'ISI (ms)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gamma_spks wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gamma_spks_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','gamma_spks.eps');
