%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = neg_corr(varargin)
% NEG_CORR M-file for neg_corr.fig
%      NEG_CORR, by itself, creates a new NEG_CORR or raises the existing
%      singleton*.
%
%      H = NEG_CORR returns the handle to a new NEG_CORR or the handle to
%      the existing singleton*.
%
%      NEG_CORR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NEG_CORR.M with the given input arguments.
%
%      NEG_CORR('Property','Value',...) creates a new NEG_CORR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before neg_corr_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to neg_corr_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help neg_corr

% Last Modified by GUIDE v2.5 13-May-2010 21:39:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @neg_corr_OpeningFcn, ...
                   'gui_OutputFcn',  @neg_corr_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before neg_corr is made visible.
function neg_corr_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to neg_corr (see VARARGIN)

% Choose default command line output for neg_corr
handles.output = hObject;

%simulate an integrate and fire neuron with a time-varying
%threshold that is incremented after an action potential and
%relaxes exponentially to its resting value,between action potentials

%Does the same thing for a static threshold and compares with the above
%model. Thiss is a modified version of lif1 and lif2

%integration time step in ms (0.1 ms)
dt = 0.1; 

%time vector; 100000 ms = 100 s
t_v = 0:dt:100000-dt;

%capacitance, nF
Cm = 2;

%current vector nA
i_v = ones(size(t_v));

%white noise vector nA
i_rnd = normrnd(0,1.5,1,length(t_v));
i_v = i_v + i_rnd;

%membrane potential vector mV
vm_v = zeros(size(t_v));

%threshold in mV
vm_thres0 = 8;

%increment in threshold for each spike in mV
thres_incr = 4;

%threshold recovery time constant ms
tau_t = 80; 

%threshold values during simulations
thres_v = zeros(size(t_v));
%initializes to baseline threshold 
thres_v(1) = vm_thres0;

%calculations to speed up the simulations
dtau_t1 = dt/tau_t;
t_fact = 1- dtau_t1;
t0_fact = vm_thres0*dtau_t1;

%spike vector
s_v = zeros(size(t_v));

%membrane time constant
tau_v = 20;
dtau_m1 = dt/tau_v;
m_fact = (1-dtau_m1);

%scale by dt to speed up computations
i_v_n = i_v*dt/Cm;

%integrate with forward euler
for k = 2:length(t_v)
    %membrane potential evolution
    vm_v(k) = vm_v(k-1)*m_fact + i_v_n(k-1);
    
    %threshold evolution
    thres_v(k) = thres_v(k-1)*t_fact + t0_fact;
    
    if (vm_v(k) > thres_v(k))
        vm_v(k) = 0; %reset
        s_v(k) = 1; %register spike
        thres_v(k) = thres_v(k) + thres_incr; %increment threshold
    end;
    
end;
    
%compute ISI serial correlation coefficient
spk_times = t_v(find(s_v>0.5));

isi_v = diff(spk_times);

mean_isi = mean(isi_v);

v1 = isi_v(2:end) - mean_isi;
v2 = isi_v(1:end-1) - mean_isi;

%compute the serial correlation coefficient from the 
%formulas in the lecture notes
scc1 = mean(v1.*v2)/(std(v1)*std(v2));

%%%%%%%%%%%%%%%%%%%%%%%
%
%static threshold model
%
%%%%%%%%%%%%%%%%%%%%%%%

%membrane potential vector mV
vm_s = zeros(size(t_v));

%threshold in mV; adjusted manually to 
vm_thress = 10.4;

%spike vector
s_s = zeros(size(t_v));

%integrate with forward euler
for k = 2:length(t_v)
    %membrane potential evolution
    vm_s(k) = vm_s(k-1)*m_fact + i_v_n(k-1);
    
    if (vm_s(k) > vm_thress)
        vm_s(k) = 0; %reset
        s_s(k) = 1; %register spike
    end;
    
end;
    
%compute ISI serial correlation coefficient
spk_times_s = t_v(find(s_s>0.5));

isi_s = diff(spk_times_s);

mean_isi_s = mean(isi_s);

v1_s = isi_s(2:end) - mean_isi_s;
v2_s = isi_s(1:end-1) - mean_isi_s;

%compute the serial correlation coefficient from the 
%formulas in the lecture notes
scc1_s = mean(v1_s.*v2_s)/(std(v1_s)*std(v2_s));


[n,xout] = hist(isi_v,20);
h = bar(handles.axes4,xout,n);
set(h,'FaceColor','r');
set(h,'EdgeColor','r');
set(handles.axes4,'XLim',[0 300]);

[n,xout] = hist(isi_s,20);
h = bar(handles.axes5,xout,n);
set(h,'FaceColor','b');
set(h,'EdgeColor','b');
set(handles.axes5,'XLim',[0 300]);
xlabel(handles.axes5,'ISI (ms)');

line('Parent',handles.axes6,'XData',v2+mean_isi,'YData',v1+mean_isi,...
    'Marker','x','Color','r','LineStyle','none');
set(handles.axes6,'XLim',[0 200],'YLim',[0 200]);
xlabel(handles.axes6,'ISI_n (ms)');
ylabel(handles.axes6,'ISI_n_+_1 (ms)');
title_str = sprintf('r = %.2g',scc1);
title(handles.axes6,title_str);

line('Parent',handles.axes7,'XData',v2_s+mean_isi_s,'YData',v1_s+mean_isi_s,...
    'Marker','x','Color','b','LineStyle','none');
set(handles.axes7,'XLim',[0 200],'YLim',[0 200]);
title_str = sprintf('r = %.2g',scc1_s);
title(handles.axes7,title_str);

t_pl = spk_times(find(spk_times<2000));
stem(handles.axes1,t_pl,ones(size(t_pl)),'Marker','none','Color','r');
set(handles.axes1,'XTickLabel',[],'XTick',[],'YTickLabel',[],'YTick',[]);

t_pl_s = spk_times_s(find(spk_times_s<2000));
stem(handles.axes2,t_pl_s,ones(size(t_pl_s)),'Marker','none','Color','b');
set(handles.axes2,'XTickLabel',[],'XTick',[],'YTickLabel',[],'YTick',[]);

tv_pl = t_v(find(t_v < 2000));
wn_pl = i_v(find(t_v < 2000));
line('Parent',handles.axes3,'XData',tv_pl,'YData',wn_pl);
xlabel(handles.axes3,'time (ms)');
ylabel(handles.axes3,'current (nA)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes neg_corr wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = neg_corr_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_eps_Callback(hObject, eventdata, handles)
% hObject    handle to save_eps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc','neg_corr.eps'); 
