%
% sse.m
%
% Gabbiani & Cox, Mathematics for Neuroscientists
%
% steady-state depolarization as a function of normalized conductance for 
% one excitatory synapse
% 
% usage: sse
%

function sse

ce = [0:.1:15];     % normalized conductance

Vss = -68./(1+ce);      % steady-state response

plot(ce,Vss,'color','k');
xlabel('c_{syn}','fontsize',14)
ylabel('V_{ss} (mV)','fontsize',14)
box off
