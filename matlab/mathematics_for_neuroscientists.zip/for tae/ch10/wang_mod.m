%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires: wanghy.m
%

function varargout = wang_mod(varargin)
% WANG_MOD M-file for wang_mod.fig
%      WANG_MOD, by itself, creates a new WANG_MOD or raises the existing
%      singleton*.
%
%      H = WANG_MOD returns the handle to a new WANG_MOD or the handle to
%      the existing singleton*.
%
%      WANG_MOD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WANG_MOD.M with the given input arguments.
%
%      WANG_MOD('Property','Value',...) creates a new WANG_MOD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before wang_mod_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to wang_mod_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help wang_mod

% Last Modified by GUIDE v2.5 11-May-2010 22:00:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @wang_mod_OpeningFcn, ...
                   'gui_OutputFcn',  @wang_mod_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before wang_mod is made visible.
function wang_mod_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to wang_mod (see VARARGIN)

% Choose default command line output for wang_mod
handles.output = hObject;

%time in ms
dt = 0.01;
tcurr_start = 10;
tcurr_end = 100;
tsim_end = 200;
curr_val = -1; 

[v, h, H2] = wanghy(dt,tcurr_start,tcurr_end,tsim_end,curr_val);
N = length(v);
t = (1:N)*dt;
curr_v = curr_val*ones(1,N).*(t>tcurr_start).*(t<tcurr_end);

line('Parent',handles.axes1,'XData',t,'YData',v);
line('Parent',handles.axes2,'XData',t,'YData',h);
line('Parent',handles.axes3,'XData',t,'YData',H2);
line('Parent',handles.axes4,'XData',t,'YData',curr_v);

curr_val = 3;

[v, h, H2] = wanghy(dt,tcurr_start,tcurr_end,tsim_end,curr_val);
curr_v = curr_val*ones(1,N).*(t>tcurr_start).*(t<tcurr_end);

line('Parent',handles.axes5,'XData',t,'YData',v);
line('Parent',handles.axes6,'XData',t,'YData',h);
line('Parent',handles.axes7,'XData',t,'YData',H2);
line('Parent',handles.axes8,'XData',t,'YData',curr_v);

set(handles.axes1,'YLim',[-90 20]);
set(handles.axes5,'YLim',[-90 20]);
set(handles.axes6,'YLim',[0 0.5]);
set(handles.axes7,'YLim',[0 0.04]);
set(handles.axes4,'YLim',[-1 3]);
set(handles.axes8,'YLim',[-1 3]);
xlabel(handles.axes4,'time (ms)');
xlabel(handles.axes8,'time (ms)');
ylabel(handles.axes1,'membrane potential (mV)');


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes wang_mod wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = wang_mod_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc','wang_mod.eps');
