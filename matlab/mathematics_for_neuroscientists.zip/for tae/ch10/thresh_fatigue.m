%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = thresh_fatigue(varargin)
% THRESH_FATIGUE M-file for thresh_fatigue.fig
%      THRESH_FATIGUE, by itself, creates a new THRESH_FATIGUE or raises the existing
%      singleton*.
%
%      H = THRESH_FATIGUE returns the handle to a new THRESH_FATIGUE or the handle to
%      the existing singleton*.
%
%      THRESH_FATIGUE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in THRESH_FATIGUE.M with the given input arguments.
%
%      THRESH_FATIGUE('Property','Value',...) creates a new THRESH_FATIGUE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before thresh_fatigue_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to thresh_fatigue_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help thresh_fatigue

% Last Modified by GUIDE v2.5 17-Dec-2008 14:33:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @thresh_fatigue_OpeningFcn, ...
                   'gui_OutputFcn',  @thresh_fatigue_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before thresh_fatigue is made visible.
function thresh_fatigue_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to thresh_fatigue (see VARARGIN)

% Choose default command line output for thresh_fatigue
handles.output = hObject;

%
%constant current injection
%

%integration time step in ms (0.1 ms)
dt = 0.1; 

%capacitance, nF
Cm = 2;

%membrane time constant
tau_v = 20; %ms

%threshold in mV
vm_thres0 = 8;

%increment in threshold for each spike in mV
thres_incr = 4;

%threshold recovery time constant ms
tau_t = 80; 

%1 second
t_v = 0:dt:350-dt;

%current vector nA
i_v = [zeros(size([0:dt:50-dt])) 2*ones(size([50:dt:300-dt])) zeros(size([300:dt:350-dt]))];

%membrane potential vector mV
vm_v = zeros(size(t_v));

%threshold values during simulations
thres_v = zeros(size(t_v));

%initializes to baseline threshold 
thres_v(1) = vm_thres0;

%spike vector
s_v = zeros(size(t_v));

%scale by dt to speed up computations
i_v_n = i_v*dt/Cm;

%membrane time constant: precompute values used in loop to save time
dtau_m1 = dt/tau_v;
m_fact = (1-dtau_m1);

%threshold time constant: calculations to speed up the simulations
dtau_t1 = dt/tau_t;
t_fact = 1- dtau_t1;
t0_fact = vm_thres0*dtau_t1;

%integrate with forward euler
for k = 2:length(t_v)
    %membrane potential evolution
    vm_v(k) = vm_v(k-1)*m_fact + i_v_n(k-1);
    
    %threshold evolution
    thres_v(k) = thres_v(k-1)*t_fact + t0_fact;
    
    if (vm_v(k) > thres_v(k))
        vm_v(k) = 0; %reset
        s_v(k) = 1; %register spike
        thres_v(k) = thres_v(k) + thres_incr; %increment threshold
    end;
    
end;

ind = find(s_v > 0.5);
t_spks = t_v(ind);

line('Parent',handles.axes2,'XData',t_v,'YData',vm_v);

for i =1:length(t_spks)
    line('Parent',handles.axes2,'XData',[t_v(ind(i)-1) t_v(ind(i)-1)],'YData',[vm_v(ind(i)-1) 50]);
end;

set(handles.axes2,'XLim',[0 350],'YLim',[0 50]);

%without threshold fatigue
vm_v2 = zeros(size(t_v));
s_v2 = zeros(size(t_v));

%integrate with forward euler
for k = 2:length(t_v)
    %membrane potential evolution
    vm_v2(k) = vm_v2(k-1)*m_fact + i_v_n(k-1);
        
    if (vm_v2(k) > vm_thres0)
        vm_v2(k) = 0; %reset
        s_v2(k) = 1; %register spike
    end;
    
end;

ind2 = find(s_v2 > 0.5);
t_spks2 = t_v(ind2);

line('Parent',handles.axes3,'XData',t_v,'YData',vm_v2);
ylabel(handles.axes3,'membrane potential (mV)');

for i =1:length(t_spks2)
    line('Parent',handles.axes3,'XData',[t_v(ind2(i)-1) t_v(ind2(i)-1)],'YData',[vm_v2(ind2(i)-1) 50]);
end;

set(handles.axes3,'XLim',[0 350],'YLim',[0 50]);

line('Parent',handles.axes4,'XData',t_v,'YData',i_v);
set(handles.axes4,'XLim',[0 350]);
xlabel(handles.axes4,'time (ms)');


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes thresh_fatigue wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = thresh_fatigue_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc','thresh_fatigue.eps');
