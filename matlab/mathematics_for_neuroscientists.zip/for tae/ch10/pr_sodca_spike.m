%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires: prsolve.m
%

function varargout = pr_sodca_spike(varargin)
% PR_SODCA_SPIKE M-file for pr_sodca_spike.fig
%      PR_SODCA_SPIKE, by itself, creates a new PR_SODCA_SPIKE or raises the existing
%      singleton*.
%
%      H = PR_SODCA_SPIKE returns the handle to a new PR_SODCA_SPIKE or the handle to
%      the existing singleton*.
%
%      PR_SODCA_SPIKE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PR_SODCA_SPIKE.M with the given input arguments.
%
%      PR_SODCA_SPIKE('Property','Value',...) creates a new PR_SODCA_SPIKE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pr_sodca_spike_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pr_sodca_spike_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pr_sodca_spike

% Last Modified by GUIDE v2.5 07-Jan-2009 12:47:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pr_sodca_spike_OpeningFcn, ...
                   'gui_OutputFcn',  @pr_sodca_spike_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pr_sodca_spike is made visible.
function pr_sodca_spike_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pr_sodca_spike (see VARARGIN)

% Choose default command line output for pr_sodca_spike
handles.output = hObject;

[t,y] = prsolve(100,[0 0.68 0]);

line('Parent',handles.axes1,'XData',t,'YData',y(:,1));
line('Parent',handles.axes1,'XData',t,'YData',y(:,2),'Color','r');
set(handles.axes1,'YLim',[-20 120]);
xlabel(handles.axes1,'time (ms)');
ylabel(handles.axes1,'membrane potential (mV)');


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pr_sodca_spike wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pr_sodca_spike_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','pr_sodca_spike.eps');
