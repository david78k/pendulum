%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
% fftexfine(N)   N = 128 for example
%
function fftexfine(N)

%usage: fftexfine(N) where N is the number of samples.

if ( ~exist('N') )
    disp('usage: ffexfine(N) where N is the number of samples');
    disp('       using N = 128 (default).');
    N = 128;
end;

T = 10;
dt = T/N;
t = 0:dt:T-dt;
utrue = t.^2.*(1-t).*(9-t).*(5-t).*(5.1-t).*(10-t).^2/3000;
noise = randn(1,N);
figure(1)
plot(t,utrue,'k');
udirty = utrue + noise;
hold on
plot(t,udirty,'r.')
hold off
axis tight 
box off

figure(2)
f = (0:N/2)/T;
udirtyhat = fft(udirty)/N;
plot(f,abs(udirtyhat(1:1+N/2)),'kx-')
axis tight
box off
xlabel('f  (Hz)','fontsize',14)
ylabel('|u_{dirty}hat|','fontsize',14)
