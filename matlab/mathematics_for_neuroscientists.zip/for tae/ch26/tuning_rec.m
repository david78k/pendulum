%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = tuning_rec(varargin)
% TUNING_REC M-file for tuning_rec.fig
%      TUNING_REC, by itself, creates a new TUNING_REC or raises the existing
%      singleton*.
%
%      H = TUNING_REC returns the handle to a new TUNING_REC or the handle to
%      the existing singleton*.
%
%      TUNING_REC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TUNING_REC.M with the given input arguments.
%
%      TUNING_REC('Property','Value',...) creates a new TUNING_REC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tuning_rec_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tuning_rec_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tuning_rec

% Last Modified by GUIDE v2.5 25-Mar-2009 22:35:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tuning_rec_OpeningFcn, ...
                   'gui_OutputFcn',  @tuning_rec_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tuning_rec is made visible.
function tuning_rec_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tuning_rec (see VARARGIN)

% Choose default command line output for tuning_rec
handles.output = hObject;

%peak firing rate 
pfr = 30; %in spk/s
vfr = 5; %variability in spk/s

%plot a tuning curve
dx = 10; %in deg
x = -180+dx:dx:180; %in deg
xr = x * (pi/180);

fr = pfr * cos(xr);

mfr = zeros(size(fr));
sfr = zeros(size(fr));

for i = 1:length(x)
    %draw a 100 random numbers
    fr_vals = randn(1,100)*vfr + fr(i);
    fr_vals = max(fr_vals,0);
    mfr(i) = mean(fr_vals);
    sfr(i) = std(fr_vals);
end;
    
line('Parent',handles.axes1,'XData',x,'YData',mfr, ...
    'Marker','o','MarkerFaceColor','k','MarkerSize',4);
for i = 1:length(x);
    line('Parent',handles.axes1,'XData',[x(i) x(i)],'YData',[mfr(i)-sfr(i) mfr(i)+sfr(i)]);
end;

set(handles.axes1,'XLim',[-110 110],'YLim',[0 40]);
xlabel(handles.axes1,'stimulus angle (deg)');
ylabel(handles.axes1,'firing rate (spk/s)');


%plot stimulus and reconstruction
n_rand = 10; %number of random samples

%orthonormal basis corresponding to phi1 and phi2
e1 = [1;0];
e2 = [0;1];

%use a stimulus at 45 deg
x = 45;
xr = x*(pi/180);

%stimulus vector
fr1 = pfr*cos(xr);
fr2 = pfr*sin(xr);
v = [fr1;fr2];

%generate n_rand random responses
rfr1 = randn(1,n_rand)*vfr + fr1;
rfr2 = randn(1,n_rand)*vfr + fr2;

%compute the corresponding vector estimates
fr_mat = e1*rfr1 + e2*rfr2;

line('Parent',handles.axes2,'XData',[0 v(1)],'YData',[0 v(2)],'Color','r');
for i = 1:n_rand
    line('Parent',handles.axes2,'XData',[0 rfr1(i)],'YData',[0 rfr2(i)]);
end;

set(handles.axes2,'XLim',[0 30],'YLim',[0 30]);
xlabel(handles.axes2,'firing rate (spk/s)');
ylabel(handles.axes2,'firing rate (spk/s)');

%compute the average mean square error between stimulus and reconstruction
n_rand = 100; %number of random samples

%use a range between 0 and 90 deg, since by symmetry the rest will be
%identical
x = -180+dx:dx:180; %in deg
xr = x * (pi/180);

rms_ang = zeros(size(x));
rms_errn = zeros(size(x));
se_errn = zeros(size(x));

for i=1:length(x)
    %stimulus vector
    fr1 = pfr*cos(xr(i));
    fr2 = pfr*sin(xr(i));
    v = [fr1;fr2];

    %generate n_rand random responses
    rfr1 = randn(1,n_rand)*vfr + fr1;
    rfr2 = randn(1,n_rand)*vfr + fr2;

    %compute the corresponding vector estimates
    fr_mat = e1*rfr1 + e2*rfr2;
    err_coord = fr_mat - repmat(v,[1 n_rand]);
    err_tot = sqrt(sum(err_coord.^2,1)); %distance between random sample and stimulus

    %root mean square error
    rms_err = mean(err_tot);
    std_err = std(err_tot);
    
    %normalize by vector length
    rms_errn(i) = rms_err/pfr;
    se_errn(i) = std_err/(pfr*sqrt(n_rand));
    
    %corresponding angle
    rms_ang(i) = atan(rms_err/pfr) * (180/pi);
end;

line('Parent',handles.axes3,'XData',x,'YData',rms_errn, ...
    'Marker','o','MarkerFaceColor','k','MarkerSize',4);
for i = 1:length(x)
    line('Parent',handles.axes3,'XData',[x(i) x(i)],'YData',[rms_errn(i)-se_errn(i) rms_errn(i)+se_errn(i)]);
end;
set(handles.axes3,'YLim',[0.15 0.25]);
xlabel(handles.axes3,'stimulus angle (deg)');
ylabel(handles.axes3,'relative RMS');

line('Parent',handles.axes4,'XData',x,'YData',rms_ang, ...
    'Marker','o','MarkerFaceColor','k','MarkerSize',4);
xlabel(handles.axes4,'stimulus angle (deg)');
ylabel(handles.axes4,'angular error (deg)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tuning_rec wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tuning_rec_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','tuning_rec.eps');

