%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = stdobs_plot(varargin)
% STDOBS_PLOT M-file for stdobs_plot.fig
%      STDOBS_PLOT, by itself, creates a new STDOBS_PLOT or raises the existing
%      singleton*.
%
%      H = STDOBS_PLOT returns the handle to a new STDOBS_PLOT or the handle to
%      the existing singleton*.
%
%      STDOBS_PLOT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STDOBS_PLOT.M with the given input arguments.
%
%      STDOBS_PLOT('Property','Value',...) creates a new STDOBS_PLOT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before stdobs_plot_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to stdobs_plot_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help stdobs_plot

% Last Modified by GUIDE v2.5 27-Jul-2009 21:55:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @stdobs_plot_OpeningFcn, ...
                   'gui_OutputFcn',  @stdobs_plot_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before stdobs_plot is made visible.
function stdobs_plot_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to stdobs_plot (see VARARGIN)

% Choose default command line output for stdobs_plot
handles.output = hObject;

stdobsy2 = load('stdcol_obs_y2');
line('Parent',handles.axes1,'XData',stdobsy2(:,1),'YData',stdobsy2(:,2),...
    'Marker','o','MarkerFaceColor','k','MarkerSize',3,'LineStyle','-','Color','k');
set(handles.axes1,'XLim',[360 800]);
set(handles.axes1,'XTick',[400:100:800]);
xlabel('wavelength (nm)');
ylabel('Spectral luminous efficiency, v(\lambda)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes stdobs_plot wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = stdobs_plot_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','stdobs_plot.eps');
