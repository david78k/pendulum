%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  the output mat file created by this m-file is scen_stat
%  which is used by scene_2d.m

%computes the power spectrum of  ten images from the 
%van Hateren data base along the horizontal and vertical
%dimension. Averages the corresponding 20 power spectra
%and fits them to a power law in log space
%saves the data is a file called scene_stat for plotting
i_max = 10;

%power spectra in linear units
p_lin = zeros(2*i_max,128);

%power spectra in log10 units
p_log = zeros(2*i_max,128);

disp('processing 10 images, this may take a while...');
for i = 1:i_max
    if ( i ~= 10 )
        im_str = ['images/imk0000' num2str(i) '.iml'];
    else
        im_str = ['images/imk000' num2str(i) '.iml'];
    end;
    
    info_str = sprintf('image %i',i);
    f1=fopen(im_str,'rb','ieee-be');
    
    w=1536;h=1024;
    buf=fread(f1,[w,h],'uint16');
    fclose(f1);
    
    %uncomment to plot each image
    %figure; 
    %colormap(gray);
    %imagesc(buf');

    %buf is 1536x1024 (width x height)
    %compute power spectrum along the y (vertical) axis

    a = buf(257:1536-256,:); %lines are horizontal dimension and columns vertical dimension

    %reshape takes elements columnwise, so we first transpose to get each
    %vertical image stripe as a column
    b_v = reshape(a',prod(size(a)),1);
    c_v = b_v - mean(b_v);
    
    %the parameters are: 1) the length of the window 256
    %2) overlap: 128
    %3) fft size 256
    %maximal two-sided frequency 60 (each pixel is 1 min of arc)
    [p_v,w_v] = pwelch(c_v,256,128,256,60,'twosided');
    
    %take only positive frequencies
    flog_v = log10(w_v(2:129));
    plog_v = log10(p_v(2:129));

    %linear fit to the data
    %flog_ve = [flog_v'; ones(1,128)]';
    %x = flog_ve\plog_v;
    
    b_h = reshape(a,prod(size(a)),1);
    c_h = b_h - mean(b_h);
    [p_h,w_h] = pwelch(c_h,256,128,256,60,'twosided');
    flog_h = log10(w_h(2:129));
    plog_h = log10(p_h(2:129));

    %linear fit to the data
    %flog_he = [flog_h'; ones(1,128)]';
    %y = flog_he\plog_h;
    
    %uncomment to plot individual power spectra and fits
    %figure;
    %plot(flog_v,plog_v);
    %hold on;
    %plot(flog_h,plog_h,'r');
    %plot(flog_v,flog_ve*x,'g');
    %plot(flog_h,flog_he*y,'y');
    
    %save data: one line for the vertical and one line for the horizontal 
    %spectrum
    p_log(2*(i-1) + 1,:) = plog_v';
    p_log(2*(i-1) + 2,:) = plog_h';
    p_lin(2*(i-1) + 1,:) = p_v(2:129)';
    p_lin(2*(i-1) + 1,:) = p_h(2:129)';
    
end;

p_mean = mean(p_log,1);
p_std = std(p_log,0,1);

p_lin_mean = mean(p_lin,1);

figure; h_m = plot(flog_v,p_mean,'c');
hold on; 
h_msm = plot(flog_v,p_mean-p_std,'r');
h_msp = plot(flog_v,p_mean+p_std,'b');

%linear fit
p_meant = p_mean';
flog_ve = [flog_v'; ones(1,128)]';
x = flog_ve\p_meant;
h_lf = plot(flog_v,flog_ve*x,'g');
xlabel('log_1_0(frequency)');
ylabel('log_1_0(luminance^2/Hz)');
legend([h_m h_msm h_msp h_lf],'mean','mean-std','mean+std','lin fit');

scene_stat.p_m = p_log;
scene_stat.p_mean = p_mean;
scene_stat.p_std = p_std;
scene_stat.w_v = w_v;
scene_stat.flog_v = flog_v;
scene_stat.flog_ve = flog_ve;
scene_stat.x = x;


scene_stat.p_lin = p_lin;
scene_stat.w_lin = w_v(2:129);
scene_stat.p_lin_mean = p_lin_mean;

%used in scene_2d.m
save('scen_stat','scene_stat');

