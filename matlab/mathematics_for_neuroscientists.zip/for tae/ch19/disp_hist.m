%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  the output mat file created by this m-file is scen_hist
%  which is used by scene_2d.m

%computes average luminance histograms of ten images from the 
%van Hateren data base in linear and log units 
i_max = 10;

%101 bins
bins_lin = -1200:62:5000;
bins_log = -0.5:0.045:4;

n_lin = zeros(i_max,length(bins_lin));
n_log = zeros(i_max,length(bins_log));

for i = 1:i_max
    if ( i ~= 10 )
        im_str = ['images/imk0000' num2str(i) '.iml'];
    else
        im_str = ['images/imk000' num2str(i) '.iml'];
    end;
    
    f1=fopen(im_str,'rb','ieee-be');
    
    w=1536;h=1024;
    buf=fread(f1,[w,h],'uint16');
    fclose(f1);
    
    %uncomment to plot each image
    %figure; 
    %colormap(gray);
    %imagesc(buf');

    %buf is 1536x1024 (width x height)
    %compute power spectrum along the y (vertical) axis

    a = buf(257:1536-256,:); %lines are horizontal dimension and columns vertical dimension

    %reshape takes elements columnwise, so we first transpose to get each
    %vertical image stripe as a column
    b_v = reshape(a',prod(size(a)),1);
    c_v = b_v - mean(b_v);
    
    n = hist(c_v,bins_lin);
    n_lin(i,:) = n;
    
    n = hist(log10(c_v),bins_log);
    n_log(i,:) = n;
    
end;

n_lin_mean = mean(n_lin,1);

n_log_mean = mean(n_log,1);

figure; bar(bins_lin,n_lin_mean);
xlabel('luminance (cd/m^2)');
ylabel('number of observations');

figure; bar(bins_log,n_log_mean);
xlabel('log_1_0(luminance)');
ylabel('number of observations');

scene_hist.bins_lin = bins_lin;
scene_hist.n_lin_mean = n_lin_mean;
scene_hist.bins_log = bins_log;
scene_hist.n_log_mean = n_log_mean;

%used in scene_2d.m
save('scen_hist','scene_hist');



