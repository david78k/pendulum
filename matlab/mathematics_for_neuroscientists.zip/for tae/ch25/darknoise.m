%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = darknoise(varargin)
% DARKNOISE M-file for darknoise.fig
%      DARKNOISE, by itself, creates a new DARKNOISE or raises the existing
%      singleton*.
%
%      H = DARKNOISE returns the handle to a new DARKNOISE or the handle to
%      the existing singleton*.
%
%      DARKNOISE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DARKNOISE.M with the given input arguments.
%
%      DARKNOISE('Property','Value',...) creates a new DARKNOISE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before darknoise_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to darknoise_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help darknoise

% Last Modified by GUIDE v2.5 28-Apr-2009 22:10:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @darknoise_OpeningFcn, ...
                   'gui_OutputFcn',  @darknoise_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before darknoise is made visible.
function darknoise_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to darknoise (see VARARGIN)

% Choose default command line output for darknoise
handles.output = hObject;

%this m-file reproduces the Barlow Fig. 2

%load second data set
load ss_dat2.txt

%log base 10 of the mean number of photons
x_hsp2s = log10(ss_dat2(:,1));

%convert to percents
y_hsp2s = ss_dat2(:,2)/100;

line('Parent',handles.axes1,'XData',x_hsp2s,'YData',y_hsp2s,...
    'Marker','x', 'LineStyle','none');

%compare with the Barlow model
x_hb = 1.3:0.01:2.7;
y_hb = p_c(x_hb,21,0.13,8.9);
 
line('Parent',handles.axes1,'XData',x_hb,'YData',y_hb,'Color','r');


%Barlow model and fig. 1 
x_hb1 = 1.3:0.01:2.3;
y_hb1 = p_c(x_hb1,19,0.13,9.8);
 
%note: we use 9.8 instead of 8.9 for the dark noise since it obviously 
%works much better with the data. 

line('Parent',handles.axes2,'XData',x_hb1,'YData',y_hb1,'Color','r');

%Barlow model and fig. 1 
x_hb2 = 1.3:0.01:2.3;
y_hb2 = p_c(x_hb2,17,0.13,9.8);
 
line('Parent',handles.axes2,'XData',x_hb2,'YData',y_hb2,'Color','k');

%coordinates measured in points, relative to (1.5 0.2)
%0.2 in x direction is 28.88 pts
%0.2 in y direction is 28.58 pts
cf_x = 0.2/28.88;
cf_y = 0.2/28.58;

ptsx = [ 18.16; 38.1; 61.62; 82.16; 105.38 ];
ptsy = [ -7.74; 9.82; 54.48; 97.64; 107.17 ];

ptsx_c = 1.5 + ptsx*cf_x;
ptsy_c = 0.2 + ptsy*cf_y;

line('Parent',handles.axes2,'XData',ptsx_c,'YData',ptsy_c,...
    'LineStyle','none','Marker','x');
set(handles.axes2,'XLim',[1.3 2.3]);

ptsy2 = [ 12.21; 44.06; 83.65; 103.89; 111.04];
ptsy2_c = 0.2 + ptsy2*cf_y;
line('Parent',handles.axes2,'XData',ptsx_c,'YData',ptsy2_c,...
    'LineStyle','none','Marker','+');

xlabel(handles.axes1,'log10 nphotons');
ylabel(handles.axes1,'detection probability');


% Update handles structure
guidata(hObject, handles);


function y = p_c(x,c,alpha,d_p)
%
% function y = p_c(x, c, alpha, d_p)
%  
% cumulative poisson function
% for photon counts
%  
% x is the log10 photon count at the retina
% alpha is the absorption yield factor
% c is the threshold for seeing 
% d_p is the dark photon number
  
%convert back x to linear space
xl = 10.^x;

%corresponding poisson parameter

p_p = alpha*xl + d_p;

y = 1 - poisscdf(c,p_p);
% UIWAIT makes darknoise wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = darknoise_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','darknoise.eps');


